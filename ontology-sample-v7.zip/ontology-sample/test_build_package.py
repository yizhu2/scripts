import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile

from build_package import FILES, build


class PackageTests(unittest.TestCase):
    def test_runtime_has_no_sdk_download_or_serializer_dependency(self):
        folder = Path(__file__).resolve().parent
        for name in FILES:
            if name.startswith("test_") or not name.endswith((".py", ".ps1")):
                continue
            text = (folder / name).read_text(encoding="utf-8-sig")
            for dependency in ("pkgs.dev.azure.com", "499b84ac-1321-427f-aa17-267ca6975798",
                               "Microsoft.AnalysisServices.Core.dll", "ontology_tmdl.ps1",
                               "sdk_bootstrap", "--sdk-directory", "SdkDirectory"):
                with self.subTest(file=name, dependency=dependency):
                    self.assertNotIn(dependency, text)

    def test_archive_contains_only_allowlisted_files_and_matching_hashes(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            for name in FILES:
                (folder / name).write_text(name, encoding="utf-8")
            (folder / "secret.token").write_text("not included", encoding="utf-8")
            (folder / "sources.manifest.json").write_text("not included", encoding="utf-8")
            (folder / "sdk.dll").write_bytes(b"not included")
            output = folder / "package.zip"
            digest = build(output, folder)
            self.assertEqual(digest, hashlib.sha256(output.read_bytes()).hexdigest())
            with ZipFile(output) as archive:
                names = set(archive.namelist())
                self.assertEqual(names, {"ontology-sample/" + name for name in (*FILES, "PACKAGE.json")})
                manifest = json.loads(archive.read("ontology-sample/PACKAGE.json"))
                for name, expected_hash in manifest["files"].items():
                    self.assertEqual(hashlib.sha256(archive.read("ontology-sample/" + name)).hexdigest(),
                                     expected_hash)
                self.assertFalse(manifest["sdkBinariesIncluded"])
                self.assertFalse(manifest["sdkRequired"])
                self.assertFalse(manifest["internalFeedAccessRequired"])
                self.assertEqual(manifest["packageVersion"], 7)
                self.assertNotIn("ontology-sample/sdk_bootstrap.py", names)
                self.assertNotIn("ontology-sample/ontology_tmdl.ps1", names)
            with self.assertRaises(FileExistsError):
                build(output, folder)

    def test_missing_input_does_not_leave_a_partial_zip(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            output = folder / "package.zip"
            with self.assertRaises(FileNotFoundError):
                build(output, folder)
            self.assertFalse(output.exists())


if __name__ == "__main__":
    unittest.main()
