"""Create and verify a fresh Daily Fabric workspace with related sample sources."""

from __future__ import annotations

import argparse
import base64
import importlib
import json
import logging
import re
import struct
import time
from contextlib import closing
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from urllib.parse import urljoin, urlsplit
from uuid import UUID

LOG = logging.getLogger("ontology-sample")
PBI_SCOPE = "https://analysis.windows.net/powerbi/api/.default"
STORAGE_SCOPE = "https://storage.azure.com/.default"
SQL_SCOPE = "https://database.windows.net/.default"
COLLECTIONS = {
    "Eventhouse": "eventhouses",
    "KQLDatabase": "kqlDatabases",
    "Lakehouse": "lakehouses",
    "MirroredDatabase": "mirroredDatabases",
    "SemanticModel": "semanticModels",
    "SQLDatabase": "sqlDatabases",
    "Warehouse": "warehouses",
}


@dataclass(frozen=True)
class Table:
    name: str
    columns: tuple[tuple[str, str], ...]
    rows: tuple[tuple, ...]

    @property
    def key(self):
        return self.columns[0][0]

    def records(self):
        return [dict(zip((c[0] for c in self.columns), row)) for row in self.rows]


def sample_tables():
    start = datetime(2026, 1, 1)
    return (
        Table("Plants", (("PlantId", "string"), ("Name", "string"), ("City", "string")),
              (("P01", "North Plant", "Seattle"), ("P02", "South Plant", "Austin"),
               ("P03", "East Plant", "Boston"))),
        Table("Assets", (("AssetId", "string"), ("PlantId", "string"),
                         ("Name", "string"), ("AssetType", "string")),
              tuple((f"A{i:03}", f"P{(i - 1) // 4 + 1:02}", f"Pump {i:02}", "Pump")
                    for i in range(1, 13))),
        Table("Readings", (("ReadingId", "string"), ("AssetId", "string"),
                           ("ObservedAt", "datetime"), ("TemperatureC", "double")),
              tuple((f"R{(i - 1) * 10 + j + 1:04}", f"A{i:03}",
                     start + timedelta(minutes=j * 5), round(20 + i + j * 0.1, 1))
                    for i in range(1, 13) for j in range(10))),
    )


def definition_part(path, value):
    text = json.dumps(value, separators=(",", ":"))
    return {"path": path, "payloadType": "InlineBase64",
            "payload": base64.b64encode(text.encode("utf-8")).decode("ascii")}


def mirror_definition():
    return {"parts": [definition_part("mirroring.json", {"properties": {
        "source": {"type": "GenericMirror", "typeProperties": {}},
        "target": {"type": "MountedRelationalDatabase",
                   "typeProperties": {"defaultSchema": "dbo", "format": "Delta"}},
    }})]}


def m_literal(value):
    if isinstance(value, datetime):
        return f"#datetime({value.year},{value.month},{value.day},{value.hour},{value.minute},{value.second})"
    if isinstance(value, str):
        return '"' + value.replace("#", "#(#)").replace('"', '""') + '"'
    return repr(value)


def semantic_definition(tables):
    m_types = {"string": "text", "datetime": "datetime", "double": "number"}
    model_tables = []
    for table in tables:
        fields = ", ".join(f"{name} = {m_types[kind]}" for name, kind in table.columns)
        rows = ",".join("{" + ",".join(m_literal(v) for v in row) + "}" for row in table.rows)
        model_tables.append({
            "name": table.name,
            "columns": [{"name": name, "dataType": "dateTime" if kind == "datetime" else kind,
                         "sourceColumn": name} for name, kind in table.columns],
            "partitions": [{"name": table.name, "mode": "import", "source": {
                "type": "m", "expression": f"#table(type table [{fields}], {{{rows}}})"}}],
        })
    relationships = [
        {"name": "Assets_Plants", "fromTable": "Assets", "fromColumn": "PlantId",
         "toTable": "Plants", "toColumn": "PlantId"},
        {"name": "Readings_Assets", "fromTable": "Readings", "fromColumn": "AssetId",
         "toTable": "Assets", "toColumn": "AssetId"},
    ]
    for relationship in relationships:
        relationship.update(fromCardinality="many", toCardinality="one",
                            crossFilteringBehavior="oneDirection")
    model = {"compatibilityLevel": 1604, "model": {
        "culture": "en-US", "defaultPowerBIDataSourceVersion": "powerBI_V3",
        "tables": model_tables, "relationships": relationships,
    }}
    return {"parts": [definition_part("model.bim", model),
                      definition_part("definition.pbism", {"version": "1.0", "settings": {}})]}


def parquet_bytes(table):
    import pyarrow as pa
    import pyarrow.parquet as pq

    # UTC-adjusted Parquet avoids timestamp_ntz, which SQL analytics endpoints omit.
    types = {"string": pa.string(), "datetime": pa.timestamp("us", tz="UTC"), "double": pa.float64()}
    schema = pa.schema([(name, types[kind]) for name, kind in table.columns])
    sink = pa.BufferOutputStream()
    pq.write_table(pa.Table.from_pylist(table.records(), schema=schema), sink)
    return sink.getvalue().to_pybytes()


def kql_seed(table):
    def literal(value):
        if isinstance(value, datetime):
            return f"datetime({value.isoformat()}Z)"
        return json.dumps(value)

    schema = ",".join(f"{name}:{'real' if kind == 'double' else kind}" for name, kind in table.columns)
    values = ",".join(literal(value) for row in table.rows for value in row)
    return f".set {table.name} <| datatable({schema})[{values}]"


def kql_tables(body):
    if body.get("error") or body.get("Exceptions"):
        raise RuntimeError(f"KQL failure: {json.dumps(body)}")
    tables = body.get("Tables", [])
    if not tables:
        raise RuntimeError("KQL response contains no tables")
    for result in tables:
        if result.get("TableName") == "QueryStatus":
            names = [c["ColumnName"] for c in result["Columns"]]
            for row in result["Rows"]:
                status = dict(zip(names, row))
                if int(status["Severity"]) <= 2:
                    raise RuntimeError(f"KQL partial query failure: {status}")
    return tables


def normalized_rows(table, records):
    def normalize(value, kind):
        if kind == "datetime":
            if isinstance(value, str):
                value = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if value.tzinfo:
                value = value.astimezone(timezone.utc).replace(tzinfo=None)
            return value.isoformat()
        if kind == "double":
            return round(float(value), 6)
        return value

    return sorted(tuple(normalize(row[name], kind) for name, kind in table.columns)
                  for row in records)


def assert_rows(table, records):
    if normalized_rows(table, records) != normalized_rows(table, table.records()):
        raise ValueError(f"{table.name}: expected {len(table.rows)} matching rows; "
                         f"received {len(records)} rows with different keys or values")


def https_url(value):
    parsed = urlsplit(value)
    if (parsed.scheme != "https" or not parsed.hostname or parsed.username
            or parsed.password or parsed.query or parsed.fragment):
        raise ValueError("Endpoints must be HTTPS URLs without credentials, query, or fragment")
    return value.rstrip("/")


def same_origin_url(base, location):
    target = https_url(urljoin(base + "/", location))
    if urlsplit(target).netloc.lower() != urlsplit(base).netloc.lower():
        raise RuntimeError(f"Refusing cross-host operation URL {target}. "
                           "Configure the correct Daily/Private Link API endpoint; no public fallback.")
    return target


def retry_delay(response, default=5):
    value = response.headers.get("Retry-After")
    if value is None:
        return default
    try:
        return max(0, float(value))
    except ValueError:
        return max(0, (parsedate_to_datetime(value) - datetime.now(timezone.utc)).total_seconds())


class Api:
    def __init__(self, base, scope, credential, timeout, operation_callback=None, *, auth_scheme="Bearer"):
        import requests

        self.base = https_url(base)
        self.scope = scope
        self.credential = credential
        self.timeout = timeout
        self.session = requests.Session()
        self.operation_callback = operation_callback
        if auth_scheme not in ("Bearer", "MwcToken"):
            raise ValueError("Unsupported authorization scheme")
        self.auth_scheme = auth_scheme

    def close(self):
        self.session.close()

    def request(self, method, path, body=None, *, params=None, request_timeout=None):
        url = same_origin_url(self.base, path)
        deadline = time.monotonic() + self.timeout
        for attempt in range(6):
            token = self.credential.get_token(self.scope).token
            response = self.session.request(
                method, url, json=body, headers={"Authorization": f"{self.auth_scheme} {token}"},
                timeout=request_timeout if request_timeout is not None else min(60, self.timeout),
                allow_redirects=False, params=params)
            # Do not replay an ambiguous POST: it might have created an item or ingested rows.
            transient = response.status_code == 429 or (
                method == "GET" and response.status_code in (502, 503, 504))
            if transient and attempt < 5:
                delay = retry_delay(response, 2 ** attempt)
                if time.monotonic() + delay >= deadline:
                    raise TimeoutError(f"{method} {url}: retry deadline exceeded")
                LOG.warning("%s %s: HTTP %s; retry in %.1fs; response=%s",
                            method, url, response.status_code, delay, response.text[:1500])
                time.sleep(delay)
                continue
            if not 200 <= response.status_code < 300:
                raise RuntimeError(f"{method} {url}: HTTP {response.status_code}: {response.text[:1500]}")
            return response
        raise RuntimeError("HTTP retry budget exhausted")

    def json(self, method, path, body=None, *, params=None, request_timeout=None):
        response = self.request(method, path, body, params=params, request_timeout=request_timeout)
        return response.json() if response.content else {}

    def mutate(self, path, body=None, *, result_required=True, params=None):
        response = self.request("POST", path, body, params=params)
        if response.status_code != 202:
            return response.json() if response.content else {}
        location = response.headers.get("Location")
        if not location:
            raise RuntimeError("Accepted operation has no Location; inspect the workspace before retrying")
        operation = same_origin_url(self.base, location)
        if self.operation_callback:
            self.operation_callback(operation)
        deadline = time.monotonic() + self.timeout
        while True:
            delay = retry_delay(response)
            if time.monotonic() + delay >= deadline:
                raise TimeoutError(f"Operation still pending: {operation}")
            time.sleep(delay)
            response = self.request("GET", operation)
            state = response.json()
            status = state.get("status")
            LOG.info("Provisioning operation status: %s (percentComplete=%s)",
                     status, state.get("percentComplete", "not reported"))
            if status == "Succeeded":
                if not result_required:
                    return {}
                result = response.headers.get("Location") or operation.rstrip("/") + "/result"
                return self.json("GET", result)
            if status in ("Failed", "Cancelled", "Canceled"):
                raise RuntimeError(f"Operation {operation} failed: {json.dumps(state)}")
            if status not in ("NotStarted", "Running"):
                raise RuntimeError(f"Unexpected operation status: {status!r} at {operation}")


class Manifest:
    def __init__(self, path, plan):
        self.path = Path(path)
        self.data = {**plan, "status": "running", "items": {}, "verified": {}}
        # Exclusive creation prevents an accidental rerun from replaying mirror INSERT files.
        with self.path.open("x", encoding="utf-8") as stream:
            json.dump(self.data, stream, indent=2)

    def save(self):
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_text(json.dumps(self.data, indent=2), encoding="utf-8")
        temporary.replace(self.path)

    def step(self, name):
        LOG.info("%s", name)
        self.data["step"] = name
        self.data.pop("pendingOperation", None)
        self.save()

    def operation(self, url):
        self.data["pendingOperation"] = url
        self.save()


def wait_for(check, timeout, description):
    deadline = time.monotonic() + timeout
    while True:
        result = check()
        if result:
            return result
        if time.monotonic() >= deadline:
            raise TimeoutError(f"Timed out waiting for {description}")
        LOG.info("Waiting for %s", description)
        time.sleep(min(10, max(0, deadline - time.monotonic())))


class Provisioner:
    def __init__(self, args, credential, manifest):
        self.args = args
        self.credential = credential
        self.manifest = manifest
        self.tables = sample_tables()
        self.api = Api(args.fabric_api, PBI_SCOPE, credential, args.timeout, manifest.operation)
        self.pbi = Api(args.powerbi_api, PBI_SCOPE, credential, args.timeout)
        self.workspace = None

    def close(self):
        self.api.close()
        self.pbi.close()

    def path(self, suffix):
        return f"{self.args.fabric_api}/workspaces/{self.workspace}/{suffix}"

    def create(self, kind, **extra):
        self.manifest.step(f"Creating {kind}")
        body = {"displayName": f"{self.args.prefix}_{kind}", **extra}
        collection = COLLECTIONS[kind]
        if kind == "SemanticModel":
            collection = "items"
            body["type"] = kind
        item = self.api.mutate(self.path(collection), body)
        if not item.get("id"):
            raise RuntimeError(f"{kind} creation returned no id")
        self.manifest.data["items"][kind] = {
            "id": item["id"], "displayName": body["displayName"],
        }
        self.manifest.save()
        return self.manifest.data["items"][kind]

    def item_path(self, kind):
        return self.path(f"{COLLECTIONS[kind]}/{self.manifest.data['items'][kind]['id']}")

    def properties(self, kind, ready):
        def check():
            properties = self.api.json("GET", self.item_path(kind)).get("properties", {})
            endpoint = properties.get("sqlEndpointProperties", {})
            if endpoint.get("provisioningStatus") == "Failed":
                raise RuntimeError(f"{kind} SQL endpoint provisioning failed: {endpoint}")
            return properties if ready(properties) else None
        return wait_for(check, self.args.timeout, f"{kind} endpoint provisioning")

    def verify(self, kind, action):
        self.manifest.step(f"Verifying {kind}")
        for table in self.tables:
            action(table)
        self.manifest.data["verified"][kind] = {t.name: len(t.rows) for t in self.tables}
        self.manifest.save()

    def kql_client(self):
        properties = self.properties("KQLDatabase", lambda p: p.get("queryServiceUri"))
        endpoint = self.args.kql_endpoint or properties["queryServiceUri"]
        return Api(endpoint, self.args.kusto_scope, self.credential, self.args.timeout)

    def kql_query(self, api, command, *, management=False):
        body = api.json("POST", api.base + ("/v1/rest/mgmt" if management else "/v1/rest/query"),
                        {"db": self.manifest.data["items"]["KQLDatabase"]["id"], "csl": command},
                        request_timeout=(30, min(self.args.kql_request_timeout, self.args.timeout)))
        return kql_tables(body)

    def seed_kql(self):
        import requests

        with closing(self.kql_client()) as api:
            self.manifest.step("Waiting for KQL query readiness before ingestion")
            def ready():
                try:
                    result = self.kql_query(api, "print Ready = 1")
                except requests.Timeout as error:
                    LOG.warning("KQL readiness probe timed out; no ingestion submitted yet: %s", error)
                    return False
                if not result or result[0]["Rows"] != [[1]]:
                    raise RuntimeError("Unexpected KQL readiness probe result")
                return True
            wait_for(ready, self.args.timeout, "KQL query readiness before ingestion")
            for table in self.tables:
                self.manifest.step(f"Loading Eventhouse / KQLDatabase table {table.name}")
                try:
                    self.kql_query(api, kql_seed(table), management=True)
                except requests.Timeout:
                    LOG.error("KQL ingestion timed out for %s; outcome is unknown. The write was NOT replayed. "
                              "Inspect %s and the existing database before retrying.", table.name, self.manifest.path)
                    raise

    def verify_kql(self):
        import requests

        with closing(self.kql_client()) as api:
            def verify(table):
                def check():
                    try:
                        results = self.kql_query(api, f"{table.name} | project " + ",".join(c[0] for c in table.columns))
                    except requests.Timeout as error:
                        LOG.warning("KQL read timed out for %s; retrying only the verification query: %s",
                                    table.name, error)
                        return False
                    if not results:
                        raise RuntimeError("KQL query returned no result tables")
                    result = results[0]
                    names = [c["ColumnName"] for c in result["Columns"]]
                    assert_rows(table, [dict(zip(names, row)) for row in result["Rows"]])
                    return True
                wait_for(check, self.args.timeout, f"KQLDatabase.{table.name} exact sample rows")
            self.verify("KQLDatabase", verify)
            self.manifest.data["verified"]["Eventhouse"] = {
                "viaKqlDatabaseId": self.manifest.data["items"]["KQLDatabase"]["id"]}
            self.manifest.save()

    def upload(self, item_id, relative_path, data, *, publish=False):
        from azure.core import MatchConditions
        from azure.core.exceptions import ResourceExistsError
        from azure.storage.filedatalake import DataLakeServiceClient

        endpoint = self.args.onelake_url.replace("{workspaceId}", self.workspace)
        with DataLakeServiceClient(https_url(endpoint), credential=self.credential,
                                   connection_timeout=30, read_timeout=60) as service:
            filesystem = service.get_file_system_client(self.workspace)
            parent, name = relative_path.rsplit("/", 1)
            segments = parent.split("/")
            for index in range(2, len(segments) + 1):
                directory = filesystem.get_directory_client(f"{item_id}/{'/'.join(segments[:index])}")
                try:
                    directory.create_directory()
                except ResourceExistsError:
                    LOG.debug("Upload directory already exists: %s", directory.path_name)
            directory = filesystem.get_directory_client(f"{item_id}/{parent}")
            file = directory.get_file_client("_" + name if publish else name)
            # The SDK creates a file only with overwrite=True; IfMissing keeps creation exclusive.
            file.upload_data(data, overwrite=True, match_condition=MatchConditions.IfMissing)
            if publish:
                file.rename_file(f"{self.workspace}/{item_id}/{relative_path}")

    def seed_lakehouse(self):
        self.manifest.step("Loading Lakehouse")
        item = self.manifest.data["items"]["Lakehouse"]
        for table in self.tables:
            path = f"Files/OntologySample/{table.name}.parquet"
            self.upload(item["id"], path, parquet_bytes(table))
            self.api.mutate(self.item_path("Lakehouse") + f"/tables/{table.name}/load", {
                "relativePath": path, "pathType": "File", "mode": "Overwrite",
                "formatOptions": {"format": "Parquet"},
            }, result_required=False)

    def seed_mirror(self):
        self.manifest.step("Loading MirroredDatabase")
        base = self.item_path("MirroredDatabase")
        item = self.manifest.data["items"]["MirroredDatabase"]

        def initialized():
            state = self.api.json("POST", base + "/getMirroringStatus")
            status = state.get("status")
            if state.get("error") or status in ("Failed", "Error"):
                raise RuntimeError(f"Mirroring initialization failed: {json.dumps(state)}")
            return status if status in ("Initialized", "Stopped", "Running") else None

        status = wait_for(initialized, self.args.timeout, "mirror initialization")
        for table in self.tables:
            folder = f"Files/LandingZone/dbo.schema/{table.name}"
            self.upload(item["id"], folder + "/_metadata.json",
                        json.dumps({"keyColumns": [table.key]}).encode("utf-8"))
            self.upload(item["id"], folder + "/00000000000000000001.parquet",
                        parquet_bytes(table), publish=True)
        if status != "Running":
            self.api.json("POST", base + "/startMirroring")

    def sql_target(self, kind):
        if kind == "SQLDatabase":
            properties = self.properties(kind, lambda p: p.get("serverFqdn") and p.get("databaseName"))
            server, catalog = properties["serverFqdn"], properties["databaseName"]
        elif kind == "Warehouse":
            properties = self.properties(kind, lambda p: p.get("connectionString"))
            server = properties["connectionString"]
            catalog = self.manifest.data["items"][kind]["displayName"]
        else:
            properties = self.properties(kind, lambda p: (
                p.get("sqlEndpointProperties", {}).get("provisioningStatus") == "Success"))
            server = properties["sqlEndpointProperties"]["connectionString"]
            catalog = self.manifest.data["items"][kind]["displayName"]
        override = self.args.sql_endpoints.get(kind, {})
        return override.get("server", server), override.get("catalog", catalog)

    def connect_sql(self, server, catalog):
        import pyodbc

        token = self.credential.get_token(SQL_SCOPE).token.encode("utf-16-le")
        attribute = struct.pack("<I", len(token)) + token
        # Brace quoting prevents connection-property injection from names or endpoint overrides.
        def quoted(value):
            return "{" + value.replace("}", "}}") + "}"
        connection = (f"DRIVER={quoted(self.args.odbc_driver)};SERVER={quoted(server)};"
                      f"DATABASE={quoted(catalog)};Encrypt=yes;TrustServerCertificate=no;")
        result = pyodbc.connect(connection, attrs_before={1256: attribute}, timeout=30)
        result.timeout = 60
        return result

    def sql_retryable(self, error):
        state = str(error.args[0]) if error.args else ""
        # Database transition (952) can be wrapped in SQLSTATE 28000 alongside login error 18456.
        # Read checks reconnect on each attempt, also ending the failed snapshot after metadata conflict 3961.
        return (state.startswith("08") or state in ("HYT00", "HYT01", "42S02")
                or any(f"({code})" in str(error) for code in (4060, 952, 3961)))

    def sql_ready(self, server, catalog):
        import pyodbc

        def check():
            try:
                with closing(self.connect_sql(server, catalog)) as connection:
                    connection.cursor().execute("SELECT 1").fetchone()
                return True
            except pyodbc.Error as error:
                if not self.sql_retryable(error):
                    raise
                LOG.warning("SQL endpoint not ready: %s", error)
                return False
        wait_for(check, self.args.timeout, f"SQL connectivity to {catalog}")

    def seed_sql(self, kind):
        self.manifest.step(f"Loading {kind}")
        server, catalog = self.sql_target(kind)
        self.sql_ready(server, catalog)
        types = {"string": "varchar(100)", "datetime": "datetime2(6)", "double": "float"}
        with closing(self.connect_sql(server, catalog)) as connection:
            cursor = connection.cursor()
            for table in self.tables:
                fields = ",".join(f"[{name}] {types[kind]} NOT NULL" for name, kind in table.columns)
                cursor.execute(f"CREATE TABLE [dbo].[{table.name}] ({fields})")
                placeholders = ",".join("?" for _ in table.columns)
                cursor.executemany(f"INSERT INTO [dbo].[{table.name}] VALUES ({placeholders})", table.rows)
            connection.commit()

    def refresh_sql_metadata(self, kind):
        properties = self.properties(kind, lambda p: (
            p.get("sqlEndpointProperties", {}).get("provisioningStatus") == "Success"))
        endpoint_id = properties["sqlEndpointProperties"]["id"]
        LOG.info("Refreshing %s SQL metadata without recreating tables", kind)
        result = self.api.mutate(
            self.path(f"sqlEndpoints/{endpoint_id}/refreshMetadata"), {"recreateTables": False})
        failures = [entry for entry in result["value"] if entry.get("status") != "Success"]
        if failures:
            raise RuntimeError(f"{kind} SQL metadata refresh failed: {json.dumps(failures)}")

    def verify_sql(self, kind, *, asynchronous=False, refresh_before_read=True):
        import pyodbc

        server, catalog = self.sql_target(kind)
        if asynchronous and refresh_before_read:
            self.refresh_sql_metadata(kind)
        last_refresh = time.monotonic()
        self.sql_ready(server, catalog)

        def refresh_if_due():
            nonlocal last_refresh
            if time.monotonic() - last_refresh >= 60:
                self.refresh_sql_metadata(kind)
                last_refresh = time.monotonic()

        def verify(table):
            def check():
                try:
                    with closing(self.connect_sql(server, catalog)) as connection:
                        columns = ",".join(f"[{name}]" for name, _ in table.columns)
                        rows = connection.cursor().execute(
                            f"SELECT {columns} FROM [dbo].[{table.name}]").fetchall()
                    records = [dict(zip((c[0] for c in table.columns), row)) for row in rows]
                    assert_rows(table, records)
                    return True
                except pyodbc.Error as error:
                    if not asynchronous or not self.sql_retryable(error):
                        raise
                    LOG.warning("%s SQL table not ready: %s", kind, error)
                    if str(error.args[0]) == "42S02":
                        refresh_if_due()
                    return False
                except ValueError as error:
                    if not asynchronous:
                        raise
                    LOG.warning("%s replication pending: %s", kind, error)
                    refresh_if_due()
                    return False
            wait_for(check, self.args.timeout, f"{kind}.{table.name} exact sample rows")
        self.verify(kind, verify)

    def seed_semantic(self):
        self.manifest.step("Refreshing SemanticModel")
        item = self.manifest.data["items"]["SemanticModel"]
        base = (f"{self.args.powerbi_api}/v1.0/myorg/groups/{self.workspace}"
                f"/datasets/{item['id']}")
        response = self.pbi.request("POST", base + "/refreshes", {
            "type": "full", "commitMode": "transactional"})
        location = response.headers.get("Location")
        if not location:
            raise RuntimeError("Refresh returned no Location; cannot identify this refresh safely")
        location = same_origin_url(self.args.powerbi_api, location)
        self.manifest.operation(location)

        def refreshed():
            state = self.pbi.json("GET", location)
            if state.get("status") == "Completed":
                return True
            if state.get("status") in ("Failed", "Cancelled", "Disabled"):
                raise RuntimeError(f"Semantic model refresh failed: {json.dumps(state)}")
            return False
        wait_for(refreshed, self.args.timeout, "semantic model refresh")

    def verify_semantic(self):
        item = self.manifest.data["items"]["SemanticModel"]
        base = (f"{self.args.powerbi_api}/v1.0/myorg/groups/{self.workspace}"
                f"/datasets/{item['id']}")

        def verify(table):
            projection = ",".join(f'"{name}",{table.name}[{name}]' for name, _ in table.columns)
            result = self.pbi.json("POST", base + "/executeQueries", {
                "queries": [{"query": f"EVALUATE SELECTCOLUMNS({table.name},{projection})"}],
                "serializerSettings": {"includeNulls": True},
            })
            if result.get("error") or any(r.get("error") for r in result.get("results", [])):
                raise RuntimeError(f"Semantic query failed: {json.dumps(result)}")
            results = result["results"][0]["tables"]
            if len(results) != 1 or results[0].get("error"):
                raise RuntimeError(f"Unexpected semantic query result: {json.dumps(result)}")
            records = [{key.removeprefix("[").removesuffix("]"): value for key, value in row.items()}
                       for row in results[0]["rows"]]
            assert_rows(table, records)
        self.verify("SemanticModel", verify)

    def run(self):
        if self.args.workspace_id:
            self.manifest.step("Checking existing empty workspace")
            base = self.args.fabric_api + "/workspaces/" + self.args.workspace_id
            workspace = self.api.json("GET", base)
            if (workspace.get("capacityId", "").lower() != self.args.capacity_id.lower()
                    or workspace.get("displayName") != self.args.workspace_name):
                raise RuntimeError("Existing workspace must match the supplied capacity and display name")
            items = self.api.json("GET", base + "/items")
            if items.get("value") != [] or items.get("continuationToken") or items.get("continuationUri"):
                raise RuntimeError("Existing workspace is not empty; refusing to modify it")
        else:
            self.manifest.step("Creating workspace on the supplied capacity")
            workspace = self.api.mutate(self.args.fabric_api + "/workspaces", {
                "displayName": self.args.workspace_name, "capacityId": self.args.capacity_id,
                "description": "Synthetic ontology source fixtures; created by ontology-sample",
            })
        self.workspace = workspace["id"]
        self.manifest.data["workspaceId"] = self.workspace
        self.manifest.save()
        skipped = ["Eventhouse", "KQLDatabase"] if self.args.skip_eventhouse_kql else []
        self.manifest.data["skipped"] = skipped
        self.manifest.save()
        if skipped:
            LOG.warning("Explicitly skipping Eventhouse and KQLDatabase; they will not be validated")
        else:
            self.create("Eventhouse")
            self.create("KQLDatabase", creationPayload={
                "databaseType": "ReadWrite",
                "parentEventhouseItemId": self.manifest.data["items"]["Eventhouse"]["id"],
            })
        self.create("Lakehouse")
        self.create("MirroredDatabase", definition=mirror_definition())
        for kind in ("SQLDatabase", "Warehouse"):
            self.create(kind)
        self.create("SemanticModel", definition=semantic_definition(self.tables))
        self.manifest.data["deferredValidation"] = {"SemanticModel": ["refresh", "sampleRows"]}
        self.manifest.step("SemanticModel created; refresh and sample-row queries deferred")

        self.seed_lakehouse()
        self.seed_mirror()
        for kind in ("SQLDatabase", "Warehouse"):
            self.seed_sql(kind)
        if not skipped:
            self.seed_kql()
        self.manifest.data["sourceLoadsCompleted"] = True
        self.manifest.step("Non-semantic source loads completed; preparing SQL metadata before verification")
        for kind in ("Lakehouse", "MirroredDatabase"):
            self.manifest.step(f"Refreshing {kind} SQL metadata before the settling period")
            self.refresh_sql_metadata(kind)
        self.manifest.step(f"Waiting {self.args.settle_seconds} seconds before reading sample data")
        if self.args.settle_seconds:
            time.sleep(self.args.settle_seconds)
        if not skipped:
            self.verify_kql()
        for kind in ("Lakehouse", "MirroredDatabase"):
            self.verify_sql(kind, asynchronous=True, refresh_before_read=False)
        for kind in ("SQLDatabase", "Warehouse"):
            self.verify_sql(kind)
        missing = set(COLLECTIONS) - set(skipped) - {"SemanticModel"} - self.manifest.data["verified"].keys()
        if missing:
            raise RuntimeError(f"Sources missing verification: {', '.join(sorted(missing))}")
        self.manifest.data["status"] = "succeeded"
        self.manifest.step("Requested source types created; non-semantic data verified; SemanticModel data deferred")


def arguments(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tenant-id", required=True, type=lambda s: str(UUID(s)))
    parser.add_argument("--capacity-id", required=True, type=lambda s: str(UUID(s)))
    parser.add_argument("--workspace-name", required=True)
    parser.add_argument("--workspace-id", type=lambda s: str(UUID(s)),
                        help="Reuse an existing EMPTY workspace matching the supplied name and capacity")
    parser.add_argument("--skip-eventhouse-kql", action="store_true",
                        help="Explicitly exclude Eventhouse and KQLDatabase from creation and validation")
    parser.add_argument("--prefix", default="OntologySample")
    parser.add_argument("--manifest", type=Path, default=Path("ontology-sample.manifest.json"))
    parser.add_argument("--execute", action="store_true", help="Create paid Fabric resources; otherwise print an offline plan")
    parser.add_argument("--timeout", type=int, default=1800, help="Seconds per provisioning/replication wait")
    parser.add_argument("--settle-seconds", type=int, default=120,
                        help="Wait after all source loads and initial SQL metadata refreshes, before row verification")
    parser.add_argument("--kql-request-timeout", type=int, default=300,
                        help="KQL HTTP read timeout per request, capped by --timeout")
    parser.add_argument("--fabric-api", default="https://dailyapi.fabric.microsoft.com/v1")
    parser.add_argument("--powerbi-api", default="https://wabi-daily-us-east2-redirect.analysis.windows.net")
    parser.add_argument("--onelake-url", default="https://daily-onelake.dfs.fabric.microsoft.com",
                        help="DFS origin; may contain {workspaceId} for configured workspace-scoped routing")
    parser.add_argument("--kql-endpoint", help="Override discovered KQL query-service origin")
    parser.add_argument("--kusto-scope", default="https://kusto.kusto.windows.net/.default")
    parser.add_argument("--sql-endpoints", type=json.loads, default={},
                        help='JSON map of source type to {"server": "...", "catalog": "..."}')
    parser.add_argument("--odbc-driver", default="ODBC Driver 18 for SQL Server")
    args = parser.parse_args(argv)
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,49}", args.prefix):
        parser.error("--prefix must start with a letter and contain at most 50 letters/digits/underscores")
    if not args.workspace_name.strip() or len(args.workspace_name) > 256:
        parser.error("--workspace-name must contain 1-256 characters")
    if args.timeout < 30:
        parser.error("--timeout must be at least 30 seconds")
    if not 0 <= args.settle_seconds <= 86400:
        parser.error("--settle-seconds must be between 0 and 86400")
    if not 30 <= args.kql_request_timeout <= 3600:
        parser.error("--kql-request-timeout must be between 30 and 3600 seconds")
    for name in ("fabric_api", "powerbi_api", "onelake_url", "kql_endpoint"):
        value = getattr(args, name)
        if value:
            setattr(args, name, https_url(value))
    if not isinstance(args.sql_endpoints, dict):
        parser.error("--sql-endpoints must be a JSON object")
    for kind, endpoint in args.sql_endpoints.items():
        if (kind not in ("Lakehouse", "MirroredDatabase", "SQLDatabase", "Warehouse")
                or not isinstance(endpoint, dict) or not endpoint
                or set(endpoint) - {"server", "catalog"}
                or any(not isinstance(v, str) or not v for v in endpoint.values())):
            parser.error("Invalid --sql-endpoints entry")
    return args


def source_plan(args):
    return {
        "environment": "Daily", "workspaceName": args.workspace_name,
        "tenantId": args.tenant_id, "capacityId": args.capacity_id,
        "sources": [kind for kind in COLLECTIONS if not (
            args.skip_eventhouse_kql and kind in ("Eventhouse", "KQLDatabase"))],
        "existingWorkspaceId": args.workspace_id,
        "verificationSettleSeconds": args.settle_seconds,
        "kqlRequestTimeoutSeconds": min(args.kql_request_timeout, args.timeout),
        "expectedRowsPerSource": {t.name: len(t.rows) for t in sample_tables()},
        "deferredValidation": {"SemanticModel": ["refresh", "sampleRows"]},
        "endpoints": {"fabric": args.fabric_api, "powerbi": args.powerbi_api, "onelake": args.onelake_url},
        "privateLink": "Existing network only; no network policy, private endpoint, or DNS changes",
    }

def check_local_dependencies(args):
    import pyodbc
    for module in ("pyarrow.parquet", "requests", "azure.storage.filedatalake"):
        importlib.import_module(module)
    if args.odbc_driver not in pyodbc.drivers():
        raise RuntimeError(f"Install {args.odbc_driver} before provisioning. Found: {pyodbc.drivers()}")


def main(argv=None):
    args = arguments(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logging.getLogger("azure").setLevel(logging.WARNING)
    plan = source_plan(args)
    if not args.execute:
        print(json.dumps(plan, indent=2))
        return

    from azure.identity import AzureCliCredential

    check_local_dependencies(args)
    # Resolve all local dependencies and token audiences before creating any resource.
    with AzureCliCredential(tenant_id=args.tenant_id, process_timeout=60) as credential:
        scopes = [PBI_SCOPE, STORAGE_SCOPE, SQL_SCOPE]
        if not args.skip_eventhouse_kql:
            scopes.append(args.kusto_scope)
        for scope in scopes:
            credential.get_token(scope)
        manifest = Manifest(args.manifest, plan)
        with closing(Provisioner(args, credential, manifest)) as provisioner:
            try:
                provisioner.run()
            except (Exception, KeyboardInterrupt) as error:
                manifest.data["status"] = "failed"
                manifest.data["error"] = str(error)
                manifest.save()
                LOG.error("Stopped at %s. Resources were NOT deleted; inspect %s before another run.",
                          manifest.data["step"], args.manifest)
                raise
        LOG.info("Source manifest (SemanticModel data validation deferred): %s", args.manifest.resolve())


if __name__ == "__main__":
    main()
