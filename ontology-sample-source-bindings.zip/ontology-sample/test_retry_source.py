import base64
import copy
import io
import json
import shutil
import subprocess
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import MagicMock, Mock, patch
from uuid import uuid4

import create_sample as sample
import retry_source as retry
from test_create_ontology import GUID, inventory


class RetrySourceTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.folder = Path(temporary.name)
        self.state = inventory()
        self.state["status"] = "failed"
        self.state["error"] = "Connection aborted"
        self.source = self.folder / "input.json"
        self.source.write_text(json.dumps(self.state), encoding="utf-8")

    def argv(self, kind="KQLDatabase"):
        return ["--sources-manifest", str(self.source), "--source-type", kind,
                "--run-directory", str(self.folder / "result"), "--settle-seconds", "0"]

    def provisioner(self, args=None, manifest=None):
        if args is None:
            _, args = retry.prepare(retry.arguments(self.argv()), self.state)
        if manifest is None:
            manifest = sample.Manifest(self.folder / f"{uuid4().hex}.json", self.state)
            manifest.data.update(items=copy.deepcopy(self.state["items"]), verified=copy.deepcopy(self.state["verified"]))
        p = sample.Provisioner(args, Mock(), manifest)
        p.api.close()
        p.pbi.close()
        p.api = Mock(base=args.fabric_api)
        p.pbi = Mock()
        self.addCleanup(p.close)

        def read(method, path, **kwargs):
            if path.endswith("/" + GUID):
                if path.endswith("/workspaces/" + GUID):
                    return {"id": GUID, "displayName": self.state["workspaceName"], "capacityId": GUID}
                for kind, collection in sample.COLLECTIONS.items():
                    if f"/{collection}/" in path:
                        return {**self.state["items"][kind],
                                "properties": {"parentEventhouseItemId": self.state["items"]["Eventhouse"]["id"]}}
            if path.endswith("/items"):
                return {"value": list(self.state["items"].values())}
            raise AssertionError(f"Unexpected API read: {path}")
        p.api.json.side_effect = read
        p.api.mutate.side_effect = lambda path, *args, **kwargs: (
            {"definition": sample.semantic_definition(sample.sample_tables())}
            if path.endswith("/getDefinition") else {"id": str(uuid4())})
        for name in ("seed_kql", "seed_lakehouse", "seed_mirror", "seed_sql", "seed_semantic",
                     "verify_semantic", "refresh_sql_metadata"):
            setattr(p, name, Mock())
        counts = {table.name: len(table.rows) for table in sample.sample_tables()}

        def kql_verified():
            manifest.data["verified"]["KQLDatabase"] = counts.copy()
            manifest.data["verified"]["Eventhouse"] = {
                "viaKqlDatabaseId": manifest.data["items"]["KQLDatabase"]["id"]}
        p.verify_kql = Mock(side_effect=kql_verified)
        p.verify_sql = Mock(side_effect=lambda kind, **kwargs: manifest.data["verified"].update({kind: counts.copy()}))
        return p

    def test_preview_does_not_authenticate_create_outputs_or_change_input(self):
        before = self.source.read_bytes()
        with patch("retry_source.open_credential") as auth, redirect_stdout(io.StringIO()) as output:
            retry.main(self.argv())
        plan = json.loads(output.getvalue())
        self.assertEqual(plan["sourceTypes"], ["KQLDatabase"])
        self.assertFalse(plan["createsWorkspace"])
        self.assertFalse(plan["changesOntology"])
        auth.assert_not_called()
        self.assertFalse((self.folder / "result").exists())
        self.assertEqual(self.source.read_bytes(), before)

    def test_each_source_recreates_only_selected_items_and_dependencies(self):
        for kind in sample.COLLECTIONS:
            with self.subTest(kind=kind):
                args = retry.arguments(self.argv(kind))
                selected, source_args = retry.prepare(args, self.state)
                p = self.provisioner(source_args)
                original = copy.deepcopy(p.manifest.data["items"])
                retry.run(p, selected, False)
                calls = [call for call in p.api.mutate.call_args_list if not call.args[0].endswith("/getDefinition")]
                self.assertEqual(len(calls), len(selected))
                for call in calls:
                    self.assertIn("/workspaces/" + GUID + "/", call.args[0])
                    self.assertNotIn("/ontologies", call.args[0])
                for other in set(sample.COLLECTIONS) - set(selected):
                    self.assertEqual(p.manifest.data["items"][other], original[other])
                for chosen in selected:
                    self.assertNotEqual(p.manifest.data["items"][chosen]["id"], original[chosen]["id"])
                    self.assertEqual(p.manifest.data["previousItems"][chosen], original[chosen])
                self.assertEqual(p.manifest.data["status"], "succeeded")
                self.assertEqual(p.manifest.data["retryStatus"], "succeeded")
                self.assertEqual(p.seed_kql.call_count, int("KQLDatabase" in selected))
                self.assertEqual(p.seed_lakehouse.call_count, int(kind == "Lakehouse"))
                self.assertEqual(p.seed_mirror.call_count, int(kind == "MirroredDatabase"))
                self.assertEqual(p.seed_sql.call_count, int(kind in ("SQLDatabase", "Warehouse")))
                p.seed_semantic.assert_not_called()
                p.verify_semantic.assert_not_called()
                p.pbi.request.assert_not_called()
                p.pbi.json.assert_not_called()
                if kind in ("Eventhouse", "KQLDatabase"):
                    kql = calls[-1].args[1]
                    self.assertEqual(kql["creationPayload"]["parentEventhouseItemId"],
                                     p.manifest.data["items"]["Eventhouse"]["id"])
                if kind == "SemanticModel":
                    self.assertNotIn(kind, p.manifest.data["verified"])
                    self.assertEqual(p.manifest.data["verifiedDefinitions"][kind]["tables"], 3)
                    self.assertEqual(p.manifest.data["deferredValidation"][kind], ["refresh", "sampleRows"])

    def test_kql_creates_missing_parent_but_verify_requires_it(self):
        del self.state["items"]["Eventhouse"]
        args = retry.arguments(self.argv())
        selected, _ = retry.prepare(args, self.state)
        self.assertEqual(selected, ("Eventhouse", "KQLDatabase"))
        args.verify_only = True
        with self.assertRaisesRegex(ValueError, "existing items"):
            retry.prepare(args, self.state)

    def test_verify_only_never_creates_loads_or_refreshes_metadata(self):
        for kind in sample.COLLECTIONS:
            with self.subTest(kind=kind):
                args = retry.arguments(self.argv(kind) + ["--verify-only"])
                selected, source_args = retry.prepare(args, self.state)
                p = self.provisioner(source_args)
                original = copy.deepcopy(p.manifest.data["items"])
                retry.run(p, selected, True)
                self.assertEqual(p.manifest.data["items"], original)
                for call in p.api.mutate.call_args_list:
                    self.assertTrue(call.args[0].endswith("/getDefinition"))
                for name in ("seed_kql", "seed_lakehouse", "seed_mirror", "seed_sql",
                             "seed_semantic", "verify_semantic", "refresh_sql_metadata"):
                    getattr(p, name).assert_not_called()
                if kind in retry.SQL_TYPES:
                    p.verify_sql.assert_called_once_with(kind, asynchronous=False, refresh_before_read=False)

    def test_remaining_sources_prevent_whole_inventory_success(self):
        self.state["verified"] = {}
        p = self.provisioner()
        retry.run(p, ("KQLDatabase",), False)
        self.assertEqual(p.manifest.data["retryStatus"], "succeeded")
        self.assertEqual(p.manifest.data["status"], "partial")
        self.assertEqual(set(p.manifest.data["remainingSources"]), set(retry.SQL_TYPES) | {"SemanticModel"})
        with self.assertRaisesRegex(ValueError, "successful source manifest"):
            retry.validate_inventory(p.manifest.data, allow_deferred_semantic=True)

    def test_workspace_and_parent_identity_changes_block_writes(self):
        for responses in (
            [{"capacityId": GUID, "displayName": "renamed"}],
            [{"capacityId": GUID, "displayName": self.state["workspaceName"]}, {"displayName": "renamed"}],
        ):
            p = self.provisioner()
            p.api.json.side_effect = responses
            with self.assertRaisesRegex(ValueError, "changed"):
                retry.run(p, ("KQLDatabase",), False)
            p.api.mutate.assert_not_called()
            p.seed_kql.assert_not_called()

    def test_wrong_kql_parent_blocks_verification(self):
        p = self.provisioner()
        p.api.json.side_effect = [
            {"capacityId": GUID, "displayName": self.state["workspaceName"]},
            self.state["items"]["Eventhouse"],
            {**self.state["items"]["KQLDatabase"], "properties": {"parentEventhouseItemId": str(uuid4())}},
        ]
        with self.assertRaisesRegex(ValueError, "recorded Eventhouse"):
            retry.run(p, ("KQLDatabase",), True)
        p.verify_kql.assert_not_called()

    def test_collision_and_existing_item_response_never_load_data(self):
        p = self.provisioner()
        with patch("retry_source.workspace_items", return_value=[
            {"id": GUID, "displayName": p.args.prefix + "_KQLDatabase"}]):
            with self.assertRaisesRegex(ValueError, "already exists"):
                retry.run(p, ("KQLDatabase",), False)
        p.api.mutate.assert_not_called()
        p.api.mutate.side_effect = None
        p.api.mutate.return_value = {"id": GUID}
        with self.assertRaisesRegex(RuntimeError, "existing item ID"):
            retry.run(p, ("KQLDatabase",), False)
        p.seed_kql.assert_not_called()

    def test_only_selected_sql_metadata_is_prepared_before_settling(self):
        for kind in ("Lakehouse", "MirroredDatabase"):
            p = self.provisioner()
            p.args.settle_seconds = 120
            order = Mock()
            order.attach_mock(p.refresh_sql_metadata, "refresh")
            order.attach_mock(p.verify_sql, "verify")
            with patch("retry_source.time.sleep") as sleep:
                order.attach_mock(sleep, "sleep")
                retry.run(p, (kind,), False)
            self.assertEqual([call[0] for call in order.mock_calls], ["refresh", "sleep", "verify"])
            p.refresh_sql_metadata.assert_called_once_with(kind)
            p.verify_sql.assert_called_once_with(kind, asynchronous=True, refresh_before_read=False)

    def test_live_failure_is_persisted_without_replaying_or_mutating_input(self):
        before = self.source.read_bytes()
        opened = MagicMock()
        instances = []
        def create(args, credential, manifest):
            p = self.provisioner(args, manifest)
            p.seed_kql.side_effect = RuntimeError("Connection aborted")
            instances.append(p)
            return p
        with patch("retry_source.open_credential", opened), patch("retry_source.Provisioner", side_effect=create), \
                redirect_stdout(io.StringIO()), self.assertLogs("ontology-sample", level="ERROR"):
            with self.assertRaisesRegex(RuntimeError, "Connection aborted"):
                retry.main(self.argv() + ["--execute"])
        p = instances[0]
        p.seed_kql.assert_called_once()
        p.verify_kql.assert_not_called()
        stored = json.loads((self.folder / "result" / "sources.manifest.json").read_text())
        self.assertEqual(stored["retryStatus"], "failed")
        self.assertEqual(stored["status"], "failed")
        self.assertNotIn("KQLDatabase", stored["verified"])
        self.assertEqual(stored["items"]["Lakehouse"], self.state["items"]["Lakehouse"])
        self.assertIn("KQLDatabase", stored["previousItems"])
        self.assertEqual(self.source.read_bytes(), before)
        credential = opened.return_value.__enter__.return_value
        self.assertEqual([call.args[0] for call in credential.get_token.call_args_list],
                         [sample.PBI_SCOPE, "https://kusto.kusto.windows.net/.default"])

    def test_successful_retry_output_can_be_reused_without_changing_input(self):
        before = self.source.read_bytes()
        with patch("retry_source.open_credential", MagicMock()), \
                patch("retry_source.Provisioner", side_effect=lambda args, credential, manifest:
                      self.provisioner(args, manifest)), redirect_stdout(io.StringIO()):
            retry.main(self.argv() + ["--execute"])
        result = json.loads((self.folder / "result" / "sources.manifest.json").read_text())
        self.assertEqual(result["retryStatus"], "succeeded")
        retry.validate_inventory(result, allow_deferred_semantic=True)
        self.assertNotEqual(result["items"]["KQLDatabase"]["id"], self.state["items"]["KQLDatabase"]["id"])
        self.assertEqual(result["sourceAttempt"]["status"], "failed")
        self.assertEqual(self.source.read_bytes(), before)

    def test_auth_failure_creates_no_run_directory(self):
        opened = MagicMock()
        opened.return_value.__enter__.return_value.get_token.side_effect = RuntimeError("Authentication failed")
        with patch("retry_source.open_credential", opened), redirect_stdout(io.StringIO()), \
                self.assertRaisesRegex(RuntimeError, "Authentication failed"):
            retry.main(self.argv() + ["--execute"])
        self.assertFalse((self.folder / "result").exists())

    def test_existing_output_and_invalid_options_fail_before_authentication(self):
        with patch("retry_source.open_credential") as auth:
            (self.folder / "result").mkdir()
            with redirect_stdout(io.StringIO()), self.assertRaises(FileExistsError):
                retry.main(self.argv() + ["--execute"])
            for options in (["--source-type", "unknown"], ["--timeout", "0"], ["--settle-seconds", "-1"]):
                with patch("sys.stderr", io.StringIO()), self.assertRaises(SystemExit):
                    retry.main(self.argv() + options)
            auth.assert_not_called()


@unittest.skipUnless(shutil.which("powershell.exe"), "Windows PowerShell is required for launcher execution tests")
class RetryLauncherTests(unittest.TestCase):
    def invoke(self, parameters):
        folder = Path(__file__).resolve().parent
        text = (folder / "Start-Sample.ps1").read_text(encoding="utf-8-sig")
        body = text[:text.index("$python = Join-Path")] + (
            f"$PSScriptRoot = '{str(folder).replace(chr(39), chr(39) * 2)}'\n"
            "$python = 'Invoke-TestPython'\n"
        ) + text[text.index("if (-not $RetrySource) {"):]
        encoded_body = base64.b64encode(body.encode("utf-8")).decode()
        encoded_parameters = base64.b64encode(json.dumps(parameters).encode("utf-8")).decode()
        script = """
$ErrorActionPreference = 'Stop'
function Invoke-TestPython { $global:captured = @($args); $global:LASTEXITCODE = 0 }
function Read-Host {
    param([string] $Prompt)
    if ($Prompt -like 'Type CREATE*') { return 'CREATE' }
    throw "Unexpected identity prompt: $Prompt"
}
function Write-Host {}
try {
    $source = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('BODY'))
    $json = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('PARAMETERS')) | ConvertFrom-Json
    $parameters = @{}
    foreach ($property in $json.PSObject.Properties) { $parameters[$property.Name] = $property.Value }
    & ([scriptblock]::Create($source)) @parameters
    ConvertTo-Json -InputObject @($global:captured) -Compress
} catch { Write-Error $_; exit 1 }
""".replace("BODY", encoded_body).replace("PARAMETERS", encoded_parameters)
        command = base64.b64encode(script.encode("utf-16le")).decode()
        return subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-EncodedCommand", command],
            capture_output=True, text=True, timeout=30)

    def test_retry_and_verify_forward_without_prompting_for_workspace_identity(self):
        for plan, verify in ((True, False), (False, False), (False, True)):
            with self.subTest(plan=plan, verify=verify):
                result = self.invoke({
                    "RetrySource": "KQLDatabase", "SourcesManifest": "sources.json", "RunDirectory": "retry-output",
                    "PlanOnly": plan, "VerifyOnly": verify, "SettleSeconds": 0, "KqlRequestTimeoutSeconds": 600,
                })
                self.assertEqual(result.returncode, 0, result.stderr)
                forwarded = json.loads(result.stdout)
                self.assertEqual(Path(forwarded[0]).name, "retry_source.py")
                self.assertEqual(forwarded[forwarded.index("--source-type") + 1], "KQLDatabase")
                self.assertEqual(forwarded[forwarded.index("--sources-manifest") + 1], "sources.json")
                self.assertEqual(forwarded[forwarded.index("--kql-request-timeout") + 1], "600")
                self.assertEqual("--verify-only" in forwarded, verify)
                self.assertEqual("--execute" in forwarded, not plan)
                self.assertNotIn("--workspace-id", forwarded)

    def test_normal_workflow_routing_is_preserved(self):
        result = self.invoke({"TenantId": GUID, "CapacityId": GUID, "WorkspaceId": GUID, "PlanOnly": True})
        self.assertEqual(result.returncode, 0, result.stderr)
        forwarded = json.loads(result.stdout)
        self.assertEqual(Path(forwarded[0]).name, "run_sample.py")
        self.assertIn("--workspace-id", forwarded)
        self.assertNotIn("--source-type", forwarded)
        self.assertNotIn("--execute", forwarded)

    def test_invalid_retry_combinations_are_rejected_before_setup(self):
        for parameters in (
            {"RetrySource": "KQLDatabase"},
            {"RetrySource": "KQLDatabase", "SourcesManifest": "input.json", "WorkspaceId": GUID},
            {"RetrySource": "Warehouse", "SourcesManifest": "input.json", "OntologyId": GUID},
        ):
            result = self.invoke(parameters)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("RetrySource", result.stderr)


if __name__ == "__main__":
    unittest.main()
