"""Create seven Daily source types in a new workspace and a bound ontology in a supplied workspace."""

import argparse
import json
import logging
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
from tempfile import TemporaryDirectory
from uuid import UUID, uuid4

from create_ontology import build_definition, discover_sources, validate_inventory
from create_sample import (
    Api, Manifest, PBI_SCOPE, SQL_SCOPE, STORAGE_SCOPE, Provisioner, arguments as source_arguments,
    check_local_dependencies, source_plan,
)
from replace_ontology import read_and_verify, serialize_definition

LOG = logging.getLogger("ontology-sample")


def guid(value):
    return str(UUID(value))


def arguments(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tenant-id", type=guid)
    parser.add_argument("--capacity-id", type=guid, help="Capacity for the new source workspace")
    parser.add_argument("--workspace-id", type=guid, help="Existing target workspace for the new ontology")
    parser.add_argument("--source-workspace-name")
    parser.add_argument("--ontology-name")
    parser.add_argument("--auth", choices=("auto", "cli", "browser"), default="auto")
    parser.add_argument("--client-id", type=guid, help="Organization-approved public client for browser auth")
    parser.add_argument("--run-directory", type=Path, help="New output directory; existing paths are refused")
    parser.add_argument("--sources-manifest", type=Path, help="Reuse successful source provisioning after inspecting a failure")
    parser.add_argument("--ontology-id", type=guid, help="Only supported with --verify-only")
    parser.add_argument("--verify-only", action="store_true", help="Read-only check of an existing ontology")
    parser.add_argument("--timeout", type=int, default=1800)
    parser.add_argument("--settle-seconds", type=int, default=120)
    parser.add_argument("--kql-request-timeout", type=int, default=300)
    parser.add_argument("--execute", action="store_true", help="Enable live calls; otherwise print an offline plan")
    args = parser.parse_args(argv)
    if args.verify_only and not (args.sources_manifest and args.ontology_id and args.ontology_name):
        parser.error("--verify-only requires --sources-manifest, --ontology-id and --ontology-name")
    if args.ontology_id and not args.verify_only:
        parser.error("Existing ontologies are never overwritten by this launcher; use --verify-only")
    if args.timeout < 30:
        parser.error("--timeout must be at least 30 seconds")
    if not 0 <= args.settle_seconds <= 86400:
        parser.error("--settle-seconds must be between 0 and 86400")
    if not 30 <= args.kql_request_timeout <= 3600:
        parser.error("--kql-request-timeout must be between 30 and 3600 seconds")
    for field, label in (("tenant_id", "Tenant ID"), ("capacity_id", "Source capacity ID"),
                         ("workspace_id", "Target workspace ID (ontology destination)")):
        if getattr(args, field) is None:
            try:
                setattr(args, field, guid(input(f"{label}: ").strip()))
            except (ValueError, EOFError):
                parser.error(f"A valid {label} is required")
    run_id = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S") + "_" + uuid4().hex[:6]
    args.source_workspace_name = args.source_workspace_name or f"OntologySources_{run_id}"
    args.ontology_name = args.ontology_name or f"Ontology_AllSources_{run_id}"
    for name in (args.source_workspace_name, args.ontology_name):
        if not name.strip() or len(name) > 256:
            parser.error("Workspace and ontology names must contain 1-256 characters")
    args.run_directory = (args.run_directory or Path("runs") / run_id).resolve()
    args.prefix = f"OntologySample_{run_id}"
    return args


def workspace_items(api, workspace):
    url = workspace + "/items"
    params = None
    seen = set()
    while True:
        page = api.json("GET", url, params=params)
        yield from page["value"]
        next_url = page.get("continuationUri")
        token = page.get("continuationToken")
        if not next_url and not token:
            return
        marker = (next_url, token)
        if marker in seen:
            raise RuntimeError("Repeated item-list continuation; refusing an incomplete collision check")
        seen.add(marker)
        url = next_url or workspace + "/items"
        params = None if next_url else {"continuationToken": token}


def provision_sources(args, credential, manifest):
    with closing(Provisioner(args, credential, manifest)) as provisioner:
        try:
            provisioner.run()
        except (Exception, KeyboardInterrupt) as error:
            manifest.data.update(status="failed", error=str(error))
            manifest.save()
            raise
    return manifest.data


def run(args, credential, manifest, source_args, state=None):
    with closing(Api(source_args.fabric_api, PBI_SCOPE, credential, args.timeout, manifest.operation)) as api:
        target = f"{api.base}/workspaces/{args.workspace_id}"
        manifest.step("Checking the target workspace before any creation")
        target_metadata = api.json("GET", target)
        if not target_metadata.get("capacityId"):
            raise ValueError("The target workspace must already be assigned to a Fabric capacity")
        manifest.data["targetWorkspace"] = target_metadata
        if args.verify_only:
            item = api.json("GET", f"{target}/items/{args.ontology_id}")
            if item.get("type") != "Ontology" or item.get("displayName") != args.ontology_name:
                raise ValueError("Verification target must be an Ontology with the supplied exact name")
        elif any(item["displayName"].casefold() == args.ontology_name.casefold()
                 for item in workspace_items(api, target)):
            raise ValueError("The target workspace already contains that name; existing items are not overwritten")

        if state is None:
            manifest.step("Creating seven source types; SemanticModel data validation is deferred")
            sources = Manifest(source_args.manifest, source_plan(source_args))
            state = provision_sources(source_args, credential, sources)
        validate_inventory(state, allow_deferred_semantic=True)
        if state["workspaceId"].lower() == args.workspace_id.lower():
            raise ValueError("Source and target workspaces must be different for this scenario")
        manifest.data["sourceWorkspaceId"] = state["workspaceId"]
        manifest.data["sourceItems"] = state["items"]
        manifest.data["verified"]["sources"] = state["verified"]
        manifest.data["deferredValidation"] = state.get("deferredValidation", {})
        manifest.save()
        expected = build_definition(state, discover_sources(api, state), "powerbi://dailyapi.powerbi.com")
        manifest.data["authoredDefinition"] = expected
        with TemporaryDirectory(prefix="ontology-public-") as temporary:
            folder = Path(temporary)
            manifest.step("Serializing and validating every source binding")
            body = serialize_definition(expected, folder)
            manifest.data["publicRequest"] = body
            if not args.verify_only:
                manifest.step("Creating the ontology in the target workspace")
                item = api.mutate(target + "/items", {"displayName": args.ontology_name, "type": "Ontology"})
                if not item.get("id"):
                    raise RuntimeError("Creation returned no ontology ID; inspect the operation before retrying")
            manifest.data["items"]["Ontology"] = item
            manifest.save()
            item_path = f"{target}/ontologies/{item['id']}"
            if not args.verify_only:
                manifest.step("Writing all bindings through the Fabric public definition API")
                api.mutate(item_path + "/updateDefinition", body, result_required=False)
                manifest.data["writeCompleted"] = True
                manifest.save()
            read_and_verify(api, item_path, state, expected, folder, manifest, args.workspace_id)
        manifest.data["status"] = "succeeded"
        manifest.data["workspaceUrl"] = f"https://daily.powerbi.com/groups/{args.workspace_id}/list"
        manifest.step("Sample ontology definition verified; consult source verification and deferredValidation")


def main(argv=None):
    args = arguments(argv)
    source_path = (args.sources_manifest.resolve() if args.sources_manifest
                   else args.run_directory / "sources.manifest.json")
    state = None
    if args.sources_manifest:
        state = json.loads(source_path.read_text(encoding="utf-8-sig"))
        validate_inventory(state, allow_deferred_semantic=True)
        if state["tenantId"].lower() != args.tenant_id or state["capacityId"].lower() != args.capacity_id:
            raise ValueError("The source manifest must match the supplied tenant and source capacity")
        if state["workspaceId"].lower() == args.workspace_id:
            raise ValueError("Source and target workspaces must be different")
        if state["endpoints"] != {
            "fabric": "https://dailyapi.fabric.microsoft.com/v1",
            "powerbi": "https://wabi-daily-us-east2-redirect.analysis.windows.net",
            "onelake": "https://daily-onelake.dfs.fabric.microsoft.com",
        }:
            raise ValueError("This wrapper supports normal Daily endpoints only")
    source_args = source_arguments([
        "--tenant-id", args.tenant_id, "--capacity-id", args.capacity_id,
        "--workspace-name", args.source_workspace_name, "--prefix", args.prefix,
        "--manifest", str(source_path), "--timeout", str(args.timeout),
        "--settle-seconds", str(args.settle_seconds),
        "--kql-request-timeout", str(args.kql_request_timeout),
    ])
    plan = {
        "environment": "Daily", "tenantId": args.tenant_id, "capacityId": args.capacity_id,
        "targetWorkspaceId": args.workspace_id, "ontologyName": args.ontology_name,
        "sourceWorkspaceName": state["workspaceName"] if state else args.source_workspace_name,
        "sourceManifest": str(source_path), "runDirectory": str(args.run_directory),
        "authentication": args.auth, "operation": "verify-only" if args.verify_only else "create",
        "reuseVerifiedSources": bool(state),
        "deferredValidation": state.get("deferredValidation", {}) if state else {
            "SemanticModel": ["refresh", "sampleRows"]},
        "verificationSettleSeconds": 0 if state else args.settle_seconds,
        "kqlRequestTimeoutSeconds": min(args.kql_request_timeout, args.timeout),
        "expected": {"sourceItemTypes": 7, "sourceGroups": 6, "entities": 18, "relationships": 12},
    }
    print(json.dumps(plan, indent=2))
    if not args.execute:
        return
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logging.getLogger("azure").setLevel(logging.WARNING)
    if args.run_directory.exists():
        raise FileExistsError(f"Run directory already exists: {args.run_directory}; inspect it, do not replay")
    if state is None:
        check_local_dependencies(source_args)
    from sample_auth import open_credential

    with open_credential(args.tenant_id, mode=args.auth, client_id=args.client_id) as credential:
        scopes = [PBI_SCOPE] if state else [PBI_SCOPE, STORAGE_SCOPE, SQL_SCOPE, source_args.kusto_scope]
        for scope in scopes:
            credential.get_token(scope)
        args.run_directory.mkdir(parents=True, exist_ok=False)
        manifest = Manifest(args.run_directory / "run.manifest.json", plan)
        try:
            run(args, credential, manifest, source_args, state)
        except (Exception, KeyboardInterrupt) as error:
            manifest.data.update(status="failed", error=str(error))
            manifest.save()
            LOG.exception("Stopped. No resources were deleted. Inspect %s and %s before retrying.",
                          manifest.path, source_path)
            raise
        LOG.info("Completed. Evidence: %s", manifest.path)


if __name__ == "__main__":
    main()
