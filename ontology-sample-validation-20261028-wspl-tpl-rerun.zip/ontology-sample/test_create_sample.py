import base64
import io
import json
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
from urllib.parse import parse_qs, urlsplit

import pyarrow as pa
import pyarrow.parquet as pq
import pyodbc
import requests
from azure.core import MatchConditions
from azure.core.exceptions import HttpResponseError, ResourceExistsError
from azure.core.pipeline.transport import HttpResponse, HttpTransport, RequestsTransport
from azure.storage.filedatalake import DataLakeFileClient
from requests.structures import CaseInsensitiveDict

import create_sample as sample


GUID = "11111111-1111-1111-1111-111111111111"
BASE = "https://dailyapi.fabric.microsoft.com/v1"


def sql_transition_error():
    return pyodbc.InterfaceError(
        "28000",
        "[28000] [Microsoft][ODBC Driver 18 for SQL Server][SQL Server]"
        "Login failed for user '<token-identified principal>'. (18456) (SQLDriverConnect); "
        "[28000] [Microsoft][ODBC Driver Manager] Driver's SQLSetConnectAttr failed (0); "
        "[28000] [Microsoft][ODBC Driver 18 for SQL Server][SQL Server]"
        "Database 'Sample_Lakehouse' is in transition. Try the statement later. (952)",
    )


def sql_snapshot_metadata_error():
    return pyodbc.ProgrammingError(
        "42000",
        "[42000] [Microsoft][ODBC Driver 18 for SQL Server][SQL Server]"
        "Snapshot isolation transaction failed in database 'Sample_Lakehouse' because the object accessed "
        "by the statement has been modified by a DDL statement in another concurrent transaction since "
        "the start of this transaction. It is disallowed because the metadata is not versioned. "
        "A concurrent update to metadata can lead to inconsistency if mixed with snapshot isolation. "
        "(3961) (SQLExecDirectW)",
    )


def args():
    return sample.arguments([
        "--tenant-id", GUID, "--capacity-id", GUID, "--workspace-name", "Sample",
    ])


def response(status=200, body=None, headers=None):
    return SimpleNamespace(status_code=status, headers=headers or {}, content=b"x" if body is not None else b"",
                           text=json.dumps(body), json=lambda: body)


def decode(definition, path):
    part = next(p for p in definition["parts"] if p["path"] == path)
    return json.loads(base64.b64decode(part["payload"]))


class DataTests(unittest.TestCase):
    def test_counts_keys_and_relationships(self):
        plants, assets, readings = sample.sample_tables()
        self.assertEqual([len(t.rows) for t in (plants, assets, readings)], [3, 12, 120])
        for table in (plants, assets, readings):
            self.assertEqual(len({r[0] for r in table.rows}), len(table.rows))
        self.assertTrue({r[1] for r in assets.rows} <= {r[0] for r in plants.rows})
        self.assertTrue({r[1] for r in readings.rows} <= {r[0] for r in assets.rows})

    def test_parquet_roundtrip_and_explicit_types_without_cdc_marker(self):
        for table in sample.sample_tables():
            restored = pq.read_table(pa.BufferReader(sample.parquet_bytes(table)))
            self.assertNotIn("__rowMarker__", restored.column_names)
            sample.assert_rows(table, restored.to_pylist())
            for name, kind in table.columns:
                if kind == "datetime":
                    self.assertEqual(restored.schema.field(name).type, pa.timestamp("us", tz="UTC"))
                    parquet_schema = pq.ParquetFile(pa.BufferReader(sample.parquet_bytes(table))).schema
                    column = parquet_schema.column(restored.schema.get_field_index(name))
                    self.assertTrue(json.loads(column.logical_type.to_json())["isAdjustedToUTC"])
                if kind == "double":
                    self.assertEqual(restored.schema.field(name).type, pa.float64())

    def test_verification_checks_values_and_duplicates_not_only_counts(self):
        table = sample.sample_tables()[0]
        sample.assert_rows(table, list(reversed(table.records())))
        for changed in (table.records()[:-1], [table.records()[0]] * len(table.rows)):
            with self.assertRaises(ValueError):
                sample.assert_rows(table, changed)
        changed = table.records()
        changed[0]["City"] = "Wrong"
        with self.assertRaises(ValueError):
            sample.assert_rows(table, changed)

    def test_datetime_strings_from_kql_and_dax(self):
        table = sample.sample_tables()[2]
        records = table.records()
        for row in records:
            row["ObservedAt"] = row["ObservedAt"].isoformat() + "Z"
        sample.assert_rows(table, records)

    def test_semantic_definition_has_all_columns_rows_and_relationships(self):
        tables = sample.sample_tables()
        definition = sample.semantic_definition(tables)
        model = decode(definition, "model.bim")["model"]
        self.assertEqual(len(model["tables"]), 3)
        self.assertEqual(len(model["relationships"]), 2)
        for expected, actual in zip(tables, model["tables"]):
            self.assertEqual(actual["name"], expected.name)
            self.assertEqual([c["name"] for c in actual["columns"]], [c[0] for c in expected.columns])
            partition = actual["partitions"][0]
            self.assertEqual(partition["mode"], "import")
            self.assertIn(expected.rows[-1][0], partition["source"]["expression"])
        self.assertIn("#datetime(2026,1,1,0,0,0)", model["tables"][2]["partitions"][0]["source"]["expression"])
        self.assertEqual(model["tables"][2]["columns"][2]["dataType"], "dateTime")
        for relationship in model["relationships"]:
            self.assertEqual(relationship["fromCardinality"], "many")
            self.assertEqual(relationship["toCardinality"], "one")
        self.assertEqual(decode(definition, "definition.pbism")["version"], "1.0")

    def test_m_literals_escape_quotes_and_hash(self):
        self.assertEqual(sample.m_literal('A"B#C'), '"A""B#(#)C"')

    def test_open_mirror_definition(self):
        properties = decode(sample.mirror_definition(), "mirroring.json")["properties"]
        self.assertEqual(properties["source"], {"type": "GenericMirror", "typeProperties": {}})
        self.assertEqual(properties["target"]["typeProperties"], {"defaultSchema": "dbo", "format": "Delta"})

    def test_kql_generation_and_partial_errors(self):
        text = sample.kql_seed(sample.sample_tables()[2])
        self.assertTrue(text.startswith(".set Readings <| datatable("))
        self.assertIn("TemperatureC:real", text)
        self.assertIn('"R0120"', text)
        self.assertIn("datetime(2026-01-01T00:00:00Z)", text)
        for severity in (0, 1, 2, 4):
            body = {"Tables": [{"TableName": "QueryStatus", "Columns": [{"ColumnName": "Severity"}],
                                "Rows": [[severity]]}]}
            if severity <= 2:
                with self.assertRaisesRegex(RuntimeError, "partial query failure"):
                    sample.kql_tables(body)
            else:
                self.assertEqual(sample.kql_tables(body), body["Tables"])
        for body in ({}, {"Exceptions": ["failure"]}, {"error": "failure"}):
            with self.assertRaises(RuntimeError):
                sample.kql_tables(body)


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.api = sample.Api(BASE, sample.PBI_SCOPE, Mock(), 30)
        self.api.session.close()
        self.api.session = Mock()
        self.addCleanup(self.api.close)

    def test_immediate_creation(self):
        self.api.session.request.return_value = response(201, {"id": GUID})
        self.assertEqual(self.api.mutate(BASE + "/workspaces")["id"], GUID)
        self.assertFalse(self.api.session.request.call_args.kwargs["allow_redirects"])

    def test_json_forwards_explicit_connect_and_read_timeouts(self):
        self.api.session.request.return_value = response(body={"value": 1})
        self.assertEqual(self.api.json("POST", BASE + "/query", request_timeout=(30, 300)), {"value": 1})
        self.assertEqual(self.api.session.request.call_args.kwargs["timeout"], (30, 300))

    @patch("create_sample.time.sleep")
    def test_mutate_query_params_are_only_used_on_initial_request(self, sleep):
        self.api.session.request.side_effect = [
            response(202, headers={"Location": BASE + "/operations/op"}),
            response(body={"status": "Succeeded"}),
            response(body={"definition": {}}),
        ]
        self.api.mutate(BASE + "/getDefinition", params={"format": "TMSL"})
        calls = self.api.session.request.call_args_list
        self.assertEqual(calls[0].kwargs["params"], {"format": "TMSL"})
        self.assertTrue(all(call.kwargs["params"] is None for call in calls[1:]))

    @patch("create_sample.time.sleep")
    def test_lro_waits_for_succeeded_not_percent_complete(self, sleep):
        operation = BASE + "/operations/op"
        self.api.operation_callback = Mock()
        self.api.session.request.side_effect = [
            response(202, headers={"Location": operation, "Retry-After": "1"}),
            response(body={"status": "Running", "percentComplete": 100}, headers={"Retry-After": "2"}),
            response(body={"status": "Succeeded"}),
            response(body={"id": GUID}),
        ]
        self.assertEqual(self.api.mutate(BASE + "/workspaces")["id"], GUID)
        self.api.operation_callback.assert_called_once_with(operation)
        self.assertEqual([c.args[0] for c in sleep.call_args_list], [1, 2])
        self.assertEqual(self.api.session.request.call_args.args[1], operation + "/result")

    @patch("create_sample.time.sleep")
    def test_lro_without_resource_result(self, sleep):
        self.api.session.request.side_effect = [
            response(202, headers={"Location": BASE + "/operations/op"}),
            response(body={"status": "Succeeded"}),
        ]
        self.assertEqual(self.api.mutate(BASE + "/load", result_required=False), {})
        self.assertEqual(self.api.session.request.call_count, 2)

    @patch("create_sample.time.sleep")
    def test_lro_failed_unknown_missing_location_and_timeout(self, sleep):
        for state in ("Failed", "Cancelled", "Unexpected"):
            self.api.session.request.side_effect = [
                response(202, headers={"Location": BASE + "/operations/op"}),
                response(body={"status": state}),
            ]
            with self.assertRaises(RuntimeError):
                self.api.mutate(BASE + "/items")
        self.api.session.request.side_effect = None
        self.api.session.request.return_value = response(202)
        with self.assertRaisesRegex(RuntimeError, "no Location"):
            self.api.mutate(BASE + "/items")
        self.api.session.request.return_value = response(202, headers={
            "Location": BASE + "/operations/op", "Retry-After": "100"})
        with self.assertRaises(TimeoutError):
            self.api.mutate(BASE + "/items")

    @patch("create_sample.time.sleep")
    def test_throttling_retries_but_ambiguous_post_does_not(self, sleep):
        self.api.session.request.side_effect = [
            response(429, headers={"Retry-After": "2"}), response(201, {"id": GUID}),
        ]
        self.api.mutate(BASE + "/items")
        sleep.assert_called_once_with(2)
        self.api.session.request.reset_mock()
        self.api.session.request.side_effect = None
        self.api.session.request.return_value = response(503, {"error": "unavailable"})
        with self.assertRaisesRegex(RuntimeError, "503"):
            self.api.mutate(BASE + "/items")
        self.api.session.request.assert_called_once()

    def test_network_exception_is_not_replayed(self):
        self.api.session.request.side_effect = TimeoutError("response lost")
        with self.assertRaises(TimeoutError):
            self.api.mutate(BASE + "/items")
        self.api.session.request.assert_called_once()

    def test_cross_origin_and_redirects_never_forward_tokens(self):
        for target in ("http://dailyapi.fabric.microsoft.com/v1", "https://api.fabric.microsoft.com/v1"):
            with self.assertRaises((ValueError, RuntimeError)):
                self.api.request("GET", target)
        self.api.session.request.assert_not_called()
        self.api.session.request.return_value = response(302, headers={"Location": "https://other.invalid"})
        with self.assertRaisesRegex(RuntimeError, "302"):
            self.api.request("GET", BASE)


class ProvisionerTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.manifest = sample.Manifest(Path(self.directory.name) / "sample.json", {})
        self.provisioner = sample.Provisioner(args(), Mock(), self.manifest)
        self.provisioner.args.settle_seconds = 0
        self.addCleanup(self.provisioner.close)
        self.provisioner.workspace = GUID
        self.provisioner.api.close()
        self.provisioner.pbi.close()
        self.provisioner.api = Mock()
        self.provisioner.pbi = Mock()

    def add_item(self, kind):
        self.manifest.data["items"][kind] = {"id": GUID, "displayName": "Sample_" + kind}

    def test_semantic_creation_uses_core_items_route_with_explicit_type(self):
        self.provisioner.api.mutate.return_value = {"id": GUID}
        definition = sample.semantic_definition(sample.sample_tables())
        self.provisioner.create("SemanticModel", definition=definition)
        call = self.provisioner.api.mutate.call_args
        self.assertTrue(call.args[0].endswith(f"/workspaces/{GUID}/items"))
        self.assertEqual(call.args[1]["type"], "SemanticModel")
        self.assertEqual(call.args[1]["definition"], definition)

    @patch("azure.storage.filedatalake.DataLakeServiceClient")
    def test_upload_creates_parents_and_atomically_publishes(self, service_type):
        service = service_type.return_value.__enter__.return_value
        filesystem = service.get_file_system_client.return_value
        directory = filesystem.get_directory_client.return_value
        directory.create_directory.side_effect = ResourceExistsError("already exists")
        relative = "Files/LandingZone/dbo.schema/Plants/00000000000000000001.parquet"
        self.provisioner.upload(GUID, relative, b"parquet", publish=True)
        self.assertEqual(directory.create_directory.call_count, 3)
        directory.get_file_client.assert_called_once_with("_00000000000000000001.parquet")
        file = directory.get_file_client.return_value
        file.upload_data.assert_called_once_with(
            b"parquet", overwrite=True, match_condition=MatchConditions.IfMissing)
        file.rename_file.assert_called_once_with(f"{GUID}/{GUID}/{relative}")

    @patch("azure.storage.filedatalake.DataLakeServiceClient")
    def test_failed_upload_never_publishes_mirror_file(self, service_type):
        service = service_type.return_value.__enter__.return_value
        file = service.get_file_system_client.return_value.get_directory_client.return_value.get_file_client.return_value
        file.upload_data.side_effect = ResourceExistsError("file exists")
        with self.assertRaises(ResourceExistsError):
            self.provisioner.upload(GUID, "Files/LandingZone/dbo.schema/Plants/00000000000000000001.parquet",
                                    b"parquet", publish=True)
        file.rename_file.assert_not_called()

    def test_initialized_mirror_publishes_metadata_before_data_then_starts(self):
        self.add_item("MirroredDatabase")
        self.provisioner.api.json.return_value = {"status": "Initialized"}
        self.provisioner.upload = Mock()
        self.provisioner.verify_sql = Mock()
        self.provisioner.seed_mirror()
        calls = self.provisioner.upload.call_args_list
        self.assertEqual(len(calls), 6)
        for index, table in enumerate(sample.sample_tables()):
            metadata, parquet = calls[index * 2:index * 2 + 2]
            self.assertTrue(metadata.args[1].endswith(f"{table.name}/_metadata.json"))
            self.assertEqual(json.loads(metadata.args[2]), {"keyColumns": [table.key]})
            self.assertTrue(parquet.kwargs["publish"])
        self.assertTrue(self.provisioner.api.json.call_args.args[1].endswith("/startMirroring"))
        self.provisioner.verify_sql.assert_not_called()

    def test_mirror_error_stops_before_upload(self):
        self.add_item("MirroredDatabase")
        self.provisioner.api.json.return_value = {"status": "Paused", "error": {"message": "Failed"}}
        self.provisioner.upload = Mock()
        with self.assertRaisesRegex(RuntimeError, "initialization failed"):
            self.provisioner.seed_mirror()
        self.provisioner.upload.assert_not_called()

    @patch("create_sample.Api")
    def test_kql_adapter_populates_and_verifies_eventhouse_database(self, api_type):
        self.add_item("KQLDatabase")
        self.provisioner.properties = Mock(return_value={"queryServiceUri": "https://daily-kql.invalid"})
        client = api_type.return_value
        client.base = "https://daily-kql.invalid"
        values = [{"Tables": [{"Rows": [[1]], "Columns": [{"ColumnName": "Ready"}]}]}]
        values += [{"Tables": [{"Rows": [], "Columns": []}]} for _ in range(3)]
        values += [{"Tables": [{"Columns": [{"ColumnName": name} for name, _ in table.columns],
                                "Rows": table.rows}]} for table in sample.sample_tables()]
        client.json.side_effect = values
        self.provisioner.seed_kql()
        self.assertEqual(client.json.call_count, 4)
        self.assertEqual(self.manifest.data["verified"], {})
        self.provisioner.verify_kql()
        self.assertEqual(client.json.call_count, 7)
        for call in client.json.call_args_list[1:4]:
            self.assertTrue(call.args[1].endswith("/v1/rest/mgmt"))
            self.assertEqual(call.args[2]["db"], GUID)
        self.assertTrue(all(call.kwargs["request_timeout"] == (30, 300)
                            for call in client.json.call_args_list))
        self.assertEqual(self.manifest.data["verified"]["KQLDatabase"],
                         {"Plants": 3, "Assets": 12, "Readings": 120})
        self.assertEqual(self.manifest.data["verified"]["Eventhouse"]["viaKqlDatabaseId"], GUID)

    def test_lakehouse_load_contract_and_verification(self):
        self.add_item("Lakehouse")
        self.provisioner.upload = Mock()
        self.provisioner.verify_sql = Mock()
        self.provisioner.seed_lakehouse()
        self.assertEqual(self.provisioner.api.mutate.call_count, 3)
        for call, table in zip(self.provisioner.api.mutate.call_args_list, sample.sample_tables()):
            self.assertTrue(call.args[0].endswith(f"/tables/{table.name}/load"))
            self.assertEqual(call.args[1]["formatOptions"], {"format": "Parquet"})
            self.assertEqual(call.args[1]["relativePath"], f"Files/OntologySample/{table.name}.parquet")
            self.assertFalse(call.kwargs["result_required"])
        self.provisioner.verify_sql.assert_not_called()

    def test_sql_seed_is_parameterized_and_committed(self):
        self.provisioner.sql_target = Mock(return_value=("server", "catalog"))
        self.provisioner.sql_ready = Mock()
        connection = Mock()
        self.provisioner.connect_sql = Mock(return_value=connection)
        self.provisioner.verify_sql = Mock()
        self.provisioner.seed_sql("Warehouse")
        cursor = connection.cursor.return_value
        for call, table in zip(cursor.executemany.call_args_list, sample.sample_tables()):
            self.assertEqual(call.args[0].count("?"), len(table.columns))
            self.assertEqual(call.args[1], table.rows)
        connection.commit.assert_called_once()
        connection.close.assert_called_once()
        self.provisioner.verify_sql.assert_not_called()

    def mock_kql_client(self):
        self.add_item("KQLDatabase")
        client = Mock(base="https://daily-kql.invalid")
        self.provisioner.kql_client = Mock(return_value=client)
        return client

    @patch("create_sample.time.sleep")
    def test_kql_readiness_timeout_retries_probe_before_any_ingestion(self, sleep):
        client = self.mock_kql_client()
        client.json.side_effect = [
            requests.ReadTimeout("cold endpoint"), {"Tables": [{"Rows": [[1]]}]},
            *[{"Tables": [{"Rows": [], "Columns": []}]} for _ in range(3)],
        ]
        with self.assertLogs("ontology-sample", level="WARNING"):
            self.provisioner.seed_kql()
        calls = client.json.call_args_list
        self.assertEqual([call.args[2]["csl"] for call in calls[:2]], ["print Ready = 1"] * 2)
        self.assertTrue(all(call.args[1].endswith("/v1/rest/mgmt") for call in calls[2:]))
        self.assertEqual(len(calls), 5)
        sleep.assert_called_once()
        self.assertEqual(self.manifest.data["verified"], {})

    @patch("create_sample.time.sleep")
    def test_kql_ingestion_timeout_is_not_replayed_or_marked_verified(self, sleep):
        client = self.mock_kql_client()
        error = requests.ReadTimeout("read timeout=300")
        client.json.side_effect = [{"Tables": [{"Rows": [[1]]}]}, error]
        with self.assertLogs("ontology-sample", level="ERROR") as logs, self.assertRaises(requests.ReadTimeout) as raised:
            self.provisioner.seed_kql()
        self.assertIs(raised.exception, error)
        self.assertEqual(client.json.call_count, 2)
        self.assertIn("NOT replayed", logs.output[0])
        self.assertTrue(client.json.call_args.args[1].endswith("/v1/rest/mgmt"))
        client.close.assert_called_once()
        sleep.assert_not_called()
        self.assertEqual(self.manifest.data["verified"], {})

    @patch("create_sample.time.sleep")
    def test_kql_verification_timeout_retries_only_reads_and_checks_all_rows(self, sleep):
        client = self.mock_kql_client()
        client.json.side_effect = [requests.ReadTimeout("slow query")] + [
            {"Tables": [{"Columns": [{"ColumnName": name} for name, _ in table.columns], "Rows": table.rows}]}
            for table in sample.sample_tables()
        ]
        with self.assertLogs("ontology-sample", level="WARNING"):
            self.provisioner.verify_kql()
        self.assertEqual(client.json.call_count, 4)
        self.assertTrue(all(call.args[1].endswith("/v1/rest/query") for call in client.json.call_args_list))
        sleep.assert_called_once()
        self.assertEqual(self.manifest.data["verified"]["KQLDatabase"], {"Plants": 3, "Assets": 12, "Readings": 120})
        self.assertIn("Eventhouse", self.manifest.data["verified"])

    @patch("create_sample.time.sleep")
    def test_kql_timeouts_are_bounded_for_readiness_and_verification(self, sleep):
        for method in ("seed_kql", "verify_kql"):
            with self.subTest(method=method):
                client = self.mock_kql_client()
                client.json.side_effect = requests.ReadTimeout("still unavailable")
                with patch("create_sample.time.monotonic", side_effect=[0, self.provisioner.args.timeout]), \
                        self.assertLogs("ontology-sample", level="WARNING"), self.assertRaises(TimeoutError):
                    getattr(self.provisioner, method)()
                client.json.assert_called_once()
                self.assertTrue(client.json.call_args.args[1].endswith("/v1/rest/query"))
                client.close.assert_called_once()
                self.assertEqual(self.manifest.data["verified"], {})
        sleep.assert_not_called()

    @patch("create_sample.time.sleep")
    def test_kql_permission_errors_are_not_retried(self, sleep):
        client = self.mock_kql_client()
        client.json.side_effect = RuntimeError("HTTP 403: Forbidden")
        with self.assertRaisesRegex(RuntimeError, "403"):
            self.provisioner.verify_kql()
        client.json.assert_called_once()
        sleep.assert_not_called()

    def test_kql_request_timeout_is_configurable_and_capped_by_wait_budget(self):
        client = self.mock_kql_client()
        client.json.return_value = {"Tables": [{"Rows": [[1]]}]}
        for configured, budget, expected in ((600, 1800, 600), (600, 90, 90)):
            self.provisioner.args.kql_request_timeout = configured
            self.provisioner.args.timeout = budget
            self.provisioner.kql_query(client, "print Ready = 1")
            self.assertEqual(client.json.call_args.kwargs["request_timeout"], (30, expected))

    def test_prepared_sql_metadata_is_not_refreshed_again_before_reads(self):
        self.provisioner.sql_target = Mock(return_value=("server", "catalog"))
        self.provisioner.sql_ready = Mock()
        self.provisioner.refresh_sql_metadata = Mock()
        connections = [Mock() for _ in sample.sample_tables()]
        for connection, table in zip(connections, sample.sample_tables()):
            connection.cursor.return_value.execute.return_value.fetchall.return_value = table.rows
        self.provisioner.connect_sql = Mock(side_effect=connections)
        self.provisioner.verify_sql("Lakehouse", asynchronous=True, refresh_before_read=False)
        self.provisioner.refresh_sql_metadata.assert_not_called()
        self.assertEqual(self.manifest.data["verified"]["Lakehouse"], {"Plants": 3, "Assets": 12, "Readings": 120})

    @patch("pyodbc.connect")
    def test_sql_connection_has_token_and_secure_transport(self, connect):
        self.provisioner.credential.get_token.return_value.token = "test-token"
        self.provisioner.connect_sql("host,1433", "catalog}name")
        connection_string = connect.call_args.args[0]
        self.assertIn("DATABASE={catalog}}name}", connection_string)
        self.assertIn("Encrypt=yes;TrustServerCertificate=no", connection_string)
        self.assertNotIn("test-token", connection_string)
        attribute = connect.call_args.kwargs["attrs_before"][1256]
        self.assertEqual(attribute[4:].decode("utf-16-le"), "test-token")

    def test_sql_verification_rejects_same_count_wrong_values(self):
        self.provisioner.sql_target = Mock(return_value=("server", "catalog"))
        self.provisioner.sql_ready = Mock()
        connection = Mock()
        connection.cursor.return_value.execute.return_value.fetchall.return_value = [
            ("P01", "North Plant", "Wrong"), ("P02", "South Plant", "Austin"),
            ("P03", "East Plant", "Boston"),
        ]
        self.provisioner.connect_sql = Mock(return_value=connection)
        with self.assertRaises(ValueError):
            self.provisioner.verify_sql("Warehouse")
        self.assertNotIn("Warehouse", self.manifest.data["verified"])

    def test_sql_metadata_refresh_never_recreates_tables(self):
        self.provisioner.properties = Mock(return_value={
            "sqlEndpointProperties": {"id": GUID, "provisioningStatus": "Success"}})
        self.provisioner.api.mutate.return_value = {"value": [{"tableName": "Plants", "status": "Success"}]}
        self.provisioner.refresh_sql_metadata("Lakehouse")
        call = self.provisioner.api.mutate.call_args
        self.assertTrue(call.args[0].endswith(f"/sqlEndpoints/{GUID}/refreshMetadata"))
        self.assertEqual(call.args[1], {"recreateTables": False})
        self.provisioner.api.mutate.return_value = {"value": [{"tableName": "Plants", "status": "Failed"}]}
        with self.assertRaisesRegex(RuntimeError, "metadata refresh failed"):
            self.provisioner.refresh_sql_metadata("Lakehouse")

    def test_async_sql_verification_refreshes_metadata_before_querying(self):
        self.provisioner.sql_target = Mock(return_value=("server", "catalog"))
        self.provisioner.sql_ready = Mock()
        self.provisioner.refresh_sql_metadata = Mock()
        connection = Mock()
        connection.cursor.return_value.execute.return_value.fetchall.side_effect = [
            table.rows for table in sample.sample_tables()]
        self.provisioner.connect_sql = Mock(return_value=connection)
        self.provisioner.verify_sql("Lakehouse", asynchronous=True)
        self.provisioner.refresh_sql_metadata.assert_called_once_with("Lakehouse")
        self.assertEqual(self.manifest.data["verified"]["Lakehouse"],
                         {"Plants": 3, "Assets": 12, "Readings": 120})

    def test_sql_auth_and_syntax_errors_are_not_hidden_as_readiness(self):
        self.assertFalse(self.provisioner.sql_retryable(pyodbc.Error("28000", "login failed")))
        self.assertFalse(self.provisioner.sql_retryable(pyodbc.Error("42000", "bad syntax")))
        self.assertTrue(self.provisioner.sql_retryable(pyodbc.Error("42S02", "table not ready")))
        self.assertTrue(self.provisioner.sql_retryable(pyodbc.Error("08001", "connection pending")))

    def test_sql_transition_native_code_overrides_outer_login_state_only_when_present(self):
        self.assertTrue(self.provisioner.sql_retryable(sql_transition_error()))
        for native in (952, 4060):
            self.assertTrue(self.provisioner.sql_retryable(pyodbc.Error("28000", f"Database unavailable. ({native})")))
        for native in (18456, 1952, 9520):
            self.assertFalse(self.provisioner.sql_retryable(pyodbc.Error("28000", f"Login failed. ({native})")))

    @patch("create_sample.time.sleep")
    def test_sql_readiness_retries_database_transition(self, sleep):
        connection = Mock()
        self.provisioner.connect_sql = Mock(side_effect=[sql_transition_error(), connection])
        with self.assertLogs("ontology-sample", level="WARNING") as logs:
            self.provisioner.sql_ready("server", "catalog")
        self.assertIn("(952)", logs.output[0])
        self.assertEqual(self.provisioner.connect_sql.call_count, 2)
        sleep.assert_called_once()
        connection.cursor.return_value.execute.assert_called_once_with("SELECT 1")
        connection.close.assert_called_once()

    @patch("create_sample.time.sleep")
    def test_async_sql_verification_retries_transition_after_readiness_without_reloading(self, sleep):
        for kind in ("Lakehouse", "MirroredDatabase"):
            with self.subTest(kind=kind):
                sleep.reset_mock()
                self.provisioner.sql_target = Mock(return_value=("server", "catalog"))
                self.provisioner.refresh_sql_metadata = Mock()
                connection = Mock()
                cursor = connection.cursor.return_value
                cursor.execute.return_value.fetchall.side_effect = [table.rows for table in sample.sample_tables()]
                self.provisioner.connect_sql = Mock(side_effect=[
                    connection, sql_transition_error(), connection, connection, connection])
                with self.assertLogs("ontology-sample", level="WARNING") as logs:
                    self.provisioner.verify_sql(kind, asynchronous=True)
                self.assertIn("(952)", logs.output[0])
                self.assertEqual(self.provisioner.connect_sql.call_count, 5)
                self.assertEqual(connection.close.call_count, 4)
                sleep.assert_called_once()
                self.assertTrue(all(call.args[0].startswith("SELECT ") for call in cursor.execute.call_args_list))
                self.provisioner.refresh_sql_metadata.assert_called_once_with(kind)
                self.provisioner.api.mutate.assert_not_called()
                self.assertEqual(self.manifest.data["verified"][kind], {"Plants": 3, "Assets": 12, "Readings": 120})

    @patch("create_sample.time.sleep")
    def test_sql_transition_timeout_does_not_mark_verified(self, sleep):
        self.provisioner.sql_target = Mock(return_value=("server", "catalog"))
        self.provisioner.sql_ready = Mock()
        self.provisioner.refresh_sql_metadata = Mock()
        self.provisioner.connect_sql = Mock(side_effect=sql_transition_error())
        with patch("create_sample.time.monotonic", side_effect=[0, 0, self.provisioner.args.timeout]), \
                self.assertLogs("ontology-sample", level="WARNING"), \
                self.assertRaisesRegex(TimeoutError, "Lakehouse.Plants exact sample rows"):
            self.provisioner.verify_sql("Lakehouse", asynchronous=True)
        self.assertNotIn("Lakehouse", self.manifest.data["verified"])
        self.provisioner.connect_sql.assert_called_once()
        sleep.assert_not_called()
        self.provisioner.api.mutate.assert_not_called()

    @patch("create_sample.time.sleep")
    def test_sql_real_login_failure_stops_without_retrying(self, sleep):
        error = pyodbc.InterfaceError("28000", "Login failed for user '<token-identified principal>'. (18456)")
        self.provisioner.connect_sql = Mock(side_effect=error)
        with self.assertRaises(pyodbc.InterfaceError) as raised:
            self.provisioner.sql_ready("server", "catalog")
        self.assertIs(raised.exception, error)
        self.provisioner.connect_sql.assert_called_once()
        sleep.assert_not_called()
        self.provisioner.sql_target = Mock(return_value=("server", "catalog"))
        self.provisioner.sql_ready = Mock()
        self.provisioner.refresh_sql_metadata = Mock()
        self.provisioner.connect_sql.reset_mock()
        with self.assertRaises(pyodbc.InterfaceError) as raised:
            self.provisioner.verify_sql("Lakehouse", asynchronous=True)
        self.assertIs(raised.exception, error)
        self.provisioner.connect_sql.assert_called_once()
        self.assertNotIn("Lakehouse", self.manifest.data["verified"])
        sleep.assert_not_called()

    def test_sql_snapshot_metadata_conflict_is_retryable_not_all_programming_errors(self):
        self.assertTrue(self.provisioner.sql_retryable(sql_snapshot_metadata_error()))
        for native in (102, 229, 39610, 13961):
            self.assertFalse(self.provisioner.sql_retryable(pyodbc.ProgrammingError("42000", f"SQL error ({native})")))

    @patch("create_sample.time.sleep")
    def test_sql_snapshot_metadata_conflict_reconnects_before_retrying_reads(self, sleep):
        for kind in ("Lakehouse", "MirroredDatabase"):
            for stage in ("execute", "fetchall"):
                with self.subTest(kind=kind, stage=stage):
                    sleep.reset_mock()
                    self.provisioner.sql_target = Mock(return_value=("server", "catalog"))
                    self.provisioner.sql_ready = Mock()
                    self.provisioner.refresh_sql_metadata = Mock()
                    failed = Mock()
                    cursor = failed.cursor.return_value
                    operation = cursor.execute if stage == "execute" else cursor.execute.return_value.fetchall
                    operation.side_effect = sql_snapshot_metadata_error()
                    healthy = [Mock() for _ in sample.sample_tables()]
                    for connection, table in zip(healthy, sample.sample_tables()):
                        connection.cursor.return_value.execute.return_value.fetchall.return_value = table.rows
                    self.provisioner.connect_sql = Mock(side_effect=[failed, *healthy])
                    order = Mock()
                    order.attach_mock(self.provisioner.connect_sql, "connect")
                    order.attach_mock(failed.close, "close_failed")
                    with self.assertLogs("ontology-sample", level="WARNING") as logs:
                        self.provisioner.verify_sql(kind, asynchronous=True)
                    self.assertIn("(3961)", logs.output[0])
                    self.assertEqual([call[0] for call in order.mock_calls[:3]], ["connect", "close_failed", "connect"])
                    sleep.assert_called_once()
                    self.assertEqual(self.provisioner.connect_sql.call_count, 4)
                    self.provisioner.refresh_sql_metadata.assert_called_once_with(kind)
                    self.provisioner.api.mutate.assert_not_called()
                    for connection in (failed, *healthy):
                        connection.close.assert_called_once()
                        connection.commit.assert_not_called()
                        connection.cursor.return_value.executemany.assert_not_called()
                        self.assertTrue(all(call.args[0].startswith("SELECT ")
                                            for call in connection.cursor.return_value.execute.call_args_list))
                    self.assertEqual(self.manifest.data["verified"][kind], {"Plants": 3, "Assets": 12, "Readings": 120})

    @patch("create_sample.time.sleep")
    def test_sql_snapshot_metadata_conflict_times_out_without_verifying(self, sleep):
        self.provisioner.sql_target = Mock(return_value=("server", "catalog"))
        self.provisioner.sql_ready = Mock()
        self.provisioner.refresh_sql_metadata = Mock()
        connection = Mock()
        connection.cursor.return_value.execute.side_effect = sql_snapshot_metadata_error()
        self.provisioner.connect_sql = Mock(return_value=connection)
        with patch("create_sample.time.monotonic", side_effect=[0, 0, self.provisioner.args.timeout]), \
                self.assertLogs("ontology-sample", level="WARNING"), self.assertRaises(TimeoutError):
            self.provisioner.verify_sql("Lakehouse", asynchronous=True)
        connection.close.assert_called_once()
        self.provisioner.connect_sql.assert_called_once()
        self.assertNotIn("Lakehouse", self.manifest.data["verified"])
        sleep.assert_not_called()

    @patch("create_sample.time.sleep")
    def test_sql_snapshot_metadata_conflict_during_writes_is_never_replayed(self, sleep):
        self.provisioner.sql_target = Mock(return_value=("server", "catalog"))
        self.provisioner.sql_ready = Mock()
        self.provisioner.verify_sql = Mock()
        connection = Mock()
        error = sql_snapshot_metadata_error()
        connection.cursor.return_value.executemany.side_effect = error
        self.provisioner.connect_sql = Mock(return_value=connection)
        with self.assertRaises(pyodbc.ProgrammingError) as raised:
            self.provisioner.seed_sql("Warehouse")
        self.assertIs(raised.exception, error)
        self.provisioner.connect_sql.assert_called_once()
        connection.cursor.return_value.executemany.assert_called_once()
        connection.commit.assert_not_called()
        connection.close.assert_called_once()
        self.provisioner.verify_sql.assert_not_called()
        sleep.assert_not_called()

    def test_semantic_refresh_correlated_and_rows_verified(self):
        self.add_item("SemanticModel")
        refresh = self.provisioner.args.powerbi_api + "/v1.0/myorg/refreshes/specific"
        self.provisioner.pbi.request.return_value = response(202, headers={"Location": refresh})
        results = [{"status": "Completed"}]
        for table in sample.sample_tables():
            rows = []
            for record in table.records():
                rows.append({f"[{key}]": value.isoformat() if hasattr(value, "isoformat") else value
                             for key, value in record.items()})
            results.append({"results": [{"tables": [{"rows": rows}]}]})
        self.provisioner.pbi.json.side_effect = results
        self.provisioner.seed_semantic()
        self.assertEqual(self.provisioner.pbi.json.call_count, 1)
        self.assertEqual(self.manifest.data["verified"], {})
        self.provisioner.verify_semantic()
        self.assertEqual(self.provisioner.pbi.json.call_args_list[0].args, ("GET", refresh))
        self.assertEqual(self.manifest.data["verified"]["SemanticModel"], {"Plants": 3, "Assets": 12, "Readings": 120})

    def test_semantic_failed_refresh_never_marks_success(self):
        self.add_item("SemanticModel")
        self.provisioner.pbi.request.return_value = response(202, headers={
            "Location": self.provisioner.args.powerbi_api + "/refresh/specific"})
        self.provisioner.pbi.json.return_value = {"status": "Failed", "message": "bad partition"}
        with self.assertRaisesRegex(RuntimeError, "refresh failed"):
            self.provisioner.seed_semantic()
        self.assertNotIn("SemanticModel", self.manifest.data["verified"])

    def mock_run_phases(self):
        self.provisioner.api.mutate.return_value = {"id": GUID}
        def verified(*kinds):
            self.manifest.data["verified"].update({kind: {"mock": True} for kind in kinds})
        for name in ("seed_kql", "seed_lakehouse", "seed_mirror", "seed_sql", "refresh_sql_metadata"):
            setattr(self.provisioner, name, Mock())
        self.provisioner.verify_kql = Mock(side_effect=lambda: verified("Eventhouse", "KQLDatabase"))
        self.provisioner.verify_sql = Mock(side_effect=lambda kind, **kwargs: verified(kind))

    def test_run_creates_all_seven_types_on_capacity(self):
        self.mock_run_phases()
        self.provisioner.run()
        calls = self.provisioner.api.mutate.call_args_list
        self.assertEqual(calls[0].args[1]["capacityId"], GUID)
        self.assertEqual(set(self.manifest.data["items"]), set(sample.COLLECTIONS))
        kql = calls[2].args[1]["creationPayload"]
        self.assertEqual(kql, {"databaseType": "ReadWrite", "parentEventhouseItemId": GUID})
        self.assertEqual(self.manifest.data["status"], "succeeded")

    def test_run_defers_semantic_data_without_refresh_or_queries(self):
        self.mock_run_phases()
        self.provisioner.pbi.request.side_effect = RuntimeError("HTTP 403")
        self.provisioner.pbi.json.side_effect = RuntimeError("HTTP 403")
        self.provisioner.run()
        self.provisioner.pbi.request.assert_not_called()
        self.provisioner.pbi.json.assert_not_called()
        stored = json.loads(self.manifest.path.read_text())
        self.assertEqual(stored["status"], "succeeded")
        self.assertIn("SemanticModel", stored["items"])
        self.assertNotIn("SemanticModel", stored["verified"])
        self.assertEqual(stored["deferredValidation"], {"SemanticModel": ["refresh", "sampleRows"]})
        self.assertEqual(set(stored["verified"]), set(sample.COLLECTIONS) - {"SemanticModel"})

    def test_run_cannot_succeed_when_a_source_is_not_verified(self):
        self.mock_run_phases()
        for name in ("verify_kql", "verify_sql"):
            setattr(self.provisioner, name, Mock())
        with self.assertRaisesRegex(RuntimeError, "Sources missing verification"):
            self.provisioner.run()
        self.assertNotEqual(self.manifest.data["status"], "succeeded")

    def test_skip_eventhouse_reuses_only_verified_empty_workspace(self):
        self.provisioner.args.skip_eventhouse_kql = True
        self.provisioner.args.workspace_id = GUID
        self.provisioner.api.json.side_effect = [
            {"id": GUID, "displayName": "Sample", "capacityId": GUID}, {"value": []}]
        self.mock_run_phases()
        self.provisioner.run()
        self.assertEqual(len(self.provisioner.api.mutate.call_args_list), 5)
        self.provisioner.seed_kql.assert_not_called()
        self.provisioner.verify_kql.assert_not_called()
        self.assertEqual(self.manifest.data["skipped"], ["Eventhouse", "KQLDatabase"])
        self.assertEqual(self.manifest.data["status"], "succeeded")

    @patch("create_sample.time.sleep")
    def test_all_creation_and_loads_precede_metadata_refresh_wait_and_row_reads(self, sleep):
        self.mock_run_phases()
        self.provisioner.args.settle_seconds = 300
        order = Mock()
        self.provisioner.create = Mock(wraps=self.provisioner.create)
        for name in ("create", "seed_kql", "seed_lakehouse", "seed_mirror", "seed_sql",
                     "refresh_sql_metadata", "verify_kql", "verify_sql"):
            order.attach_mock(getattr(self.provisioner, name), name)
        order.attach_mock(sleep, "sleep")
        def settling(seconds):
            self.assertEqual(set(self.manifest.data["items"]), set(sample.COLLECTIONS))
            self.assertEqual(self.manifest.data["verified"], {})
            self.assertTrue(json.loads(self.manifest.path.read_text())["sourceLoadsCompleted"])
        sleep.side_effect = settling
        self.provisioner.run()
        self.assertEqual([call[0] for call in order.mock_calls], [
            *["create"] * 7, "seed_lakehouse", "seed_mirror", "seed_sql", "seed_sql", "seed_kql",
            "refresh_sql_metadata", "refresh_sql_metadata", "sleep",
            "verify_kql", "verify_sql", "verify_sql", "verify_sql", "verify_sql",
        ])
        sleep.assert_called_once_with(300)
        sql_calls = self.provisioner.verify_sql.call_args_list
        self.assertEqual([call.args[0] for call in sql_calls], ["Lakehouse", "MirroredDatabase", "SQLDatabase", "Warehouse"])
        self.assertTrue(all(call.kwargs == {"asynchronous": True, "refresh_before_read": False}
                            for call in sql_calls[:2]))

    @patch("create_sample.time.sleep")
    def test_zero_settling_delay_does_not_skip_verification(self, sleep):
        self.mock_run_phases()
        self.provisioner.run()
        sleep.assert_not_called()
        self.assertEqual(set(self.manifest.data["verified"]), set(sample.COLLECTIONS) - {"SemanticModel"})

    @patch("create_sample.time.sleep")
    def test_failed_loading_never_waits_or_verifies_or_replays(self, sleep):
        self.mock_run_phases()
        self.provisioner.seed_kql.side_effect = requests.ReadTimeout("ingestion outcome unknown")
        with self.assertRaises(requests.ReadTimeout):
            self.provisioner.run()
        self.provisioner.seed_kql.assert_called_once()
        sleep.assert_not_called()
        self.provisioner.refresh_sql_metadata.assert_not_called()
        self.provisioner.verify_kql.assert_not_called()
        self.provisioner.verify_sql.assert_not_called()
        self.provisioner.pbi.json.assert_not_called()
        self.assertNotIn("sourceLoadsCompleted", self.manifest.data)
        self.assertNotEqual(self.manifest.data["status"], "succeeded")

    @patch("create_sample.time.sleep", side_effect=KeyboardInterrupt)
    def test_interrupted_settling_preserves_loaded_items_without_success(self, sleep):
        self.mock_run_phases()
        self.provisioner.args.settle_seconds = 120
        with self.assertRaises(KeyboardInterrupt):
            self.provisioner.run()
        stored = json.loads(self.manifest.path.read_text())
        self.assertTrue(stored["sourceLoadsCompleted"])
        self.assertEqual(set(stored["items"]), set(sample.COLLECTIONS))
        self.assertEqual(stored["verified"], {})
        self.assertNotEqual(stored["status"], "succeeded")

    @patch("create_sample.time.sleep")
    def test_metadata_refresh_failure_stops_before_wait_and_verification(self, sleep):
        self.mock_run_phases()
        self.provisioner.args.settle_seconds = 120
        self.provisioner.refresh_sql_metadata.side_effect = RuntimeError("metadata refresh failed")
        with self.assertRaisesRegex(RuntimeError, "metadata refresh failed"):
            self.provisioner.run()
        sleep.assert_not_called()
        self.provisioner.verify_kql.assert_not_called()
        self.provisioner.verify_sql.assert_not_called()
        self.provisioner.pbi.json.assert_not_called()
        self.assertTrue(self.manifest.data["sourceLoadsCompleted"])
        self.assertNotEqual(self.manifest.data["status"], "succeeded")

    def test_reuse_rejects_nonempty_workspace_or_wrong_capacity_before_writes(self):
        self.provisioner.args.workspace_id = GUID
        for workspace, items in (
            ({"id": GUID, "displayName": "Sample", "capacityId": GUID}, {"value": [{"id": GUID}]}),
            ({"id": GUID, "displayName": "Sample", "capacityId": "other"}, {"value": []}),
            ({"id": GUID, "displayName": "Other", "capacityId": GUID}, {"value": []}),
            ({"id": GUID, "displayName": "Sample", "capacityId": GUID}, {"value": [], "continuationToken": "more"}),
        ):
            self.provisioner.api.json.side_effect = [workspace, items]
            with self.assertRaises(RuntimeError):
                self.provisioner.run()
        self.provisioner.api.mutate.assert_not_called()

    def test_run_stops_after_failure_preserving_created_ids(self):
        self.provisioner.api.mutate.side_effect = [{"id": GUID}, {"id": GUID}, RuntimeError("KQL unavailable")]
        with self.assertRaisesRegex(RuntimeError, "KQL unavailable"):
            self.provisioner.run()
        stored = json.loads(self.manifest.path.read_text())
        self.assertEqual(stored["workspaceId"], GUID)
        self.assertEqual(set(stored["items"]), {"Eventhouse"})
        self.assertNotEqual(stored["status"], "succeeded")


class StorageResponse(HttpResponse):
    def __init__(self, request, status):
        super().__init__(request, None)
        self.status_code = status
        self.headers = CaseInsensitiveDict({"etag": '"created-etag"', "content-type": "application/json"})
        if status == 412:
            self.headers["x-ms-error-code"] = "ConditionNotMet"
        self.reason = "Precondition Failed" if status == 412 else "Created"
        self.content_type = "application/json"

    def body(self):
        if self.status_code == 412:
            return b'{"error":{"code":"ConditionNotMet","message":"File already exists"}}'
        return b""

    def text(self, encoding=None):
        return self.body().decode(encoding or "utf-8")


class StorageTransport(HttpTransport):
    def __init__(self, existing=False):
        self.requests = []
        self.existing = existing

    def open(self):
        pass

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def send(self, request, **kwargs):
        unexpected = {"etag", "match_condition"} & kwargs.keys()
        if unexpected:
            raise TypeError(f"Unsupported HTTP transport arguments: {sorted(unexpected)}")
        self.requests.append(request)
        action = parse_qs(urlsplit(request.url).query).get("action", [None])[0]
        status = {"append": 202, "flush": 200}.get(action, 201)
        return StorageResponse(request, 412 if self.existing else status)


class StorageContractTests(unittest.TestCase):
    def upload(self, existing=False):
        transport = StorageTransport(existing)
        client = DataLakeFileClient(
            "https://daily-onelake.dfs.fabric.microsoft.com", GUID,
            f"{GUID}/Files/Plants.parquet", credential=None, transport=transport,
            retry_total=0)
        self.addCleanup(client.close)
        return client, transport

    def test_actual_sdk_creates_before_append_and_flush_with_exclusive_condition(self):
        client, transport = self.upload()
        client.upload_data(b"sample", overwrite=True, match_condition=MatchConditions.IfMissing)
        self.assertEqual([r.method for r in transport.requests], ["PUT", "PATCH", "PATCH"])
        create, append, flush = transport.requests
        self.assertEqual(create.headers["If-None-Match"], "*")
        self.assertEqual(parse_qs(urlsplit(create.url).query)["resource"], ["file"])
        self.assertEqual(parse_qs(urlsplit(append.url).query)["action"], ["append"])
        self.assertEqual(parse_qs(urlsplit(flush.url).query)["action"], ["flush"])
        self.assertEqual(flush.headers["If-Match"], '"created-etag"')

    def test_actual_sdk_existing_file_rejected_before_append(self):
        client, transport = self.upload(existing=True)
        with self.assertRaises(HttpResponseError):
            client.upload_data(b"sample", overwrite=True, match_condition=MatchConditions.IfMissing)
        self.assertEqual(len(transport.requests), 1)
        self.assertEqual(transport.requests[0].method, "PUT")

    def test_transport_rejects_redundant_etag(self):
        client, _ = self.upload()
        with self.assertRaisesRegex(TypeError, "Unsupported HTTP transport arguments"):
            client.upload_data(b"sample", overwrite=True, etag="*", match_condition=MatchConditions.IfMissing)

    def test_requests_transport_accepts_exclusive_upload_and_rejects_redundant_etag(self):
        session = requests.Session()
        self.addCleanup(session.close)

        def respond(method, url, **kwargs):
            action = parse_qs(urlsplit(url).query).get("action", [None])[0]
            result = requests.Response()
            result.status_code = {"append": 202, "flush": 200}.get(action, 201)
            result.headers = CaseInsensitiveDict({"ETag": '"created-etag"'})
            result._content = b""
            result.raw = io.BytesIO(b"")
            return result

        with patch.object(session, "request", autospec=True, side_effect=respond) as request:
            with DataLakeFileClient(
                "https://daily-onelake.dfs.fabric.microsoft.com", GUID,
                f"{GUID}/Files/Plants.parquet", credential=None,
                transport=RequestsTransport(session=session, session_owner=False),
                retry_total=0,
            ) as client:
                client.upload_data(b"sample", overwrite=True, match_condition=MatchConditions.IfMissing)
                self.assertEqual([c.args[0] for c in request.call_args_list], ["PUT", "PATCH", "PATCH"])
                self.assertEqual(request.call_args_list[0].kwargs["headers"]["If-None-Match"], "*")
                request.reset_mock()
                with self.assertRaisesRegex(TypeError, "etag"):
                    client.upload_data(b"sample", overwrite=True, etag="*",
                                       match_condition=MatchConditions.IfMissing)
                request.assert_not_called()


class SafetyTests(unittest.TestCase):
    def test_wait_defaults_and_invalid_settings(self):
        defaults = args()
        self.assertEqual(defaults.settle_seconds, 120)
        self.assertEqual(defaults.kql_request_timeout, 300)
        base = ["--tenant-id", GUID, "--capacity-id", GUID, "--workspace-name", "Sample"]
        for flag, value in (("--settle-seconds", "-1"), ("--settle-seconds", "86401"),
                            ("--kql-request-timeout", "29"), ("--kql-request-timeout", "3601")):
            with self.subTest(flag=flag, value=value), patch("sys.stderr", io.StringIO()), self.assertRaises(SystemExit):
                sample.arguments(base + [flag, value])

    def test_manifest_refuses_replay_and_persists_progress(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "manifest.json"
            manifest = sample.Manifest(path, {})
            manifest.step("Creating")
            manifest.operation(BASE + "/operations/op")
            stored = json.loads(path.read_text())
            self.assertEqual(stored["pendingOperation"], BASE + "/operations/op")
            with self.assertRaises(FileExistsError):
                sample.Manifest(path, {})
            self.assertFalse(path.with_suffix(".json.tmp").exists())

    @patch("azure.identity.AzureCliCredential")
    def test_preview_does_not_authenticate_or_write(self, credential):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "manifest.json"
            output = io.StringIO()
            with redirect_stdout(output):
                sample.main(["--tenant-id", GUID, "--capacity-id", GUID,
                             "--workspace-name", "Preview", "--manifest", str(path)])
            credential.assert_not_called()
            self.assertFalse(path.exists())
            self.assertEqual(len(json.loads(output.getvalue())["sources"]), 7)

    def test_endpoint_validation(self):
        for url in ("http://host", "https://user:secret@host", "https://host?token=secret", "https://host/#fragment"):
            with self.assertRaises(ValueError):
                sample.https_url(url)
        self.assertEqual(sample.same_origin_url(BASE, "/v1/operations/id"), BASE + "/operations/id")

    @patch("create_sample.time.sleep")
    @patch("create_sample.time.monotonic", side_effect=[0, 31])
    def test_wait_is_bounded(self, monotonic, sleep):
        with self.assertRaises(TimeoutError):
            sample.wait_for(lambda: False, 30, "replication")
        sleep.assert_not_called()


if __name__ == "__main__":
    unittest.main()
