import io
import os
import subprocess
import unittest
from contextlib import ExitStack
from unittest.mock import call, patch

from azure.core.exceptions import ClientAuthenticationError, HttpResponseError
from azure.identity import CredentialUnavailableError

import sample_auth

TENANT = "11111111-1111-4111-8111-111111111111"
CLIENT = "22222222-2222-4222-8222-222222222222"
AZ = r"C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd"


class SampleAuthTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.cli_type = self.stack.enter_context(patch("sample_auth.AzureCliCredential"))
        self.browser_type = self.stack.enter_context(patch("sample_auth.InteractiveBrowserCredential"))
        self.cli = self.cli_type.return_value
        self.browser = self.browser_type.return_value
        self.which = self.stack.enter_context(patch("sample_auth.shutil.which", return_value=AZ))
        self.run = self.stack.enter_context(patch("sample_auth.subprocess.run"))
        self.prompt = self.stack.enter_context(patch("builtins.input"))
        self.prompt.side_effect = AssertionError("Unexpected interactive prompt")
        self.tty = self.stack.enter_context(patch("sample_auth.sys.stdin.isatty", return_value=True))
        self.stderr = self.stack.enter_context(patch("sample_auth.sys.stderr", new_callable=io.StringIO))

    def cache_miss(self):
        self.cli.get_token.side_effect = ClientAuthenticationError("sensitive authentication details")

    def test_cli_cache_is_reused_and_closed(self):
        self.tty.return_value = False
        with sample_auth.open_credential(TENANT) as credential:
            self.assertIs(credential, self.cli)
            self.cli.close.assert_not_called()
        self.cli_type.assert_called_once_with(tenant_id=TENANT)
        self.cli.get_token.assert_called_once_with(sample_auth.PBI_SCOPE)
        self.cli.close.assert_called_once()
        self.prompt.assert_not_called()
        self.which.assert_not_called()
        self.run.assert_not_called()
        self.browser_type.assert_not_called()

    def test_cli_browser_launch_uses_child_only_settings(self):
        self.cli.get_token.side_effect = [ClientAuthenticationError("expired"), object()]
        self.prompt.side_effect = ["yes"]
        with patch.dict(os.environ, {
            "AZURE_CORE_ENABLE_BROKER_ON_WINDOWS": "true",
            "AZURE_CORE_LOGIN_EXPERIENCE_V2": "on",
            "SAMPLE_AUTH_TEST": "unchanged",
        }):
            original = dict(os.environ)
            with sample_auth.open_credential(TENANT) as credential:
                self.assertIs(credential, self.cli)
            self.assertEqual(dict(os.environ), original)
        self.run.assert_called_once()
        args, kwargs = self.run.call_args
        self.assertEqual(args[0], [
            AZ, "login", "--tenant", TENANT, "--allow-no-subscriptions", "--output", "none",
        ])
        expected_env = dict(original)
        expected_env["AZURE_CORE_ENABLE_BROKER_ON_WINDOWS"] = "false"
        expected_env["AZURE_CORE_LOGIN_EXPERIENCE_V2"] = "off"
        self.assertEqual(kwargs, {"env": expected_env, "check": True, "shell": False})
        self.assertIn("SYSTEM BROWSER", self.prompt.call_args.args[0])
        self.assertIn("Cached Azure CLI authentication failed", self.stderr.getvalue())
        self.assertEqual(self.cli.get_token.call_args_list, [call(sample_auth.PBI_SCOPE)] * 2)
        self.browser_type.assert_not_called()
        self.cli.close.assert_called_once()

    def test_unavailable_cli_offers_approved_browser(self):
        self.cli.get_token.side_effect = CredentialUnavailableError("not installed")
        self.which.return_value = None
        self.prompt.side_effect = ["y"]
        with sample_auth.open_credential(TENANT, client_id=CLIENT) as credential:
            self.assertIs(credential, self.browser)
            self.cli.close.assert_called_once()
        self.assertIn("unavailable on PATH", self.stderr.getvalue())
        self.run.assert_not_called()
        self.browser.authenticate.assert_called_once_with(scopes=[sample_auth.PBI_SCOPE])
        self.browser.close.assert_called_once()

    def test_cli_decline_offers_browser_and_prompts_for_approved_client(self):
        self.cache_miss()
        self.prompt.side_effect = ["n", "y", CLIENT]
        with sample_auth.open_credential(TENANT) as credential:
            self.assertIs(credential, self.browser)
        self.assertEqual(self.prompt.call_count, 3)
        self.assertIn("different application", self.prompt.call_args_list[1].args[0])
        self.assertIn("Organization-approved", self.prompt.call_args_list[2].args[0])
        self.browser_type.assert_called_once_with(
            tenant_id=TENANT, client_id=CLIENT, redirect_uri="http://localhost:8400",
            disable_automatic_authentication=True,
        )
        self.run.assert_not_called()
        self.cli.close.assert_called_once()
        self.browser.close.assert_called_once()

    def test_cli_subprocess_failure_offers_browser_without_printing_exception(self):
        self.cache_miss()
        self.prompt.side_effect = ["y", "y"]
        self.run.side_effect = subprocess.CalledProcessError(1, ["az"], stderr="secret")
        with sample_auth.open_credential(TENANT, client_id=CLIENT) as credential:
            self.assertIs(credential, self.browser)
        self.assertIn("system-browser login failed", self.stderr.getvalue())
        self.assertNotIn("secret", self.stderr.getvalue())
        self.assertNotIn("sensitive", self.stderr.getvalue())
        self.cli.close.assert_called_once()

    def test_cli_executable_disappears_offers_browser(self):
        self.cache_miss()
        self.prompt.side_effect = ["y", "y"]
        self.run.side_effect = FileNotFoundError("az")
        with sample_auth.open_credential(TENANT, client_id=CLIENT) as credential:
            self.assertIs(credential, self.browser)
        self.assertIn("FileNotFoundError", self.stderr.getvalue())

    def test_cli_post_login_token_failure_offers_browser(self):
        self.cache_miss()
        self.prompt.side_effect = ["y", "y"]
        with sample_auth.open_credential(TENANT, client_id=CLIENT) as credential:
            self.assertIs(credential, self.browser)
        self.assertIn("after browser login failed", self.stderr.getvalue())
        self.assertEqual(self.cli.get_token.call_count, 2)

    def test_cli_mode_never_switches_client_after_decline(self):
        self.cache_miss()
        self.prompt.side_effect = ["n"]
        with self.assertRaisesRegex(sample_auth.AuthenticationCancelled, "never switches"):
            with sample_auth.open_credential(TENANT, mode="cli", client_id=CLIENT):
                self.fail("No credential should be yielded")
        self.assertEqual(self.prompt.call_count, 1)
        self.browser_type.assert_not_called()
        self.cli.close.assert_called_once()

    def test_cli_mode_can_use_system_browser_login(self):
        self.cli.get_token.side_effect = [ClientAuthenticationError("expired"), object()]
        self.prompt.side_effect = ["y"]
        with sample_auth.open_credential(TENANT, mode="cli") as credential:
            self.assertIs(credential, self.cli)
        self.run.assert_called_once()
        self.browser_type.assert_not_called()

    def test_cli_mode_stops_after_failed_login(self):
        self.cache_miss()
        self.prompt.side_effect = ["y"]
        self.run.side_effect = subprocess.CalledProcessError(1, ["az"])
        with self.assertRaisesRegex(sample_auth.AuthenticationCancelled, "cli mode"):
            with sample_auth.open_credential(TENANT, mode="cli"):
                self.fail("No credential should be yielded")
        self.assertEqual(self.prompt.call_count, 1)
        self.browser_type.assert_not_called()
        self.cli.close.assert_called_once()

    def test_cli_mode_unavailable_stops_without_prompt(self):
        self.cache_miss()
        self.which.return_value = None
        with self.assertRaisesRegex(sample_auth.AuthenticationCancelled, "cli mode"):
            with sample_auth.open_credential(TENANT, mode="cli"):
                self.fail("No credential should be yielded")
        self.prompt.assert_not_called()
        self.browser_type.assert_not_called()
        self.cli.close.assert_called_once()

    def test_browser_mode_direct_approved_client_uses_memory_cache(self):
        with sample_auth.open_credential(TENANT, mode="browser", client_id=CLIENT) as credential:
            self.assertIs(credential, self.browser)
            self.browser.close.assert_not_called()
        self.cli_type.assert_not_called()
        self.prompt.assert_not_called()
        self.run.assert_not_called()
        self.browser_type.assert_called_once_with(
            tenant_id=TENANT, client_id=CLIENT, redirect_uri="http://localhost:8400",
            disable_automatic_authentication=True,
        )
        self.browser.authenticate.assert_called_once_with(scopes=[sample_auth.PBI_SCOPE])
        self.browser.get_token.assert_called_once_with(sample_auth.PBI_SCOPE)
        self.browser.close.assert_called_once()

    def test_browser_mode_prompts_for_client_only_when_needed(self):
        self.prompt.side_effect = [CLIENT]
        with sample_auth.open_credential(TENANT, mode="browser"):
            pass
        self.prompt.assert_called_once()
        self.assertEqual(self.browser_type.call_args.kwargs["client_id"], CLIENT)
        self.cli_type.assert_not_called()

    def test_no_approved_client_stops_without_default_client(self):
        self.prompt.side_effect = [""]
        with self.assertRaisesRegex(sample_auth.AuthenticationCancelled, "approved public client"):
            with sample_auth.open_credential(TENANT, mode="browser"):
                self.fail("No credential should be yielded")
        self.browser_type.assert_not_called()

    def test_explicit_blank_client_stops_without_prompt(self):
        with self.assertRaisesRegex(sample_auth.AuthenticationCancelled, "approved public client"):
            with sample_auth.open_credential(TENANT, mode="browser", client_id=" "):
                self.fail("No credential should be yielded")
        self.browser_type.assert_not_called()
        self.prompt.assert_not_called()

    def test_declining_both_options_closes_failed_cli(self):
        self.cache_miss()
        self.prompt.side_effect = ["n", "n"]
        with self.assertRaisesRegex(sample_auth.AuthenticationCancelled, "declined"):
            with sample_auth.open_credential(TENANT):
                self.fail("No credential should be yielded")
        self.cli.close.assert_called_once()
        self.browser_type.assert_not_called()

    def test_explicit_cancel_does_not_fall_back(self):
        self.cache_miss()
        self.prompt.side_effect = ["q"]
        with self.assertRaisesRegex(sample_auth.AuthenticationCancelled, "cancelled"):
            with sample_auth.open_credential(TENANT):
                self.fail("No credential should be yielded")
        self.assertEqual(self.prompt.call_count, 1)
        self.cli.close.assert_called_once()
        self.browser_type.assert_not_called()

    def test_eof_stops_and_closes_cli(self):
        self.cache_miss()
        self.prompt.side_effect = EOFError
        with self.assertRaisesRegex(sample_auth.AuthenticationCancelled, "cancelled"):
            with sample_auth.open_credential(TENANT):
                self.fail("No credential should be yielded")
        self.cli.close.assert_called_once()
        self.run.assert_not_called()
        self.browser_type.assert_not_called()

    def test_ctrl_c_at_prompt_stops_and_closes_cli(self):
        self.cache_miss()
        self.prompt.side_effect = KeyboardInterrupt
        with self.assertRaisesRegex(sample_auth.AuthenticationCancelled, "cancelled"):
            with sample_auth.open_credential(TENANT):
                self.fail("No credential should be yielded")
        self.cli.close.assert_called_once()
        self.browser_type.assert_not_called()

    def test_ctrl_c_during_cli_login_stops_without_fallback(self):
        self.cache_miss()
        self.prompt.side_effect = ["y"]
        self.run.side_effect = KeyboardInterrupt
        with self.assertRaisesRegex(sample_auth.AuthenticationCancelled, "cancelled"):
            with sample_auth.open_credential(TENANT):
                self.fail("No credential should be yielded")
        self.cli.close.assert_called_once()
        self.browser_type.assert_not_called()
        self.assertEqual(self.prompt.call_count, 1)

    def test_noninteractive_cache_miss_stops_without_launching(self):
        self.cache_miss()
        self.tty.return_value = False
        with self.assertRaisesRegex(sample_auth.AuthenticationCancelled, "requires a terminal"):
            with sample_auth.open_credential(TENANT):
                self.fail("No credential should be yielded")
        self.prompt.assert_not_called()
        self.run.assert_not_called()
        self.browser_type.assert_not_called()
        self.cli.close.assert_called_once()

    def test_noninteractive_browser_mode_stops_even_with_client_id(self):
        self.tty.return_value = False
        with self.assertRaisesRegex(sample_auth.AuthenticationCancelled, "requires a terminal"):
            with sample_auth.open_credential(TENANT, mode="browser", client_id=CLIENT):
                self.fail("No credential should be yielded")
        self.browser_type.assert_not_called()

    def test_browser_auth_failure_closes_and_propagates(self):
        error = ClientAuthenticationError("sensitive browser details")
        self.browser.authenticate.side_effect = error
        with self.assertRaises(ClientAuthenticationError) as raised:
            with sample_auth.open_credential(TENANT, mode="browser", client_id=CLIENT):
                self.fail("No credential should be yielded")
        self.assertIs(raised.exception, error)
        self.assertNotIn("sensitive", self.stderr.getvalue())
        self.browser.close.assert_called_once()
        self.cli_type.assert_not_called()

    def test_browser_cancel_closes_and_stops(self):
        self.browser.authenticate.side_effect = KeyboardInterrupt
        with self.assertRaisesRegex(sample_auth.AuthenticationCancelled, "cancelled"):
            with sample_auth.open_credential(TENANT, mode="browser", client_id=CLIENT):
                self.fail("No credential should be yielded")
        self.browser.close.assert_called_once()

    def test_failed_browser_fallback_closes_both_credentials(self):
        self.cache_miss()
        self.prompt.side_effect = ["n", "y"]
        self.browser.authenticate.side_effect = ClientAuthenticationError("policy denied")
        with self.assertRaises(ClientAuthenticationError):
            with sample_auth.open_credential(TENANT, client_id=CLIENT):
                self.fail("No credential should be yielded")
        self.cli.close.assert_called_once()
        self.browser.close.assert_called_once()
        self.browser_type.assert_called_once()

    def test_browser_initial_token_failure_closes(self):
        self.browser.get_token.side_effect = ClientAuthenticationError("token rejected")
        with self.assertRaises(ClientAuthenticationError):
            with sample_auth.open_credential(TENANT, mode="browser", client_id=CLIENT):
                self.fail("No credential should be yielded")
        self.browser.close.assert_called_once()

    def test_downstream_scopes_reuse_one_credential(self):
        scopes = [
            sample_auth.PBI_SCOPE, "https://storage.azure.com/.default",
            "https://database.windows.net/.default", "https://kusto.kusto.windows.net/.default",
        ]
        with sample_auth.open_credential(TENANT) as credential:
            for scope in scopes:
                credential.get_token(scope)
        self.assertEqual(self.cli.get_token.call_args_list, [
            call(sample_auth.PBI_SCOPE), *(call(scope) for scope in scopes),
        ])
        self.cli_type.assert_called_once()
        self.browser_type.assert_not_called()

    def test_later_cli_scope_auth_failure_never_falls_back(self):
        error = ClientAuthenticationError("Storage scope rejected")
        self.cli.get_token.side_effect = [object(), error]
        with self.assertRaises(ClientAuthenticationError) as raised:
            with sample_auth.open_credential(TENANT) as credential:
                credential.get_token("https://storage.azure.com/.default")
        self.assertIs(raised.exception, error)
        self.prompt.assert_not_called()
        self.browser_type.assert_not_called()
        self.cli.close.assert_called_once()

    def test_later_browser_scope_auth_failure_never_reauthenticates(self):
        error = ClientAuthenticationError("SQL scope rejected")
        self.browser.get_token.side_effect = [object(), error]
        with self.assertRaises(ClientAuthenticationError) as raised:
            with sample_auth.open_credential(TENANT, mode="browser", client_id=CLIENT) as credential:
                credential.get_token("https://database.windows.net/.default")
        self.assertIs(raised.exception, error)
        self.browser.authenticate.assert_called_once()
        self.browser.close.assert_called_once()
        self.cli_type.assert_not_called()

    def test_http_error_from_body_never_triggers_fallback(self):
        error = HttpResponseError("Forbidden")
        with self.assertRaises(HttpResponseError) as raised:
            with sample_auth.open_credential(TENANT):
                raise error
        self.assertIs(raised.exception, error)
        self.prompt.assert_not_called()
        self.browser_type.assert_not_called()
        self.cli.close.assert_called_once()

    def test_unexpected_initial_error_propagates_without_fallback(self):
        self.cli.get_token.side_effect = ValueError("programming error")
        with self.assertRaisesRegex(ValueError, "programming error"):
            with sample_auth.open_credential(TENANT):
                self.fail("No credential should be yielded")
        self.prompt.assert_not_called()
        self.browser_type.assert_not_called()
        self.cli.close.assert_called_once()

    def test_body_interrupt_is_not_interpreted_as_initial_auth_failure(self):
        with self.assertRaises(KeyboardInterrupt):
            with sample_auth.open_credential(TENANT):
                raise KeyboardInterrupt
        self.cli.close.assert_called_once()
        self.prompt.assert_not_called()
        self.browser_type.assert_not_called()

    def test_invalid_mode_rejected_before_authentication(self):
        with self.assertRaisesRegex(ValueError, "mode"):
            with sample_auth.open_credential(TENANT, mode="device"):
                self.fail("No credential should be yielded")
        self.cli_type.assert_not_called()
        self.browser_type.assert_not_called()

    def test_invalid_tenant_rejected_before_subprocess(self):
        with self.assertRaisesRegex(ValueError, "Tenant ID"):
            with sample_auth.open_credential("tenant & unexpected command"):
                self.fail("No credential should be yielded")
        self.cli_type.assert_not_called()
        self.run.assert_not_called()

    def test_invalid_client_is_not_replaced_with_another_client(self):
        with self.assertRaisesRegex(ValueError, "Public client application ID"):
            with sample_auth.open_credential(TENANT, mode="browser", client_id="invalid"):
                self.fail("No credential should be yielded")
        self.browser_type.assert_not_called()
        self.prompt.assert_not_called()


if __name__ == "__main__":
    unittest.main()
