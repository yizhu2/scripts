"""Opt-in UX scripting with in-memory workload credentials and explicit private routing."""

from contextlib import contextmanager, closing
import re
import time
from urllib.parse import urlsplit
from uuid import UUID

from create_ontology import (
    build_extension_script, require_empty_definition, verify_definition, verify_existing_content,
    resolution_issues, verify_resolution_health, verify_script_result, workload_api,
)
from create_sample import Api, PBI_SCOPE, https_url
from replace_ontology import normalize_public_sql_bindings, normalize_tom_defaults

DAILY_METADATA_API = "https://wabi-daily-us-east2-redirect.analysis.windows.net"
RESOLUTION_READ_ATTEMPTS = 3
RESOLUTION_RETRY_SECONDS = 30


def trusted_origin(value):
    if not isinstance(value, str) or re.search(r"\s|\\", value):
        raise ValueError("UX endpoints cannot contain whitespace or backslashes")
    origin = https_url(value)
    parsed = urlsplit(origin)
    if (parsed.path or parsed.port is not None or not re.fullmatch(r"[a-z0-9]+(?:[a-z0-9.-]*[a-z0-9])?", parsed.hostname)
            or not any(parsed.hostname.endswith(suffix) for suffix in (
                ".analysis.windows.net", ".pbidedicated.windows.net", ".dailyapi.fabric.microsoft.com",
                ".daily-c.fabric.microsoft.com",
            ))):
        raise ValueError("UX endpoints must be HTTPS Microsoft service origins, without paths or ports")
    return origin.lower()


def workload_host(value):
    if not isinstance(value, str) or not value or any(char in value for char in "/:@?#\\"):
        raise ValueError("UX workload host must be a hostname, not a URL, token, or path")
    return urlsplit(trusted_origin("https://" + value)).hostname


def routing(network, metadata_api=None, expected_host=None):
    if network not in ("public", "wspl", "tenantpl"):
        raise ValueError("Unknown target network for UX authoring")
    if network != "public" and (not metadata_api or not expected_host):
        raise ValueError(
            "Private-link UX mode requires --ux-metadata-api and --ux-workload-host from the working UX's "
            "generatemwctoken call. Supply only the origin and TargetUriHost, never its token."
        )
    origin = trusted_origin(metadata_api or DAILY_METADATA_API)
    if network != "public" and origin == DAILY_METADATA_API:
        raise ValueError("Private-link UX mode cannot use the default public Daily metadata endpoint")
    return origin, workload_host(expected_host) if expected_host else None


@contextmanager
def open_workload(args, credential, target_metadata, item_id):
    origin, expected_host = routing(args.target_network, args.ux_metadata_api, args.ux_workload_host)
    target_state = {
        "workspaceId": str(UUID(args.workspace_id)),
        "capacityId": str(UUID(target_metadata["capacityId"])),
    }

    def validate_host(host):
        actual = workload_host(host)
        if expected_host and actual != expected_host:
            raise RuntimeError(
                "MWC routing host does not match --ux-workload-host; no workload call was made. "
                "Check the target workspace's UX route; do not substitute a public endpoint."
            )

    with closing(Api(origin, PBI_SCOPE, credential, args.timeout, sensitive_response=True)) as pbi:
        try:
            workload = workload_api(pbi, target_state, item_id, args.timeout,
                                    validate_host=validate_host, routing_mode="direct",
                                    token_version=args.ux_token_version)
        except RuntimeError as error:
            raise RuntimeError(
                f"UX workload-token acquisition failed: {error}. "
                "Compare the metadata origin and expected host with the working provisioning/UX MWC request; "
                "WSPL may require its workspace-specific metadata origin, not the tenant-wide origin. "
                "A 403 alone does not distinguish routing, policy or application permissions. "
                "No alternate login or public fallback was attempted."
            ) from error
        with closing(workload) as api:
            yield api


def workspace_routing(config, prefix):
    """Share workspace routing; retain explicit service overrides and public defaults."""
    origin, host = config.get(prefix + "_metadata_api"), config.get(prefix + "_workload_host")
    if origin or host:
        if config["target_network"] != "public" and (not origin or not host):
            raise ValueError(f"Set both {prefix}_metadata_api and {prefix}_workload_host, "
                             "or clear both to use workspace routing")
        origin = origin or config.get("ux_metadata_api")
        host = host or config.get("ux_workload_host")
    else:
        origin, host = config.get("ux_metadata_api"), config.get("ux_workload_host")
    return routing(config["target_network"], origin, host)


def read_resolved_definitions(api, path, manifest):
    for attempt in range(1, RESOLUTION_READ_ATTEMPTS + 1):
        manifest.data["storedDefinition"] = api.json("GET", path)
        manifest.save()
        expanded = api.json("GET", path, params={"expand": "true"})
        manifest.data["expandedDefinition"] = expanded
        issues = resolution_issues(expanded)
        manifest.data.setdefault("resolutionReadAttempts", []).append({
            "attempt": attempt, "issues": issues, "expandedDefinition": expanded,
        })
        manifest.save()
        if not issues:
            manifest.data["resolutionHealth"] = "No reported resolution failures on the final expanded read"
            manifest.save()
            return expanded
        transient = all(issue["state"] == "Failed" and issue["errors"] == ["ResolutionUnavailable"]
                        for issue in issues)
        if not transient or attempt == RESOLUTION_READ_ATTEMPTS:
            verify_resolution_health(expanded)
        manifest.step(
            f"Resolver unavailable on read {attempt}/{RESOLUTION_READ_ATTEMPTS}; "
            f"waiting {RESOLUTION_RETRY_SECONDS}s before a read-only retry. No writes will be replayed")
        time.sleep(RESOLUTION_RETRY_SECONDS)
    raise RuntimeError("Resolution read attempts exhausted")


def author_and_verify(args, credential, target_metadata, item, expected, manifest, *,
                      baseline=None, additions=None, source_state=None):
    hybrid = baseline is not None
    if hybrid and (additions is None or source_state is None):
        raise ValueError("Hybrid authoring requires the baseline, additions and source inventory")
    before_expanded = None
    if hybrid:
        manifest.data["authoringPhase"] = "ux-verification" if args.verify_only else "ux-extension"
    manifest.step("Acquiring an in-memory UX workload token for the target ontology")
    with open_workload(args, credential, target_metadata, item["id"]) as api:
        path = f"{api.base}/v4/workspaces/{args.workspace_id}/ontologies/{item['id']}/definition"
        manifest.data["uxWorkloadApi"] = api.base
        if not args.verify_only:
            existing = api.json("GET", path)
            manifest.data["beforeDefinition"] = existing
            manifest.save()
            if not hybrid:
                require_empty_definition(existing)
            # The existing UX builder relies on the server projecting entities from backing tables.
            expanded = api.json("GET", path, params={"expand": "true"})
            manifest.data["beforeExpandedDefinition"] = expanded
            manifest.save()
            if hybrid:
                verify_definition(
                    normalize_public_sql_bindings(baseline, expanded, source_state, args.workspace_id),
                    normalize_tom_defaults(expanded))
                before_expanded = expanded
            else:
                require_empty_definition(expanded)
            script = build_extension_script(additions if hybrid else expected, expanded)
            manifest.data["authoredScript"] = script
            manifest.step("Writing source bindings through one transactional UX definition script")
            response = api.request("POST", path + "/scripts", script, request_timeout=args.timeout)
            if response.status_code != 200:
                raise RuntimeError("Unexpected UX script response status; inspect the ontology before retrying")
            manifest.data["writeCompleted"] = True
            if hybrid:
                manifest.data["uxWriteCompleted"] = True
                manifest.data["authoringPhase"] = "ux-verification"
            manifest.save()
            result = response.json()
            manifest.data["scriptResult"] = result
            manifest.save()
            verify_script_result(script, result)

        manifest.step("Reading and validating the UX definition without ALM export")
        expanded = read_resolved_definitions(api, path, manifest)
        verification_expected = (
            normalize_public_sql_bindings(expected, expanded, source_state, args.workspace_id)
            if hybrid else expected)
        verify_definition(verification_expected, normalize_tom_defaults(expanded))
        if before_expanded is not None:
            verify_existing_content(normalize_tom_defaults(before_expanded), normalize_tom_defaults(expanded))
        model = expected["model"]
        manifest.data["verified"]["uxDefinition"] = {
            "entities": len(model["entities"]), "boundTables": len(model["tables"]),
            "relationships": len(model["relationships"]), "entityRelationships": len(model["entityRelationships"]),
        }
        manifest.data["queryValidation"] = "Not performed; definition validation is not an agent or data-query test"
        if hybrid:
            manifest.data["authoringPhase"] = "verified"
        manifest.save()
