"""Diagnose the existing UX MWC token exchange without creating or changing Fabric items."""

import argparse
import json
import re
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
from uuid import UUID

from azure.core.exceptions import ClientAuthenticationError
import requests

from create_ontology import MwcCredential
from create_sample import Api, PBI_SCOPE
from sample_auth import AuthenticationCancelled, open_credential
from ux_authoring import routing, workload_host


def response_evidence(response):
    evidence = {"httpStatus": response.status_code}
    for header in ("RequestId", "x-ms-request-id", "ActivityId", "x-ms-correlation-request-id"):
        value = response.headers.get(header)
        if isinstance(value, str):
            try:
                evidence[header] = str(UUID(value))
            except ValueError:
                pass  # Only valid correlation GUIDs are safe to echo from arbitrary headers.
    if not 200 <= response.status_code < 300:
        try:
            body = response.json()
        except ValueError:
            return evidence
        if isinstance(body, dict):
            candidates = [body]
            error = body.get("error")
            if isinstance(error, dict):
                candidates.append(error)
                if isinstance(error.get("pbi.error"), dict):
                    candidates.append(error["pbi.error"])
            codes = []
            for candidate in candidates:
                for field in ("errorCode", "code"):
                    value = candidate.get(field)
                    if (isinstance(value, str) and re.fullmatch(r"[A-Za-z][A-Za-z0-9_.-]{0,95}", value)
                            and value.count(".") < 2 and value not in codes):
                        codes.append(value)
                value = candidate.get("requestId")
                if isinstance(value, str):
                    try:
                        evidence["bodyRequestId"] = str(UUID(value))
                    except ValueError:
                        pass
            if codes:
                evidence["serviceErrorCodes"] = codes
    return evidence


def load_plan(path, token_version=None, metadata_api=None):
    saved = json.loads(path.read_text(encoding="utf-8-sig"))
    if saved.get("environment") != "Daily" or saved.get("authoringMode") not in ("ux", "hybrid"):
        raise ValueError("Select a Daily UX or hybrid run.manifest.json, not a source manifest")
    item = saved.get("items", {}).get("Ontology", {})
    if not item.get("id"):
        raise ValueError("The selected run has no ontology ID; select the failed token-exchange run")
    origin, expected_host = routing(
        saved["targetNetwork"], metadata_api or saved.get("uxMetadataApi"), saved.get("uxExpectedWorkloadHost"))
    # Older packages always used v2 and did not record the version.
    version = token_version or saved.get("uxTokenVersion", "v2")
    if version not in ("v1", "v2"):
        raise ValueError("Unsupported token version")
    return {
        "tenantId": str(UUID(saved["tenantId"])),
        "workspaceId": str(UUID(saved["targetWorkspaceId"])),
        "capacityId": str(UUID(saved["targetWorkspace"]["capacityId"])),
        "ontologyId": str(UUID(item["id"])),
        "metadataOrigin": origin,
        "expectedWorkloadHost": expected_host,
        "authentication": saved["authentication"],
        "tokenVersion": version,
        "endpoint": origin + "/metadata/v201606/generatemwctoken" + ("v2" if version == "v2" else ""),
    }


def probe(plan, credential, timeout):
    evidence = {
        "status": "checking", "endpoint": plan["endpoint"],
        "credentialType": type(credential).__name__, "responses": [],
        "resourceChanges": False, "startedUtc": datetime.now(timezone.utc).isoformat(),
    }

    def observe(response, *args, **kwargs):
        evidence["responses"].append(response_evidence(response))

    def validate_host(host):
        host = workload_host(host)
        if plan["expectedWorkloadHost"] and host != plan["expectedWorkloadHost"]:
            raise ValueError("Returned workload host differs from the configured host")
        evidence["workloadHost"] = host

    try:
        with closing(Api(plan["metadataOrigin"], PBI_SCOPE, credential, timeout, sensitive_response=True)) as pbi:
            pbi.session.hooks["response"].append(observe)
            MwcCredential(pbi, plan, plan["ontologyId"], validate_host=validate_host, token_version=plan["tokenVersion"])
    except (ClientAuthenticationError, requests.RequestException, RuntimeError, ValueError) as error:
        # Exception messages and response bodies may carry secrets; emit only the allowlisted evidence.
        evidence.update(status="failed", exceptionType=type(error).__name__)
    else:
        evidence["status"] = "token-acquired"
    evidence["finishedUtc"] = datetime.now(timezone.utc).isoformat()
    return evidence


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-manifest", type=Path, required=True,
                        help="Manifest from the failed UX run that already created an ontology")
    parser.add_argument("--auth", choices=("auto", "cli", "browser"),
                        help="Defaults to the mode recorded in the run; use the same client as the failed attempt")
    parser.add_argument("--client-id", type=UUID, help="Same organization-approved client if using browser auth")
    parser.add_argument("--token-version", choices=("v1", "v2"),
                        help="Explicit contract to test; defaults to the run's version (legacy manifests used v2)")
    parser.add_argument("--metadata-api", help="Explicit HTTPS origin captured from the working UX token request")
    parser.add_argument("--timeout", type=int, default=60)
    parser.add_argument("--execute", action="store_true", help="Request a token only; default is an offline plan")
    args = parser.parse_args(argv)
    if args.timeout < 1:
        parser.error("--timeout must be positive")
    try:
        plan = load_plan(args.run_manifest, args.token_version, args.metadata_api)
    except (OSError, ValueError, KeyError, TypeError) as error:
        parser.error(f"Cannot use that UX run manifest ({type(error).__name__}); no requests were made")
    plan["authentication"] = args.auth or plan["authentication"]
    if plan["authentication"] not in ("auto", "cli", "browser"):
        parser.error("The run manifest has an unsupported authentication mode")
    print(json.dumps({**plan, "operation": "token-exchange-only", "resourceChanges": False}, indent=2))
    if not args.execute:
        return 0
    try:
        with open_credential(plan["tenantId"], mode=plan["authentication"],
                             client_id=str(args.client_id) if args.client_id else None) as credential:
            evidence = probe(plan, credential, args.timeout)
    except (ClientAuthenticationError, AuthenticationCancelled) as error:
        evidence = {"status": "sign-in-failed", "exceptionType": type(error).__name__, "resourceChanges": False}
    print(json.dumps(evidence, indent=2))
    if evidence["status"] != "token-acquired":
        print("Authentication probe failed. No items were created or modified. "
              "Use the safe service codes and correlation IDs above to investigate; "
              "a 403 alone does not distinguish application permissions from network policy. "
              "Do not blindly switch token versions or rerun ontology creation.")
        return 1
    print("Token exchange succeeded. The token was not printed or saved. "
          "Workload read/write permissions and definition/scripts were NOT tested.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
