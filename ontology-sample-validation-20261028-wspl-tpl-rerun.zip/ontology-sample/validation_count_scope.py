"""Conservative structural proof of A012 count scope in executed SQL/DAX.

This recognizes a bounded read-only subset, not arbitrary SQL/DAX semantics.
Unsupported expressions remain unverified; literals/comments cannot act as filters.
"""

import re


COUNT_COLUMNS = {"readingcount", "a012readingcount", "readingsfora012"}
LEXEME = re.compile(
    r"(?P<space>\s+)|(?P<comment>--[^\n]*|/\*.*?\*/)"
    r"|(?P<single>'(?:''|[^'])*')|(?P<double>\"(?:\"\"|[^\"])*\")"
    r"|(?P<bracket>\[(?:\]\]|[^\]])*\])"
    r"|(?P<word>[A-Za-z_][A-Za-z0-9_@$]*)|(?P<number>\d+(?:\.\d+)?)"
    r"|(?P<symbol>==|!=|<>|<=|>=|&&|\|\||[().,;*=<>!+\-/%|&])",
    re.S,
)


def _tokens(code):
    if not isinstance(code, str) or len(code) > 65536:
        raise ValueError("Query is missing or exceeds the scope-check size limit")
    code = code.strip()
    if code.startswith("```"):
        fenced = re.fullmatch(r"```(?:sql|tsql|dax)\s*\n(.*?)\s*```", code, re.I | re.S)
        if not fenced:
            raise ValueError("Unsupported code fence")
        code = fenced[1]
    root = []
    stack = [root]
    position = 0
    while position < len(code):
        match = LEXEME.match(code, position)
        if not match:
            raise ValueError("Unsupported query syntax")
        position = match.end()
        kind, text = match.lastgroup, match[0]
        if kind in ("space", "comment"):
            if kind == "comment" and text.startswith("/*") and "/*" in text[2:-2]:
                raise ValueError("Nested comments are not supported")
            continue
        if text == "(":
            if len(stack) >= 32:
                raise ValueError("Query nesting exceeds the scope-check limit")
            group = []
            stack[-1].append(group)
            stack.append(group)
        elif text == ")":
            if len(stack) == 1:
                raise ValueError("Unbalanced query parentheses")
            stack.pop()
        else:
            if kind in ("single", "double", "bracket"):
                text = text[1:-1].replace({"single": "''", "double": '""', "bracket": "]]"}[kind],
                                        {"single": "'", "double": '"', "bracket": "]"}[kind])
            stack[-1].append((kind, text.casefold() if kind == "word" else text))
    if len(stack) != 1:
        raise ValueError("Unbalanced query parentheses")
    if root and root[-1] == ("symbol", ";"):
        root.pop()
    if ("symbol", ";") in root:
        raise ValueError("Multiple statements are not count-scope proof")
    return root


def _word(token, value):
    return token == ("word", value)


def _name(token):
    return token[1].casefold() if isinstance(token, tuple) and token[0] in (
        "word", "double", "bracket") else None


def _unwrap(tokens):
    while len(tokens) == 1 and isinstance(tokens[0], list):
        tokens = tokens[0]
    return tokens


def _split(tokens, separator):
    parts = [[]]
    for token in tokens:
        if separator(token):
            parts.append([])
        else:
            parts[-1].append(token)
    return parts


def _column(tokens, qualifier):
    if not tokens or any(token != ("symbol", ".") for token in tokens[1::2]):
        return None
    names = [_name(token) for token in tokens[::2]]
    if len(tokens) % 2 == 0 or not all(names):
        return None
    if len(names) > 1 and names[-2] != qualifier:
        return None
    return names[-1]


def _sql_filter(tokens, qualifier):
    tokens = _unwrap(tokens)
    if any(_word(t, key) for t in tokens for key in ("case", "when", "then", "else", "end")):
        return False
    for operator, combine in (("or", all), ("and", any)):
        parts = _split(tokens, lambda token: _word(token, operator))
        if len(parts) > 1:
            return combine(_sql_filter(part, qualifier) for part in parts)
    parts = _split(tokens, lambda token: token == ("symbol", "="))
    if len(parts) != 2:
        return False
    for column, literal in (parts, parts[::-1]):
        if literal and _word(literal[0], "n"):
            literal = literal[1:]
        if _column(_unwrap(column), qualifier) == "assetid" and _unwrap(literal) == [("single", "A012")]:
            return True
    return False


def _projection(tokens):
    if len(tokens) >= 3 and _word(tokens[-2], "as") and _name(tokens[-1]):
        return _name(tokens[-1]), tokens[:-2]
    if len(tokens) > 1 and _name(tokens[-1]) and tokens[-2] != ("symbol", "."):
        return _name(tokens[-1]), tokens[:-1]
    return (_name(tokens[-1]) if tokens else None), tokens


def _output_key(name):
    return re.sub(r"[^a-z0-9]", "", name.casefold()) if name else None


def _select_parts(tokens):
    if not tokens or not _word(tokens[0], "select"):
        raise ValueError("Expected a SELECT query")
    if any(_word(t, key) for t in tokens[1:] for key in ("select", "except", "intersect", "into", "for", "option")):
        raise ValueError("Unsupported SELECT transformation")
    end = next((i for i, t in enumerate(tokens) if _word(t, "from")), len(tokens))
    projections = [_projection(part) for part in _split(tokens[1:end], lambda t: t == ("symbol", ","))]
    return projections, tokens[end + 1:]


def _relation(tokens):
    end = next((i for i, t in enumerate(tokens) if any(_word(t, key) for key in
                ("where", "group", "having", "order", "offset", "fetch"))), len(tokens))
    source = tokens[:end]
    names = []
    while source and _name(source[0]):
        names.append(_name(source.pop(0)))
        if source and source[0] == ("symbol", "."):
            source.pop(0)
        else:
            break
    if source and _word(source[0], "as"):
        source.pop(0)
    if not names or len(source) > 1 or (source and not _name(source[0])):
        return None
    qualifier = _name(source[0]) if source else names[-1]
    return names, qualifier, tokens[end:]


def _sql_scope(expression, from_tokens, ctes, tables, depth):
    expression = _unwrap(expression)
    if expression == [("word", "null")]:
        return "null"
    if (len(expression) == 2 and expression[0] in (("word", "cast"), ("word", "try_cast"))
            and isinstance(expression[1], list) and expression[1][:2] == [("word", "null"), ("word", "as")]):
        return "null"
    relation = _relation(from_tokens)
    if relation is None:
        return "unknown"
    names, qualifier, tail = relation
    column = _column(expression, qualifier)
    if column and len(names) == 1 and names[0] in ctes:
        columns = _sql_columns(ctes[names[0]], ctes, tables, depth + 1, wanted=column)
        return columns.get(column, "unknown")
    if not (len(expression) == 2 and expression[0] in (("word", "count"), ("word", "count_big"))
            and expression[1] in ([("symbol", "*")], [("number", "1")])):
        return "unknown"
    if names[-1] not in tables or (len(names) == 1 and names[0] in ctes):
        return "unknown"
    if not tail or not _word(tail[0], "where"):
        return "unknown"
    if any(_word(t, key) for t in tail for key in ("group", "having", "order", "offset", "fetch")):
        return "unknown"
    return "a012" if _sql_filter(tail[1:], qualifier) else "unknown"


def _sql_columns(tokens, inherited, tables, depth=0, wanted=None):
    if depth > 12:
        raise ValueError("CTE lineage exceeds the scope-check limit")
    tokens, ctes = list(_unwrap(tokens)), dict(inherited)
    if tokens and _word(tokens[0], "with"):
        tokens.pop(0)
        while True:
            if len(tokens) < 3 or not _name(tokens[0]) or not _word(tokens[1], "as") or not isinstance(tokens[2], list):
                raise ValueError("Unsupported CTE declaration")
            ctes[_name(tokens[0])] = tokens[2]
            tokens = tokens[3:]
            if not tokens or tokens[0] != ("symbol", ","):
                break
            tokens.pop(0)
    branches = _split(tokens, lambda t: _word(t, "union"))
    projections = []
    for index, branch in enumerate(branches):
        if index and branch and (branch[0] in (("word", "all"), ("word", "distinct"))):
            branch = branch[1:]
        projections.append(_select_parts(branch))
    names = [name for name, _ in projections[0][0]]
    if len({_output_key(name) for name in names}) != len(names) or any(
            len(parts) != len(names) for parts, _ in projections):
        raise ValueError("Ambiguous output columns")
    result = {}
    for index, name in enumerate(names):
        # Only count columns are followed; unrelated projections cannot confer scope.
        if (wanted is not None and name != wanted) or (wanted is None and _output_key(name) not in COUNT_COLUMNS):
            continue
        scopes = [_sql_scope(parts[index][1], source, ctes, tables, depth) for parts, source in projections]
        result[name] = ("a012" if "a012" in scopes and all(scope in ("a012", "null") for scope in scopes)
                        else "null" if all(scope == "null" for scope in scopes) else "unknown")
    return result


def _dax_table(tokens):
    if len(tokens) == 1 and isinstance(tokens[0], tuple) and tokens[0][0] in ("word", "single"):
        return tokens[0][1].casefold()
    return None


def _dax_filter(tokens, table):
    tokens = _unwrap(tokens)
    parts = _split(tokens, lambda t: t in (("symbol", "="), ("symbol", "==")))
    if len(parts) != 2:
        return False
    for column, literal in (parts, parts[::-1]):
        if (len(column) == 2 and _dax_table(column[:1]) == table
                and isinstance(column[1], tuple) and column[1][0] == "bracket"
                and _name(column[1]) == "assetid" and literal == [("double", "A012")]):
            return True
    return False


def _dax_columns(tokens, tables):
    if not (len(tokens) == 3 and _word(tokens[0], "evaluate") and _word(tokens[1], "row")
            and isinstance(tokens[2], list)):
        raise ValueError("Unsupported DAX count shape")
    pairs = _split(tokens[2], lambda t: t == ("symbol", ","))
    if len(pairs) % 2:
        raise ValueError("Invalid DAX ROW")
    result = {}
    for label, expression in zip(pairs[::2], pairs[1::2]):
        if len(label) != 1 or not isinstance(label[0], tuple) or label[0][0] != "double":
            raise ValueError("Unsupported DAX output label")
        name = _output_key(label[0][1])
        if name in result:
            raise ValueError("Duplicate DAX output label")
        result[name] = "unknown"
        expression = _unwrap(expression)
        if len(expression) != 2 or not _word(expression[0], "calculate") or not isinstance(expression[1], list):
            continue
        args = _split(expression[1], lambda t: t == ("symbol", ","))
        count = args[0]
        if len(args) < 2 or len(count) != 2 or not _word(count[0], "countrows") or not isinstance(count[1], list):
            continue
        table = _dax_table(count[1])
        if table in tables and all(_dax_filter(arg, table) for arg in args[1:]):
            result[name] = "a012"
    return result


def prove_count_scope(tool, code, readings_entity):
    tables = {"readings", readings_entity.casefold()}
    try:
        tokens = _tokens(code)
        if tool == "analyze.database.execute":
            columns = _sql_columns(tokens, {}, tables)
        elif tool == "askPBI.tool.execute":
            columns = _dax_columns(tokens, tables)
        else:
            raise ValueError("Unsupported execution tool")
        proven = sorted(_output_key(name) for name, scope in columns.items()
                        if _output_key(name) in COUNT_COLUMNS and scope == "a012")
        return {"status": "VERIFIED" if proven else "UNVERIFIED", "columns": proven,
                "reason": "Executed count projection is restricted to A012" if proven
                else "No supported A012-scoped count projection"}
    except ValueError as error:
        return {"status": "UNVERIFIED", "columns": [], "reason": str(error)}
