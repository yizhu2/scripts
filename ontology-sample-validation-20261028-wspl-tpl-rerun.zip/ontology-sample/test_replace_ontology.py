import copy
import io
import json
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import MagicMock, patch

import create_ontology
import replace_ontology
from create_sample import Manifest
from test_create_ontology import GUID, inventory, metadata


class PublicReplacementTests(unittest.TestCase):
    def test_deferred_semantic_manifest_requires_explicit_opt_in(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            state = inventory()
            del state["verified"]["SemanticModel"]
            state["deferredValidation"] = {"SemanticModel": ["refresh", "sampleRows"]}
            source = folder / "sources.json"
            source.write_text(json.dumps(state), encoding="utf-8")
            argv = ["--sources-manifest", str(source), "--ontology-id", GUID, "--name", "Sample",
                    "--manifest", str(folder / "repair.json")]
            with self.assertRaisesRegex(ValueError, "SemanticModel"):
                replace_ontology.main(argv)
            with redirect_stdout(io.StringIO()) as output:
                replace_ontology.main(argv + ["--allow-deferred-semantic"])
            plan = json.loads(output.getvalue())
            self.assertEqual(plan["deferredValidation"], state["deferredValidation"])
            self.assertFalse((folder / "repair.json").exists())
            del state["verified"]["Lakehouse"]
            source.write_text(json.dumps(state), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "Lakehouse"):
                replace_ontology.main(argv + ["--allow-deferred-semantic"])

    def test_complete_definition_roundtrip_needs_no_sdk_subprocess_or_download(self):
        state = inventory()
        expected = create_ontology.build_definition(state, metadata(), "powerbi://dailyapi.powerbi.com")
        with tempfile.TemporaryDirectory() as temporary, \
                patch("subprocess.run", side_effect=AssertionError("No external serializer permitted")), \
                patch("requests.sessions.Session.request", side_effect=AssertionError("No package download permitted")):
            folder = Path(temporary)
            body = replace_ontology.serialize_definition(expected, folder)
            api = MagicMock()
            api.mutate.return_value = body
            manifest = Manifest(folder / "result.json", {})
            replace_ontology.read_and_verify(api, "https://example.com/ontology", state, expected,
                                            folder, manifest, state["workspaceId"])
            self.assertEqual(manifest.data["verified"]["publicDefinition"], {
                "entities": 18, "boundTables": 18, "relationships": 12, "entityRelationships": 12
            })

    def test_cross_workspace_warehouse_requires_absolute_source_identity(self):
        state = inventory()
        expected = create_ontology.build_definition(state, metadata(), "powerbi://dailyapi.powerbi.com")
        actual = copy.deepcopy(expected)
        expression = next(item for item in actual["model"]["expressions"] if item["name"] == "Warehouse_Source")
        expression["expression"] = (
            f'let Source = Sql.Database("ONT_ALM_SQL_ENDPOINT", '
            f'"ONT_ALM_SQL_DATABASE-Warehouse:{state["workspaceId"]}:{state["items"]["Warehouse"]["id"]}") in Source'
        )
        target = "22222222-2222-4222-8222-222222222222"
        replace_ontology.verify_public_bindings(expected, actual, state, target)
        expression["expression"] = (
            'let Source = Sql.Database("ONT_ALM_SQL_ENDPOINT", '
            f'"ONT_ALM_SQL_DATABASE-RELATIVE-{state["items"]["Warehouse"]["displayName"]}") in Source'
        )
        with self.assertRaises(ValueError):
            replace_ontology.verify_public_bindings(expected, actual, state, target)

    def test_tmdl_parts_round_trip_without_platform_metadata(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            request = folder / "request"
            request.mkdir()
            (request / "database.tmdl").write_text("database\n\tcompatibilityLevel: 1000000", encoding="utf-8")
            (request / "model.tmdl").write_text("model Model", encoding="utf-8")
            parts = replace_ontology.tmdl_parts(request)
            parts.append({"path": ".platform", "payloadType": "InlineBase64", "payload": "e30="})
            stored = folder / "stored"
            replace_ontology.unpack_tmdl({"parts": parts}, stored)
            self.assertEqual((stored / "database.tmdl").read_bytes(), (request / "database.tmdl").read_bytes())
            self.assertFalse((stored / ".platform").exists())

    def test_rejects_unsafe_export_paths(self):
        for path in ("../escape.tmdl", "/escape.tmdl", "C:/escape.tmdl", "tables\\escape.tmdl",
                     "./model.tmdl", "tables//model.tmdl", "definition.json"):
            with self.subTest(path=path), tempfile.TemporaryDirectory() as temporary:
                with self.assertRaises(ValueError):
                    replace_ontology.unpack_tmdl({"parts": [
                        {"path": path, "payloadType": "InlineBase64", "payload": "e30="}
                    ]}, Path(temporary))

    def test_rejects_duplicate_and_unsupported_parts(self):
        for second in (
            {"path": "DATABASE.tmdl", "payloadType": "InlineBase64", "payload": "e30="},
            {"path": "model.tmdl", "payloadType": "ExternalUrl", "payload": "https://example.com"},
        ):
            with self.subTest(second=second), tempfile.TemporaryDirectory() as temporary:
                with self.assertRaises(ValueError):
                    replace_ontology.unpack_tmdl({"parts": [
                        {"path": "database.tmdl", "payloadType": "InlineBase64", "payload": "e30="}, second
                    ]}, Path(temporary))

    def test_rejects_missing_required_documents(self):
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaises(ValueError):
                replace_ontology.tmdl_parts(Path(temporary))
            with self.assertRaises(ValueError):
                replace_ontology.unpack_tmdl({"parts": []}, Path(temporary))

    def test_bad_base64_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaises(ValueError):
                replace_ontology.unpack_tmdl({"parts": [
                    {"path": "database.tmdl", "payloadType": "InlineBase64", "payload": "%%%"}
                ]}, Path(temporary))

    def test_public_readback_checks_bindings_even_when_projections_are_minimized(self):
        expected = create_ontology.build_definition(inventory(), metadata(), "powerbi://dailyapi.powerbi.com")
        actual = copy.deepcopy(expected)
        for entity in actual["model"]["entities"]:
            del entity["description"]
            entity["properties"] = [prop for prop in entity["properties"] if prop["name"] in entity["keyProperties"]]
        replace_ontology.verify_public_bindings(expected, actual, inventory())
        actual["model"]["tables"][0]["partitions"][0]["source"]["entityName"] = "WrongTable"
        with self.assertRaises(ValueError):
            replace_ontology.verify_public_bindings(expected, actual, inventory())

    def test_preview_does_not_authenticate_or_serialize(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            source = folder / "sources.json"
            source.write_text(json.dumps(inventory()), encoding="utf-8")
            with patch("replace_ontology.Api") as api, patch("replace_ontology.serialize_definition") as serialize:
                output = io.StringIO()
                with redirect_stdout(output):
                    replace_ontology.main([
                        "--sources-manifest", str(source), "--ontology-id", GUID, "--name", "Sample",
                        "--manifest", str(folder / "result.json"),
                    ])
                self.assertEqual(json.loads(output.getvalue())["transport"], "fabric-public-api")
                api.assert_not_called()
                serialize.assert_not_called()
                self.assertFalse((folder / "result.json").exists())

    def test_verify_only_never_updates_the_definition(self):
        state = inventory()
        expected = create_ontology.build_definition(state, metadata(), "powerbi://dailyapi.powerbi.com")

        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            exported = replace_ontology.serialize_definition(expected, folder)
            source = folder / "sources.json"
            source.write_text(json.dumps(state), encoding="utf-8")
            with patch("azure.identity.AzureCliCredential"), patch("replace_ontology.Api") as api_class, \
                    patch("replace_ontology.discover_sources", return_value=metadata()):
                api = api_class.return_value
                api.base = state["endpoints"]["fabric"]
                api.json.return_value = {"type": "Ontology", "displayName": "Sample", "id": GUID}
                api.mutate.return_value = exported
                replace_ontology.main([
                    "--sources-manifest", str(source), "--ontology-id", GUID, "--name", "Sample",
                    "--manifest", str(folder / "result.json"),
                    "--verify-only", "--execute",
                ])
                api.mutate.assert_called_once_with(
                    f"{api.base}/workspaces/{GUID}/ontologies/{GUID}/getDefinition")
                result = json.loads((folder / "result.json").read_text())
                self.assertEqual(result["status"], "succeeded")
                self.assertNotIn("writeCompleted", result)

    def test_normalizes_sdk_defaults_but_rejects_explicitly_wrong_cardinality(self):
        expected = create_ontology.build_definition(inventory(), metadata(), "powerbi://dailyapi.powerbi.com")
        actual = copy.deepcopy(expected)
        for relationship in actual["model"]["relationships"]:
            for key in ("fromCardinality", "toCardinality", "crossFilteringBehavior"):
                del relationship[key]
        for entity in actual["model"]["entities"]:
            for prop in entity["properties"]:
                del prop["backingConfiguration"]["type"]
        for relationship in actual["model"]["entityRelationships"]:
            del relationship["backingConfiguration"]["type"]
        create_ontology.verify_definition(expected, replace_ontology.normalize_tom_defaults(actual))
        self.assertNotIn("fromCardinality", actual["model"]["relationships"][0])
        actual["model"]["relationships"][0]["toCardinality"] = "many"
        with self.assertRaises(ValueError):
            replace_ontology.verify_public_bindings(expected, actual, inventory())

    def test_public_sql_transport_markers_must_match_the_intended_items(self):
        state = inventory()
        expected = create_ontology.build_definition(state, metadata(), "powerbi://dailyapi.powerbi.com")
        actual = copy.deepcopy(expected)
        sql = next(e for e in actual["model"]["expressions"] if e["name"] == "SQLDatabase_Source")
        warehouse = next(e for e in actual["model"]["expressions"] if e["name"] == "Warehouse_Source")
        sql["expression"] = (f'let Source = Sql.Database("ONT_ALM_SQL_ENDPOINT", '
                             f'"ONT_ALM_SQL_DATABASE-SQLDatabase:{GUID}:{GUID}") in Source')
        warehouse["expression"] = ('let Source = Sql.Database("ONT_ALM_SQL_ENDPOINT", '
                                   '"ONT_ALM_SQL_DATABASE-RELATIVE-Warehouse") in Source')
        replace_ontology.verify_public_bindings(expected, actual, state)
        sql["expression"] = sql["expression"].replace(GUID, "22222222-2222-2222-2222-222222222222")
        with self.assertRaises(ValueError):
            replace_ontology.verify_public_bindings(expected, actual, state)

    def test_persisted_entity_keys_are_verified(self):
        expected = create_ontology.build_definition(inventory(), metadata(), "powerbi://dailyapi.powerbi.com")
        actual = copy.deepcopy(expected)
        actual["model"]["entities"][0]["keyProperties"] = ["WrongKey"]
        with self.assertRaises(ValueError):
            replace_ontology.verify_public_bindings(expected, actual, inventory())

    def test_missing_entity_or_unknown_persisted_property_fails(self):
        expected = create_ontology.build_definition(inventory(), metadata(), "powerbi://dailyapi.powerbi.com")
        for failure in ("entity", "property"):
            actual = copy.deepcopy(expected)
            if failure == "entity":
                actual["model"]["entities"].pop()
            else:
                actual["model"]["entities"][0]["properties"].append({"name": "Unexpected"})
            with self.subTest(failure=failure), self.assertRaises(ValueError):
                replace_ontology.verify_public_bindings(expected, actual, inventory())


if __name__ == "__main__":
    unittest.main()
