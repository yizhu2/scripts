"""Offline tests: no Azure credential acquisition, network calls or live writes."""

import base64
import copy
import json
import unittest
from contextlib import nullcontext
from types import SimpleNamespace
from unittest.mock import Mock

import requests

import validation_data_agent as adapter
from validation_common import HttpFailure, ScenarioBlocked
from test_validation_count_scope import DAX, SQL


WORKSPACE = "10000000-0000-0000-0000-000000000001"
ONTOLOGY = "10000000-0000-0000-0000-000000000002"
AGENT = "10000000-0000-0000-0000-000000000003"
CAPACITY = "10000000-0000-0000-0000-000000000004"
LAKEHOUSE = "20000000-0000-0000-0000-000000000001"
SEMANTIC = "20000000-0000-0000-0000-000000000002"
KQL = "20000000-0000-0000-0000-000000000003"
HOST = "test-daily.pbidedicated.windows.net"
PRIVATE_METADATA = "https://private-route.analysis.windows.net"
SOURCE_IDS = {"Lakehouse": LAKEHOUSE, "SemanticModel": SEMANTIC, "EventhouseKQL": KQL,
              "Warehouse": "20000000-0000-0000-0000-000000000004",
              "SQLDatabase": "20000000-0000-0000-0000-000000000005",
              "MirroredDatabase": "20000000-0000-0000-0000-000000000006"}
FULL_TABLE = """
File: result.json
Total rows: 1
| A012ReadingCount | TemperatureC | AssetId | PlantId | PlantName | City | ReadingId | ObservedAt |
|:---|:---|:---|:---|:---|:---|:---|:---|
| 10 | 32.9 | A012 | P03 | East Plant | Boston | R0120 | 2026-01-01T00:45:00Z |
"""


def pair(name, arguments, result, call_id, diagnostics=None, status="completed"):
    return [
        {"type": "function_call", "name": name, "call_id": call_id,
         "arguments": json.dumps(arguments), "status": "completed"},
        {"type": "function_call_output", "call_id": call_id, "status": status, "output": result,
         "metadata": {"diagnostic_details": json.dumps(diagnostics or {})}},
    ]


def execution(source, filename="result.json", call_id="execute", workspace=WORKSPACE, failed=False):
    return pair("askPBI.tool.execute" if source == SEMANTIC else "analyze.database.execute",
                {"datasource_artifact_id": source, "datasource_workspace_id": workspace,
                 "code": "SELECT * FROM Readings", "result_file_name": filename},
                f"The resulting dataset can be found in the file '{filename}'. The dataset contains 1 rows.",
                call_id, {"queries_ran": [{"is_error": failed}]})


def terminal(source=LAKEHOUSE, table=FULL_TABLE):
    output = pair("ontology.context.datasources_attached", {}, json.dumps({
        "attached": [{"id": source, "type": "LakehouseTables"}]}), "context")
    output += execution(source)
    output += pair("generate_files_data_insights.execute", {"file_names": ["result.json"]}, table, "insight")
    return {"id": "response-test", "status": "completed", "output": output}


def count_terminal(source=LAKEHOUSE, code=SQL, count="10", asset=None):
    doc = terminal(source, FULL_TABLE.replace("| 10 |", "| {} |"))
    count_execution = execution(source, "count.json", "count-execute")
    arguments = json.loads(count_execution[0]["arguments"])
    arguments["code"] = code
    count_execution[0]["arguments"] = json.dumps(arguments)
    doc["output"] += count_execution
    header = "| ReadingCount |" + (" AssetId |" if asset is not None else "")
    row = f"| {count} |" + (f" {asset} |" if asset is not None else "")
    doc["output"] += pair("generate_files_data_insights.execute", {"file_names": ["count.json"]},
                          f"File: count.json\nTotal rows: 1\n{header}\n{row}\n", "count-insight")
    return doc


def response(value, sse=True):
    result = requests.Response()
    result.status_code = 200
    result.headers["x-ms-root-activity-id"] = "test-root-activity"
    result.encoding = "utf-8"
    text = ("event: response.completed\ndata: " +
            json.dumps({"type": "response.completed", "response": value}) + "\n\n") if sse else json.dumps(value)
    result._content = text.encode()
    return result


def fixture():
    names = [f"{group}_{entity}" for group in SOURCE_IDS for entity in ("Assets", "Plants", "Readings")]
    return {"model": {
        "entities": [{"name": name} for name in names],
        "tables": [{"name": name, "partitions": [{"annotations": [
            {"name": "ONT_RESOLVED_State", "value": "Resolved"},
            {"name": "ONT_RESOLVED_ItemId", "value": SOURCE_IDS[name.rsplit("_", 1)[0]]},
            {"name": "ONT_RESOLVED_WorkspaceId", "value": WORKSPACE},
        ]}]} for name in names],
    }}


class FakeContext:
    def __init__(self):
        self.config = {"workspace_id": WORKSPACE, "ontology_id": ONTOLOGY,
                       "tenant_id": WORKSPACE, "target_network": "public", "allow_create": True}
        self.credential = Mock()
        self.timeout = 20
        self.state = {}
        self.fabric = SimpleNamespace(base="https://dailyapi.fabric.microsoft.com/v1")
        self.do = SimpleNamespace(base="https://test-daily.pbidedicated.windows.net/direct")
        self.workload = Mock(side_effect=lambda: nullcontext(self.do))
        self.definition = fixture()
        self.runtime = response(terminal())
        self.route_host = HOST
        self.events = []
        self.save_evidence = Mock(side_effect=lambda label, value: self.events.append(("save", label, copy.deepcopy(value))))
        self.request = Mock(side_effect=self._request)
        self.exchange = Mock(side_effect=self._exchange)
        self.mutate = Mock(side_effect=self._mutate)

    def _request(self, api, method, url, body=None, params=None):
        self.events.append((method, url, body))
        if "generatemwctokenv2" in url:
            return {"Token": "fake-mwc-credential", "TargetUriHost": self.route_host}
        if url.endswith("/definition"):
            return self.definition
        if url.endswith("/items/" + ONTOLOGY):
            return {"id": ONTOLOGY, "displayName": "TestOntology"}
        if url.endswith("/workspaces/" + WORKSPACE):
            return {"capacityId": CAPACITY}
        raise AssertionError("Unexpected HTTP: " + url)

    def _mutate(self, api, path, body):
        self.events.append(("mutate", path, copy.deepcopy(body)))
        if path.endswith("/dataAgents"):
            return {"id": AGENT}
        raise AssertionError("Unexpected mutation: " + path)

    def _exchange(self, api, method, url, body=None, params=None):
        self.events.append(("runtime", url, body))
        if isinstance(self.runtime, Exception):
            raise self.runtime
        self.runtime_api = api
        return self.runtime

    def existing(self):
        self.config["allow_create"] = False
        self.config["data_agent_id"] = AGENT


class RoutingTests(unittest.TestCase):
    def test_private_uses_workspace_route_without_separate_ml_settings(self):
        for network in ("wspl", "tenantpl"):
            ctx = FakeContext()
            ctx.config.update(target_network=network, ux_metadata_api=PRIVATE_METADATA, ux_workload_host=HOST)
            result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
            self.assertEqual("PASS", result["status"])
            mint = next(c for c in ctx.request.call_args_list if "generatemwctokenv2" in c.args[2])
            self.assertTrue(mint.args[2].startswith(PRIVATE_METADATA))

    def test_private_rejects_public_metadata_default_and_unsafe_hosts(self):
        for metadata, host in [
            (adapter.routing("public")[0], HOST),
            ("https://attacker.example", HOST),
            (PRIVATE_METADATA, "test.pbidedicated.windows.net/evil"),
        ]:
            with self.subTest(metadata=metadata, host=host):
                with self.assertRaises((ValueError, ScenarioBlocked)):
                    adapter.ml_routing({"target_network": "wspl", "data_agent_metadata_api": metadata,
                                        "data_agent_workload_host": host})

    def test_private_mismatch_never_calls_workload(self):
        ctx = FakeContext()
        ctx.existing()
        ctx.config.update(target_network="tenantpl", data_agent_metadata_api=PRIVATE_METADATA,
                          data_agent_workload_host="expected.pbidedicated.windows.net")
        result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
        self.assertEqual("BLOCKED", result["status"])
        ctx.exchange.assert_not_called()
        self.assertFalse(any("/ontologydatasources" in call.args[2] for call in ctx.request.call_args_list))

    def test_private_explicit_route_uses_same_identity_and_sandbox(self):
        ctx = FakeContext()
        ctx.config.update(target_network="wspl", data_agent_metadata_api=PRIVATE_METADATA,
                          data_agent_workload_host=HOST)
        result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
        self.assertEqual("PASS", result["status"])
        mint = next(c for c in ctx.request.call_args_list if "generatemwctokenv2" in c.args[2])
        self.assertIs(ctx.credential, mint.args[0].credential)
        self.assertTrue(mint.args[2].startswith(PRIVATE_METADATA))
        self.assertTrue(mint.args[0].sensitive_response)
        self.assertEqual("ML", mint.args[3]["workloadType"])
        self.assertEqual("MwcToken", ctx.runtime_api.auth_scheme)
        self.assertEqual("sandbox", ctx.runtime_api.session.headers["x-ms-ai-aiskill-stage"])
        self.assertNotIn("fake-mwc-credential", json.dumps(result))

    def test_no_v1_fallback(self):
        ctx = FakeContext()
        ctx.config["ux_token_version"] = "v1"
        self.assertEqual("BLOCKED", adapter.SCENARIOS["data-agent.lakehouse"](ctx)["status"])
        ctx.request.assert_not_called()


class LifecycleTests(unittest.TestCase):
    def test_all_ten_existing_drafts_reach_query_without_any_alm_or_create_call(self):
        for scenario in adapter.SCENARIOS.values():
            with self.subTest(scenario=scenario):
                ctx = FakeContext()
                ctx.existing()
                result = scenario(ctx)
                self.assertTrue(result["evidence"]["queryAttempted"])
                ctx.mutate.assert_not_called()
                ctx.exchange.assert_called_once()

    def test_new_draft_has_requested_binding_without_export_readback(self):
        ctx = FakeContext()
        ctx.config["data_agent_mode"] = "isolated"
        adapter.SCENARIOS["data-agent.sm-lakehouse"](ctx)
        self.assertEqual(ctx.mutate.call_count, 1)
        self.assertTrue(ctx.mutate.call_args.args[1].endswith("/dataAgents"))
        parts = ctx.mutate.call_args.args[2]["definition"]["parts"]
        ontology = next(json.loads(base64.b64decode(p["payload"])) for p in parts
                        if p["path"].endswith("/ontology.json"))
        self.assertEqual(ontology["artifactId"], ONTOLOGY)
        self.assertEqual(ontology["workspaceId"], WORKSPACE)
        self.assertEqual({e["id"] for e in ontology["elements"] if e["is_selected"]},
                         {"SemanticModel_Assets", "SemanticModel_Plants", "Lakehouse_Readings"})

    def test_default_shared_creates_one_all_entity_draft_for_ten_independent_questions(self):
        ctx = FakeContext()
        ctx.definition["model"]["entities"].append({"name": "AdditionalOntologyEntity"})
        for case, scenario in adapter.SCENARIOS.items():
            group, readings = adapter.CASES[case.removeprefix("data-agent.")]
            ctx.runtime = response({"status": "completed", "output": [
                {"type": "message", "content": [{"text": json.dumps(adapter.EXPECTED)}]}]})
            result = scenario(ctx)
            self.assertEqual("PASS", result["status"])
            self.assertEqual("shared", result["evidence"]["dataAgentMode"])
            self.assertEqual([group + "_Assets", group + "_Plants", readings + "_Readings"],
                             result["evidence"]["selectedEntities"])
        ctx.mutate.assert_called_once()
        parts = ctx.mutate.call_args.args[2]["definition"]["parts"]
        ontology_parts = [p for p in parts if p["path"].endswith("/ontology.json")]
        self.assertEqual(1, len(ontology_parts))
        ontology = json.loads(base64.b64decode(ontology_parts[0]["payload"]))
        self.assertEqual(ONTOLOGY, ontology["artifactId"])
        self.assertEqual(WORKSPACE, ontology["workspaceId"])
        self.assertEqual({e["name"] for e in ctx.definition["model"]["entities"]},
                         {e["id"] for e in ontology["elements"]})
        self.assertTrue(all(e["is_selected"] for e in ontology["elements"]))
        self.assertEqual(3, len(parts))
        self.assertEqual(10, ctx.exchange.call_count)
        self.assertEqual({name: AGENT for name in adapter.SCENARIOS}, ctx.state["data_agents"])
        self.assertEqual("created", ctx.state["data_agent_shared"]["status"])
        for call, (group, readings) in zip(ctx.exchange.call_args_list, adapter.CASES.values()):
            self.assertIn(f"/artifacts/{AGENT}/responses", call.args[2])
            self.assertEqual({"model", "input"}, set(call.args[3]))
            self.assertIn(f"Use only {group}_Assets, {group}_Plants, {readings}_Readings", call.args[3]["input"])
            self.assertEqual({"agent": "aiskill", "stage": "sandbox"}, call.kwargs["params"])

    def test_shared_query_failure_does_not_block_later_questions_or_create_replacement(self):
        ctx = FakeContext()
        ctx.runtime = HttpFailure(500, "query unavailable")
        self.assertEqual("FAIL", adapter.SCENARIOS["data-agent.lakehouse"](ctx)["status"])
        ctx.runtime = response(terminal(SEMANTIC))
        self.assertEqual("PASS", adapter.SCENARIOS["data-agent.semantic"](ctx)["status"])
        ctx.mutate.assert_called_once()
        self.assertEqual(2, ctx.exchange.call_count)
        self.assertEqual({AGENT}, set(ctx.state["data_agents"].values()))

    def test_shared_failed_or_ambiguous_creation_never_retries_in_run(self):
        for outcome in (TimeoutError("Creation outcome unknown"), HttpFailure(500, "creation failed"),
                        {}, {"id": "not-a-guid"}):
            with self.subTest(outcome=outcome):
                ctx = FakeContext()
                if isinstance(outcome, Exception):
                    ctx.mutate.side_effect = outcome
                else:
                    ctx.mutate.side_effect = None
                    ctx.mutate.return_value = outcome
                first = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
                self.assertEqual("BLOCKED", first["status"])
                for scenario in adapter.SCENARIOS.values():
                    result = scenario(ctx)
                    self.assertEqual("BLOCKED", result["status"])
                    self.assertIn("no replacement", result["summary"])
                    self.assertTrue(result["evidence"]["sharedCreation"]["creationAttempted"])
                ctx.mutate.assert_called_once()
                ctx.exchange.assert_not_called()
                self.assertEqual({}, ctx.state["data_agents"])
                shared = ctx.state["data_agent_shared"]
                self.assertEqual("failed-or-ambiguous", shared["status"])
                self.assertIn("error", shared)
                attempts = [event for event in ctx.events if event[:2] == ("save", "data-agent-create-attempt")]
                self.assertEqual("attempted", attempts[0][2]["status"])
                self.assertEqual("failed-or-ambiguous", attempts[-1][2]["status"])

    def test_new_context_does_not_implicitly_reuse_previous_run_resources_or_attempt(self):
        for previous in ("created", "failed-or-ambiguous"):
            with self.subTest(previous=previous):
                ctx = FakeContext()
                ctx.state = {"data_agents": {name: SEMANTIC for name in adapter.SCENARIOS},
                             "data_agent_shared": {"creationAttempted": True, "status": previous,
                                                   "agentId": SEMANTIC}}
                adapter.SCENARIOS["data-agent.lakehouse"](ctx)
                ctx.mutate.assert_called_once()
                self.assertEqual({AGENT}, set(ctx.state["data_agents"].values()))

    def test_persisted_resource_does_not_bypass_explicit_reuse_or_creation_consent(self):
        ctx = FakeContext()
        ctx.state["data_agents"] = {"data-agent.lakehouse": AGENT}
        ctx.config["allow_create"] = False
        result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
        self.assertEqual("BLOCKED", result["status"])
        self.assertIn("requires allow_create", result["summary"])
        ctx.mutate.assert_not_called()
        ctx.exchange.assert_not_called()

    def test_explicit_recovery_after_ambiguous_creation_does_not_create_again(self):
        ctx = FakeContext()
        ctx.mutate.side_effect = TimeoutError("Creation outcome unknown")
        self.assertEqual("BLOCKED", adapter.SCENARIOS["data-agent.lakehouse"](ctx)["status"])
        ctx.config["data_agent_id"] = AGENT
        self.assertEqual("PASS", adapter.SCENARIOS["data-agent.lakehouse"](ctx)["status"])
        ctx.mutate.assert_called_once()
        self.assertEqual("configured", ctx.state["data_agent_shared"]["status"])
        self.assertIn("error", ctx.state["data_agent_shared"])

    def test_repeated_shared_question_uses_same_draft_without_conversation_chaining(self):
        ctx = FakeContext()
        for _ in range(2):
            self.assertEqual("PASS", adapter.SCENARIOS["data-agent.lakehouse"](ctx)["status"])
        ctx.mutate.assert_called_once()
        self.assertEqual(2, ctx.exchange.call_count)
        self.assertEqual(ctx.exchange.call_args_list[0].args[3], ctx.exchange.call_args_list[1].args[3])
        self.assertEqual({"model", "input"}, set(ctx.exchange.call_args.args[3]))

    def test_shared_explicit_single_id_mapping_is_reused_for_all_cases_without_edits(self):
        for scalar in (False, True):
            with self.subTest(scalar=scalar):
                ctx = FakeContext()
                ctx.config["allow_create"] = False
                ctx.config["data_agent_ids"] = {"data-agent.semantic": AGENT, "data-agent.sql": AGENT}
                if scalar:
                    ctx.config["data_agent_id"] = AGENT
                for scenario in adapter.SCENARIOS.values():
                    self.assertTrue(scenario(ctx)["evidence"]["queryAttempted"])
                ctx.mutate.assert_not_called()
                self.assertEqual({name: AGENT for name in adapter.SCENARIOS}, ctx.state["data_agents"])
                self.assertFalse(ctx.state["data_agent_shared"]["creationAttempted"])

    def test_shared_conflicting_explicit_ids_block_before_requests(self):
        for config in ({"data_agent_ids": {"data-agent.lakehouse": AGENT, "data-agent.semantic": SEMANTIC}},
                       {"data_agent_id": AGENT, "data_agent_ids": {"data-agent.semantic": SEMANTIC}}):
            with self.subTest(config=config):
                ctx = FakeContext()
                ctx.config.update(config)
                result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
                self.assertEqual("BLOCKED", result["status"])
                self.assertIn("one existing draft ID", result["summary"])
                self.assertIn("isolated", result["summary"])
                ctx.request.assert_not_called()
                ctx.mutate.assert_not_called()
                ctx.exchange.assert_not_called()

    def test_shared_reference_normalizes_equivalent_explicit_guids(self):
        ctx = FakeContext()
        ctx.config.update(allow_create=False, data_agent_id="{" + AGENT + "}",
                          data_agent_ids={"data-agent.semantic": AGENT.replace("-", "")})
        result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
        self.assertEqual("PASS", result["status"])
        self.assertEqual(AGENT, result["evidence"]["agentId"])
        self.assertEqual({AGENT}, set(ctx.state["data_agents"].values()))
        ctx.mutate.assert_not_called()

    def test_malformed_reference_configuration_fails_before_requests(self):
        for config in ({"data_agent_ids": []}, {"data_agent_id": "not-a-guid"}):
            with self.subTest(config=config):
                ctx = FakeContext()
                ctx.config.update(config)
                result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
                self.assertEqual("BLOCKED", result["status"])
                self.assertEqual("ValueError", result["evidence"]["error"]["type"])
                ctx.request.assert_not_called()
                ctx.mutate.assert_not_called()

    def test_invalid_mode_is_explicitly_rejected_before_requests(self):
        for mode in ("invalid", "", None, 1, []):
            with self.subTest(mode=mode):
                ctx = FakeContext()
                ctx.config["data_agent_mode"] = mode
                result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
                self.assertEqual("BLOCKED", result["status"])
                self.assertIn("data_agent_mode must be", result["summary"])
                ctx.request.assert_not_called()
                ctx.mutate.assert_not_called()

    def test_isolated_mode_keeps_distinct_configured_ids(self):
        ctx = FakeContext()
        ctx.config.update(data_agent_mode="isolated", allow_create=False,
                          data_agent_ids={"data-agent.lakehouse": AGENT, "data-agent.semantic": SEMANTIC})
        for name, agent in ctx.config["data_agent_ids"].items():
            result = adapter.SCENARIOS[name](ctx)
            self.assertEqual(agent, result["evidence"]["agentId"])
            self.assertIn(f"/artifacts/{agent}/responses", ctx.exchange.call_args.args[2])
        ctx.mutate.assert_not_called()

    def test_isolated_mode_creates_per_case_drafts(self):
        ctx = FakeContext()
        ctx.config["data_agent_mode"] = "isolated"
        ctx.mutate.side_effect = [{"id": AGENT}, {"id": SEMANTIC}]
        adapter.SCENARIOS["data-agent.lakehouse"](ctx)
        adapter.SCENARIOS["data-agent.semantic"](ctx)
        self.assertEqual(2, ctx.mutate.call_count)
        self.assertEqual({"data-agent.lakehouse": AGENT, "data-agent.semantic": SEMANTIC},
                         ctx.state["data_agents"])

    def test_setup_failure_is_blocked_not_a_query_failure(self):
        ctx = FakeContext()
        ctx.existing()
        ctx.request.side_effect = HttpFailure(500, "setup read unavailable")
        result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
        self.assertEqual(result["status"], "BLOCKED")
        self.assertFalse(result["evidence"]["queryAttempted"])
        self.assertNotIn("queryDurationSeconds", result["evidence"])
        ctx.exchange.assert_not_called()

    def test_registry(self):
        self.assertEqual({"data-agent." + n for n in (
            "lakehouse", "kql", "warehouse", "sql", "mirror", "semantic", "sm-lakehouse",
            "sm-kql", "lakehouse-kql", "lakehouse-warehouse")}, set(adapter.SCENARIOS))

    def test_no_creation_without_consent(self):
        ctx = FakeContext()
        ctx.config["allow_create"] = False
        self.assertEqual("BLOCKED", adapter.SCENARIOS["data-agent.lakehouse"](ctx)["status"])
        ctx.mutate.assert_not_called()

    def test_created_id_saved_before_query_failure_without_export(self):
        ctx = FakeContext()
        ctx.runtime = HttpFailure(500, "query unavailable")
        result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
        self.assertEqual("FAIL", result["status"])
        self.assertTrue(result["evidence"]["queryAttempted"])
        self.assertEqual(AGENT, ctx.state["data_agents"]["data-agent.lakehouse"])
        self.assertTrue(any(e[:2] == ("save", "data-agent-resource") for e in ctx.events))
        self.assertEqual(ctx.mutate.call_count, 1)
        self.assertTrue(ctx.mutate.call_args.args[1].endswith("/dataAgents"))

    def test_existing_draft_queries_without_export_or_mutation(self):
        ctx = FakeContext()
        ctx.existing()
        result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
        self.assertEqual("PASS", result["status"])
        ctx.mutate.assert_not_called()
        self.assertTrue(result["evidence"]["queryAttempted"])
        self.assertFalse(result["evidence"]["configurationVerified"])
        self.assertEqual(result["evidence"]["queryCompletion"], "completed")
        self.assertGreaterEqual(result["evidence"]["queryDurationSeconds"], 0)
        self.assertEqual(ctx.exchange.call_args.kwargs["params"], {"agent": "aiskill", "stage": "sandbox"})
        self.assertEqual(ctx.state["data_agents"]["data-agent.lakehouse"], AGENT)

    def test_query_failure_keeps_reused_id_and_does_not_replace_draft(self):
        ctx = FakeContext()
        ctx.existing()
        ctx.config["allow_create"] = True
        ctx.runtime = HttpFailure(403, "runtime denied")
        result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
        self.assertEqual(result["status"], "FAIL")
        self.assertIn("query", result["summary"])
        self.assertEqual(result["evidence"]["phase"], "query")
        self.assertFalse(result["evidence"]["created"])
        self.assertEqual(ctx.state["data_agents"]["data-agent.lakehouse"], AGENT)
        ctx.mutate.assert_not_called()
        ctx.exchange.assert_called_once()

    def test_wrong_runtime_source_does_not_pass_or_edit_configuration(self):
        ctx = FakeContext()
        ctx.existing()
        ctx.config["allow_create"] = True
        ctx.runtime = response(terminal(SEMANTIC))
        self.assertEqual("FAIL", adapter.SCENARIOS["data-agent.lakehouse"](ctx)["status"])
        ctx.mutate.assert_not_called()
        ctx.exchange.assert_called_once()

    def test_resolver_warnings_do_not_skip_runtime_or_require_discovery(self):
        ctx = FakeContext()
        ctx.definition["model"]["tables"][0]["partitions"][0]["annotations"][0]["value"] = "Failed"
        result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
        self.assertEqual("PASS", result["status"])
        self.assertGreaterEqual(len(result["evidence"]["warnings"]), 1)
        ctx.exchange.assert_called_once()
        self.assertFalse(any("/ontologydatasources" in call.args[2] for call in ctx.request.call_args_list))

    def test_runtime_timeout_not_replayed_and_next_scenario_runs(self):
        ctx = FakeContext()
        ctx.runtime = TimeoutError("SSE total budget exhausted")
        self.assertEqual("TIMEOUT", adapter.SCENARIOS["data-agent.lakehouse"](ctx)["status"])
        self.assertEqual(1, ctx.exchange.call_count)
        ctx.runtime = response(terminal())
        self.assertEqual("PASS", adapter.SCENARIOS["data-agent.lakehouse"](ctx)["status"])
        self.assertEqual(2, ctx.exchange.call_count)

    def test_missing_entity_blocks_before_creation(self):
        ctx = FakeContext()
        ctx.definition["model"]["entities"] = []
        self.assertEqual("BLOCKED", adapter.SCENARIOS["data-agent.lakehouse"](ctx)["status"])
        ctx.mutate.assert_not_called()


class EvidenceTests(unittest.TestCase):
    def test_offline_entry_point_accepts_json_identities_without_mutating_inputs(self):
        selected = ["Lakehouse_Assets", "Lakehouse_Plants", "Lakehouse_Readings"]
        identities = {name: [LAKEHOUSE, WORKSPACE] for name in selected}
        doc = terminal()
        original = copy.deepcopy((doc, identities, selected))
        first = adapter.assess_response(doc, identities, selected)
        second = adapter.assess_response(doc, identities, selected)
        self.assertEqual("PASS", first["status"])
        self.assertEqual(first, second)
        self.assertEqual(original, (doc, identities, selected))

    def assess(self, value, group="Lakehouse", readings=None):
        readings = readings or group
        selected = [group + "_Assets", group + "_Plants", readings + "_Readings"]
        identities = {n: (SOURCE_IDS[n.rsplit("_", 1)[0]], WORKSPACE) for n in selected}
        evidence = {"warnings": []}
        return adapter.assess(value, identities, selected, evidence), evidence

    def test_actual_lakehouse_and_semantic_datasets_pass(self):
        for group in ("Lakehouse", "SemanticModel"):
            self.assertEqual("PASS", self.assess(terminal(SOURCE_IDS[group]), group)[0][0])

    def test_correct_answer_does_not_require_independent_execution(self):
        for output in ([{"type": "message", "content": [{"text": FULL_TABLE}]}],
                       pair("generate_files_data_insights.execute", {}, FULL_TABLE, "insight")):
            value = {"status": "completed", "output": output}
            result, evidence = self.assess(value)
            self.assertEqual("PASS", result[0])
            self.assertFalse(evidence["sourceEvidenceVerified"])
            self.assertFalse(evidence["sourceEvidenceRequired"])

    def test_empty_or_generated_code_only_is_not_an_answer(self):
        for output in ([], pair("generate_code", {}, "SELECT 10 AS A012ReadingCount", "code")):
            self.assertEqual("PARTIAL", self.assess({"status": "completed", "output": output})[0][0])

    def test_complete_structured_final_answer_passes_without_sources(self):
        doc = {"status": "completed", "output": [
            {"type": "message", "role": "assistant", "content": [
                {"type": "output_text", "text": json.dumps(adapter.EXPECTED)}]}]}
        result, evidence = self.assess(doc)
        self.assertEqual("PASS", result[0])
        self.assertEqual("PASS", evidence["answerCheck"]["status"])
        self.assertEqual(adapter.EXPECTED, evidence["answerCheck"]["actual"])
        self.assertFalse(evidence["sourceEvidenceVerified"])

    def test_offline_assessment_accepts_naive_utc_fixture_timestamp(self):
        answer = dict(adapter.EXPECTED, ObservedAt="2026-01-01T00:45:00")
        doc = {"status": "completed", "output": [
            {"type": "message", "role": "assistant", "content": [
                {"type": "output_text", "text": json.dumps(answer)}]}]}
        original = copy.deepcopy(doc)
        result = adapter.assess_response(doc, {}, ["Lakehouse_Assets", "Lakehouse_Plants", "Lakehouse_Readings"])
        self.assertEqual("PASS", result["status"])
        check = result["evidence"]["answerCheck"]
        self.assertEqual("2026-01-01T00:45:00Z", check["actual"]["ObservedAt"])
        self.assertEqual({"input": "2026-01-01T00:45:00", "assumedTimeZone": "UTC",
                          "scope": "Known-UTC sample fixture"}, check["timestampNormalization"])
        self.assertEqual(original, doc)

    def test_offline_assessment_rejects_wrong_naive_utc_fixture_timestamp(self):
        answer = dict(adapter.EXPECTED, ObservedAt="2026-01-01T00:46:00")
        doc = {"status": "completed", "output": [
            {"type": "message", "role": "assistant", "content": [
                {"type": "output_text", "text": json.dumps(answer)}]}]}
        result = adapter.assess_response(doc, {}, ["Lakehouse_Assets", "Lakehouse_Plants", "Lakehouse_Readings"])
        self.assertEqual("FAIL", result["status"])
        check = result["evidence"]["answerCheck"]
        self.assertEqual({"ObservedAt": {"expected": "2026-01-01T00:45:00Z",
                                        "actual": "2026-01-01T00:46:00Z"}}, check["mismatches"])

    def test_missing_structured_answer_fields_never_pass(self):
        for key in adapter.EXPECTED:
            with self.subTest(key=key):
                answer = dict(adapter.EXPECTED)
                del answer[key]
                doc = {"status": "completed", "output": [
                    {"type": "message", "content": [{"text": json.dumps(answer)}]}]}
                self.assertEqual("PARTIAL", self.assess(doc)[0][0])

    def test_missing_table_answer_fields_never_pass(self):
        for value in ("10", "32.9", "A012", "P03", "East Plant", "Boston", "R0120",
                      "2026-01-01T00:45:00Z"):
            with self.subTest(value=value):
                table = FULL_TABLE.replace(f"| {value} |", "| {} |")
                doc = {"status": "completed", "output": [
                    {"type": "message", "content": [{"text": table}]}]}
                self.assertEqual("PARTIAL", self.assess(doc)[0][0])

    def test_wrong_structured_answer_fails_even_with_correct_dataset(self):
        for key in adapter.EXPECTED:
            with self.subTest(key=key):
                answer = dict(adapter.EXPECTED, **{key: "wrong"})
                doc = terminal()
                doc["output"].append({"type": "message", "content": [{"text": json.dumps(answer)}]})
                self.assertEqual("FAIL", self.assess(doc)[0][0])

    def test_missing_fixture_source_identities_are_informational(self):
        ctx = FakeContext()
        ctx.definition["model"]["tables"] = []
        result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
        self.assertEqual("PASS", result["status"])
        self.assertFalse(result["evidence"]["sourceEvidenceVerified"])
        self.assertTrue(result["evidence"]["warnings"])

    def test_missing_runtime_source_identity_is_informational(self):
        for missing in ("omitted", None, ""):
            with self.subTest(missing=missing):
                doc = terminal()
                call = next(o for o in doc["output"] if o.get("call_id") == "execute"
                            and o["type"] == "function_call")
                args = json.loads(call["arguments"])
                for field in ("datasource_artifact_id", "datasource_workspace_id"):
                    if missing == "omitted":
                        del args[field]
                    else:
                        args[field] = missing
                call["arguments"] = json.dumps(args)
                result, evidence = self.assess(doc)
                self.assertEqual("PASS", result[0])
                self.assertFalse(evidence["sourceEvidenceVerified"])
                self.assertEqual([], evidence["wrongSourceEvidence"])

    def test_correct_answer_cannot_override_terminal_error_tool_failure_or_refusal(self):
        for failure in ("error", "failed-tool", "refusal"):
            with self.subTest(failure=failure):
                doc = terminal()
                if failure == "error":
                    doc["error"] = {"message": "service failure"}
                elif failure == "failed-tool":
                    doc["output"] += pair("other.tool", {}, "service failure", "failed", status="failed")
                else:
                    doc["output"].append({"type": "message", "content": [
                        {"type": "refusal", "refusal": "Cannot comply"}]})
                self.assertEqual("FAIL", self.assess(doc)[0][0])

    def test_correct_final_answer_cannot_override_wrong_count_or_contradictory_label(self):
        for doc in (count_terminal(count="120"), count_terminal(asset="A013"), terminal(KQL)):
            doc["output"].append({"type": "message", "content": [{"text": json.dumps(adapter.EXPECTED)}]})
            self.assertEqual("FAIL", self.assess(doc)[0][0])

    def test_correct_dataset_cannot_override_additional_failed_execution(self):
        doc = terminal()
        doc["output"] += execution(LAKEHOUSE, "failed.json", "failed", failed=True)
        self.assertEqual("FAIL", self.assess(doc)[0][0])

    def test_completed_tool_envelope_does_not_hide_explicit_service_error(self):
        for text in ("The request timed out. Try simplifying your question or reducing the data scope.",
                     "Error: service unavailable", "Execution failed: denied", "Query failed: unavailable"):
            with self.subTest(text=text):
                doc = terminal()
                doc["output"] += pair("trace.analyze_semantic_model", {}, text, "failed")
                result, evidence = self.assess(doc)
                self.assertEqual("FAIL", result[0])
                self.assertEqual(text, evidence["toolFailures"][0]["output"])

    def test_explicit_a012_label_with_contradictory_asset_fails_without_lineage(self):
        table = FULL_TABLE.replace("| A012 |", "| A013 |")
        doc = {"status": "completed", "output": [
            {"type": "message", "content": [{"text": table}]}]}
        result, evidence = self.assess(doc)
        self.assertEqual("FAIL", result[0])
        self.assertEqual("FAIL", evidence["answerChecks"]["A012ReadingCount"])

    def test_failed_execution_cannot_be_rescued_by_correct_table(self):
        value = terminal()
        result = next(o for o in value["output"] if o.get("call_id") == "execute"
                      and o["type"] == "function_call_output")
        result["metadata"]["diagnostic_details"] = '{"queries_ran":[{"is_error":true}]}'
        self.assertEqual("FAIL", self.assess(value)[0][0])

    def test_wrong_source_fails_but_missing_code_is_informational(self):
        for field, value in (("datasource_artifact_id", KQL), ("datasource_workspace_id", AGENT), ("code", "")):
            doc = terminal()
            call = next(o for o in doc["output"] if o["type"] == "function_call" and o["call_id"] == "execute")
            args = json.loads(call["arguments"])
            args[field] = value
            call["arguments"] = json.dumps(args)
            self.assertEqual("PASS" if field == "code" else "FAIL", self.assess(doc)[0][0])

    def test_overwritten_file_cannot_reuse_old_execution_provenance(self):
        doc = terminal()
        doc["output"] += execution(KQL, "result.json", "overwrite")
        self.assertEqual("FAIL", self.assess(doc)[0][0])

    def test_wrong_fixture_data_fails_with_explicit_answer_checks(self):
        for table in (FULL_TABLE.replace("| 10 |", "| 110 |"),
                      FULL_TABLE.replace("R0120", "R0001"), FULL_TABLE.replace("Boston", "Paris")):
            result, evidence = self.assess(terminal(table=table))
            self.assertEqual("FAIL", result[0])
            self.assertIn("FAIL", evidence["answerChecks"].values())

    def test_generic_count_must_be_for_a012(self):
        table = """
File: result.json
Total rows: 2
| ReadingCount | TemperatureC | AssetId | PlantId | PlantName | City | ReadingId | ObservedAt |
|:---|:---|:---|:---|:---|:---|:---|:---|
| 10 | {} | A013 | {} | {} | {} | {} | {} |
| {} | 32.9 | A012 | P03 | East Plant | Boston | R0120 | 2026-01-01T00:45:00Z |
"""
        self.assertEqual("PARTIAL", self.assess(terminal(table=table))[0][0])

    def test_sql_and_dax_count_only_rows_use_their_own_execution_proof(self):
        for group, code in (("Lakehouse", SQL), ("SemanticModel", DAX)):
            with self.subTest(group=group):
                result, evidence = self.assess(count_terminal(SOURCE_IDS[group], code), group)
                self.assertEqual("PASS", result[0])
                self.assertTrue(evidence["sourceEvidenceVerified"])
                self.assertEqual([{"basis": "executed-query", "file": "count.json",
                                   "callId": "count-execute", "column": "readingcount", "value": "10"}],
                                 evidence["countScopeEvidence"])
                self.assertTrue(all(v == "PASS" for v in evidence["answerChecks"].values()))

    def test_explicit_row_label_still_works_and_records_basis(self):
        result, evidence = self.assess(terminal())
        self.assertEqual("PASS", result[0])
        self.assertEqual("row-label", evidence["countScopeEvidence"][0]["basis"])

    def test_proven_scope_with_wrong_numeric_count_fails(self):
        result, evidence = self.assess(count_terminal(count="120"))
        self.assertEqual("FAIL", result[0])
        self.assertEqual("FAIL", evidence["answerChecks"]["A012ReadingCount"])

    def test_correct_count_cannot_mask_another_proven_wrong_count(self):
        doc = count_terminal(code=SQL + " UNION ALL " + SQL + " AND TemperatureC > 30")
        doc["output"][-1]["output"] += "| 9 |\n"
        result, evidence = self.assess(doc)
        self.assertEqual("FAIL", result[0])
        self.assertEqual(["10", "9"], [r["value"] for r in evidence["countScopeEvidence"]])

    def test_query_proof_cannot_override_contradictory_row_asset(self):
        result, evidence = self.assess(count_terminal(asset="A013"))
        self.assertEqual("FAIL", result[0])
        self.assertEqual([], evidence["countScopeEvidence"])

    def test_missing_row_asset_can_use_query_proof(self):
        for asset in (None, "{}", "null"):
            with self.subTest(asset=asset):
                self.assertEqual("PASS", self.assess(count_terminal(asset=asset))[0][0])

    def test_other_file_query_cannot_bless_unfiltered_count(self):
        doc = count_terminal(code=SQL.split(" WHERE")[0])
        other = execution(LAKEHOUSE, "other.json", "other-execute")
        args = json.loads(other[0]["arguments"])
        args["code"] = SQL
        other[0]["arguments"] = json.dumps(args)
        doc["output"] += other
        result, evidence = self.assess(doc)
        self.assertEqual("PARTIAL", result[0])
        self.assertEqual("UNVERIFIED", evidence["answerChecks"]["A012ReadingCount"])

    def test_unrelated_filename_cannot_use_count_scope(self):
        doc = count_terminal()
        doc["output"][-1]["output"] = doc["output"][-1]["output"].replace("count.json", "unexecuted.json")
        self.assertEqual("PARTIAL", self.assess(doc)[0][0])

    def test_later_execution_cannot_grant_scope_to_an_earlier_dataset_inspection(self):
        doc = count_terminal()
        execution_rows = [o for o in doc["output"] if o["call_id"] == "count-execute"]
        doc["output"] = [o for o in doc["output"] if o["call_id"] != "count-execute"] + execution_rows
        result, evidence = self.assess(doc)
        self.assertEqual("PARTIAL", result[0])
        proof = next(t["countScope"] for t in evidence["resultTables"] if t["file"] == "count.json")
        self.assertIn("precedes", proof["reason"])

    def test_count_proof_requires_expected_source_workspace_and_executed_code(self):
        for field, value in (("datasource_artifact_id", KQL), ("datasource_workspace_id", AGENT), ("code", "")):
            with self.subTest(field=field):
                doc = count_terminal()
                call = next(o for o in doc["output"] if o["type"] == "function_call"
                            and o["call_id"] == "count-execute")
                args = json.loads(call["arguments"])
                args[field] = value
                args["natural_language_query"] = "Readings for A012; return 10"
                call["arguments"] = json.dumps(args)
                self.assertEqual("PARTIAL" if field == "code" else "FAIL", self.assess(doc)[0][0])

    def test_failed_or_missing_count_execution_cannot_grant_proof(self):
        for failed in (True, False):
            doc = count_terminal()
            result = next(o for o in doc["output"] if o["type"] == "function_call_output"
                          and o["call_id"] == "count-execute")
            if failed:
                result["metadata"]["diagnostic_details"] = '{"queries_ran":[{"is_error":true}]}'
            else:
                doc["output"].remove(result)
            self.assertEqual("FAIL", self.assess(doc)[0][0])

    def test_reused_filename_cannot_rebind_old_count_to_new_scope(self):
        for new_code in (SQL, SQL.replace("A012", "A013"), "SELECT * FROM Readings"):
            with self.subTest(new_code=new_code):
                doc = count_terminal()
                overwrite = execution(LAKEHOUSE, "count.json", "overwrite")
                args = json.loads(overwrite[0]["arguments"])
                args["code"] = new_code
                overwrite[0]["arguments"] = json.dumps(args)
                doc["output"] += overwrite
                result, evidence = self.assess(doc)
                self.assertEqual("PARTIAL", result[0])
                proof = next(t["countScope"] for t in evidence["resultTables"] if t["file"] == "count.json")
                self.assertIn("ambiguous", proof["reason"])

    def test_unlinked_result_file_can_supply_explicitly_labeled_answer(self):
        doc = terminal(table=FULL_TABLE.replace("result.json", "unexecuted.json"))
        self.assertEqual("PASS", self.assess(doc)[0][0])

    def test_missing_ontology_runtime_provenance_is_informational(self):
        doc = terminal()
        doc["output"] = [o for o in doc["output"] if o["call_id"] != "context"]
        self.assertEqual("PASS", self.assess(doc)[0][0])

    def test_cross_source_missing_independent_join_proof_is_informational(self):
        result, evidence = self.assess(terminal(), "SemanticModel", "Lakehouse")
        self.assertEqual("PASS", result[0])
        self.assertFalse(evidence["sourceEvidenceVerified"])

    def test_cross_source_joined_datasets_pass(self):
        doc = terminal()
        doc["output"][1]["output"] = json.dumps({"attached": [{"id": LAKEHOUSE}, {"id": SEMANTIC}]})
        doc["output"] += execution(SEMANTIC, "context.json", "context-execution")
        doc["output"] += pair("generate_files_data_insights.execute", {}, """
File: context.json
Total rows: 1
| AssetId | PlantId | PlantName | City |
|:---|:---|:---|:---|
| A012 | P03 | East Plant | Boston |
""", "context-insights")
        self.assertEqual("PASS", self.assess(doc, "SemanticModel", "Lakehouse")[0][0])

    def test_incomplete_terminal_never_passes(self):
        doc = terminal()
        doc["status"] = "incomplete"
        self.assertEqual("FAIL", self.assess(doc)[0][0])

    def test_json_and_sse_parse_without_reasoning(self):
        doc = terminal()
        doc["output"].append({"type": "reasoning", "content": "not retained"})
        for sse in (True, False):
            parsed = adapter.terminal_response(response(doc, sse))
            self.assertEqual("completed", parsed["status"])
            self.assertFalse(any(o["type"] == "reasoning" for o in parsed["output"]))

    def test_empty_missing_terminal_and_malformed_sse_fail(self):
        for text in ("", "data: {\"type\":\"response.created\"}\n\n", "data: nonsense\n\n"):
            result = response({})
            result._content = text.encode()
            with self.assertRaises(ValueError):
                adapter.terminal_response(result)

    def test_kql_and_unsupported_sources_are_attempted_not_assumed_pass(self):
        for case in ("kql", "warehouse", "sql", "mirror"):
            ctx = FakeContext()
            ctx.runtime = response({"status": "completed", "output": []})
            result = adapter.SCENARIOS["data-agent." + case](ctx)
            self.assertEqual("PARTIAL", result["status"])
            ctx.exchange.assert_called_once()
            self.assertTrue(result["evidence"]["warnings"])


if __name__ == "__main__":
    unittest.main()
