import copy
import io
import json
import tempfile
import unittest
from contextlib import ExitStack, redirect_stdout
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch
from urllib.parse import quote

import run_sample
from create_sample import Manifest
from test_create_ontology import GUID, inventory, metadata

TARGET = "22222222-2222-4222-8222-222222222222"
ONTOLOGY = "33333333-3333-4333-8333-333333333333"


class WrappedSampleTests(unittest.TestCase):
    def argv(self, folder):
        return ["--tenant-id", GUID, "--capacity-id", GUID, "--workspace-id", TARGET,
                "--ontology-name", "BoundSample", "--run-directory", str(folder / "run")]

    def test_prompts_for_three_ids(self):
        with patch("builtins.input", side_effect=[GUID, GUID, TARGET]) as prompt:
            args = run_sample.arguments([])
        self.assertEqual(prompt.call_count, 3)
        self.assertEqual(args.workspace_id, TARGET)
        self.assertEqual(args.capacity_id, GUID)

    def test_preview_never_authenticates_or_creates_outputs(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            with patch("run_sample.run") as run:
                output = io.StringIO()
                with redirect_stdout(output):
                    run_sample.main(self.argv(folder))
                plan = json.loads(output.getvalue())
                self.assertEqual(plan["expected"]["sourceItemTypes"], 7)
                self.assertEqual(plan["targetWorkspaceId"], TARGET)
                self.assertEqual(plan["verificationSettleSeconds"], 120)
                self.assertEqual(plan["kqlRequestTimeoutSeconds"], 300)
                self.assertEqual(plan["deferredValidation"], {"SemanticModel": ["refresh", "sampleRows"]})
                self.assertFalse((folder / "run").exists())
                run.assert_not_called()

    def test_wait_settings_are_forwarded_to_source_provisioning(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            folder = Path(temporary)
            stack.enter_context(patch.dict("sys.modules", {
                "sample_auth": SimpleNamespace(open_credential=MagicMock())
            }))
            stack.enter_context(patch("run_sample.check_local_dependencies"))
            run = stack.enter_context(patch("run_sample.run"))
            with redirect_stdout(io.StringIO()):
                run_sample.main(self.argv(folder) + [
                    "--execute", "--settle-seconds", "300", "--kql-request-timeout", "600",
                ])
            source_args = run.call_args.args[3]
            self.assertEqual(source_args.settle_seconds, 300)
            self.assertEqual(source_args.kql_request_timeout, 600)

    def test_invalid_wait_settings_fail_before_prompting(self):
        for flag, value in (("--settle-seconds", "-1"), ("--settle-seconds", "86401"),
                            ("--kql-request-timeout", "29"), ("--kql-request-timeout", "3601")):
            with self.subTest(flag=flag, value=value), patch("builtins.input") as prompt, \
                    patch("sys.stderr", io.StringIO()), self.assertRaises(SystemExit):
                run_sample.arguments([flag, value])
            prompt.assert_not_called()

    def test_existing_id_requires_read_only_verification(self):
        with redirect_stdout(io.StringIO()), patch("sys.stderr", io.StringIO()):
            for flags in (["--ontology-id", ONTOLOGY], ["--verify-only"]):
                with self.assertRaises(SystemExit):
                    run_sample.arguments(flags)

    def test_no_devops_or_sdk_token_is_requested(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            folder = Path(temporary)
            opened = MagicMock()
            credential = opened.return_value.__enter__.return_value
            stack.enter_context(patch.dict("sys.modules", {
                "sample_auth": SimpleNamespace(open_credential=opened)
            }))
            stack.enter_context(patch("run_sample.check_local_dependencies"))
            stack.enter_context(patch("run_sample.run"))
            with redirect_stdout(io.StringIO()):
                run_sample.main(self.argv(folder) + ["--execute"])
            scopes = [call.args[0] for call in credential.get_token.call_args_list]
            self.assertEqual(scopes, [run_sample.PBI_SCOPE, run_sample.STORAGE_SCOPE,
                                      run_sample.SQL_SCOPE, "https://kusto.kusto.windows.net/.default"])

    def setup_run(self, folder, stack, verify=False):
        flags = self.argv(folder)
        if verify:
            flags += ["--verify-only", "--sources-manifest", str(folder / "sources.json"),
                      "--ontology-id", ONTOLOGY]
        args = run_sample.arguments(flags)
        source_args = run_sample.source_arguments([
            "--tenant-id", GUID, "--capacity-id", GUID, "--workspace-name", "NewSources",
            "--manifest", str(folder / "sources.json"),
        ])
        api = stack.enter_context(patch("run_sample.TargetApi")).return_value
        api.base = args.target_fabric_api
        source_api = stack.enter_context(patch("run_sample.Api")).return_value
        source_api.base = source_args.fabric_api
        api.json.side_effect = [{"id": TARGET, "capacityId": GUID}, (
            {"id": ONTOLOGY, "type": "Ontology", "displayName": "BoundSample"} if verify else {"value": []}
        )]
        api.mutate.return_value = {"id": ONTOLOGY, "type": "Ontology", "displayName": "BoundSample"}
        sources = stack.enter_context(patch("run_sample.provision_sources", return_value=inventory()))
        stack.enter_context(patch("run_sample.discover_sources", return_value=metadata()))
        stack.enter_context(patch("run_sample.serialize_definition", return_value={"definition": {"parts": []}}))
        readback = stack.enter_context(patch("run_sample.read_and_verify"))
        manifest = Manifest(folder / "result.json", {})
        return args, source_args, api, sources, readback, manifest

    def test_target_routing_is_separate_for_create_reuse_manifest_and_verification(self):
        for network in ("public", "wspl", "tenantpl"):
            for mode in ("create", "workspace", "manifest", "verify"):
                with self.subTest(network=network, mode=mode), \
                        tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
                    args, source_args, api, sources, readback, manifest = self.setup_run(
                        Path(temporary), stack, verify=mode == "verify")
                    args.target_network = network
                    args.target_fabric_api = run_sample.target_fabric_api(network, TARGET, GUID)
                    api.base = args.target_fabric_api
                    reused = stack.enter_context(patch("run_sample.reuse_workspace_sources", return_value=inventory()))
                    if mode == "workspace":
                        args.skip_source_creation = True
                        args.source_workspace_id = GUID
                    state = inventory() if mode in ("manifest", "verify") else None
                    credential = MagicMock()
                    run_sample.run(args, credential, manifest, None if mode == "workspace" else source_args, state)
                    run_sample.TargetApi.assert_called_once_with(
                        args.target_fabric_api, run_sample.PBI_SCOPE, credential, args.timeout, manifest.operation)
                    run_sample.Api.assert_called_once_with(
                        run_sample.DAILY_ENDPOINTS["fabric"], run_sample.PBI_SCOPE,
                        credential, args.timeout, manifest.operation)
                    source_api = run_sample.Api.return_value
                    run_sample.discover_sources.assert_called_once_with(source_api, inventory())
                    if mode == "workspace":
                        reused.assert_called_once_with(args, credential, source_api)
                    readback.assert_called_once()
                    self.assertIs(readback.call_args.args[0], api)
                    self.assertTrue(all(call.args[1].startswith(api.base + "/workspaces/" + TARGET)
                                        for call in api.json.call_args_list))
                    self.assertTrue(all(call.args[0].startswith(api.base + "/workspaces/" + TARGET)
                                        for call in api.mutate.call_args_list))
                    self.assertEqual(sources.call_count, 1 if mode == "create" else 0)
                    self.assertEqual(api.mutate.call_count, 0 if mode == "verify" else 2)
                    self.assertEqual(manifest.data["status"], "succeeded")
                    api.close.assert_called_once()
                    source_api.close.assert_called_once()

    def test_target_mode_and_endpoint_are_recorded_in_plan_and_manifest(self):
        for network in ("wspl", "tenantpl"):
            with self.subTest(network=network), tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
                folder = Path(temporary)
                stack.enter_context(patch.dict("sys.modules", {
                    "sample_auth": SimpleNamespace(open_credential=MagicMock())
                }))
                stack.enter_context(patch("run_sample.check_local_dependencies"))
                run = stack.enter_context(patch("run_sample.run"))
                with redirect_stdout(io.StringIO()) as output:
                    run_sample.main(self.argv(folder) + ["--target-network", network, "--execute"])
                plan = json.loads(output.getvalue())
                self.assertEqual(plan["targetNetwork"], network)
                self.assertEqual(plan["targetFabricApi"], run_sample.target_fabric_api(network, TARGET, GUID))
                persisted = json.loads((folder / "run" / "run.manifest.json").read_text())
                self.assertEqual(persisted["targetFabricApi"], plan["targetFabricApi"])
                self.assertEqual(run.call_args.args[3].fabric_api, run_sample.DAILY_ENDPOINTS["fabric"])

    def test_ux_mode_keeps_source_handling_and_never_uses_alm_definition_calls(self):
        for network in ("public", "wspl", "tenantpl"):
            for mode in ("create", "workspace", "manifest", "verify"):
                with self.subTest(network=network, mode=mode), \
                        tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
                    args, source_args, api, sources, readback, manifest = self.setup_run(
                        Path(temporary), stack, verify=mode == "verify")
                    args.authoring_mode = "ux"
                    args.target_network = network
                    args.target_fabric_api = run_sample.target_fabric_api(network, TARGET, GUID)
                    api.base = args.target_fabric_api
                    ux = stack.enter_context(patch("run_sample.author_and_verify"))
                    reused = stack.enter_context(patch("run_sample.reuse_workspace_sources", return_value=inventory()))
                    if mode == "workspace":
                        args.skip_source_creation = True
                    state = inventory() if mode in ("manifest", "verify") else None
                    credential = MagicMock()
                    run_sample.run(args, credential, manifest, None if mode == "workspace" else source_args, state)
                    ux.assert_called_once_with(args, credential, {"id": TARGET, "capacityId": GUID},
                                               {"id": ONTOLOGY, "type": "Ontology", "displayName": "BoundSample"},
                                               manifest.data["authoredDefinition"], manifest)
                    self.assertEqual(api.mutate.call_count, 0 if mode == "verify" else 1)
                    self.assertEqual(sources.call_count, 1 if mode == "create" else 0)
                    self.assertEqual(reused.call_count, 1 if mode == "workspace" else 0)
                    readback.assert_not_called()
                    run_sample.serialize_definition.assert_not_called()
                    self.assertNotIn("publicRequest", manifest.data)

    def test_source_workspace_creation_and_target_ontology_are_separate(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            folder = Path(temporary)
            args, source_args, api, sources, readback, manifest = self.setup_run(folder, stack)
            run_sample.run(args, MagicMock(), manifest, source_args)
            self.assertIsNone(sources.call_args.args[0].workspace_id)
            target = f"{api.base}/workspaces/{TARGET}"
            self.assertEqual(api.mutate.call_args_list[0].args, (
                target + "/items", {"displayName": "BoundSample", "type": "Ontology"}))
            self.assertEqual(api.mutate.call_args_list[1].args[0],
                             target + f"/ontologies/{ONTOLOGY}/updateDefinition")
            self.assertEqual(readback.call_args.args[-1], TARGET)
            self.assertEqual(manifest.data["sourceWorkspaceId"], GUID)
            self.assertTrue(manifest.data["writeCompleted"])
            self.assertEqual(manifest.data["status"], "succeeded")
            expression = next(entry for entry in manifest.data["authoredDefinition"]["model"]["expressions"]
                              if entry["name"] == "SemanticModel_Source")
            self.assertIn(quote(inventory()["workspaceName"], safe=""), expression["expression"])
            self.assertNotIn(TARGET, json.dumps(manifest.data["authoredDefinition"]))

    def test_hybrid_orders_baseline_write_and_verification_before_extension(self):
        for verify in (False, True):
            with self.subTest(verify=verify), tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
                args, source_args, api, sources, readback, manifest = self.setup_run(
                    Path(temporary), stack, verify=verify)
                args.authoring_mode = "hybrid"
                events = []

                def read_baseline(*values):
                    events.append("alm-read")
                    self.assertTrue(manifest.data["almWriteCompleted"])
                    manifest.data["storedDefinition"] = copy.deepcopy(values[3])

                readback.side_effect = read_baseline
                ux = stack.enter_context(patch("run_sample.author_and_verify"))

                def extend(*values, **kwargs):
                    events.append("ux")
                    self.assertEqual(api.mutate.call_count, 0 if verify else 2)
                    if not verify:
                        self.assertTrue(manifest.data["almBaselineVerified"])
                        self.assertEqual(manifest.data["almStoredDefinition"], kwargs["baseline"])
                    self.assertEqual(kwargs["source_state"], inventory())
                    self.assertEqual(
                        [e["name"] for e in kwargs["baseline"]["model"]["expressions"]],
                        ["Warehouse_Source", "SemanticModel_Source"])
                    self.assertEqual(
                        [e["name"] for e in kwargs["additions"]["model"]["expressions"]],
                        ["Lakehouse_Source", "MirroredDatabase_Source", "SQLDatabase_Source"])
                    self.assertNotIn("SemanticModel", json.dumps(kwargs["additions"]))
                    self.assertEqual(len(values[4]["model"]["tables"]), 18)

                ux.side_effect = extend
                run_sample.run(args, MagicMock(), manifest, source_args, inventory())
                self.assertEqual(events, ["ux"] if verify else ["alm-read", "ux"])
                self.assertEqual(manifest.data["status"], "succeeded")
                sources.assert_not_called()
                if verify:
                    run_sample.serialize_definition.assert_not_called()
                    api.mutate.assert_not_called()
                    self.assertNotIn("writeCompleted", manifest.data)
                else:
                    self.assertEqual(run_sample.serialize_definition.call_args.args[0],
                                     manifest.data["almBaselineDefinition"])
                    self.assertEqual(len(readback.call_args.args[3]["model"]["tables"]), 9)

    def test_hybrid_failures_preserve_phase_evidence_without_replay(self):
        for phase in ("write", "baseline-read", "ux"):
            with self.subTest(phase=phase), tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
                args, source_args, api, _, readback, manifest = self.setup_run(Path(temporary), stack)
                args.authoring_mode = "hybrid"
                ux = stack.enter_context(patch("run_sample.author_and_verify"))
                if phase == "write":
                    api.mutate.side_effect = [
                        {"id": ONTOLOGY, "type": "Ontology", "displayName": "BoundSample"},
                        RuntimeError("write"),
                    ]
                elif phase == "baseline-read":
                    readback.side_effect = RuntimeError("baseline-read")
                else:
                    def read_baseline(*values):
                        manifest.data["storedDefinition"] = copy.deepcopy(values[3])
                    readback.side_effect = read_baseline
                    ux.side_effect = RuntimeError("ux")
                with self.assertRaisesRegex(RuntimeError, phase):
                    run_sample.run(args, MagicMock(), manifest, source_args, inventory())
                saved = json.loads(manifest.path.read_text())
                self.assertEqual(saved["items"]["Ontology"]["id"], ONTOLOGY)
                self.assertEqual(saved.get("almWriteCompleted", False), phase != "write")
                self.assertEqual(saved.get("almBaselineVerified", False), phase == "ux")
                self.assertNotIn("uxWriteCompleted", saved)
                self.assertEqual(api.mutate.call_count, 2)
                self.assertEqual(ux.call_count, 1 if phase == "ux" else 0)

    def test_hybrid_preview_records_both_groups_and_requires_private_routes(self):
        with tempfile.TemporaryDirectory() as temporary, patch("sample_auth.open_credential") as authenticate:
            with redirect_stdout(io.StringIO()) as output:
                run_sample.main(self.argv(Path(temporary)) + ["--authoring-mode", "hybrid", "--auth", "cli"])
            plan = json.loads(output.getvalue())
            self.assertEqual(plan["authoringMode"], "hybrid")
            self.assertEqual(plan["authentication"], "cli")
            self.assertEqual(plan["uxTokenVersion"], "v2")
            self.assertEqual(plan["authoringPhases"][0]["sourceGroups"], list(run_sample.ALM_GROUPS))
            self.assertEqual(plan["authoringPhases"][1]["sourceGroups"], list(run_sample.UX_GROUPS))
            authenticate.assert_not_called()
            with patch("sys.stderr", io.StringIO()), patch("builtins.input") as prompt:
                with self.assertRaises(SystemExit):
                    run_sample.arguments(["--authoring-mode", "hybrid", "--target-network", "wspl"])
                prompt.assert_not_called()

    def test_existing_workspace_mode_only_creates_target_ontology(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            args, _, api, sources, readback, manifest = self.setup_run(Path(temporary), stack)
            args.skip_source_creation = True
            args.source_workspace_id = GUID
            reused = stack.enter_context(patch("run_sample.reuse_workspace_sources", return_value=inventory()))
            run_sample.run(args, MagicMock(), manifest, None)
            reused.assert_called_once()
            sources.assert_not_called()
            self.assertEqual(api.mutate.call_count, 2)
            self.assertTrue(all(f"/workspaces/{TARGET}/" in call.args[0] for call in api.mutate.call_args_list))
            readback.assert_called_once()
            self.assertEqual(manifest.data["sourceWorkspaceId"], GUID)
            self.assertEqual(manifest.data["status"], "succeeded")

    def test_discovery_failure_never_creates_ontology(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            args, _, api, sources, _, manifest = self.setup_run(Path(temporary), stack)
            args.skip_source_creation = True
            stack.enter_context(patch("run_sample.reuse_workspace_sources", side_effect=ValueError("Ambiguous sources")))
            with self.assertRaisesRegex(ValueError, "Ambiguous"):
                run_sample.run(args, MagicMock(), manifest, None)
            sources.assert_not_called()
            api.mutate.assert_not_called()

    def test_existing_workspace_supports_read_only_ontology_verification(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            args, _, api, sources, readback, manifest = self.setup_run(Path(temporary), stack, verify=True)
            args.skip_source_creation = True
            args.source_workspace_id = GUID
            args.sources_manifest = None
            stack.enter_context(patch("run_sample.reuse_workspace_sources", return_value=inventory()))
            run_sample.run(args, MagicMock(), manifest, None)
            sources.assert_not_called()
            api.mutate.assert_not_called()
            readback.assert_called_once()

    def test_manifest_capacity_is_read_without_prompting(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            source = folder / "sources.json"
            source.write_text(json.dumps(inventory()), encoding="utf-8")
            with patch("builtins.input") as prompt, redirect_stdout(io.StringIO()) as output:
                run_sample.main([
                    "--tenant-id", GUID, "--workspace-id", TARGET, "--sources-manifest", str(source),
                ])
            prompt.assert_not_called()
            plan = json.loads(output.getvalue())
            self.assertEqual(plan["capacityId"], GUID)
            self.assertFalse(plan["createsSourceItems"])

    def test_verify_only_does_not_create_sources_or_update_ontology(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            args, source_args, api, sources, readback, manifest = self.setup_run(Path(temporary), stack, verify=True)
            run_sample.run(args, MagicMock(), manifest, source_args, inventory())
            sources.assert_not_called()
            api.mutate.assert_not_called()
            readback.assert_called_once()
            self.assertNotIn("writeCompleted", manifest.data)

    def test_main_workflow_reaches_definition_readback_with_semantic_data_deferred(self):
        for mode in ("create", "reuse", "verify"):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
                args, source_args, api, sources, readback, manifest = self.setup_run(
                    Path(temporary), stack, verify=mode == "verify")
                state = inventory()
                del state["verified"]["SemanticModel"]
                state["deferredValidation"] = {"SemanticModel": ["refresh", "sampleRows"]}
                sources.return_value = state
                run_sample.run(args, MagicMock(), manifest, source_args, None if mode == "create" else state)
                self.assertEqual(api.mutate.call_count, 0 if mode == "verify" else 2)
                readback.assert_called_once()
                self.assertEqual(manifest.data["status"], "succeeded")
                self.assertEqual(manifest.data["deferredValidation"], state["deferredValidation"])
                self.assertNotIn("SemanticModel", manifest.data["verified"]["sources"])
                self.assertEqual(len(manifest.data["authoredDefinition"]["model"]["tables"]), 18)

    def test_main_accepts_successful_deferred_source_manifest_without_reloading(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            folder = Path(temporary)
            state = inventory()
            del state["verified"]["SemanticModel"]
            state["deferredValidation"] = {"SemanticModel": ["refresh", "sampleRows"]}
            source = folder / "sources.json"
            source.write_text(json.dumps(state), encoding="utf-8")
            stack.enter_context(patch.dict("sys.modules", {
                "sample_auth": SimpleNamespace(open_credential=MagicMock())
            }))
            dependencies = stack.enter_context(patch("run_sample.check_local_dependencies"))
            run = stack.enter_context(patch("run_sample.run"))
            with redirect_stdout(io.StringIO()):
                run_sample.main(self.argv(folder) + ["--sources-manifest", str(source), "--execute"])
            self.assertEqual(run.call_args.args[4], state)
            dependencies.assert_not_called()

    def test_collision_on_second_page_stops_before_creation(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            args, source_args, api, sources, _, manifest = self.setup_run(Path(temporary), stack)
            api.json.side_effect = [
                {"id": TARGET, "capacityId": GUID},
                {"value": [], "continuationToken": "page2"},
                {"value": [{"displayName": "boundsample"}]},
            ]
            with self.assertRaisesRegex(ValueError, "already contains"):
                run_sample.run(args, MagicMock(), manifest, source_args)
            sources.assert_not_called()
            api.mutate.assert_not_called()
            self.assertEqual(api.json.call_args.kwargs["params"], {"continuationToken": "page2"})

    def test_repeated_pagination_is_rejected(self):
        api = MagicMock()
        api.json.return_value = {"value": [], "continuationToken": "same"}
        with self.assertRaisesRegex(RuntimeError, "Repeated"):
            list(run_sample.workspace_items(api, "https://example.com/workspaces/123"))

    def test_capacity_required_before_any_creation(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            args, source_args, api, sources, _, manifest = self.setup_run(Path(temporary), stack)
            api.json.side_effect = [{"id": TARGET}]
            with self.assertRaisesRegex(ValueError, "Fabric capacity"):
                run_sample.run(args, MagicMock(), manifest, source_args)
            sources.assert_not_called()
            api.mutate.assert_not_called()

    def test_created_id_is_saved_before_a_failed_definition_write(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            args, source_args, api, _, _, manifest = self.setup_run(Path(temporary), stack)
            api.mutate.side_effect = [
                {"id": ONTOLOGY, "displayName": "BoundSample", "type": "Ontology"},
                RuntimeError("Definition failed"),
            ]
            with self.assertRaisesRegex(RuntimeError, "Definition failed"):
                run_sample.run(args, MagicMock(), manifest, source_args, inventory())
            persisted = json.loads(manifest.path.read_text())
            self.assertEqual(persisted["items"]["Ontology"]["id"], ONTOLOGY)
            self.assertNotIn("writeCompleted", persisted)
            self.assertEqual(api.mutate.call_count, 2)

    def test_completed_write_is_saved_before_readback_failure(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            args, source_args, api, _, readback, manifest = self.setup_run(Path(temporary), stack)
            readback.side_effect = RuntimeError("Read-back unavailable")
            with self.assertRaisesRegex(RuntimeError, "Read-back unavailable"):
                run_sample.run(args, MagicMock(), manifest, source_args, inventory())
            self.assertTrue(json.loads(manifest.path.read_text())["writeCompleted"])
            self.assertEqual(api.mutate.call_count, 2)

    def test_existing_sources_must_match_tenant_capacity_and_separate_workspace(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            for field, value in (("tenantId", TARGET), ("capacityId", TARGET), ("workspaceId", TARGET)):
                state = copy.deepcopy(inventory())
                state[field] = value
                source = folder / "sources.json"
                source.write_text(json.dumps(state), encoding="utf-8")
                with self.subTest(field=field), self.assertRaises(ValueError):
                    run_sample.main(self.argv(folder) + ["--sources-manifest", str(source)])

    def test_source_failure_manifest_is_saved(self):
        with tempfile.TemporaryDirectory() as temporary, patch("run_sample.Provisioner") as provisioner:
            manifest = Manifest(Path(temporary) / "sources.json", {})
            provisioner.return_value.run.side_effect = RuntimeError("Replication failed")
            with self.assertRaisesRegex(RuntimeError, "Replication failed"):
                run_sample.provision_sources(MagicMock(), MagicMock(), manifest)
            self.assertEqual(json.loads(manifest.path.read_text())["status"], "failed")
            provisioner.return_value.close.assert_called_once()

    def test_audience_failure_stops_before_resources_or_manifests(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            folder = Path(temporary)
            credential = MagicMock()
            credential.get_token.side_effect = [object(), RuntimeError("Storage consent required")]
            opened = MagicMock()
            opened.return_value.__enter__.return_value = credential
            stack.enter_context(patch.dict("sys.modules", {"sample_auth": SimpleNamespace(open_credential=opened)}))
            stack.enter_context(patch("run_sample.check_local_dependencies"))
            run = stack.enter_context(patch("run_sample.run"))
            with redirect_stdout(io.StringIO()), self.assertRaisesRegex(RuntimeError, "Storage consent"):
                run_sample.main(self.argv(folder) + ["--execute"])
            run.assert_not_called()
            self.assertFalse((folder / "run").exists())
            opened.return_value.__exit__.assert_called_once()

    def test_run_failure_is_persisted_without_automatic_retry(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            folder = Path(temporary)
            stack.enter_context(patch.dict("sys.modules", {
                "sample_auth": SimpleNamespace(open_credential=MagicMock())
            }))
            stack.enter_context(patch("run_sample.check_local_dependencies"))
            run = stack.enter_context(patch("run_sample.run", side_effect=RuntimeError("Provision failed")))
            with redirect_stdout(io.StringIO()), self.assertLogs("ontology-sample", level="ERROR"):
                with self.assertRaisesRegex(RuntimeError, "Provision failed"):
                    run_sample.main(self.argv(folder) + ["--execute"])
            result = json.loads((folder / "run" / "run.manifest.json").read_text())
            self.assertEqual(result["status"], "failed")
            self.assertEqual(result["error"], "Provision failed")
            run.assert_called_once()

    def test_existing_run_directory_stops_before_authentication(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            (folder / "run").mkdir()
            with patch("run_sample.run") as run, redirect_stdout(io.StringIO()):
                with self.assertRaises(FileExistsError):
                    run_sample.main(self.argv(folder) + ["--execute"])
                run.assert_not_called()


if __name__ == "__main__":
    unittest.main()
