"""Refresh and verify the EXISTING sample Semantic Model without recreating any items."""

import argparse
import copy
import json
import logging
from contextlib import closing
from pathlib import Path
from urllib.parse import urlsplit
from uuid import UUID, uuid4

from create_sample import Manifest, Provisioner
from create_semantic_ontology import source_model, verify_source_schema
from retry_source import arguments as retry_arguments, prepare, remaining_sources
from sample_auth import open_credential
from target_routing import target_fabric_api
from ux_authoring import trusted_origin

LOG = logging.getLogger("ontology-sample")


def source_origin(value, state):
    origin = value if value in ("https://dailyapi.powerbi.com", "https://dailyapi.fabric.microsoft.com") else trusted_origin(value)
    host = urlsplit(origin).hostname
    if host.endswith((".daily-c.fabric.microsoft.com", ".pbidedicated.windows.net")):
        raise ValueError("Use a Power BI metadata/API origin, not the workload or XMLA host")
    if host.endswith(".w.dailyapi.fabric.microsoft.com"):
        expected = target_fabric_api("wspl", state["workspaceId"], state["tenantId"]).removesuffix("/v1")
        if origin != expected:
            raise ValueError("The workspace-scoped origin must belong to the SOURCE workspace, not the ontology workspace")
    return origin


def arguments(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sources-manifest", type=Path, required=True)
    parser.add_argument("--powerbi-api", help="Explicit source Power BI API origin; defaults to the recorded source origin")
    parser.add_argument("--verify-only", action="store_true", help="Check schema and exact rows without refreshing")
    parser.add_argument("--auth", choices=("auto", "cli", "browser"), default="auto")
    parser.add_argument("--client-id", type=lambda value: str(UUID(value)))
    parser.add_argument("--timeout", type=int, default=1800)
    parser.add_argument("--run-directory", type=Path)
    parser.add_argument("--execute", action="store_true", help="Enable live calls; otherwise print an offline plan")
    args = parser.parse_args(argv)
    args.run_directory = (args.run_directory or Path("runs") / f"semantic_data_{uuid4().hex[:12]}").resolve()
    return args


def load_plan(args):
    state = json.loads(args.sources_manifest.read_text(encoding="utf-8-sig"))
    if state.get("environment") != "Daily":
        raise ValueError("Use a Daily sources.manifest.json; other environments are not supported")
    retry_args = retry_arguments([
        "--sources-manifest", str(args.sources_manifest), "--source-type", "SemanticModel",
        "--verify-only", "--run-directory", str(args.run_directory), "--timeout", str(args.timeout),
    ])
    _, source_args = prepare(retry_args, state)
    if not source_args.fabric_api.endswith("/v1"):
        raise ValueError("The recorded source Fabric API must end in /v1")
    source_origin(source_args.fabric_api.removesuffix("/v1"), state)
    source_args.powerbi_api = source_origin(args.powerbi_api or source_args.powerbi_api, state)
    plan = {
        "operation": "verify-existing-semantic-data" if args.verify_only else "refresh-existing-semantic-data",
        "sourceWorkspaceId": state["workspaceId"], "semanticModelId": state["items"]["SemanticModel"]["id"],
        "powerbiApi": source_args.powerbi_api, "fabricApi": source_args.fabric_api,
        "sourceManifest": str(args.sources_manifest.resolve()), "outputManifest": str(source_args.manifest),
        "createsItems": False, "changesOntology": False, "changesModelDefinition": False,
        "refreshesModelData": not args.verify_only,
    }
    return state, source_args, plan


def run(provisioner, verify_only):
    state = provisioner.manifest.data
    provisioner.workspace = state["workspaceId"]
    provisioner.manifest.step("Checking existing source workspace and Semantic Model identity")
    workspace = provisioner.api.json("GET", provisioner.path("").rstrip("/"))
    if (workspace.get("capacityId", "").lower() != state["capacityId"].lower()
            or workspace.get("displayName") != state["workspaceName"]):
        raise ValueError("Source workspace identity changed; no refresh was requested")
    found = provisioner.api.json("GET", provisioner.item_path("SemanticModel"))
    item = state["items"]["SemanticModel"]
    if found.get("id", "").lower() != item["id"].lower() or found.get("displayName") != item["displayName"]:
        raise ValueError("Source Semantic Model identity changed; no refresh was requested")
    provisioner.manifest.step("Checking the existing Semantic Model tables, relationships and import partitions")
    exported = provisioner.api.mutate(provisioner.item_path("SemanticModel") + "/getDefinition",
                                     params={"format": "TMSL"})
    schema = verify_source_schema(exported)
    for table in source_model(exported)["tables"]:
        partitions = table.get("partitions", [])
        if (len(partitions) != 1 or partitions[0].get("mode", "import") != "import"
                or partitions[0].get("source", {}).get("type") != "m"):
            raise ValueError("Expected one M import partition per sample table; no refresh was requested")
    state.setdefault("verifiedDefinitions", {})["SemanticModel"] = schema
    if not verify_only:
        provisioner.seed_semantic()
        state["semanticRefreshCompleted"] = True
        state.setdefault("deferredValidation", {})["SemanticModel"] = ["sampleRows"]
        provisioner.manifest.save()
    provisioner.manifest.step("Verifying exact Semantic Model sample rows: Plants=3, Assets=12, Readings=120")
    provisioner.verify_semantic()
    state.get("deferredValidation", {}).pop("SemanticModel", None)
    state["remainingSources"] = remaining_sources(state)
    state["status"] = "partial" if state["remainingSources"] else "succeeded"
    state["retryStatus"] = "succeeded"
    provisioner.manifest.step("Existing Semantic Model data verified; no ontology or model-definition changes")


def main(argv=None):
    args = arguments(argv)
    state, source_args, plan = load_plan(args)
    print(json.dumps(plan, indent=2))
    if not args.execute:
        return
    if args.run_directory.exists():
        raise FileExistsError("Use a new run directory; inspect previous results before retrying")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logging.getLogger("azure").setLevel(logging.WARNING)
    args.run_directory.mkdir(parents=True, exist_ok=False)
    initial = copy.deepcopy(state)
    initial["endpoints"]["powerbi"] = source_args.powerbi_api
    for key in ("error", "step", "pendingOperation", "retryStatus", "remainingSources", "semanticRefreshCompleted"):
        initial.pop(key, None)
    manifest = Manifest(source_args.manifest, initial)
    manifest.data.update(items=copy.deepcopy(state["items"]), verified=copy.deepcopy(state["verified"]), retry=plan)
    manifest.data["verified"].pop("SemanticModel", None)
    manifest.data.setdefault("verifiedDefinitions", {}).pop("SemanticModel", None)
    manifest.data.setdefault("deferredValidation", {})["SemanticModel"] = ["refresh", "sampleRows"]
    manifest.save()
    try:
        with open_credential(state["tenantId"], mode=args.auth, client_id=args.client_id) as credential:
            with closing(Provisioner(source_args, credential, manifest)) as provisioner:
                run(provisioner, args.verify_only)
    except (Exception, KeyboardInterrupt) as error:
        manifest.data.update(status="failed", retryStatus="failed", error=str(error))
        manifest.save()
        LOG.exception("Semantic data retry stopped. No items deleted or recreated; inspect %s", manifest.path)
        raise
    LOG.info("Verified data. Input manifest unchanged; output: %s", manifest.path)


if __name__ == "__main__":
    main()
