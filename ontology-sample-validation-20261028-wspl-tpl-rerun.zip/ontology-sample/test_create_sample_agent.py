import copy
import io
import json
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import MagicMock, patch

import create_sample_agent as agent
from test_create_ontology import GUID, inventory
from test_create_semantic_ontology import NEW_ID, exported


class SampleAgentTests(unittest.TestCase):
    def test_data_agent_is_draft_and_only_references_semantic_model(self):
        parts = agent.documents("data", inventory())
        self.assertEqual(len(parts), 3)
        source = next(value for path, value in parts.items() if path.endswith("/datasource.json"))
        self.assertEqual(source["artifactId"], GUID)
        self.assertEqual(source["workspaceId"], GUID)
        self.assertEqual(source["type"], "semantic_model")
        self.assertEqual(source["elements"], [
            {"display_name": name, "type": "semantic_model.table", "is_selected": True}
            for name in ("Plants", "Assets", "Readings")
        ])
        self.assertTrue(agent.verify_documents("data", parts, agent.definition(parts), {})["definitionMatches"])

    def test_operations_agent_is_inactive_without_actions_or_destination(self):
        parts = agent.documents("operations", inventory(), GUID, GUID)
        item = {"properties": {"state": "Inactive"}}
        result = agent.verify_documents("operations", parts, agent.definition(parts), item)
        self.assertIs(result["shouldRun"], False)
        self.assertEqual(result["actions"], 0)
        for change in ("running", "state", "actions", "playbook", "destination", "source"):
            with self.subTest(change=change):
                changed = copy.deepcopy(parts)
                changed_item = copy.deepcopy(item)
                configuration = changed["Configurations.json"]
                if change == "running":
                    configuration["shouldRun"] = True
                elif change == "state":
                    changed_item["properties"]["state"] = "Active"
                elif change == "actions":
                    configuration["configuration"]["actions"] = {"unexpected": {}}
                elif change == "playbook":
                    configuration["playbook"] = {"unexpected": {}}
                elif change == "destination":
                    configuration["configuration"]["messageDestination"] = {"kind": "Recipient", "recipient": "x"}
                else:
                    configuration["configuration"]["dataSources"]["businessOntology"]["id"] = NEW_ID
                with self.assertRaises(ValueError):
                    agent.verify_documents("operations", parts, agent.definition(changed), changed_item)

    def test_data_agent_canonical_export_defaults_preserve_selection_checks(self):
        expected = agent.documents("data", inventory())
        changed = copy.deepcopy(expected)
        source = changed["Files/Config/draft/semantic-model-SampleModel/datasource.json"]
        source.update(dataSourceInstructions=None, userDescription=None, metadata=None)
        for element in source["elements"]:
            element.update(id=None, description=None, children=[])
        self.assertTrue(agent.verify_documents("data", expected, agent.definition(changed), {})["definitionMatches"])
        source["elements"][0]["children"] = [{"display_name": "Unrequested", "is_selected": True}]
        with self.assertRaises(ValueError):
            agent.verify_documents("data", expected, agent.definition(changed), {})

    def test_rejects_published_or_duplicate_parts_and_changed_sources(self):
        expected = agent.documents("data", inventory())
        for change in ("published", "publish_info", "duplicate", "source", "missing", "selection"):
            with self.subTest(change=change):
                changed = copy.deepcopy(expected)
                if change == "published":
                    changed["Files/Config/published/stage_config.json"] = {}
                elif change == "publish_info":
                    changed["Files/Config/publish_info.json"] = {}
                elif change == "source":
                    next(v for p, v in changed.items() if p.endswith("/datasource.json"))["artifactId"] = NEW_ID
                elif change == "missing":
                    changed.pop("Files/Config/draft/stage_config.json")
                elif change == "selection":
                    next(v for p, v in changed.items() if p.endswith("/datasource.json"))["elements"][0]["is_selected"] = False
                response = agent.definition(changed)
                if change == "duplicate":
                    response["definition"]["parts"].append(response["definition"]["parts"][0])
                with self.assertRaises(ValueError):
                    agent.verify_documents("data", expected, response, {})

    def run_flow(self, folder, kind, extra=(), collision=False):
        state = inventory()
        source = folder / "source.json"
        source.write_text(json.dumps(state), encoding="utf-8")
        result = folder / "result.json"
        item_type, collection = agent.COLLECTIONS[kind]
        item = {"id": NEW_ID, "displayName": "TestAgent", "type": item_type, "properties": {"state": "Inactive"}}
        expected = agent.documents(kind, state, GUID, GUID)
        api = MagicMock()
        api.base = state["endpoints"]["fabric"]

        def get(method, path, **kwargs):
            self.assertEqual(method, "GET")
            if path.endswith("/items"):
                return {"value": [{"displayName": "TestAgent"}] if collision else []}
            if path.endswith("/" + NEW_ID):
                return item
            if "/items/" in path:
                return {"id": GUID, "displayName": "AllSources", "type": "Ontology"}
            if "/semanticModels/" in path:
                return state["items"]["SemanticModel"]
            return {"capacityId": GUID}

        def mutate(path, body=None, **kwargs):
            if "/semanticModels/" in path:
                self.assertEqual(kwargs, {"params": {"format": "TMSL"}})
                return exported()
            if path.endswith("/getDefinition"):
                return agent.definition(expected)
            self.assertTrue(path.endswith("/" + collection))
            if "--unconfigured" in extra:
                self.assertNotIn("definition", body)
            else:
                self.assertEqual(body["definition"], agent.definition(expected)["definition"])
            return item

        api.json.side_effect = get
        api.mutate.side_effect = mutate
        argv = ["--kind", kind, "--sources-manifest", str(source), "--name", "TestAgent", "--manifest", str(result)]
        if kind == "operations" and "--unconfigured" not in extra:
            argv += ["--ontology-id", GUID]
        with patch.object(agent, "Api", return_value=api), patch.object(agent, "open_credential") as authentication, \
                redirect_stdout(io.StringIO()):
            agent.main([*argv, *extra])
        return api, authentication, result

    def test_offline_preview_never_creates_resources(self):
        for kind in agent.COLLECTIONS:
            with self.subTest(kind=kind), tempfile.TemporaryDirectory() as temporary:
                api, auth, result = self.run_flow(Path(temporary), kind)
                api.mutate.assert_not_called()
                auth.assert_not_called()
                self.assertFalse(result.exists())

    def test_create_and_readback_both_types_without_start_or_publish(self):
        for kind in agent.COLLECTIONS:
            with self.subTest(kind=kind), tempfile.TemporaryDirectory() as temporary:
                api, _, result = self.run_flow(Path(temporary), kind, ["--execute"])
                manifest = json.loads(result.read_text())
                self.assertEqual(manifest["status"], "succeeded")
                self.assertTrue(manifest["writeCompleted"])
                paths = [call.args[0] for call in api.mutate.call_args_list]
                self.assertEqual(sum(path.endswith("/" + agent.COLLECTIONS[kind][1]) for path in paths), 1)
                self.assertTrue(all(path.endswith("/getDefinition") or path.endswith("/" + agent.COLLECTIONS[kind][1])
                                    for path in paths))

    def test_verify_only_never_creates(self):
        for kind in agent.COLLECTIONS:
            with self.subTest(kind=kind), tempfile.TemporaryDirectory() as temporary:
                api, _, result = self.run_flow(Path(temporary), kind, ["--execute", "--verify-only", "--item-id", NEW_ID])
                self.assertNotIn("writeCompleted", json.loads(result.read_text()))
                self.assertTrue(all(call.args[0].endswith("/getDefinition") for call in api.mutate.call_args_list))

    def test_explicit_unconfigured_operations_agent_never_claims_connection(self):
        with tempfile.TemporaryDirectory() as temporary:
            api, _, result = self.run_flow(Path(temporary), "operations", ["--execute", "--unconfigured"])
            manifest = json.loads(result.read_text())
            self.assertEqual(manifest["status"], "succeeded")
            self.assertEqual(manifest["verified"]["OperationsAgent"],
                             {"state": "Inactive", "sourceAttached": False, "configurationVerified": False})
            self.assertEqual(api.mutate.call_count, 1)
            self.assertNotIn("sourceItem", manifest)

    def test_collision_stops_with_failed_manifest(self):
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaises(ValueError):
                self.run_flow(Path(temporary), "data", ["--execute"], collision=True)
            self.assertEqual(json.loads((Path(temporary) / "result.json").read_text())["status"], "failed")


if __name__ == "__main__":
    unittest.main()
