#Requires -Version 5.1
<#
.DESCRIPTION
Operations selects ten inactive native playbook-authoring cases plus a manual runtime SKIP.
Operations requires -AllowCreate for one fresh inactive artifact per run, shared by sequential previews.
An uncertain preview outcome blocks later Operations previews; -ReuseResults is Data Agent only.
Data Agent defaults to one fresh shared draft per run, selecting all ontology entities.
OA and ML reuse the configured workspace route; no separate endpoint prompts.
Existing paired service overrides remain supported. Use -PlanOnly to check prerequisites.
No Operations activation, monitoring, notifications or external actions are performed.
#>
[CmdletBinding()]
param(
    [string]$Config,
    [ValidateSet('ontology', 'mcp', 'data-agent', 'generation', 'operations')][string[]]$Agents,
    [string[]]$Scenarios,
    [string]$RerunFailed,
    [string]$ReuseResults,
    [string]$OutputDirectory,
    [string]$PythonExecutable,
    [switch]$ListScenarios,
    [switch]$PlanOnly,
    [switch]$Configure,
    [string]$SampleManifest,
    [switch]$AllowCreate,
    [switch]$Strict,
    [switch]$InstallDependencies
)

$ErrorActionPreference = 'Stop'
if (([int][bool]$Agents + [int][bool]$Scenarios + [int][bool]$RerunFailed) -gt 1) {
    throw 'Choose only one of -Agents, -Scenarios, or -RerunFailed.'
}
if (-not $ListScenarios -and -not $Config) { throw '-Config is required unless using -ListScenarios.' }
if ($SampleManifest -and -not $Configure) { throw '-SampleManifest requires -Configure.' }
if ($ReuseResults -and ($Configure -or $ListScenarios -or $AllowCreate)) {
    throw '-ReuseResults cannot be combined with -Configure, -ListScenarios or -AllowCreate.'
}
if ($Configure -and ($ListScenarios -or $PlanOnly -or $AllowCreate)) {
    throw '-Configure saves settings only; do not combine it with -ListScenarios, -PlanOnly or -AllowCreate.'
}
if (-not $OutputDirectory) {
    $OutputDirectory = Join-Path $PSScriptRoot ('runs\validation_' + [guid]::NewGuid().ToString('N').Substring(0, 12))
}
if (-not $ListScenarios -and -not $Configure -and (Test-Path -LiteralPath $OutputDirectory)) {
    throw 'OutputDirectory already exists. Choose a new directory; previous evidence is never overwritten.'
}
$launchArguments = @()
if ($PythonExecutable) {
    $python = (Get-Command $PythonExecutable -CommandType Application -ErrorAction Stop | Select-Object -First 1).Source
}
elseif (Test-Path -LiteralPath (Join-Path $PSScriptRoot '.venv\Scripts\python.exe')) {
    $python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
}
elseif (Get-Command py -CommandType Application -ErrorAction SilentlyContinue) {
    $python = (Get-Command py -CommandType Application | Select-Object -First 1).Source
    $launchArguments = @('-3')
}
elseif (Get-Command python -CommandType Application -ErrorAction SilentlyContinue) {
    $python = (Get-Command python -CommandType Application | Select-Object -First 1).Source
}
else { throw 'Python 3.10+ is required. Reuse Start-Sample.ps1 setup or provide -PythonExecutable.' }

# Suppress dependency probe tracebacks; the explicit failure below gives an offline-safe next step.
& $python @launchArguments -c "import sys, importlib.util; sys.exit(3 if sys.version_info < (3,10) else (0 if all(importlib.util.find_spec(m) for m in ('requests', 'azure')) and importlib.util.find_spec('azure.identity') else 4))"
$probeExit = $LASTEXITCODE
if ($probeExit -eq 3) { throw 'Python 3.10 or later is required.' }
if ($probeExit -ne 0) {
    if (-not $InstallDependencies) {
        New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
        $report = Join-Path $OutputDirectory 'report.md'
        @'
# Fabric validation: blocked before execution

Python dependencies are missing. No test or network request ran.
Reuse the Python environment prepared by Start-Sample.ps1, or install requirements.txt
from an approved source. -InstallDependencies explicitly allows pip access.
Use a NEW output directory when retrying.
'@ | Set-Content -LiteralPath $report -Encoding UTF8
        Write-Host "Report: $report"
        exit 2
    }
    & $python @launchArguments -m pip install -r (Join-Path $PSScriptRoot 'requirements.txt')
    if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. No live validation ran.' }
}

$arguments = @((Join-Path $PSScriptRoot 'validate_sample.py'))
if ($ListScenarios) { $arguments += '--list' }
else {
    $arguments += @('--config', $Config, '--output', $OutputDirectory)
    if ($Agents) { $arguments += '--agents'; $arguments += $Agents }
    if ($Scenarios) { $arguments += '--scenarios'; $arguments += $Scenarios }
    if ($RerunFailed) { $arguments += @('--rerun-failed', $RerunFailed) }
    if ($ReuseResults) { $arguments += @('--reuse-results', $ReuseResults) }
    if ($PlanOnly) { $arguments += '--plan' }
    if ($Configure) { $arguments += '--configure' }
    if ($SampleManifest) { $arguments += @('--sample-manifest', $SampleManifest) }
    if ($AllowCreate) { $arguments += '--allow-create' }
    if ($Strict) { $arguments += '--strict' }
}
& $python @launchArguments @arguments
$result = $LASTEXITCODE
if ($Configure) {
    Write-Host "Configuration exit code: $result (0 = saved; 1 = saved with missing prerequisites; 2 = stopped). No tests ran."
}
else {
    Write-Host "Validation runner exit code: $result (0 = runner completed, not an all-tests-pass assertion)."
}
exit $result
