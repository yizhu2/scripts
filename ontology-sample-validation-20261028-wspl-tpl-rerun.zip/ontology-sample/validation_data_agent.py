"""Ontology-backed, unpublished Data Agent scenarios for the standalone validator.

Workspace routing is shared by default; paired data_agent_* routing overrides are optional.
One fresh draft with all ontology entities is shared by independent questions per run.
data_agent_mode="isolated" opts into per-case drafts. Explicit data_agent_id or
data_agent_ids may reuse existing drafts, which are never edited or exported.
Creation requires allow_create. Fixture-correct answers determine functional coverage;
independent source evidence is informational. All HTTP (including finite SSE reads)
goes through ValidationContext.
"""

import base64
import json
import re
import time
from contextlib import closing, contextmanager
from functools import partial
from types import SimpleNamespace
from uuid import UUID, uuid4

from create_sample import Api, PBI_SCOPE
from ux_authoring import routing, workload_host, workspace_routing
from validation_common import ScenarioBlocked, sanitize
from validation_count_scope import prove_count_scope
from validation_queries import EXPECTED, answer_check
from validation_setup import data_agent_reference


GROUPS = {
    "lakehouse": "Lakehouse", "kql": "EventhouseKQL", "warehouse": "Warehouse",
    "sql": "SQLDatabase", "mirror": "MirroredDatabase", "semantic": "SemanticModel",
}
CASES = {key: (value, value) for key, value in GROUPS.items()}
CASES.update({
    "sm-lakehouse": ("SemanticModel", "Lakehouse"),
    "sm-kql": ("SemanticModel", "EventhouseKQL"),
    "lakehouse-kql": ("Lakehouse", "EventhouseKQL"),
    "lakehouse-warehouse": ("Lakehouse", "Warehouse"),
})
SCHEMA = "https://developer.microsoft.com/json-schemas/fabric/item/dataAgent/definition/"
EXECUTION_TOOLS = {"askPBI.tool.execute", "analyze.database.execute"}


def ml_routing(config):
    if config.get("ux_token_version", "v2") != "v2":
        raise ScenarioBlocked("Data Agent requires ML MWC v2; no v1 fallback")
    return workspace_routing(config, "data_agent")


@contextmanager
def ml_context(ctx, agent_id, capacity_id):
    origin, expected_host = ml_routing(ctx.config)
    workspace = str(UUID(ctx.config["workspace_id"]))
    agent_id, capacity_id = str(UUID(agent_id)), str(UUID(capacity_id))
    with closing(Api(origin, PBI_SCOPE, ctx.credential, ctx.timeout,
                     sensitive_response=True)) as metadata:
        result = ctx.request(metadata, "POST", origin + "/metadata/v201606/generatemwctokenv2", {
            "workspaceObjectId": workspace, "workloadType": "ML",
            "artifacts": [{"artifactType": "DataAgent", "artifactObjectId": agent_id}],
        })
    host = workload_host(result["TargetUriHost"])
    if expected_host and host != expected_host:
        raise ScenarioBlocked("ML routing host mismatch; no workload call or public fallback attempted")
    token = result.get("Token")
    if not isinstance(token, str) or not token:
        raise ScenarioBlocked("ML MWC response did not contain a workload token")
    credential = SimpleNamespace(get_token=lambda *_args, **_kwargs: SimpleNamespace(token=token))
    base = f"https://{host}/webapi/capacities/{capacity_id}/workloads/ML"
    with closing(Api(base, PBI_SCOPE, credential, ctx.timeout, auth_scheme="MwcToken")) as api:
        api.session.headers.update({
            "Accept": "application/json", "ActivityId": str(uuid4()),
            "x-ms-workload-resource-moniker": str(uuid4()),
            "x-ms-ai-assistant-scenario": "aiskill", "x-ms-ai-aiskill-stage": "sandbox",
            "X-Taxonomy-TrafficType": "Production", "x-llm-service-tier": "default",
        })
        yield api


def fixture_bindings(definition, selected, evidence):
    model = definition.get("model", {})
    entities = {e["name"] for e in model.get("entities", [])}
    if not set(selected) <= entities:
        raise ScenarioBlocked("Ontology is missing selected fixture entities: " +
                              ", ".join(sorted(set(selected) - entities)))
    tables = {t["name"]: t for t in model.get("tables", [])}
    identities = {}
    for name in selected:
        found = set()
        for partition in tables.get(name, {}).get("partitions", []):
            annotations = {a["name"]: a.get("value") for a in partition.get("annotations", [])}
            state = annotations.get("ONT_RESOLVED_State")
            if state and state != "Resolved":
                evidence["warnings"].append(f"{name}: resolver state {state}; still attempting independent query")
            item = annotations.get("ONT_RESOLVED_ItemId") or annotations.get("ONT_ItemId")
            workspace = annotations.get("ONT_RESOLVED_WorkspaceId") or annotations.get("ONT_WorkspaceId")
            if item and workspace:
                found.add((str(UUID(item)), str(UUID(workspace))))
        if len(found) == 1:
            identities[name] = next(iter(found))
        else:
            evidence["warnings"].append(f"{name}: source identity missing/ambiguous; lineage is informational")
    return entities, identities


def definition_parts(entities, selected, workspace, ontology, display_name):
    if not display_name or any(c in display_name for c in "/\\") or display_name in (".", ".."):
        raise ScenarioBlocked("Ontology display name is not a safe definition path component")
    documents = {
        "Files/Config/data_agent.json": {"$schema": SCHEMA + "dataAgent/2.1.0/schema.json"},
        "Files/Config/draft/stage_config.json": {
            "$schema": SCHEMA + "stageConfiguration/1.0.0/schema.json",
            "aiInstructions": "Use only selected ontology entities. Execute read-only queries and show actual "
                              "datasets; never infer fixture answers. Do not modify data, publish, refresh, "
                              "activate monitoring or invoke external actions.",
        },
        f"Files/Config/draft/ontologies/{display_name}/ontology.json": {
            "$schema": SCHEMA + "ontology/1.0.0/schema.json",
            "artifactId": ontology, "workspaceId": workspace, "displayName": display_name,
            "elements": [{"id": name, "display_name": name, "type": "ontology.entity",
                          "is_selected": name in selected, "children": []} for name in sorted(entities)],
        },
    }
    return [{"path": path, "payloadType": "InlineBase64",
             "payload": base64.b64encode(json.dumps(value).encode()).decode()}
            for path, value in documents.items()]


def get_draft(ctx, case, selected, entities, evidence):
    config = ctx.config
    name = "data-agent." + case
    explicit = data_agent_reference(config, name)
    mode = config.get("data_agent_mode", "shared")
    workspace, ontology = config["workspace_id"], config["ontology_id"]
    root = f"{ctx.fabric.base}/workspaces/{workspace}/dataAgents"
    # A context is one run: persisted resource mappings are evidence, not implicit reuse consent.
    run = getattr(ctx, "_data_agent_run_state", None)
    if run is None:
        run = {"mode": mode, "workspaceId": workspace, "ontologyId": ontology, "agents": {},
               "shared": {"creationAttempted": False, "status": "not-attempted"}}
        ctx._data_agent_run_state = run
        ctx.state["data_agents"] = run["agents"]
        if mode == "shared":
            ctx.state["data_agent_shared"] = run["shared"]
    if (run["mode"], run["workspaceId"], run["ontologyId"]) != (mode, workspace, ontology):
        raise ScenarioBlocked("Data Agent mode, workspace and ontology cannot change within a run")
    owned, shared = run["agents"], run["shared"]
    evidence["dataAgentMode"] = mode
    if mode == "shared":
        agent = shared.get("agentId")
        if agent and explicit and agent != explicit:
            raise ScenarioBlocked("Shared Data Agent ID cannot change within a run")
        if not agent and not explicit and shared["creationAttempted"]:
            evidence["sharedCreation"] = dict(shared)
            raise ScenarioBlocked("Shared Data Agent creation already attempted with failed/ambiguous outcome; "
                                  "no replacement will be created in this run")
        agent = agent or explicit
    else:
        agent = owned.get(name) or explicit
    if agent:
        agent = str(UUID(agent))
        evidence.update(agentId=agent, created=False, configurationVerified=False)
        if mode == "shared":
            shared.update(agentId=agent, status=shared["status"] if shared.get("agentId") else "configured")
            owned.update({"data-agent." + key: agent for key in CASES})
            evidence["sharedCreation"] = dict(shared)
        else:
            owned[name] = agent
        ctx.save_evidence("data-agent-resource", {"scenario": name, "agentId": agent, "published": False})
        return agent
    elif not config.get("allow_create"):
        raise ScenarioBlocked("No ontology-backed draft configured; creation requires allow_create")
    evidence["phase"] = "draft-create"
    item = ctx.request(ctx.fabric, "GET", f"{ctx.fabric.base}/workspaces/{workspace}/items/{ontology}")
    parts = definition_parts(entities, entities if mode == "shared" else selected,
                             workspace, ontology, item["displayName"])
    body = {
        "displayName": f"OntologyValidation_{'shared' if mode == 'shared' else case}_{uuid4().hex[:12]}",
        "description": f"Unpublished {mode} ontology validation. Read-only questions; no external actions.",
        "definition": {"parts": parts},
    }
    if mode == "shared":
        shared.update(creationAttempted=True, status="attempted", displayName=body["displayName"])
        evidence["sharedCreation"] = dict(shared)
        ctx.save_evidence("data-agent-create-attempt", dict(shared))
    try:
        created = ctx.mutate(ctx.fabric, root, body)
        agent = str(UUID(created["id"]))
    except Exception as error:
        if mode == "shared":
            shared.update(status="failed-or-ambiguous",
                          error={"type": type(error).__name__, "message": sanitize(str(error))})
            evidence["sharedCreation"] = dict(shared)
            ctx.save_evidence("data-agent-create-attempt", dict(shared))
        raise
    if mode == "shared":
        shared.update(agentId=agent, status="created")
        owned.update({"data-agent." + key: agent for key in CASES})
        evidence["sharedCreation"] = dict(shared)
    else:
        owned[name] = agent
    evidence.update(agentId=agent, created=True, configurationVerified=False)
    ctx.save_evidence("data-agent-resource", {"scenario": name, "agentId": agent, "published": False})
    return agent


def terminal_response(response):
    """Accept JSON Responses output or terminal SSE; never infer success from HTTP 200."""
    text = response.text
    if not text.strip():
        raise ValueError("Empty Responses body is not an execution result")
    if text.lstrip().startswith("{"):
        terminal = json.loads(text)
    else:
        terminal = None
        for frame in re.split(r"\r?\n\r?\n", text):
            data = "\n".join(line[5:].lstrip() for line in frame.splitlines() if line.startswith("data:"))
            if not data or data == "[DONE]":
                continue
            event = json.loads(data)
            if event.get("type") in ("response.completed", "response.failed", "response.incomplete"):
                terminal = event.get("response")
        if terminal is None:
            raise ValueError("SSE ended without a terminal response; no completed query proven")
    return {**{k: terminal.get(k) for k in ("id", "status", "error")},
            "output": [o for o in terminal.get("output", []) if o.get("type") != "reasoning"]}


def _json(value):
    return json.loads(value) if isinstance(value, str) else value


def _key(value):
    return re.sub(r"[^a-z0-9]", "", value.lower())


def _rows(text):
    header = None
    for line in text.splitlines():
        if not line.strip().startswith("|"):
            header = None
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if all(re.fullmatch(r"[: -]+", c or "-") for c in cells):
            continue
        if header is None:
            header = [_key(c) for c in cells]
        elif len(cells) == len(header):
            yield dict(zip(header, cells))


def _value(row, *names):
    return next((row[_key(n)] for n in names if _key(n) in row), "")


def _tool_failed(result):
    text = result.get("output", "")
    return (result.get("status") != "completed" or bool(result.get("error"))
            or isinstance(text, str) and bool(re.search(
                r"(?im)^\s*(?:the request timed out\b|error:|execution failed\b|query failed\b)", text)))


def _answer_checks(rows, count_evidence):
    readings = context = [r for _, r, _ in rows]

    def present(value):
        return value not in ("", "{}", "null", "None", "N/A", "-")

    def check(candidates, matches):
        return ("FAIL" if any(not matches(r) for r in candidates)
                else "PASS" if candidates else "UNVERIFIED")

    count_rows = []
    contradictory_count = False
    for source, row, provenance in rows:
        column = next((name for name in ("readingcount", "a012readingcount", "readingsfora012")
                       if name in row), None)
        if column is None or not present(row[column]):
            continue
        asset = _value(row, "AssetId")
        metric_assets = set(re.findall(r"\bA\d{3}\b", _value(row, "Metric", "ResultType"), re.I))
        if (present(asset) and asset != "A012") or any(a.upper() != "A012" for a in metric_assets):
            contradictory_count |= (column in ("a012readingcount", "readingsfora012")
                                    or column in provenance["countScope"]["columns"])
            continue
        labeled = (column in ("a012readingcount", "readingsfora012") or asset == "A012"
                   or any(a.upper() == "A012" for a in metric_assets))
        if labeled or column in provenance["countScope"]["columns"]:
            count_rows.append(row)
            count_evidence.append({"basis": "row-label" if labeled else "executed-query",
                                   "file": provenance["file"], "callId": provenance["callId"],
                                   "column": column, "value": row[column]})
    maximum_rows = [r for r in readings if all(present(_value(r, *names)) for names in (
        ("TemperatureC", "MaxTemperatureC"), ("AssetId",), ("ReadingId",),
        ("ObservedAtUtc", "ObservedAt", "Timestamp")))]
    asset_rows = [r for r in context if _value(r, "AssetId") == "A012" and present(_value(r, "PlantId"))]
    plant_rows = [r for r in context if _value(r, "PlantId") == "P03"
                  and present(_value(r, "PlantName", "Name")) and present(_value(r, "City"))]
    return {
        "A012ReadingCount": ("FAIL" if contradictory_count or any(
            _value(r, "ReadingCount", "A012ReadingCount", "ReadingsForA012") not in ("10", "10.0")
            for r in count_rows) else "PASS" if count_rows else "UNVERIFIED"),
        "maximumReading": check(maximum_rows, lambda r:
                                _value(r, "TemperatureC", "MaxTemperatureC") == "32.9"
                                and _value(r, "AssetId") == "A012" and _value(r, "ReadingId") == "R0120"
                                and _value(r, "ObservedAtUtc", "ObservedAt", "Timestamp").removesuffix("Z")
                                .removesuffix("+00:00") == "2026-01-01T00:45:00"),
        "assetPlant": check(asset_rows, lambda r: _value(r, "PlantId") == "P03"),
        "plantLocation": check(plant_rows, lambda r:
                               _value(r, "PlantName", "Name") == "East Plant" and _value(r, "City") == "Boston"),
    }


def assess_response(terminal, identities, selected):
    """Reassess a retained terminal response offline without modifying its inputs."""
    evidence = {"warnings": []}
    status, summary = assess(terminal, identities, selected, evidence)
    return {"status": status, "summary": summary, "evidence": evidence}


def assess(terminal, identities, selected, evidence):
    identities = {name: tuple(identity) for name, identity in identities.items()}
    output = terminal["output"]
    calls = {o["call_id"]: o for o in output if o.get("type") == "function_call"}
    results = {o["call_id"]: o for o in output if o.get("type") == "function_call_output"}
    call_positions = {o["call_id"]: i for i, o in enumerate(output) if o.get("type") == "function_call"}
    result_positions = {o["call_id"]: i for i, o in enumerate(output) if o.get("type") == "function_call_output"}
    files, rows, attached, written = {}, [], set(), set()
    overwritten = set()
    evidence.update(executions=[], resultTables=[], ontologyRuntime=[], countScopeEvidence=[],
                    sourceEvidenceRequired=False, wrongSourceEvidence=[], toolFailures=[])
    for call_id, call in calls.items():
        result = results.get(call_id, {})
        text = result.get("output", "")
        if _tool_failed(result):
            evidence["toolFailures"].append({"callId": call_id, "tool": call["name"], "output": text})
        if call["name"].startswith("ontology."):
            evidence["ontologyRuntime"].append({"tool": call["name"], "output": text})
            if call["name"] == "ontology.context.datasources_attached":
                attached.update(x["id"].lower() for x in _json(text).get("attached", []))
        if call["name"] not in EXECUTION_TOOLS:
            continue
        arguments = _json(call.get("arguments", "{}"))
        diagnostics = _json(result.get("metadata", {}).get("diagnostic_details", "{}"))
        failed = _tool_failed(result) or any(
            query.get("is_error") is True for query in diagnostics.get("queries_ran", []))
        match = re.search(r"file ['\"]([^'\"]+)['\"].*?dataset contains (\d+) rows", text, re.I | re.S)
        filename = match[1] if match else arguments.get("result_file_name")
        if filename:
            if filename in written:
                overwritten.add(filename)
            written.add(filename)
            files.pop(filename, None)
        source = (str(arguments.get("datasource_artifact_id") or "").lower(),
                  str(arguments.get("datasource_workspace_id") or "").lower())
        known_sources = set(identities.values())
        if (len(identities) == len(selected) and any(source)
                and not any(all(not actual or actual == expected for actual, expected in zip(source, known))
                            for known in known_sources)):
            evidence["wrongSourceEvidence"].append({"callId": call_id, "source": source})
        evidence["executions"].append({"tool": call["name"], "arguments": arguments, "output": text,
                                       "diagnostics": diagnostics, "failed": failed})
        if match and not failed and arguments.get("code"):
            files[match[1]] = {
                "source": source, "file": match[1], "callId": call_id,
                "completedAt": result_positions[call_id],
                "countScope": prove_count_scope(call["name"], arguments["code"], selected[2]),
            }
        if not (match and not failed and arguments.get("code") and source in known_sources):
            evidence["warnings"].append(f"{call['name']} did not prove a successful expected-source dataset")
    for filename in overwritten & files.keys():
        files[filename]["countScope"] = {
            "status": "UNVERIFIED", "columns": [],
            "reason": "Filename was reused by executions; count-query lineage is ambiguous",
        }

    def retain_table(table, filename=None, provenance=None):
        provenance = provenance or {
            "source": None, "file": filename, "callId": None,
            "countScope": {"status": "UNVERIFIED", "columns": [],
                           "reason": "No independent executed-query lineage"},
        }
        evidence["resultTables"].append({"file": filename, "table": table,
                                         "callId": provenance["callId"],
                                         "countScope": provenance["countScope"]})
        rows.extend((provenance["source"], row, provenance) for row in _rows(table))

    for call_id, call in calls.items():
        if call["name"] != "generate_files_data_insights.execute":
            continue
        result = results.get(call_id, {})
        if result.get("status") != "completed":
            continue
        for section in re.split(r"(?m)^File:\s*", result.get("output", ""))[1:]:
            filename, _, table = section.partition("\n")
            if filename.strip() in files:
                table = table.split("## Instructions")[0]
                provenance = files[filename.strip()]
                if (provenance["countScope"]["status"] == "VERIFIED"
                        and call_positions[call_id] <= provenance["completedAt"]):
                    provenance = {**provenance, "countScope": {
                        "status": "UNVERIFIED", "columns": [],
                        "reason": "Dataset inspection precedes successful execution; count lineage is unverified",
                    }}
                retain_table(table, filename.strip(), provenance)
            else:
                retain_table(table.split("## Instructions")[0], filename.strip())
    texts = [part["text"] for item in output if item.get("type") == "message"
             and item.get("role", "assistant") == "assistant"
             for part in item.get("content", []) if isinstance(part.get("text"), str)]
    evidence["answer"] = "\n".join(texts)
    evidence["answerCheck"] = answer_check(evidence["answer"])
    for text in texts:
        retain_table(text)
    evidence["queryCompletion"] = terminal.get("status")
    evidence["sourceEvidenceVerified"] = (
        len(identities) == len(selected)
        and {item for item, _ in identities.values()} <= attached
        and set(identities.values()) <= {file["source"] for file in files.values()})
    checks = _answer_checks(rows, evidence["countScopeEvidence"])
    evidence["answerChecks"] = checks
    proven = (all(value == "PASS" for value in checks.values())
              or evidence["answerCheck"]["status"] == "PASS")
    if not evidence["sourceEvidenceVerified"]:
        evidence["warnings"].append("Independent source lineage is unverified; informational only")
    if terminal.get("status") != "completed" or terminal.get("error"):
        return "FAIL", "Responses did not complete successfully; retain tool failures and correlation IDs"
    if evidence["wrongSourceEvidence"]:
        return "FAIL", "Runtime execution explicitly used an unexpected source; see wrongSourceEvidence"
    if "FAIL" in checks.values() or evidence["answerCheck"]["status"] == "FAIL":
        return "FAIL", "Answer data does not match the sample fixture; see answerChecks and answerCheck"
    if any(execution["failed"] for execution in evidence["executions"]):
        return "FAIL", "Runtime source execution failed; a correct answer cannot override service failures"
    if evidence["toolFailures"]:
        return "FAIL", "Runtime tool did not complete successfully"
    if any(part.get("type") == "refusal" for item in output if item.get("type") == "message"
           for part in item.get("content", [])):
        return "FAIL", "Runtime refused the requested answer"
    if proven:
        return "PASS", "Fixture-correct answer verifies A012=10 and global 32.9°C; source lineage is informational"
    return "PARTIAL", "Query completed, but required fixture answer fields or A012 count scope are incomplete"


def run_scenario(ctx, case):
    group, readings = CASES[case]
    selected = [group + "_Assets", group + "_Plants", readings + "_Readings"]
    evidence = {"scenario": "data-agent." + case, "selectedEntities": selected, "phase": "preflight",
                "warnings": [], "published": False, "queryAttempted": False,
                "independentBackendTelemetryVerified": False}
    try:
        data_agent_reference(ctx.config, "data-agent." + case)
        ml_routing(ctx.config)  # Fail private routing closed before any resource creation.
        workspace, ontology = str(UUID(ctx.config["workspace_id"])), str(UUID(ctx.config["ontology_id"]))
        evidence["phase"] = "ontology-definition"
        with ctx.workload() as api:
            definition = ctx.request(api, "GET",
                                     f"{api.base}/v4/workspaces/{workspace}/ontologies/{ontology}/definition",
                                     params={"expand": "true"})
        entities, identities = fixture_bindings(definition, selected, evidence)
        evidence["sourceIdentities"] = identities
        agent = get_draft(ctx, case, selected, entities, evidence)
        evidence["phase"] = "workspace-metadata"
        metadata = ctx.request(ctx.fabric, "GET", f"{ctx.fabric.base}/workspaces/{workspace}")
        evidence["phase"] = "ml-token"
        with ml_context(ctx, agent, metadata["capacityId"]) as api:
            evidence["phase"] = "query"
            evidence["queryAttempted"] = True
            query_started = time.monotonic()
            response = ctx.exchange(
                api, "POST", api.base + f"/AISkill/Automatic/v1/workspaces/{workspace}/artifacts/{agent}/responses",
                {"model": "gpt-5.1", "input": (
                    f"Use only {', '.join(selected)} in the attached ontology, not duplicate source groups. "
                    "Execute read-only queries: count readings for AssetId A012; separately find the global "
                    "maximum Celsius temperature across ALL assets and its asset/plant/location/reading/time. "
                    "Return actual dataset rows using columns ReadingCount, TemperatureC, AssetId, PlantId, "
                    "PlantName, City, ReadingId, ObservedAtUtc. Show execution evidence and inspect result files. "
                    "Finish with one JSON object with these exact keys: " + ", ".join(EXPECTED) + ". "
                    "Do not merely generate code, guess, modify sources, refresh or invoke external actions. "
                    "If tools or bindings are unavailable, report the exact failure.")},
                params={"agent": "aiskill", "stage": "sandbox"})
        terminal = terminal_response(response)
        evidence["phase"] = "answer-verification"
        evidence["response"] = terminal
        evidence["correlations"] = {k: v for k, v in response.headers.items()
                                    if k.lower() in ("requestid", "x-ms-request-id", "x-ms-root-activity-id")}
        status, summary = assess(terminal, identities, selected, evidence)
        if status != "PASS" and (group in ("Warehouse", "SQLDatabase", "MirroredDatabase")
                                    or readings == "Warehouse"):
            evidence["warnings"].append(
                "Known capability limit: Gen4 ontology-to-DataAgent mapping omits explicit Warehouse/SQLDatabase/"
                "MirroredDatabase kinds. Do not relabel or bypass source-kind validation.")
        if status != "PASS" and readings == "EventhouseKQL":
            evidence["warnings"].append(
                "Known KQL mapping risk: M-partition physical table names may differ from TOM entity aliases. "
                "Discovery success alone does not establish executable tools.")
    except Exception as error:
        status = ("TIMEOUT" if isinstance(error, TimeoutError) and evidence["queryAttempted"] else
                  "FAIL" if evidence["queryAttempted"] else "BLOCKED")
        summary = sanitize(f"{evidence['phase']}: {error}")
        evidence["error"] = {"type": type(error).__name__, "message": summary}
        if hasattr(error, "operation_error"):
            evidence["error"].update(operation=error.operation, serviceError=error.operation_error)
    finally:
        if evidence["queryAttempted"]:
            evidence["queryDurationSeconds"] = round(time.monotonic() - query_started, 3)
    result = {"status": status, "summary": summary, "evidence": sanitize(evidence)}
    ctx.save_evidence("data-agent-result", result)
    return result


SCENARIOS = {"data-agent." + case: partial(run_scenario, case=case) for case in CASES}
