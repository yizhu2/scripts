"""Repair only missing entity keys on an existing, otherwise complete hybrid sample ontology."""

import argparse
import copy
import json
import logging
from contextlib import closing
from pathlib import Path
from types import SimpleNamespace
from uuid import UUID, uuid4

from check_ux_auth import load_plan as load_auth_plan
from create_ontology import entity_key_operation, verify_definition, verify_existing_content, verify_script_result
from create_sample import Manifest, PBI_SCOPE, sample_tables
from replace_ontology import normalize_public_sql_bindings, normalize_tom_defaults
from run_sample import UX_GROUPS
from sample_auth import open_credential
from target_routing import TargetApi, target_fabric_api
from ux_authoring import open_workload, read_resolved_definitions

LOG = logging.getLogger("ontology-sample")


def repair_script(expected, actual, state, workspace_id):
    desired = copy.deepcopy(actual)
    entities = {entity["name"]: entity for entity in desired["model"]["entities"]}
    authored = {entity["name"]: entity for entity in expected["model"]["entities"]}
    operations = []
    for group in UX_GROUPS:
        for table in sample_tables():
            name, keys = f"{group}_{table.name}", [table.columns[0][0]]
            if authored[name]["keyProperties"] != keys:
                raise ValueError(f"Unexpected sample key definition for {name}; refusing repair")
            entity = entities[name]
            current = entity.get("keyProperties", [])
            if current == keys:
                continue
            if current != []:
                raise ValueError(f"{name} already has different keyProperties; refusing to overwrite them")
            entity["keyProperties"] = keys
            operations.append(entity_key_operation(entity))
    # Validate everything, allowing only the exact empty-key omissions repaired above.
    verify_definition(normalize_public_sql_bindings(expected, desired, state, workspace_id),
                      normalize_tom_defaults(desired))
    return {"sequence": {"operations": operations}}, desired


def prepare(path):
    saved = json.loads(path.read_text(encoding="utf-8-sig"))
    if (saved.get("authoringMode") != "hybrid" or saved.get("almBaselineVerified") is not True
            or saved.get("uxWriteCompleted") is not True):
        raise ValueError("Select the original hybrid run with a verified ALM baseline and completed UX write")
    auth = load_auth_plan(path)
    if auth["authentication"] not in ("auto", "cli", "browser"):
        raise ValueError("Unsupported recorded authentication mode")
    item = saved["items"]["Ontology"]
    if item.get("type") != "Ontology" or item.get("displayName") != saved["ontologyName"]:
        raise ValueError("The manifest must record the created Ontology with its exact name")
    state = {"workspaceId": str(UUID(saved["sourceWorkspaceId"])), "items": saved["sourceItems"]}
    script, _ = repair_script(saved["authoredDefinition"], saved["expandedDefinition"], state, auth["workspaceId"])
    return saved, auth, state, script


def run(args, credential, saved, auth, state, manifest):
    workspace_id, item_id = auth["workspaceId"], auth["ontologyId"]
    origin = target_fabric_api(saved["targetNetwork"], workspace_id, auth["tenantId"])
    manifest.step("Checking the existing target workspace and ontology identity")
    with closing(TargetApi(origin, PBI_SCOPE, credential, args.timeout, manifest.operation)) as api:
        path = f"{api.base}/workspaces/{workspace_id}"
        workspace = api.json("GET", path)
        if workspace.get("capacityId", "").lower() != auth["capacityId"]:
            raise ValueError("The target capacity changed; no repair was submitted")
        item = api.json("GET", path + f"/items/{item_id}")
        if (item.get("id", "").lower() != item_id or item.get("type") != "Ontology"
                or item.get("displayName") != saved["ontologyName"]):
            raise ValueError("The target ontology identity changed; no repair was submitted")
    manifest.data["items"]["Ontology"] = item
    expected = saved["authoredDefinition"]
    manifest.data["authoredDefinition"] = expected
    route = SimpleNamespace(
        workspace_id=workspace_id, target_network=saved["targetNetwork"], timeout=args.timeout,
        ux_metadata_api=auth["metadataOrigin"], ux_workload_host=auth["expectedWorkloadHost"],
        ux_token_version=auth["tokenVersion"],
    )
    with open_workload(route, credential, workspace, item_id) as api:
        path = f"{api.base}/v4/workspaces/{workspace_id}/ontologies/{item_id}/definition"
        manifest.step("Reading current bindings; only empty keys on the nine UX-added entities may differ")
        manifest.data["beforeDefinition"] = api.json("GET", path)
        manifest.save()
        before = api.json("GET", path, params={"expand": "true"})
        manifest.data["beforeExpandedDefinition"] = before
        manifest.save()
        script, desired = repair_script(expected, before, state, workspace_id)
        manifest.data["authoredScript"] = script
        operations = script["sequence"]["operations"]
        manifest.data["repairTargets"] = [operation["alter"]["object"]["entity"] for operation in operations]
        if operations:
            manifest.data["writeAttempted"] = True
            manifest.step("Patching only missing entity keyProperties in one UX transaction")
            response = api.request("POST", path + "/scripts", script, request_timeout=args.timeout)
            if response.status_code != 200:
                raise RuntimeError("Unexpected repair response; inspect the item before retrying")
            manifest.data["writeCompleted"] = True
            manifest.save()
            result = response.json()
            manifest.data["scriptResult"] = result
            manifest.save()
            verify_script_result(script, result)
        else:
            manifest.step("All sample entity keys already match; no repair write is needed")
        manifest.step("Verifying all bindings and preserving existing content after the key repair")
        after = read_resolved_definitions(api, path, manifest)
        verify_definition(normalize_public_sql_bindings(expected, after, state, workspace_id),
                          normalize_tom_defaults(after))
        verify_existing_content(normalize_tom_defaults(desired), normalize_tom_defaults(after))
        model = expected["model"]
        manifest.data["verified"]["uxDefinition"] = {
            "entities": len(model["entities"]), "boundTables": len(model["tables"]),
            "relationships": len(model["relationships"]), "entityRelationships": len(model["entityRelationships"]),
        }
        manifest.data["queryValidation"] = "Not performed; this repair verifies definitions, not source data or queries"
        manifest.data["status"] = "succeeded"
        manifest.step("Existing ontology keys and all sample bindings verified")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-manifest", type=Path, required=True, help="Original failed hybrid run.manifest.json")
    parser.add_argument("--run-directory", type=Path, help="New evidence directory; original manifest is never modified")
    parser.add_argument("--auth", choices=("auto", "cli", "browser"), help="Defaults to the recorded sign-in mode")
    parser.add_argument("--client-id", type=lambda value: str(UUID(value)), help="Same approved client for browser auth")
    parser.add_argument("--timeout", type=int, default=1800)
    parser.add_argument("--execute", action="store_true", help="Enable live read/repair; default prints an offline plan")
    args = parser.parse_args(argv)
    if args.timeout < 30:
        parser.error("--timeout must be at least 30 seconds")
    saved, auth, state, script = prepare(args.run_manifest)
    args.run_directory = (args.run_directory or Path("runs") / f"entity_keys_{uuid4().hex[:12]}").resolve()
    plan = {
        "operation": "repair-existing-hybrid-entity-keys", "sourceRunManifest": str(args.run_manifest.resolve()),
        "tenantId": auth["tenantId"], "targetWorkspaceId": auth["workspaceId"], "ontologyId": auth["ontologyId"],
        "ontologyName": saved["ontologyName"], "authentication": args.auth or auth["authentication"],
        "runDirectory": str(args.run_directory), "createsItems": False, "changesSourceData": False,
        "replacesDefinition": False, "changesSemanticModelBindings": False,
        "plannedScriptFromSavedReadback": script, "liveReadbackRequiredBeforeWrite": True,
    }
    print(json.dumps(plan, indent=2))
    if not args.execute:
        return
    if args.run_directory.exists():
        raise FileExistsError("Use a new repair evidence directory; do not overwrite a previous run")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logging.getLogger("azure").setLevel(logging.WARNING)
    args.run_directory.mkdir(parents=True, exist_ok=False)
    manifest = Manifest(args.run_directory / "repair.manifest.json", plan)
    try:
        with open_credential(auth["tenantId"], mode=plan["authentication"], client_id=args.client_id) as credential:
            run(args, credential, saved, auth, state, manifest)
    except (Exception, KeyboardInterrupt) as error:
        manifest.data.update(status="failed", error=str(error))
        manifest.save()
        LOG.exception("Key repair stopped; no resources deleted or recreated. Inspect %s before retrying.", manifest.path)
        raise
    LOG.info("Verified existing ontology. Original run unchanged; evidence: %s", manifest.path)


if __name__ == "__main__":
    main()
