import unittest

from validation_count_scope import prove_count_scope


SQL = "SELECT COUNT(*) AS ReadingCount FROM [dbo].[Readings] WHERE AssetId = 'A012'"
DAX = '''EVALUATE ROW("ReadingCount", CALCULATE(COUNTROWS('Readings'), 'Readings'[AssetId] = "A012"))'''
COMBINED_SQL = """
WITH AssetReadingCount AS (
    SELECT COUNT_BIG(*) AS ReadingCount FROM [dbo].[Readings] WHERE AssetId = 'A012'
), GlobalMaximum AS (
    SELECT MAX(TemperatureC) AS TemperatureC FROM [dbo].[Readings]
)
SELECT arc.ReadingCount AS ReadingCount,
    CAST(NULL AS float) AS TemperatureC,
    CAST(NULL AS varchar(100)) AS AssetId
FROM AssetReadingCount AS arc
UNION ALL
SELECT CAST(NULL AS bigint) AS ReadingCount, r.TemperatureC, r.AssetId
FROM [dbo].[Readings] AS r
CROSS JOIN GlobalMaximum AS gm
WHERE r.TemperatureC = gm.TemperatureC;
"""


class CountScopeTests(unittest.TestCase):
    def sql(self, code, expected=True):
        proof = prove_count_scope("analyze.database.execute", code, "Lakehouse_Readings")
        self.assertEqual(["readingcount"] if expected else [], proof["columns"], (code, proof))
        self.assertEqual("VERIFIED" if expected else "UNVERIFIED", proof["status"])
        self.assertTrue(proof["reason"])
        return proof

    def dax(self, code, expected=True):
        proof = prove_count_scope("askPBI.tool.execute", code, "SemanticModel_Readings")
        self.assertEqual(["readingcount"] if expected else [], proof["columns"], (code, proof))
        self.assertEqual("VERIFIED" if expected else "UNVERIFIED", proof["status"])
        self.assertTrue(proof["reason"])

    def test_sql_count_filter_variants(self):
        for code in (
            SQL, SQL + ";", SQL.replace("COUNT(*)", "COUNT_BIG(*)"),
            SQL.replace("COUNT(*)", "COUNT(1)"),
            SQL.replace("AssetId = 'A012'", "([AssetId] = N'A012')"),
            SQL.replace("AssetId = 'A012'", "'A012' = [AssetId]"),
            SQL.replace("ReadingCount", "[Reading Count]"),
            SQL.replace("ReadingCount", '"ReadingCount"'),
            SQL.replace("[dbo].[Readings]", "[Lakehouse_Readings]"),
            SQL.replace("WHERE AssetId", "AS r WHERE r.[AssetId]"),
            SQL.replace("WHERE AssetId", "r WHERE [r].[AssetId]"),
            SQL.replace("AssetId", "assetid").replace("SELECT", "select"),
            SQL.replace(" AS ReadingCount", " ReadingCount"),
            "```sql\n" + SQL + "\n```",
            SQL.replace("WHERE", "/* unrelated 'A013' */ WHERE") + " -- harmless",
        ):
            with self.subTest(code=code):
                self.sql(code)

    def test_sql_supported_and_or_guarantees(self):
        for predicate, expected in (
            ("AssetId='A012' AND TemperatureC>0", True),
            ("(AssetId='A012' AND TemperatureC>0) OR AssetId='A012'", True),
            ("AssetId='A012' OR 1=1", False),
            ("(AssetId='A012' OR AssetId='A013') AND TemperatureC>0", False),
            ("NOT (AssetId='A012')", False),
            ("AssetId != 'A012'", False),
            ("CASE WHEN 1=1 AND AssetId='A012' AND 1=1 THEN 1 ELSE 1 END = 1", False),
        ):
            with self.subTest(predicate=predicate):
                self.sql(SQL.split(" WHERE")[0] + " WHERE " + predicate, expected)

    def test_sql_cte_union_matches_live_count_and_maximum_shape(self):
        self.sql(COMBINED_SQL)

    def test_sql_second_live_shape_projects_maximum_from_another_cte(self):
        self.sql("""
WITH AssetReadingCount AS (
    SELECT COUNT_BIG(*) AS ReadingCount FROM dbo.Readings WHERE AssetId='A012'
), GlobalMaxTemperature AS (
    SELECT r.TemperatureC, r.AssetId FROM dbo.Readings r
    WHERE r.TemperatureC=(SELECT MAX(TemperatureC) FROM dbo.Readings)
)
SELECT arc.ReadingCount, CAST(NULL AS float) AS TemperatureC,
    CAST(NULL AS varchar(100)) AS AssetId FROM AssetReadingCount arc
UNION ALL
SELECT CAST(NULL AS bigint), gmt.TemperatureC, gmt.AssetId FROM GlobalMaxTemperature gmt
""")

    def test_sql_cte_alias_lineage_and_null_first_union(self):
        self.sql("""
WITH a AS (SELECT COUNT(*) AS n FROM Readings WHERE AssetId='A012'),
b AS (SELECT a.n AS total FROM a)
SELECT b.total AS ReadingCount FROM b
""")
        self.sql("SELECT NULL AS ReadingCount UNION ALL " + SQL)

    def test_sql_other_union_count_must_not_inherit_scope(self):
        for tail in (
            "SELECT COUNT(*) AS ReadingCount FROM Readings",
            "SELECT COUNT(*) AS ReadingCount FROM Readings WHERE AssetId='A013'",
            "SELECT 10 AS ReadingCount",
        ):
            with self.subTest(tail=tail):
                self.sql(SQL + " UNION ALL " + tail, False)
                self.sql(tail + " UNION ALL " + SQL, False)

    def test_sql_output_ordinal_not_other_branch_label_drives_proof(self):
        self.sql("""
SELECT COUNT(*) AS ReadingCount, NULL AS Other FROM Readings WHERE AssetId='A012'
UNION ALL
SELECT COUNT(*) AS Other, NULL AS ReadingCount FROM Readings WHERE AssetId='A013'
""", False)

    def test_sql_unreferenced_cte_and_subquery_cannot_prove_scope(self):
        for code in (
            "WITH unused AS (" + SQL + ") SELECT COUNT(*) AS ReadingCount FROM Readings",
            SQL.split(" WHERE")[0] + " WHERE EXISTS (SELECT 1 FROM Assets WHERE AssetId='A012')",
            "WITH unused AS (" + SQL + ") SELECT 10 AS ReadingCount",
            "SELECT COUNT(*) AS ReadingCount FROM Readings WHERE "
            "(SELECT COUNT(*) FROM Assets WHERE AssetId='A012') > 0",
        ):
            with self.subTest(code=code):
                self.sql(code, False)

    def test_sql_literals_comments_and_wrong_tables_do_not_prove_scope(self):
        for code in (
            SQL.replace("'A012'", "'A013'"),
            SQL.split(" WHERE")[0] + " -- WHERE AssetId='A012'",
            SQL.split(" WHERE")[0] + " /* WHERE AssetId='A012' */",
            SQL.split(" WHERE")[0] + " WHERE 'AssetId'='A012'",
            SQL.replace("AssetId =", "OtherId ="),
            SQL.replace("AssetId =", "other.AssetId ="),
            SQL.replace("[Readings]", "[Assets]"),
            SQL.replace("AssetId =", "'AssetId = ''A012''' ="),
        ):
            with self.subTest(code=code):
                self.sql(code, False)

    def test_sql_unsupported_query_transformations_fail_closed(self):
        for code in (
            SQL + "; SELECT 10 AS ReadingCount",
            SQL + " AND 1=1 EXCEPT SELECT 10 AS ReadingCount",
            SQL + " AND 1=1 INTERSECT SELECT 10 AS ReadingCount",
            SQL.replace("COUNT(*)", "SUM(10)"),
            SQL.replace("COUNT(*)", "COUNT(DISTINCT AssetId)"),
            SQL.replace("COUNT(*)", "COUNT(TemperatureC)"),
            SQL + " GROUP BY TemperatureC",
            SQL.replace("WHERE", "JOIN Assets a ON 1=1 WHERE"),
            SQL.replace("AS ReadingCount", "AS ReadingCount, 10 AS [Reading Count]"),
            "WITH a AS (SELECT ReadingCount FROM a) SELECT ReadingCount FROM a",
            "WITH Readings AS (SELECT * FROM Assets) " + SQL.replace("[dbo].[Readings]", "Readings"),
        ):
            with self.subTest(code=code):
                self.sql(code, False)

    def test_dax_live_calculate_countrows(self):
        for code in (
            DAX, DAX + ";", "```dax\n" + DAX + "\n```",
            DAX.replace("[AssetId]", "[assetid]").replace("EVALUATE", "evaluate"),
            DAX.replace("'Readings'", "Readings"),
            DAX.replace("'Readings'", "'SemanticModel_Readings'"),
            DAX.replace(' = "A012"', ' == "A012"'),
            DAX.replace(' = "A012"', ' = "A012" /* scope */'),
            DAX.replace(''' 'Readings'[AssetId] = "A012"''', ''' "A012" = 'Readings'[AssetId]'''),
        ):
            with self.subTest(code=code):
                self.dax(code)

    def test_dax_incidental_filters_and_scope_removal_do_not_prove_scope(self):
        for code in (
            DAX.replace('"A012"', '"A013"'),
            DAX.replace("'Readings'[AssetId]", "'Assets'[AssetId]"),
            DAX.replace("COUNTROWS('Readings')", "COUNTROWS('Assets')"),
            '''EVALUATE ROW("ReadingCount", COUNTROWS('Readings')) // AssetId = "A012"''',
            '''EVALUATE ROW("ReadingCount", 10, "A012", "AssetId")''',
            DAX.replace(' = "A012"', ' = "A012" || 1=1'),
            DAX.replace(' = "A012"', ' <> "A012"'),
            DAX.replace(' = "A012"', ' = "A012", ALL(\'Readings\')'),
            DAX.replace(' = "A012"', ' = "A012", REMOVEFILTERS(\'Readings\')'),
            '''EVALUATE ROW("Other", CALCULATE(COUNTROWS('Readings'), 'Readings'[AssetId]="A012"),
                "ReadingCount", COUNTROWS('Readings'))''',
        ):
            with self.subTest(code=code):
                self.dax(code, False)

    def test_missing_unsupported_and_excessively_nested_code_returns_reason(self):
        for code in (None, "", 42, "SELECT 'unclosed", "SELECT /* nested /* comment */",
                     "(" * 40 + SQL + ")" * 40, "x" * 65537):
            with self.subTest(code=code if not isinstance(code, str) else code[:80]):
                self.sql(code, False)
        proof = prove_count_scope("unexecuted.tool", SQL, "Lakehouse_Readings")
        self.assertEqual("UNVERIFIED", proof["status"])


if __name__ == "__main__":
    unittest.main()
