"""Initial interactive authentication for the Windows Fabric Daily sample.

Requires azure-identity>=1.25.3,<2 and an interactive terminal/system browser
when cached CLI authentication is unavailable. Azure CLI must be on PATH to
use CLI login; it manages its own normal sign-in cache. This module never
persists tokens or changes global CLI configuration.

Browser mode requires an explicitly supplied, organization-approved Microsoft
Entra public client application ID, a Mobile and desktop applications redirect
URI of http://localhost:8400 (with local port 8400 available), and delegated
permissions/consent for the downstream Power BI, Storage, SQL, and Kusto APIs the
caller uses. Tenant policy and resource permissions still apply. Browser tokens
are cached only in memory.

Use ``with open_credential(tenant_id, mode="auto", client_id=client_id) as cred``
before creating resources. Reuse ``cred`` for every downstream scope. Only the
initial Power BI authentication can select a fallback; subsequent authentication
and HTTP errors propagate without changing credentials or opening another login.
"""

import os
import shutil
import subprocess
import sys
from contextlib import ExitStack, contextmanager
from uuid import UUID

from azure.core.exceptions import ClientAuthenticationError
from azure.identity import AzureCliCredential, InteractiveBrowserCredential

PBI_SCOPE = "https://analysis.windows.net/powerbi/api/.default"


class AuthenticationCancelled(RuntimeError):
    """Interactive authentication was declined, interrupted, or unavailable."""


def _report(message):
    print(message, file=sys.stderr)


def _require_terminal():
    if sys.stdin is None or not sys.stdin.isatty():
        raise AuthenticationCancelled(
            "Interactive authentication requires a terminal; authentication stopped. "
            "Sign in with Azure CLI interactively first, then retry."
        )


def _read(prompt):
    _require_terminal()
    try:
        return input(prompt).strip()
    except (EOFError, KeyboardInterrupt):
        raise AuthenticationCancelled("Authentication cancelled; no login was selected.") from None


def _offer(prompt):
    answer = _read(prompt + " [y/N; q to cancel]: ").lower()
    if answer in ("y", "yes"):
        return True
    if answer in ("", "n", "no"):
        return False
    raise AuthenticationCancelled("Authentication cancelled; an explicit yes is required.")


def _guid(value, label):
    try:
        return str(UUID(value))
    except (ValueError, AttributeError, TypeError):
        raise ValueError(f"{label} must be a valid GUID.") from None


def _initialize_cli(credential, tenant_id):
    try:
        credential.get_token(PBI_SCOPE)
        return True
    except ClientAuthenticationError as error:
        # Do not print SDK exception bodies, which can contain sensitive details.
        _report(f"Cached Azure CLI authentication failed ({type(error).__name__}).")

    executable = shutil.which("az")
    if executable is None:
        _report("Azure CLI is unavailable on PATH; CLI browser login cannot run.")
        return False
    if not _offer(
        "Sign in with Azure CLI in the SYSTEM BROWSER for the requested tenant? "
        "This updates Azure CLI's normal sign-in cache"
    ):
        return False

    child_env = os.environ.copy()
    child_env["AZURE_CORE_ENABLE_BROKER_ON_WINDOWS"] = "false"
    child_env["AZURE_CORE_LOGIN_EXPERIENCE_V2"] = "off"
    try:
        subprocess.run(
            [executable, "login", "--tenant", tenant_id,
             "--allow-no-subscriptions", "--output", "none"],
            env=child_env,
            check=True,
            shell=False,
        )
    except (subprocess.CalledProcessError, OSError) as error:
        _report(f"Azure CLI system-browser login failed ({type(error).__name__}).")
        return False

    try:
        credential.get_token(PBI_SCOPE)
        return True
    except ClientAuthenticationError as error:
        _report(f"Azure CLI authentication after browser login failed ({type(error).__name__}).")
        return False


def _initialize_browser(stack, tenant_id, client_id):
    _require_terminal()
    if client_id is None:
        client_id = _read(
            "Organization-approved public client application ID "
            "(http://localhost:8400 redirect URI; blank to stop): "
        )
    if not client_id or not client_id.strip():
        raise AuthenticationCancelled(
            "An organization-approved public client application ID is required; "
            "authentication stopped. Ask your tenant administrator for an approved app."
        )
    client_id = _guid(client_id.strip(), "Public client application ID")
    credential = InteractiveBrowserCredential(
        tenant_id=tenant_id,
        client_id=client_id,
        redirect_uri="http://localhost:8400",
        disable_automatic_authentication=True,
    )
    stack.callback(credential.close)
    try:
        credential.authenticate(scopes=[PBI_SCOPE])
        credential.get_token(PBI_SCOPE)
    except ClientAuthenticationError as error:
        _report(f"Approved-client browser authentication failed ({type(error).__name__}).")
        raise
    return credential


@contextmanager
def open_credential(tenant_id, mode="auto", client_id=None):
    """Yield one authenticated TokenCredential and close it on every exit.

    ``auto`` tries CLI cache, offers CLI browser login, then explicitly offers
    approved-client browser login. ``cli`` never switches to a different client.
    ``browser`` skips CLI entirely. EOF/Ctrl+C or unavailable interactive input
    stops authentication. No authentication fallback surrounds the yielded body.
    """
    if mode not in ("auto", "cli", "browser"):
        raise ValueError("Authentication mode must be auto, cli, or browser.")
    tenant_id = _guid(tenant_id, "Tenant ID")
    with ExitStack() as stack:
        try:
            credential = None
            if mode != "browser":
                cli = AzureCliCredential(tenant_id=tenant_id)
                stack.callback(cli.close)
                if _initialize_cli(cli, tenant_id):
                    credential = cli
                else:
                    stack.close()
                    if mode == "cli":
                        raise AuthenticationCancelled(
                            "Azure CLI authentication did not complete; cli mode never "
                            "switches to another identity/client. Authentication stopped."
                        )
                    if not _offer(
                        "Use an organization-approved public client in the browser instead? "
                        "This is a different application and may select a different account"
                    ):
                        raise AuthenticationCancelled("Browser authentication declined; authentication stopped.")
            if credential is None:
                credential = _initialize_browser(stack, tenant_id, client_id)
        except KeyboardInterrupt:
            raise AuthenticationCancelled("Authentication cancelled; authentication stopped.") from None
        yield credential
