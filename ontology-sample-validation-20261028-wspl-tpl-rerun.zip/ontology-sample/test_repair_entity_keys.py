import copy
import io
import json
import tempfile
import unittest
from contextlib import ExitStack, redirect_stdout
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

import repair_entity_keys as repair
from create_ontology import build_definition
from create_sample import Manifest
from test_create_ontology import GUID, inventory, metadata
from test_ux_authoring import CAPACITY, HOST, ITEM, METADATA, TARGET, result_for


class KeyRepairTests(unittest.TestCase):
    def saved_run(self):
        state = inventory()
        expected = build_definition(state, metadata(), "powerbi://dailyapi.powerbi.com")
        actual = copy.deepcopy(expected)
        for entity in actual["model"]["entities"]:
            entity["lineageTag"] = "existing-" + entity["name"]
            if entity["name"].startswith(tuple(group + "_" for group in repair.UX_GROUPS)):
                entity["keyProperties"] = []
        return {
            "environment": "Daily", "authoringMode": "hybrid", "tenantId": GUID, "targetNetwork": "wspl",
            "targetWorkspaceId": TARGET, "targetWorkspace": {"capacityId": CAPACITY},
            "ontologyName": "BoundSample",
            "items": {"Ontology": {"id": ITEM, "type": "Ontology", "displayName": "BoundSample"}},
            "uxMetadataApi": METADATA, "uxExpectedWorkloadHost": HOST, "authentication": "cli",
            "uxTokenVersion": "v2", "almBaselineVerified": True, "uxWriteCompleted": True,
            "sourceWorkspaceId": state["workspaceId"], "sourceItems": state["items"],
            "authoredDefinition": expected, "expandedDefinition": actual,
        }

    def prepare(self, folder, saved=None):
        path = folder / "run.manifest.json"
        path.write_text(json.dumps(saved or self.saved_run()), encoding="utf-8")
        return path, repair.prepare(path)

    def setup_live(self, folder, stack, actual=None):
        path, (saved, auth, state, _) = self.prepare(folder)
        before = copy.deepcopy(actual if actual is not None else saved["expandedDefinition"])
        script, after = repair.repair_script(saved["authoredDefinition"], before, state, TARGET)
        api = stack.enter_context(patch("repair_entity_keys.TargetApi")).return_value
        api.base = "https://target.w.dailyapi.fabric.microsoft.com/v1"
        api.json.side_effect = [
            {"id": TARGET, "capacityId": CAPACITY}, saved["items"]["Ontology"],
        ]
        workload = stack.enter_context(patch("repair_entity_keys.open_workload")).return_value.__enter__.return_value
        workload.base = f"https://{HOST}/workload"
        workload.json.side_effect = [before, before, after, after]
        workload.request.return_value = SimpleNamespace(status_code=200, json=lambda: result_for(script))
        manifest = Manifest(folder / "repair.manifest.json", {})
        args = SimpleNamespace(timeout=120)
        return args, path, saved, auth, state, api, workload, manifest, before, after, script

    def test_only_empty_keys_on_nine_ux_entities_are_patched(self):
        with tempfile.TemporaryDirectory() as temporary:
            path, (saved, _, state, script) = self.prepare(Path(temporary))
            original = path.read_bytes()
            operations = script["sequence"]["operations"]
            self.assertEqual(len(operations), 9)
            for operation in operations:
                self.assertEqual(set(operation), {"alter"})
                body = operation["alter"]
                self.assertEqual(set(body), {"object", "entity"})
                self.assertEqual(set(body["entity"]), {"keyProperties"})
                self.assertTrue(body["object"]["entity"].startswith(("Lakehouse_", "MirroredDatabase_", "SQLDatabase_")))
            self.assertEqual(operations[0], {"alter": {
                "object": {"entity": "Lakehouse_Plants"}, "entity": {"keyProperties": ["PlantId"]}}})
            _, desired = repair.repair_script(saved["authoredDefinition"], saved["expandedDefinition"], state, TARGET)
            for entity in desired["model"]["entities"]:
                self.assertEqual(len(entity["keyProperties"]), 1)
            self.assertEqual(path.read_bytes(), original)
            self.assertEqual(saved["expandedDefinition"]["model"]["entities"][0]["keyProperties"], [])

    def test_partial_and_absent_keys_are_supported_but_conflicting_keys_are_not(self):
        saved = self.saved_run()
        state = inventory()
        actual = saved["expandedDefinition"]
        actual["model"]["entities"][0].pop("keyProperties")
        actual["model"]["entities"][1]["keyProperties"] = ["AssetId"]
        script, _ = repair.repair_script(saved["authoredDefinition"], actual, state, TARGET)
        self.assertEqual(len(script["sequence"]["operations"]), 8)
        for conflicting in (["Other"], ["PlantId", "Other"], None, "PlantId"):
            actual["model"]["entities"][0]["keyProperties"] = conflicting
            with self.subTest(conflicting=conflicting), self.assertRaisesRegex(ValueError, "different keyProperties"):
                repair.repair_script(saved["authoredDefinition"], actual, state, TARGET)

    def test_unrelated_mismatches_stop_repair_before_network(self):
        for corruption in ("annotation", "expression", "property", "extra-entity", "baseline-key", "expected-key"):
            saved = self.saved_run()
            model = saved["expandedDefinition"]["model"]
            if corruption == "annotation":
                model["tables"][0]["partitions"][0].pop("annotations")
            elif corruption == "expression":
                model["expressions"][0]["expression"] = "wrong source"
            elif corruption == "property":
                model["entities"][0]["properties"].pop()
            elif corruption == "extra-entity":
                model["entities"].append({"name": "Unrelated"})
            elif corruption == "baseline-key":
                next(e for e in model["entities"] if e["name"] == "SemanticModel_Plants")["keyProperties"] = []
            else:
                saved["authoredDefinition"]["model"]["entities"][0]["keyProperties"] = ["Unexpected"]
            with self.subTest(corruption=corruption), tempfile.TemporaryDirectory() as temporary:
                with self.assertRaises(ValueError):
                    self.prepare(Path(temporary), saved)

    def test_wrong_mode_incomplete_write_and_untrusted_route_are_rejected(self):
        for changes in (
            {"authoringMode": "public"}, {"authoringMode": "ux"}, {"almBaselineVerified": False},
            {"uxWriteCompleted": False}, {"uxMetadataApi": "https://example.com"},
            {"ontologyName": "Different"}, {"authentication": "unknown"},
        ):
            saved = self.saved_run()
            saved.update(changes)
            with self.subTest(changes=changes), tempfile.TemporaryDirectory() as temporary:
                with self.assertRaises(ValueError):
                    self.prepare(Path(temporary), saved)

    def test_offline_preview_does_not_authenticate_create_directory_or_modify_input(self):
        with tempfile.TemporaryDirectory() as temporary, patch("repair_entity_keys.open_credential") as authenticate:
            folder = Path(temporary)
            path, _ = self.prepare(folder)
            original = path.read_bytes()
            output = folder / "output"
            with redirect_stdout(io.StringIO()) as printed:
                repair.main(["--run-manifest", str(path), "--run-directory", str(output)])
            plan = json.loads(printed.getvalue())
            self.assertEqual(plan["ontologyId"], ITEM)
            self.assertEqual(plan["authentication"], "cli")
            self.assertFalse(plan["createsItems"])
            self.assertFalse(plan["changesSemanticModelBindings"])
            self.assertEqual(len(plan["plannedScriptFromSavedReadback"]["sequence"]["operations"]), 9)
            authenticate.assert_not_called()
            self.assertFalse(output.exists())
            self.assertEqual(path.read_bytes(), original)

    def test_live_repair_rechecks_identity_and_preserves_everything_but_keys(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            args, path, saved, auth, state, api, workload, manifest, before, after, script = self.setup_live(
                Path(temporary), stack)
            original = path.read_bytes()
            credential = Mock()
            repair.run(args, credential, saved, auth, state, manifest)
            api.mutate.assert_not_called()
            workload.mutate.assert_not_called()
            route, supplied_credential, workspace, item_id = repair.open_workload.call_args.args
            self.assertEqual(route.workspace_id, TARGET)
            self.assertEqual(route.ux_token_version, "v2")
            self.assertEqual(route.ux_metadata_api, METADATA)
            self.assertIs(supplied_credential, credential)
            self.assertEqual(workspace["capacityId"], CAPACITY)
            self.assertEqual(item_id, ITEM)
            workload.request.assert_called_once_with(
                "POST", workload.base + f"/v4/workspaces/{TARGET}/ontologies/{ITEM}/definition/scripts",
                script, request_timeout=120)
            saved_result = json.loads(manifest.path.read_text())
            self.assertEqual(saved_result["status"], "succeeded")
            self.assertTrue(saved_result["writeCompleted"])
            self.assertEqual(saved_result["beforeExpandedDefinition"], before)
            self.assertEqual(saved_result["expandedDefinition"], after)
            self.assertEqual(saved_result["verified"]["uxDefinition"]["entities"], 18)
            self.assertEqual(saved_result["verified"]["uxDefinition"]["relationships"], 12)
            self.assertEqual(path.read_bytes(), original)

    def test_already_fixed_item_is_verified_without_posting_an_empty_script(self):
        saved = self.saved_run()
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            args, _, saved, auth, state, _, workload, manifest, _, _, _ = self.setup_live(
                Path(temporary), stack, actual=saved["authoredDefinition"])
            repair.run(args, Mock(), saved, auth, state, manifest)
            workload.request.assert_not_called()
            self.assertEqual(manifest.data["status"], "succeeded")
            self.assertEqual(manifest.data["repairTargets"], [])
            self.assertNotIn("writeAttempted", manifest.data)
            self.assertNotIn("writeCompleted", manifest.data)

    def test_live_identity_and_content_drift_stop_before_write(self):
        for change in ("capacity", "item", "name", "annotation", "key"):
            with self.subTest(change=change), tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
                args, _, saved, auth, state, api, workload, manifest, before, _, _ = self.setup_live(
                    Path(temporary), stack)
                if change == "capacity":
                    api.json.side_effect = [{"capacityId": GUID}]
                elif change in ("item", "name"):
                    item = copy.deepcopy(saved["items"]["Ontology"])
                    item["id" if change == "item" else "displayName"] = "Changed"
                    api.json.side_effect = [{"capacityId": CAPACITY}, item]
                else:
                    drift = copy.deepcopy(before)
                    if change == "annotation":
                        drift["model"]["tables"][0]["partitions"][0].pop("annotations")
                    else:
                        drift["model"]["entities"][0]["keyProperties"] = ["Other"]
                    workload.json.side_effect = [drift, drift]
                with self.assertRaises(ValueError):
                    repair.run(args, Mock(), saved, auth, state, manifest)
                workload.request.assert_not_called()

    def test_write_failures_and_bad_results_keep_evidence_without_replay(self):
        for failure in ("timeout", "status", "results", "json"):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
                args, _, saved, auth, state, _, workload, manifest, _, _, script = self.setup_live(Path(temporary), stack)
                if failure == "timeout":
                    workload.request.side_effect = TimeoutError("unknown outcome")
                elif failure == "status":
                    workload.request.return_value = Mock(status_code=202)
                elif failure == "results":
                    workload.request.return_value = Mock(status_code=200)
                    workload.request.return_value.json.return_value = {"results": []}
                else:
                    workload.request.return_value = Mock(status_code=200)
                    workload.request.return_value.json.side_effect = ValueError("invalid JSON")
                with self.assertRaises((TimeoutError, RuntimeError, ValueError)):
                    repair.run(args, Mock(), saved, auth, state, manifest)
                persisted = json.loads(manifest.path.read_text())
                self.assertTrue(persisted["writeAttempted"])
                self.assertEqual(persisted["authoredScript"], script)
                self.assertEqual(persisted.get("writeCompleted", False), failure in ("results", "json"))
                self.assertNotIn("uxDefinition", persisted["verified"])
                self.assertEqual(workload.request.call_count, 1)

    def test_post_repair_checks_reject_missing_keys_and_changed_lineage_or_bindings(self):
        for change in ("key", "lineage", "binding"):
            with self.subTest(change=change), tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
                args, _, saved, auth, state, _, workload, manifest, before, after, _ = self.setup_live(
                    Path(temporary), stack)
                if change == "key":
                    after["model"]["entities"][0]["keyProperties"] = []
                elif change == "lineage":
                    after["model"]["entities"][0]["lineageTag"] = "Changed"
                else:
                    after["model"]["tables"][0]["partitions"][0]["source"]["entityName"] = "Wrong"
                workload.json.side_effect = [before, before, after, after]
                with self.assertRaises(ValueError):
                    repair.run(args, Mock(), saved, auth, state, manifest)
                self.assertTrue(manifest.data["writeCompleted"])
                self.assertEqual(manifest.data["expandedDefinition"], after)
                self.assertNotIn("uxDefinition", manifest.data["verified"])

    def test_execute_preserves_input_and_records_failure_in_separate_manifest(self):
        with tempfile.TemporaryDirectory() as temporary, patch("repair_entity_keys.open_credential"), \
                patch("repair_entity_keys.run", side_effect=RuntimeError("read-back failed")):
            folder = Path(temporary)
            path, _ = self.prepare(folder)
            original = path.read_bytes()
            output = folder / "repair"
            with redirect_stdout(io.StringIO()), self.assertLogs("ontology-sample", level="ERROR"):
                with self.assertRaisesRegex(RuntimeError, "read-back failed"):
                    repair.main(["--run-manifest", str(path), "--run-directory", str(output), "--execute"])
            evidence = json.loads((output / "repair.manifest.json").read_text())
            self.assertEqual(evidence["status"], "failed")
            self.assertEqual(path.read_bytes(), original)
            with redirect_stdout(io.StringIO()), self.assertRaises(FileExistsError):
                repair.main(["--run-manifest", str(path), "--run-directory", str(output), "--execute"])


if __name__ == "__main__":
    unittest.main()
