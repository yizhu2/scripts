import io
import json
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import Mock, patch

import requests
from azure.core.exceptions import ClientAuthenticationError

import check_ux_auth as check
from test_ux_authoring import CAPACITY, GUID, HOST, ITEM, METADATA, TARGET, WSPL_METADATA


class AuthProbeTests(unittest.TestCase):
    def manifest(self):
        return {
            "environment": "Daily", "authoringMode": "ux", "tenantId": GUID, "targetNetwork": "wspl",
            "targetWorkspaceId": TARGET, "targetWorkspace": {"capacityId": CAPACITY},
            "items": {"Ontology": {"id": ITEM}}, "uxMetadataApi": METADATA,
            "uxExpectedWorkloadHost": HOST, "authentication": "cli",
        }

    def plan(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "run.json"
            path.write_text(json.dumps(self.manifest()))
            return check.load_plan(path)

    def test_hybrid_failed_run_reuses_existing_item_and_credentials(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "run.json"
            saved = self.manifest()
            saved.update(authoringMode="hybrid", almWriteCompleted=True, authoringPhase="ux-extension")
            original = json.dumps(saved)
            path.write_text(original)
            plan = check.load_plan(path)
            self.assertEqual(plan["ontologyId"], ITEM)
            self.assertEqual(plan["authentication"], "cli")
            self.assertEqual(plan["tokenVersion"], "v2")
            self.assertEqual(path.read_text(), original)

    def test_only_safe_codes_and_guid_headers_are_reported(self):
        response = Mock(status_code=403, headers={"RequestId": GUID, "ActivityId": "SECRET", "Authorization": "SECRET"})
        response.json.return_value = {"error": {"code": "PowerBINotAuthorizedException",
                                                "message": "SECRET", "details": ["SECRET"],
                                                "pbi.error": {"code": "DeniedByPolicy"}},
                                      "requestId": ITEM, "Token": "SECRET"}
        evidence = check.response_evidence(response)
        self.assertEqual(evidence["RequestId"], GUID)
        self.assertEqual(evidence["bodyRequestId"], ITEM)
        self.assertEqual(evidence["serviceErrorCodes"], ["PowerBINotAuthorizedException", "DeniedByPolicy"])
        self.assertNotIn("SECRET", json.dumps(evidence))

    def test_html_or_malformed_error_body_does_not_get_echoed(self):
        for body in (ValueError("SECRET"), "SECRET", {"errorCode": "header.payload.signature"},
                     {"error": {"code": "Bearer SECRET", "requestId": "SECRET"}}):
            response = Mock(status_code=403, headers={})
            if isinstance(body, Exception):
                response.json.side_effect = body
            else:
                response.json.return_value = body
            self.assertEqual(check.response_evidence(response), {"httpStatus": 403})

    def test_probe_uses_existing_item_same_v2_body_and_no_workload_calls(self):
        for status in (200, 403):
            with self.subTest(status=status), patch("requests.Session") as factory:
                session = factory.return_value
                session.hooks = {"response": []}
                response = Mock(status_code=status, headers={"RequestId": GUID}, content=b"json",
                                text="SECRET")
                response.json.return_value = (
                    {"Token": "SECRET", "TargetUriHost": HOST, "CapacityObjectId": CAPACITY} if status == 200
                    else {"errorCode": "PowerBINotAuthorizedException", "message": "SECRET"}
                )

                def request(*args, **kwargs):
                    for hook in session.hooks["response"]:
                        hook(response)
                    return response

                session.request.side_effect = request
                evidence = check.probe(self.plan(), Mock(), 60)
                self.assertEqual(evidence["status"], "token-acquired" if status == 200 else "failed")
                self.assertFalse(evidence["resourceChanges"])
                self.assertNotIn("SECRET", json.dumps(evidence))
                session.request.assert_called_once()
                call = session.request.call_args
                self.assertEqual(call.args, ("POST", METADATA + "/metadata/v201606/generatemwctokenv2"))
                self.assertEqual(call.kwargs["json"],
                                 {"workspaceObjectId": TARGET, "workloadType": "DO",
                                  "artifacts": [{"artifactType": "Ontology", "artifactObjectId": ITEM}]})
                self.assertFalse(call.kwargs["allow_redirects"])
                session.close.assert_called_once()

    def test_probe_can_explicitly_test_v1_from_a_legacy_v2_run_without_recreating(self):
        with tempfile.TemporaryDirectory() as temporary, patch("requests.Session") as factory:
            path = Path(temporary) / "run.json"
            original = json.dumps(self.manifest())
            path.write_text(original)
            self.assertEqual(check.load_plan(path)["tokenVersion"], "v2")
            plan = check.load_plan(path, "v1")
            self.assertEqual(plan["endpoint"], METADATA + "/metadata/v201606/generatemwctoken")
            session = factory.return_value
            session.hooks = {"response": []}
            response = Mock(status_code=200, content=b"json")
            response.json.return_value = {"Token": "SECRET", "TargetUriHost": HOST}
            session.request.return_value = response
            self.assertEqual(check.probe(plan, Mock(), 60)["status"], "token-acquired")
            self.assertEqual(session.request.call_args.kwargs["json"], {
                "capacityObjectId": CAPACITY, "workspaceObjectId": TARGET,
                "workloadType": "DO", "artifactObjectIds": [ITEM],
            })
            session.request.assert_called_once()
            self.assertEqual(path.read_text(), original)

    def test_explicit_captured_metadata_origin_is_validated_and_manifest_is_unchanged(self):
        with (tempfile.TemporaryDirectory() as temporary,
              patch("check_ux_auth.open_credential"),
              patch("requests.Session") as factory):
            path = Path(temporary) / "run.json"
            original = json.dumps(self.manifest())
            path.write_text(original)
            session = factory.return_value
            session.hooks = {"response": []}
            response = Mock(status_code=200, content=b"json")
            response.json.return_value = {"Token": "SECRET", "TargetUriHost": HOST}
            session.request.return_value = response
            with redirect_stdout(io.StringIO()) as output:
                self.assertEqual(check.main([
                    "--run-manifest", str(path), "--metadata-api", WSPL_METADATA,
                    "--token-version", "v2", "--execute",
                ]), 0)
            self.assertNotIn("SECRET", output.getvalue())
            session.request.assert_called_once()
            self.assertEqual(session.request.call_args.args,
                             ("POST", WSPL_METADATA + "/metadata/v201606/generatemwctokenv2"))
            self.assertEqual(session.request.call_args.kwargs["json"], {
                "workspaceObjectId": TARGET, "workloadType": "DO",
                "artifacts": [{"artifactType": "Ontology", "artifactObjectId": ITEM}],
            })
            self.assertEqual(path.read_text(), original)
            for origin in ("https://evil.example", WSPL_METADATA + "/metadata/v201606/generatemwctokenv2"):
                with self.assertRaises(ValueError):
                    check.load_plan(path, metadata_api=origin)

    def test_connection_error_is_failed_without_echoing_exception_body(self):
        with patch("requests.Session") as factory:
            factory.return_value.hooks = {"response": []}
            factory.return_value.request.side_effect = requests.ConnectionError("SECRET")
            evidence = check.probe(self.plan(), Mock(), 60)
            self.assertEqual(evidence["status"], "failed")
            self.assertEqual(evidence["exceptionType"], "ConnectionError")
            self.assertNotIn("SECRET", json.dumps(evidence))

    def test_returned_host_or_capacity_mismatch_fails_without_exposing_token(self):
        for change in ({"TargetUriHost": "unexpected.pbidedicated.windows.net"}, {"CapacityObjectId": GUID}):
            with self.subTest(change=change), patch("requests.Session") as factory:
                session = factory.return_value
                session.hooks = {"response": []}
                response = Mock(status_code=200, content=b"json")
                response.json.return_value = {"Token": "SECRET", "TargetUriHost": HOST,
                                             "CapacityObjectId": CAPACITY, **change}
                session.request.return_value = response
                evidence = check.probe(self.plan(), Mock(), 60)
                self.assertEqual(evidence["status"], "failed")
                self.assertNotIn("SECRET", json.dumps(evidence))
                self.assertTrue(evidence["startedUtc"].endswith("+00:00"))
                self.assertTrue(evidence["finishedUtc"].endswith("+00:00"))
                session.request.assert_called_once()

    def test_execute_exit_status_and_explicit_version(self):
        for status, exit_code in (("token-acquired", 0), ("failed", 1)):
            with (tempfile.TemporaryDirectory() as temporary,
                  patch("check_ux_auth.open_credential") as authenticate,
                  patch("check_ux_auth.probe", return_value={"status": status}) as probe):
                path = Path(temporary) / "run.json"
                path.write_text(json.dumps(self.manifest()))
                with redirect_stdout(io.StringIO()):
                    self.assertEqual(check.main([
                        "--run-manifest", str(path), "--token-version", "v1", "--execute",
                    ]), exit_code)
                authenticate.assert_called_once_with(GUID, mode="cli", client_id=None)
                probe.assert_called_once()
                self.assertEqual(probe.call_args.args[0]["tokenVersion"], "v1")

    def test_signin_failure_does_not_echo_secret_or_request_token(self):
        with (tempfile.TemporaryDirectory() as temporary,
              patch("check_ux_auth.open_credential", side_effect=ClientAuthenticationError("SECRET")),
              patch("check_ux_auth.probe") as probe):
            path = Path(temporary) / "run.json"
            path.write_text(json.dumps(self.manifest()))
            with redirect_stdout(io.StringIO()) as output:
                self.assertEqual(check.main(["--run-manifest", str(path), "--execute"]), 1)
            self.assertIn("sign-in-failed", output.getvalue())
            self.assertNotIn("SECRET", output.getvalue())
            probe.assert_not_called()

    def test_offline_preview_does_not_authenticate_and_keeps_manifest_unchanged(self):
        with tempfile.TemporaryDirectory() as temporary, patch("check_ux_auth.open_credential") as authenticate:
            path = Path(temporary) / "run.json"
            path.write_text(json.dumps(self.manifest()))
            before = path.read_bytes()
            with redirect_stdout(io.StringIO()) as output:
                self.assertEqual(check.main(["--run-manifest", str(path)]), 0)
            self.assertFalse(json.loads(output.getvalue())["resourceChanges"])
            authenticate.assert_not_called()
            self.assertEqual(path.read_bytes(), before)

    def test_no_item_or_wrong_manifest_fails_before_network(self):
        for change in ({"items": {}}, {"authoringMode": "public"}, {"uxMetadataApi": "https://evil.example"}):
            with tempfile.TemporaryDirectory() as temporary:
                path = Path(temporary) / "run.json"
                path.write_text(json.dumps({**self.manifest(), **change}))
                with self.assertRaises((ValueError, KeyError)):
                    check.load_plan(path)


if __name__ == "__main__":
    unittest.main()
