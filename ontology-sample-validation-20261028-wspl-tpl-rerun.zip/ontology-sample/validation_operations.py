"""Operations runtime is explicitly untested; no ALM substitute or activation."""

"""Inactive Operations playbook previews, not monitoring or notification tests."""

import re
import time
from contextlib import closing, contextmanager
from decimal import Decimal, InvalidOperation
from functools import partial
from types import SimpleNamespace
from uuid import UUID, uuid4

from create_sample import Api, PBI_SCOPE
from ux_authoring import workload_host, workspace_routing
from validation_common import HttpFailure, InvalidResponse, ScenarioBlocked, sanitize, utc_now
from validation_queries import GROUPS
from validation_setup import MANUAL_SCENARIOS


API_VERSION = {"api-version": "2025-05-01"}
CELSIUS_PROPERTIES = frozenset({"TemperatureC", "TemperatureCelsius"})
SCOPE = ("Inactive preview authoring and static playbook checks only; the runner does not separately "
         "execute generated queries or test monitoring, rule firing, notifications or external actions.")


def operations_routing(config):
    if config.get("ux_token_version", "v2") != "v2":
        raise ScenarioBlocked("Operations Agent requires OA MWC v2; no v1 fallback")
    try:
        return workspace_routing(config, "operations")
    except ValueError as error:
        raise ScenarioBlocked(f"Operations workspace routing: {error}") from error


@contextmanager
def operations_context(ctx, agent_id, capacity_id):
    origin, expected_host = operations_routing(ctx.config)
    workspace = str(UUID(ctx.config["workspace_id"]))
    agent_id, capacity_id = str(UUID(agent_id)), str(UUID(capacity_id))
    with closing(Api(origin, PBI_SCOPE, ctx.credential, ctx.timeout,
                     sensitive_response=True)) as metadata:
        result = ctx.request(metadata, "POST", origin + "/metadata/v201606/generatemwctokenv2", {
            "workspaceObjectId": workspace, "workloadType": "OA",
            "artifacts": [{"artifactType": "OperationalAgents", "artifactObjectId": agent_id}],
        })
    if not isinstance(result, dict):
        raise InvalidResponse("OA MWC response must be an object")
    host = workload_host(result.get("TargetUriHost"))
    if expected_host and host != expected_host:
        raise ScenarioBlocked("OA routing host mismatch; no workload call or public fallback attempted")
    if result.get("CapacityObjectId") and str(UUID(result["CapacityObjectId"])) != capacity_id:
        raise ScenarioBlocked("OA MWC capacity mismatch; no workload call attempted")
    token = result.get("Token")
    if not isinstance(token, str) or not token:
        raise InvalidResponse("OA MWC response omitted its workload token")
    credential = SimpleNamespace(get_token=lambda *_args, **_kwargs: SimpleNamespace(token=token))
    base = f"https://{host}/webapi/capacities/{capacity_id}/workloads/OA/OAgentsService/automatic"
    with closing(Api(base, PBI_SCOPE, credential, ctx.timeout, auth_scheme="MwcToken")) as api:
        yield api


def preview_configuration(config, case, ontology_name):
    dimensions, readings = GROUPS[case]
    return {
        "goals": "Draft one historical sample temperature rule. Do not start the agent.",
        "instructions": (
            f"Use only {readings}_Readings, {dimensions}_Assets and {dimensions}_Plants "
            f"from the supplied ontology. Create exactly one rule for {readings}_Readings "
            "whose numeric TemperatureC is strictly above 32.5 degrees Celsius. "
            "Use TemperatureC or the equivalent TemperatureCelsius consistently in the query output "
            "and the condition Is Above 32.5; keep the value in degrees Celsius. "
            "Return that Celsius temperature value, ReadingId, AssetId and PlantId, joining each reading's AssetId to the "
            f"AssetId in {dimensions}_Assets and that asset's PlantId to {dimensions}_Plants.PlantId. "
            "Use historical fixture data without a relative-time or now() filter. "
            "Include the backing ontology query and the rule condition in the playbook. "
            "Do not replace an unavailable source group with another group. "
            "Generate a preview only: no activation, schedule, notification recipient, "
            "message destination, external action or source/ontology mutation."
        ),
        "dataSources": {"businessOntology": {
            "id": config["ontology_id"], "type": "Ontology",
            "displayName": ontology_name, "workspaceId": config["workspace_id"],
            # The shared native DTO requires this Eventhouse field even for Ontology.
            "connection": {"tableName": ""},
        }},
        "actions": {},
    }


def assess_playbook(value, case):
    """Check service-rendered rule structure, never count prose as source/query proof."""
    if (not isinstance(value, dict) or not isinstance(value.get("ontology"), str)
            or not isinstance(value.get("rules"), str)):
        raise InvalidResponse("Preview must contain ontology and rules Markdown strings")
    dimensions, readings = GROUPS[case]
    expected = {f"{dimensions}_Assets", f"{dimensions}_Plants", f"{readings}_Readings"}
    rules = value["rules"]
    details = re.findall(r"<details>\s*(.*?)\s*</details>", rules, re.S | re.I)
    check = {
        "scope": "Static service-rendered playbook contract; not query execution or data correctness",
        "expectedEntities": sorted(expected), "queryExecuted": False, "sourceEvidenceRequired": False,
        "ruleCount": len(details), "status": "UNVERIFIED",
    }
    if not details:
        check["reason"] = "No inspectable rule/query/condition structure; prose alone is insufficient"
        return check
    if len(details) != 1:
        check.update(status="FAIL", reason="Expected exactly one rule")
        return check
    queries = re.findall(r"^\s*```(gql|kql|kqldataquery)\s*\n(.*?)^\s*```\s*$",
                         details[0], re.S | re.M | re.I)
    conditions = re.findall(
        r"^\s*\|\s*([^|\r\n]+)\s*\|\s*([^|\r\n]+)\s*\|\s*([^|\r\n]+)\s*\|\s*$",
        details[0], re.M)
    conditions = [tuple(part.strip() for part in row) for row in conditions
                  if row[0].strip().lower() != "property"
                  and not all(re.fullmatch(r"[-: ]+", part) for part in row)]
    check["conditions"] = conditions
    if len(queries) != 1 or len(conditions) != 1:
        check["reason"] = "Expected one inspectable native query and one condition row"
        return check
    prop, condition, threshold = conditions[0]
    try:
        threshold_matches = Decimal(threshold) == Decimal("32.5")
    except InvalidOperation:
        threshold_matches = False
    check["temperatureProperty"] = prop
    if prop not in CELSIUS_PROPERTIES or condition != "Is Above" or not threshold_matches:
        check.update(status="FAIL", reason="Expected a Celsius temperature property with Is Above 32.5")
        return check
    language, query = queries[0][0].lower(), queries[0][1].strip()
    check.update(queryLanguage=language, query=query)
    # Strings/comments cannot establish entity selection. This is intentionally a bounded
    # shape check, not a GQL parser or authorization to execute model-produced code.
    code = re.sub(r"'(?:''|\\.|[^'\\])*'|\"(?:\"\"|\\.|[^\"\\])*\"|//[^\n]*|/\*.*?\*/",
                  " ", query, flags=re.S)
    if language == "gql" and re.search(r"\(\s*\w*\s*:\s*\)", code):
        check.update(status="FAIL", reason="Rendered GQL contains an empty entity label")
        return check
    labels = set(re.findall(
        r"\(\s*(?:[A-Za-z_]\w*\s*)?(?::|\bIS\b)\s*`?([A-Za-z_]\w*)`?(?=\s*[{)])",
        code, re.I)) if language == "gql" else set()
    if language != "gql":
        known_entities = {f"{group}_{entity}" for groups in GROUPS.values() for group in groups
                          for entity in ("Plants", "Assets", "Readings")}
        labels = known_entities.intersection(re.findall(r"\b[A-Za-z_]\w*\b", code))
    check["queryEntityLabels"] = sorted(labels)
    check["sourceEvidenceVerified"] = labels == expected
    if labels - expected:
        check.update(status="FAIL", reason="Query explicitly selects an unexpected source group")
        return check
    check["sourceEvidenceNote"] = "Source binding and join lineage are informational, not pass/fail requirements"
    identifiers = set(re.findall(r"\b[A-Za-z_]\w*\b", code))
    # Native SQL passthrough carries projected column names inside the SQL string.
    property_code = code if language == "gql" else re.sub(r"//[^\n]*|/\*.*?\*/", " ", query, flags=re.S)
    properties = set(re.findall(r"\b[A-Za-z_]\w*\b", property_code))
    required = {prop, "ReadingId", "AssetId", "PlantId"}
    projections = list(re.finditer(r"\b(?:RETURN|project(?!-))\s+", code, re.I))
    if projections:
        projection = re.split(r"[|;]", code[projections[-1].end():], maxsplit=1)[0]
        properties = set(re.findall(r"\b[A-Za-z_]\w*\b", projection))
        if "Id" in properties and re.search(
                r"\bReadingId\s+AS\s+Id\b|\bId\s*=\s*(?:[A-Za-z_]\w*\.)?ReadingId\b",
                property_code, re.I):
            properties.add("ReadingId")
        check["outputProperties"] = sorted(properties)
    check["missingProperties"] = sorted(required - properties)
    # Reject explicit renaming of a different measurement into an accepted Celsius name.
    rename_sources = re.findall(
        r"(?:[A-Za-z_]\w*\.)?`?([A-Za-z_]\w*)`?\s+AS\s+`?" + re.escape(prop) + r"`?(?!\w)",
        property_code, re.I)
    if language != "gql":
        rename_sources += re.findall(
            r"(?:\bproject(?:-rename)?\s+|\bextend\s+|,\s*)`?" + re.escape(prop)
            + r"`?\s*=\s*(?:(?:todouble|toreal)\s*\(\s*)?"
            + r"(?:[A-Za-z_]\w*\.)?`?([A-Za-z_]\w*)`?(?!\w|\s*\()",
            property_code, re.I)
    check["temperatureRenameSources"] = rename_sources
    predicates = re.findall(
        r"\bWHERE\b(.*?)(?=\||\b(?:RETURN|PROJECT|SUMMARIZE|ORDER|GROUP|LIMIT|TAKE)\b|;|$)",
        property_code, re.I | re.S)
    forbidden = {"INSERT", "DELETE", "UPDATE", "CREATE", "DROP", "SET", "CALL", "MERGE", "LOAD"}
    if {word.upper() for word in identifiers} & forbidden:
        check.update(status="FAIL", reason="Query contains unsupported mutation/procedure keywords")
    elif any(source not in CELSIUS_PROPERTIES for source in rename_sources):
        check.update(status="FAIL", reason="Condition temperature explicitly aliases a non-Celsius property")
    elif not required <= properties or (language == "gql" and not re.search(r"\bRETURN\b", code, re.I)):
        check["reason"] = "Required output properties or GQL RETURN are missing from the rendered query"
    elif any(re.search(r"\b(?:now|ago|current_timestamp)\s*\(", predicate, re.I)
             for predicate in predicates):
        check["reason"] = "Relative-time filters require manual review against the historical fixture"
    elif not value["ontology"].strip():
        check["reason"] = "Generated ontology concepts are empty"
    else:
        check.update(status="PASS", reason="One rule, required properties and threshold inspected; source proof is informational")
    return check


def read_state(ctx, api, path, evidence, phase):
    try:
        value = ctx.request(api, "GET", path + "/settings", params=API_VERSION)
        state = value.get("agentState") if isinstance(value, dict) else None
        evidence.setdefault("stateChecks", []).append({"phase": phase, "utc": utc_now(), "agentState": state})
        if state not in ("Inactive", "Unconfigured"):
            raise InvalidResponse(f"Agent state is {state!r}, not Inactive/Unconfigured; no activation was requested")
        return state
    except Exception:
        ctx.state["operations_safety_stop"] = (
            f"Inactive state could not be verified for {evidence['agentId']} ({phase}); "
            "inspect this retained agent before another Operations run.")
        raise


def get_shared_agent(ctx, evidence):
    workspace, ontology = (str(UUID(ctx.config[key])) for key in ("workspace_id", "ontology_id"))
    # Persisted resources are evidence, not consent to reuse an agent from an earlier run.
    run = getattr(ctx, "_operations_run_state", None)
    if run is None:
        run = {"workspaceId": workspace, "ontologyId": ontology, "agents": {}, "previews": {},
               "creation": {"creationAttempted": False, "status": "not-attempted"}}
        ctx._operations_run_state = run
        ctx.state["operations_agents"] = run["agents"]
        ctx.state["operations_previews"] = run["previews"]
        ctx.state["operations_shared"] = run["creation"]
        ctx.state["operations_playbooks"] = {}
        ctx.state["operations_creation_attempts"] = {}
    if (run["workspaceId"], run["ontologyId"]) != (workspace, ontology):
        raise ScenarioBlocked("Operations workspace and ontology cannot change within a run")
    creation = run["creation"]
    evidence["sharedCreation"] = dict(creation)
    created = False
    if not run.get("agentId"):
        if creation["creationAttempted"]:
            raise ScenarioBlocked("Shared Operations creation already attempted with failed/ambiguous outcome; "
                                  "no replacement will be created in this run")
        metadata = ctx.request(ctx.fabric, "GET", f"{ctx.fabric.base}/workspaces/{workspace}")
        run["capacityId"] = str(UUID(metadata["capacityId"]))
        item = ctx.request(ctx.fabric, "GET", f"{ctx.fabric.base}/workspaces/{workspace}/items/{ontology}")
        if (not isinstance(item, dict) or item.get("id") != ontology or item.get("type") != "Ontology"
                or not isinstance(item.get("displayName"), str) or not item["displayName"].strip()):
            raise InvalidResponse("Ontology item metadata did not contain the expected identity/type/displayName")
        run["ontologyDisplayName"] = item["displayName"]
        name = f"OntologySample-Operations-shared-{uuid4().hex[:12]}"
        creation.update(creationAttempted=True, status="attempted", displayName=name)
        evidence.update(createdDisplayName=name, sharedCreation=dict(creation))
        ctx.state["operations_creation_attempts"][ctx.scenario] = name
        ctx.save_evidence("operations-resource", evidence)
        try:
            item = ctx.mutate(ctx.fabric, f"{ctx.fabric.base}/workspaces/{workspace}/operationsAgents",
                              {"displayName": name,
                               "description": "Inactive shared sample playbook previews; do not activate."})
            run["agentId"] = str(UUID(item["id"]))
        except Exception as error:
            creation.update(status="failed-or-ambiguous",
                            error={"type": type(error).__name__, "message": sanitize(str(error))})
            evidence["sharedCreation"] = dict(creation)
            ctx.save_evidence("operations-resource", evidence)
            raise
        creation.update(status="created", agentId=run["agentId"])
        created = True
    run["agents"][ctx.scenario] = run["agentId"]
    evidence.update(agentId=run["agentId"], created=created, sharedCreation=dict(creation),
                    ontologyDisplayName=run["ontologyDisplayName"])
    ctx.save_evidence("operations-resource", evidence)
    return run


def generate_preview(ctx, api, path, case, evidence, run):
    read_state(ctx, api, path, evidence, "before")
    evidence["phase"] = "generation"
    primary_error = None
    safety_error = None
    result = None
    preview = None
    scenario_deadline = ctx.deadline
    try:
        configuration = preview_configuration(ctx.config, case, evidence["ontologyDisplayName"])
        ctx.save_evidence("operations-preview-request", configuration)
        preview = {"state": "Submitting", "terminalConfirmed": False, "startedUtc": utc_now()}
        run["previews"][ctx.scenario] = preview
        evidence["previewLifecycle"] = preview
        evidence["generationPostAttempted"] = True
        ctx.save_evidence("operations-progress", evidence)
        started = time.monotonic()
        deadline = started + ctx.config.get("operations_generation_timeout", 900)
        ctx.deadline = min(scenario_deadline, deadline) if scenario_deadline is not None else deadline
        response = ctx.request(api, "POST", path + "/behaviorModel", configuration, params=API_VERSION)
        if not isinstance(response, dict):
            raise InvalidResponse("Playbook generation response must be an object containing id")
        try:
            playbook = str(UUID(response.get("id", "")))
        except (ValueError, TypeError, AttributeError) as error:
            raise InvalidResponse("Playbook generation response omitted a valid id; POST will not be replayed") from error
        evidence["playbookId"] = playbook
        preview.update(playbookId=playbook, state="Submitted")
        if playbook in ctx.state["operations_playbooks"].values():
            raise InvalidResponse("Preview ID was reused across scenarios; refusing another scenario's playbook")
        ctx.state.setdefault("operations_playbooks", {})[ctx.scenario] = playbook
        ctx.save_evidence("operations-progress", evidence)
        model_path = path + "/behaviorModel/" + playbook
        while time.monotonic() < deadline:
            current = ctx.request(api, "GET", model_path + "/status", params=API_VERSION)
            state = current.get("state") if isinstance(current, dict) else None
            evidence["generationStatus"] = current
            evidence["generationSeconds"] = round(time.monotonic() - started, 3)
            ctx.save_evidence("operations-progress", evidence)
            if state == "Failed":
                preview.update(state=state, terminalConfirmed=True)
                result = {"status": "FAIL", "summary": "Native playbook generation failed; inspect service error"}
                break
            if state == "Completed":
                if current.get("error"):
                    raise InvalidResponse("Completed generation also returned an error; inspect status evidence")
                preview.update(state=state, terminalConfirmed=True)
                value = ctx.request(api, "GET", model_path, params=API_VERSION)
                ctx.save_evidence("operations-playbook", value)
                check = assess_playbook(value, case)
                evidence["playbookCheck"] = check
                result = {
                    "status": "PARTIAL" if check["status"] == "UNVERIFIED" else check["status"],
                    "summary": f"Preview generation completed; static playbook check {check['status']}. "
                               "No monitoring or generated-query execution.",
                }
                break
            if state != "InProgress":
                raise InvalidResponse(f"Unknown playbook generation state: {state!r}")
            preview["state"] = state
            time.sleep(min(ctx.config.get("poll_seconds", 5), max(0, deadline - time.monotonic())))
        else:
            raise TimeoutError("Playbook generation budget exhausted; retained agent/model, no POST replay")
    except Exception as error:
        primary_error = error
        evidence["generationError"] = {"type": type(error).__name__, "message": sanitize(str(error))}
    finally:
        ctx.deadline = scenario_deadline
        try:
            read_state(ctx, api, path, evidence, "after")
            evidence["inactiveVerified"] = True
        except Exception as error:
            safety_error = error
            evidence["inactiveVerified"] = False
            evidence["safetyError"] = {"type": type(error).__name__, "message": sanitize(str(error))}
        if preview is not None and not preview["terminalConfirmed"]:
            stop = (f"Shared Operations preview outcome is unconfirmed for {ctx.scenario}; "
                    "no later previews will be submitted in this run. Inspect the retained agent/model.")
            ctx.state.setdefault("operations_safety_stop", stop)
            evidence["generationSafetyStop"] = stop
        ctx.save_evidence("operations-progress", evidence)
    if primary_error is not None:
        raise primary_error
    if safety_error is not None:
        raise safety_error
    return result


def authoring(ctx, case):
    evidence = {
        "scope": SCOPE, "runtimeValidated": False, "queryExecuted": False,
        "activatedByRunner": False, "actionsInvokedByRunner": False,
        "notificationsSentByRunner": False, "inactiveVerified": False, "phase": "setup",
    }
    try:
        if ctx.state.get("operations_safety_stop"):
            raise ScenarioBlocked(ctx.state["operations_safety_stop"])
        operations_routing(ctx.config)
        if not ctx.config.get("allow_create"):
            raise ScenarioBlocked("One fresh Operations agent per run requires explicit --allow-create; "
                                  "no prior-run agents are reused")
        run = get_shared_agent(ctx, evidence)
        if ctx.scenario in run["previews"]:
            raise ScenarioBlocked("Operations preview already attempted for this scenario; no POST replay")
        if any(not preview["terminalConfirmed"] for preview in run["previews"].values()):
            raise ScenarioBlocked("A prior Operations preview has no confirmed terminal outcome; no new preview")
        with operations_context(ctx, run["agentId"], run["capacityId"]) as api:
            path = (f"{api.base}/v1/workspaces/{run['workspaceId']}"
                    f"/operationalagents/{run['agentId']}/configuration")
            result = generate_preview(ctx, api, path, case, evidence, run)
        return {**result, "evidence": evidence}
    except Exception as error:
        evidence["error"] = {"type": type(error).__name__, "message": sanitize(str(error))}
        ctx.save_evidence("operations-progress", evidence)
        status = "ERROR"
        if isinstance(error, TimeoutError):
            status = "TIMEOUT"
        elif isinstance(error, ScenarioBlocked) or (
                isinstance(error, HttpFailure) and evidence["phase"] == "setup"):
            status = "BLOCKED"
        elif isinstance(error, HttpFailure):
            status = "FAIL"
        return {"status": status, "summary": f"Operations {evidence['phase']}: {sanitize(str(error))}",
                "evidence": evidence}


def runtime_not_automated(ctx):
    return {"status": "SKIP", "summary": MANUAL_SCENARIOS["operations.runtime"],
            "evidence": {"runtimeValidated": False, "activated": False}}


SCENARIOS = {f"operations.{case}": partial(authoring, case=case) for case in GROUPS}
SCENARIOS["operations.runtime"] = runtime_not_automated
