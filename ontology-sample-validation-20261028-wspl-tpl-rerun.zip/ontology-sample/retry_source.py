"""Set up one source type in an existing sample workspace, or verify its existing items."""

import argparse
import copy
import json
import logging
import time
from contextlib import closing
from pathlib import Path
from uuid import UUID, uuid4

from create_ontology import GROUPS, validate_inventory
from create_sample import (
    COLLECTIONS, PBI_SCOPE, SQL_SCOPE, STORAGE_SCOPE, Manifest, Provisioner,
    arguments as source_arguments, check_local_dependencies, mirror_definition,
    sample_tables, semantic_definition,
)
from create_semantic_ontology import verify_source_schema
from run_sample import workspace_items
from sample_auth import open_credential

LOG = logging.getLogger("ontology-sample")
SQL_TYPES = ("Lakehouse", "MirroredDatabase", "SQLDatabase", "Warehouse")


def arguments(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sources-manifest", type=Path, required=True)
    parser.add_argument("--source-type", choices=COLLECTIONS, required=True)
    parser.add_argument("--verify-only", action="store_true", help="Read existing items; never create or reload data")
    parser.add_argument("--run-directory", type=Path)
    parser.add_argument("--auth", choices=("auto", "cli", "browser"), default="auto")
    parser.add_argument("--client-id", type=lambda value: str(UUID(value)))
    parser.add_argument("--timeout", type=int, default=1800)
    parser.add_argument("--settle-seconds", type=int, default=120)
    parser.add_argument("--kql-request-timeout", type=int, default=300)
    parser.add_argument("--kql-endpoint", help="Explicit approved KQL query-service origin")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args(argv)
    args.run_directory = (args.run_directory or Path("runs") / f"retry_{uuid4().hex[:12]}").resolve()
    return args


def selected_types(state, kind, verify_only):
    if kind == "Eventhouse" or (kind == "KQLDatabase" and not verify_only and "Eventhouse" not in state["items"]):
        return ("Eventhouse", "KQLDatabase")
    return (kind,)


def prepare(args, state):
    for field in ("tenantId", "capacityId", "workspaceId"):
        UUID(state[field])
    if not isinstance(state["items"], dict) or not isinstance(state["verified"], dict):
        raise ValueError("Use a source manifest with items and verified dictionaries")
    for kind, item in state["items"].items():
        if kind not in COLLECTIONS:
            raise ValueError("Use sources.manifest.json, not an ontology run manifest")
        UUID(item["id"])
        if not isinstance(item["displayName"], str) or not item["displayName"].strip():
            raise ValueError(f"Missing source display name for {kind}")
    selected = selected_types(state, args.source_type, args.verify_only)
    if args.verify_only:
        required = set(selected) | ({"Eventhouse"} if "KQLDatabase" in selected else set())
        if not required.issubset(state["items"]):
            raise ValueError("Verification requires existing items for the selected source and its dependencies")
    values = [
        "--tenant-id", state["tenantId"], "--capacity-id", state["capacityId"],
        "--workspace-name", state["workspaceName"], "--prefix", f"OntologyRetry_{uuid4().hex[:12]}",
        "--manifest", str(args.run_directory / "sources.manifest.json"),
        "--fabric-api", state["endpoints"]["fabric"], "--powerbi-api", state["endpoints"]["powerbi"],
        "--onelake-url", state["endpoints"]["onelake"], "--timeout", str(args.timeout),
        "--settle-seconds", str(args.settle_seconds), "--kql-request-timeout", str(args.kql_request_timeout),
    ]
    if args.kql_endpoint:
        values += ["--kql-endpoint", args.kql_endpoint]
    return selected, source_arguments(values)


def remaining_sources(state):
    counts = {table.name: len(table.rows) for table in sample_tables()}
    deferred = state.get("deferredValidation") == {"SemanticModel": ["refresh", "sampleRows"]}
    return [
        kind for kind in COLLECTIONS
        if kind not in state["items"] or (
            kind in GROUPS and state["verified"].get(kind) != counts
            and not (kind == "SemanticModel" and deferred and kind not in state["verified"]))
    ]


def run(provisioner, selected, verify_only):
    manifest = provisioner.manifest
    state = manifest.data
    provisioner.workspace = state["workspaceId"]
    base = f"{provisioner.api.base}/workspaces/{provisioner.workspace}"
    manifest.step("Checking the existing source workspace before selected-source retry")
    workspace = provisioner.api.json("GET", base)
    if (workspace.get("capacityId", "").lower() != state["capacityId"].lower()
            or workspace.get("displayName") != state["workspaceName"]):
        raise ValueError("Source workspace capacity or name changed; refusing to modify it")
    check = selected if verify_only else (("Eventhouse",) if selected == ("KQLDatabase",) else ())
    if verify_only and selected == ("KQLDatabase",):
        check = ("Eventhouse", "KQLDatabase")
    for kind in check:
        item = state["items"][kind]
        found = provisioner.api.json("GET", f"{base}/{COLLECTIONS[kind]}/{item['id']}")
        if found.get("displayName") != item["displayName"]:
            raise ValueError(f"{kind} identity changed since source provisioning")
        if kind == "KQLDatabase":
            if found["properties"]["parentEventhouseItemId"].lower() != state["items"]["Eventhouse"]["id"].lower():
                raise ValueError("KQLDatabase does not belong to the recorded Eventhouse")

    if not verify_only:
        existing = list(workspace_items(provisioner.api, base))
        names = {item["displayName"].casefold() for item in existing}
        if any(f"{provisioner.args.prefix}_{kind}".casefold() in names for kind in selected):
            raise ValueError("A retry item name already exists; refusing to reuse it")
        existing_ids = {item["id"].lower() for item in existing} | {
            item["id"].lower() for item in state["items"].values()}
        state["previousItems"] = {kind: copy.deepcopy(state["items"][kind])
                                  for kind in selected if kind in state["items"]}
        for kind in selected:
            state["items"].pop(kind, None)
        state["skipped"] = [kind for kind in state.get("skipped", []) if kind not in selected]
    for kind in selected:
        state["verified"].pop(kind, None)
        state.get("verifiedDefinitions", {}).pop(kind, None)
    if "KQLDatabase" in selected:
        state["verified"].pop("Eventhouse", None)
    manifest.save()

    if not verify_only:
        for kind in selected:
            extra = {}
            if kind == "KQLDatabase":
                extra["creationPayload"] = {
                    "databaseType": "ReadWrite", "parentEventhouseItemId": state["items"]["Eventhouse"]["id"]}
            elif kind == "MirroredDatabase":
                extra["definition"] = mirror_definition()
            elif kind == "SemanticModel":
                extra["definition"] = semantic_definition(provisioner.tables)
            created = provisioner.create(kind, **extra)
            if created["id"].lower() in existing_ids:
                raise RuntimeError("Creation returned an existing item ID; no data load will be attempted")
            existing_ids.add(created["id"].lower())
        if "KQLDatabase" in selected:
            provisioner.seed_kql()
        elif selected[0] == "Lakehouse":
            provisioner.seed_lakehouse()
        elif selected[0] == "MirroredDatabase":
            provisioner.seed_mirror()
        elif selected[0] in ("SQLDatabase", "Warehouse"):
            provisioner.seed_sql(selected[0])
        if selected[0] in ("Lakehouse", "MirroredDatabase"):
            provisioner.refresh_sql_metadata(selected[0])
        if selected[0] != "SemanticModel" and provisioner.args.settle_seconds:
            manifest.step(f"Waiting {provisioner.args.settle_seconds} seconds before selected-source verification")
            time.sleep(provisioner.args.settle_seconds)

    if "KQLDatabase" in selected:
        provisioner.verify_kql()
    elif selected[0] in SQL_TYPES:
        provisioner.verify_sql(selected[0], asynchronous=not verify_only, refresh_before_read=False)
    else:
        manifest.step("Checking SemanticModel schema; refresh and row queries remain deferred")
        exported = provisioner.api.mutate(
            provisioner.item_path("SemanticModel") + "/getDefinition", params={"format": "TMSL"})
        state.setdefault("verifiedDefinitions", {})["SemanticModel"] = verify_source_schema(exported)
        state.setdefault("deferredValidation", {})["SemanticModel"] = ["refresh", "sampleRows"]
    state["skipped"] = [kind for kind in state.get("skipped", []) if kind not in selected]
    missing = remaining_sources(state)
    if not missing:
        state["status"] = "succeeded"
        validate_inventory(state, allow_deferred_semantic=True)
    else:
        state["status"] = "partial"
    state["retryStatus"] = "succeeded"
    state["remainingSources"] = missing
    manifest.step("Selected source completed; other sources still require setup/verification: " + ", ".join(missing)
                  if missing else "Selected source completed; source inventory is ready for the main workflow")


def main(argv=None):
    args = arguments(argv)
    state = json.loads(args.sources_manifest.read_text(encoding="utf-8-sig"))
    selected, source_args = prepare(args, state)
    plan = {
        "operation": "verify-source" if args.verify_only else "recreate-source",
        "sourceTypes": selected, "workspaceId": state["workspaceId"],
        "sourceManifest": str(args.sources_manifest.resolve()), "outputManifest": str(source_args.manifest),
        "prefix": source_args.prefix, "createsWorkspace": False, "changesOntology": False,
        "kqlEndpointOverride": source_args.kql_endpoint,
        "semanticDataValidation": "Deferred",
    }
    print(json.dumps(plan, indent=2))
    if not args.execute:
        return
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logging.getLogger("azure").setLevel(logging.WARNING)
    if args.run_directory.exists():
        raise FileExistsError("Use a new run directory; inspect the previous retry before another attempt")
    if selected[0] in SQL_TYPES:
        check_local_dependencies(source_args)
    with open_credential(state["tenantId"], mode=args.auth, client_id=args.client_id) as credential:
        scopes = [PBI_SCOPE]
        if "KQLDatabase" in selected:
            scopes.append(source_args.kusto_scope)
        if selected[0] in SQL_TYPES:
            scopes.append(SQL_SCOPE)
        if not args.verify_only and selected[0] in ("Lakehouse", "MirroredDatabase"):
            scopes.append(STORAGE_SCOPE)
        for scope in scopes:
            credential.get_token(scope)
        args.run_directory.mkdir(parents=True, exist_ok=False)
        initial = copy.deepcopy(state)
        initial["sourceAttempt"] = {
            "manifest": str(args.sources_manifest.resolve()), "status": state.get("status"),
            "step": state.get("step"), "pendingOperation": state.get("pendingOperation"),
        }
        for key in ("error", "step", "pendingOperation", "sourceLoadsCompleted", "retryStatus", "remainingSources"):
            initial.pop(key, None)
        initial["retry"] = plan
        manifest = Manifest(source_args.manifest, initial)
        manifest.data.update(items=copy.deepcopy(state["items"]), verified=copy.deepcopy(state["verified"]))
        manifest.save()
        with closing(Provisioner(source_args, credential, manifest)) as provisioner:
            try:
                run(provisioner, selected, args.verify_only)
            except (Exception, KeyboardInterrupt) as error:
                manifest.data.update(status="failed", retryStatus="failed", error=str(error))
                manifest.save()
                LOG.exception("Selected-source retry stopped. No resources deleted; inspect %s", manifest.path)
                raise
        LOG.info("Selected-source result: %s; input manifest and existing ontologies unchanged", manifest.path)


if __name__ == "__main__":
    main()
