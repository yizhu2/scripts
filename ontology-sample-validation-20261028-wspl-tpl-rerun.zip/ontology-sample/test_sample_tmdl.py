"""Offline tests using synthetic fixtures, never live customer IDs or SDK calls."""

import ast
import copy
import shutil
import unittest
from pathlib import Path
from unittest.mock import patch
from uuid import uuid4

from create_ontology import build_definition, verify_definition
from replace_ontology import normalize_tom_defaults
from test_create_ontology import inventory, metadata
import sample_tmdl


class SampleTmdlTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(__file__).parent / f".sample-tmdl-tests-{uuid4().hex}"
        self.root.mkdir()
        self.addCleanup(shutil.rmtree, self.root)
        self.document = build_definition(inventory(), metadata(), "powerbi://dailyapi.powerbi.com")

    def write(self, document=None):
        folder = self.root / uuid4().hex
        sample_tmdl.serialize(self.document if document is None else document, folder)
        return folder

    def change(self, folder, filename, old, new):
        path = folder.joinpath(*filename.split("/"))
        text = path.read_text(encoding="utf-8")
        self.assertIn(old, text)
        path.write_text(text.replace(old, new, 1), encoding="utf-8", newline="\n")

    def test_complete_fixture_roundtrip(self):
        before = copy.deepcopy(self.document)
        folder = self.write()
        actual = normalize_tom_defaults(sample_tmdl.deserialize(folder))
        verify_definition(self.document, actual)
        verify_definition(actual, self.document)
        self.assertEqual(before, self.document)
        model = actual["model"]
        for collection, count in (("tables", 18), ("entities", 18), ("relationships", 12),
                                  ("entityRelationships", 12), ("expressions", 5), ("namespaces", 1)):
            self.assertEqual(len(model[collection]), count)
        self.assertEqual(len(list(folder.rglob("*.tmdl"))), 42)
        self.assertEqual((folder / "database.tmdl").read_text(), "database\n\tcompatibilityLevel: 1000000\n")

    def test_all_partition_kinds_and_column_types(self):
        model = sample_tmdl.deserialize(self.write())["model"]
        shapes = {(p["source"]["type"], p["mode"], p["source"].get("schemaName"))
                  for table in model["tables"] for p in table["partitions"]}
        self.assertEqual(shapes, {
            ("entity", "directLake", None), ("entity", "directLake", "dbo"),
            ("entity", "directQuery", "dbo"), ("entity", "directQuery", None),
            ("m", "directQuery", None),
        })
        self.assertEqual({c["dataType"] for t in model["tables"] for c in t["columns"]},
                         {"string", "dateTime", "double"})

    def test_canonical_minimized_entity_and_lineage_metadata(self):
        folder = self.write()
        for path in (folder / "entities").glob("*.tmdl"):
            name = path.stem
            table = next(t for t in self.document["model"]["tables"] if t["name"] == name)
            key = table["columns"][0]["name"]
            path.write_text(
                f"entity {name}\n\tkeyProperty: {key}\n\tbackingTable: {name}\n"
                f"\tproperty {key}\n\t\tbackingConfiguration\n\t\t\tvalueColumn: {name}.{key}\n"
                "\t\tdataType: string\n", encoding="utf-8")
        self.change(folder, "tables/Lakehouse_Plants.tmdl", "table Lakehouse_Plants\n",
                    "table Lakehouse_Plants\n\tlineageTag: synthetic-table\n")
        self.change(folder, "tables/Lakehouse_Plants.tmdl", "\tcolumn PlantId\n",
                    "\tcolumn PlantId\n\t\tlineageTag: synthetic-column\n")
        self.change(folder, "expressions.tmdl", "\n\nexpression MirroredDatabase",
                    "\n\tlineageTag: synthetic-expression\n\nexpression MirroredDatabase")
        path = folder / "relationships.tmdl"
        text = path.read_text()
        for line in ("\tfromCardinality: many\n", "\ttoCardinality: one\n",
                     "\tcrossFilteringBehavior: oneDirection\n"):
            text = text.replace(line, "")
        path.write_text(text, encoding="utf-8")
        actual = sample_tmdl.deserialize(folder)
        self.assertTrue(all(len(e["properties"]) == 1 for e in actual["model"]["entities"]))
        self.assertTrue(all("description" not in e for e in actual["model"]["entities"]))
        self.assertNotIn("fromCardinality", actual["model"]["relationships"][0])
        table = actual["model"]["tables"][0]
        self.assertEqual(table["lineageTag"], "synthetic-table")
        self.assertEqual(table["columns"][0]["lineageTag"], "synthetic-column")
        self.assertEqual(actual["model"]["expressions"][0]["lineageTag"], "synthetic-expression")
        verify_definition(actual, sample_tmdl.deserialize(self.write(actual)))

    def test_independent_tmdl_fixture_and_m_text(self):
        folder = self.root / "hand-authored"
        folder.mkdir()
        for directory in ("tables", "entities", "namespaces"):
            (folder / directory).mkdir()
        parts = {
            "database.tmdl": "database\n\tcompatibilityLevel: 1000000\n",
            "model.tmdl": "model Model\nref entity Example\nref namespace default\nref table Example\n",
            "namespaces/default.tmdl": "namespace default\n\tlineageTag: default\n",
            "expressions.tmdl": 'expression Example_Source = let X = "雪 = ""quoted"" // ///" in X  \n',
            "tables/Example.tmdl": (
                "/// First line\n/// Second line\n"
                "table Example\n"
                "\tpartition Example = entity\n\t\tmode: directLake\n\t\tsource\n"
                "\t\t\texpressionSource: Example_Source\n\t\t\tentityName: Plants\n"
                "\tcolumn Id\n\t\tsourceColumn: Id\n\t\tisNullable: false\n\t\tisKey\n\t\tdataType: string\n"
            ),
            "entities/Example.tmdl": (
                "entity Example\n\tbackingTable: Example\n\tkeyProperty: Id\n"
                "\tproperty Id\n\t\tdataType: string\n\t\tbackingConfiguration\n"
                "\t\t\tvalueColumn: Example.Id\n"
            ),
        }
        for name, text in parts.items():
            folder.joinpath(*name.split("/")).write_text(text, encoding="utf-8")
        actual = sample_tmdl.deserialize(folder)
        self.assertEqual(actual["model"]["expressions"][0]["expression"], 'let X = "雪 = ""quoted"" // ///" in X  ')
        self.assertEqual(actual["model"]["tables"][0]["description"], "First line\nSecond line")
        verify_definition(actual, sample_tmdl.deserialize(self.write(actual)))

    def test_m_escaping_unicode_equals_and_injection_payloads(self):
        state, sources = inventory(), metadata()
        malicious = '雪 "x" = #(#) ref table Injected // ///'
        state["workspaceName"] = malicious
        state["items"]["Warehouse"]["displayName"] = malicious
        sources["SQLDatabase"]["databaseName"] = malicious
        sources["KQLDatabase"]["queryServiceUri"] = malicious
        document = build_definition(state, sources, "powerbi://dailyapi.powerbi.com")
        folder = self.write(document)
        actual = normalize_tom_defaults(sample_tmdl.deserialize(folder))
        verify_definition(document, actual)
        self.assertEqual(document["model"]["expressions"], actual["model"]["expressions"])
        self.assertEqual(len(actual["model"]["tables"]), 18)
        self.assertNotIn("ref table Injected", (folder / "model.tmdl").read_text())

    def test_descriptions_cannot_inject_declarations(self):
        self.document["model"]["tables"][0]["description"] = "First\nref table Injected\n雪 = ///"
        actual = sample_tmdl.deserialize(self.write())
        self.assertEqual(actual["model"]["tables"][0]["description"], "First\nref table Injected\n雪 = ///")
        self.assertEqual(len(actual["model"]["tables"]), 18)

    def test_ref_order_and_metadata_order_are_not_semantics(self):
        folder = self.write()
        path = folder / "model.tmdl"
        lines = path.read_text().splitlines()
        path.write_text("\n".join([lines[0], *reversed(lines[1:])]), encoding="utf-8")
        self.change(folder, "tables/Lakehouse_Plants.tmdl",
                    "\t\tdataType: string\n\t\tisKey\n\t\tisNullable: false\n\t\tsourceColumn: PlantId",
                    "\t\tsourceColumn: PlantId\n\t\tisNullable: false\n\t\tdataType: string\n\t\tisKey")
        actual = normalize_tom_defaults(sample_tmdl.deserialize(folder))
        self.assertEqual(actual["model"]["tables"][0]["name"], "EventhouseKQL_Readings")
        verify_definition(self.document, actual)

    def test_bom_and_crlf(self):
        folder = self.write()
        for path in folder.rglob("*.tmdl"):
            path.write_bytes(b"\xef\xbb\xbf" + path.read_bytes().replace(b"\n", b"\r\n"))
        verify_definition(self.document, normalize_tom_defaults(sample_tmdl.deserialize(folder)))

    def test_existing_folder_is_never_overwritten(self):
        folder = self.write()
        before = {p: p.read_bytes() for p in folder.rglob("*.tmdl")}
        with self.assertRaises(FileExistsError):
            sample_tmdl.serialize(self.document, folder)
        self.assertEqual(before, {p: p.read_bytes() for p in folder.rglob("*.tmdl")})

    def test_invalid_input_is_rejected_before_folder_creation(self):
        cases = [
            lambda d: d.update(name="UnexpectedDatabase"),
            lambda d: d.update({123: "invalid field"}),
            lambda d: d.update(compatibilityLevel=1600),
            lambda d: d["model"].update(annotations=[]),
            lambda d: d["model"]["tables"][0].update(measures=[]),
            lambda d: d["model"]["tables"][0]["columns"][0].update(dataType="int64"),
            lambda d: d["model"]["tables"][0]["columns"][0].update(isKey=False),
            lambda d: d["model"]["tables"][0]["columns"][0].update(isNullable=True),
            lambda d: d["model"]["tables"][0]["columns"][0].pop("isKey"),
            lambda d: d["model"]["tables"][0]["columns"][1].update(isKey=True, isNullable=False),
            lambda d: d["model"]["tables"][0]["partitions"][0].update(mode="import"),
            lambda d: d["model"]["tables"][0]["partitions"][0]["source"].update(query="SELECT 1"),
            lambda d: d["model"]["expressions"][0].update(kind="sql"),
            lambda d: d["model"]["expressions"][0].update(expression="x\nref table Injected"),
            lambda d: d["model"]["tables"][-1]["partitions"][0]["source"].update(expression="x\r\nInjected"),
            lambda d: d["model"]["tables"][0].update(name="../escape"),
            lambda d: d["model"]["entities"][0].update(keyProperties=["PlantId", "Name"]),
            lambda d: d["model"]["entities"][0]["properties"][0].update(unknown=True),
            lambda d: d["model"]["entities"][0]["properties"][0].update(dataType="double"),
            lambda d: d["model"]["entities"][0]["properties"][0]["backingConfiguration"].update(type="other"),
            lambda d: d["model"]["entityRelationships"][0]["backingConfiguration"].update(type="other"),
            lambda d: d["model"]["namespaces"][0].update(lineageTag="other"),
            lambda d: d["model"]["relationships"][0].update(fromCardinality="invalid"),
            lambda d: d["model"]["tables"].append(copy.deepcopy(d["model"]["tables"][0])),
            lambda d: d["model"]["entities"][0]["properties"].append(
                copy.deepcopy(d["model"]["entities"][0]["properties"][0])),
            lambda d: d["model"]["tables"][0]["columns"].append(
                copy.deepcopy(d["model"]["tables"][0]["columns"][0])),
            lambda d: d["model"]["tables"][0]["partitions"].append(
                copy.deepcopy(d["model"]["tables"][0]["partitions"][0])),
        ]
        for number, change in enumerate(cases):
            with self.subTest(case=number):
                document = copy.deepcopy(self.document)
                change(document)
                folder = self.root / f"invalid-{number}"
                with self.assertRaises(ValueError):
                    sample_tmdl.serialize(document, folder)
                self.assertFalse(folder.exists())

    def test_unknown_parts_and_directories(self):
        for name in ("unknown.tmdl", ".platform", "tables/Unknown.txt", "cultures/default.tmdl",
                     "tables/nested/extra.tmdl"):
            with self.subTest(name=name):
                folder = self.write()
                path = folder.joinpath(*name.split("/"))
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text("unsupported", encoding="utf-8")
                with self.assertRaisesRegex(ValueError, "unknown"):
                    sample_tmdl.deserialize(folder)

    def test_malformed_and_unsupported_syntax(self):
        cases = [
            ("database.tmdl", "1000000", "1600"),
            ("database.tmdl", "database\n", "database Extra\n"),
            ("model.tmdl", "model Model", "model Unexpected"),
            ("model.tmdl", "ref table Lakehouse_Plants", "\tref table Lakehouse_Plants"),
            ("model.tmdl", "ref table Lakehouse_Plants", "ref expression Lakehouse_Source"),
            ("tables/Lakehouse_Plants.tmdl", "\tcolumn PlantId", "    column PlantId"),
            ("tables/Lakehouse_Plants.tmdl", "\tcolumn PlantId", "\t\tcolumn PlantId"),
            ("tables/Lakehouse_Plants.tmdl", "\tcolumn PlantId", "\t column PlantId"),
            ("tables/Lakehouse_Plants.tmdl", "dataType: string", "dataType: int64"),
            ("tables/Lakehouse_Plants.tmdl", "dataType: string", "unknown: string"),
            ("tables/Lakehouse_Plants.tmdl", "\t\tisKey", "\t\tisKey: true"),
            ("tables/Lakehouse_Plants.tmdl", "\t\tisKey", "\t\t/// not an object\n\t\tisKey"),
            ("tables/Lakehouse_Plants.tmdl", "isNullable: false", "isNullable: true"),
            ("tables/Lakehouse_Plants.tmdl", "table Lakehouse_Plants", "table 'Lakehouse_Plants'"),
            ("tables/Lakehouse_Plants.tmdl", "table Lakehouse_Plants", "table Different"),
            ("tables/Lakehouse_Plants.tmdl", " = entity", " = query"),
            ("tables/Lakehouse_Plants.tmdl", "\t\tsource\n", "\t\tsource = let X = 1 in X\n"),
            ("tables/EventhouseKQL_Plants.tmdl", "mode: directQuery", "mode: directLake"),
            ("entities/Lakehouse_Plants.tmdl", "valueColumn: Lakehouse_Plants.PlantId",
             "valueColumn: Lakehouse_Plants.PlantId.Extra"),
            ("expressions.tmdl", "expression Lakehouse_Source = ", "expression Lakehouse_Source\n\t"),
            ("expressions.tmdl", "\n\nexpression MirroredDatabase", "\n\tunknown: unsupported\n\nexpression MirroredDatabase"),
            ("model.tmdl", "ref namespace default\n", "ref namespace default\n/// orphan comment\n"),
            ("namespaces/default.tmdl", "\tlineageTag: default", "\tlineageTag: default\nnamespace other"),
        ]
        for filename, old, new in cases:
            with self.subTest(filename=filename, new=new):
                folder = self.write()
                self.change(folder, filename, old, new)
                with self.assertRaises(ValueError):
                    sample_tmdl.deserialize(folder)

    def test_duplicate_declarations_and_properties(self):
        cases = [
            ("tables/Lakehouse_Plants.tmdl", "\t\tdataType: string", "\t\tdataType: string\n\t\tdataType: string"),
            ("tables/Lakehouse_Plants.tmdl", "\t\tisKey", "\t\tisKey\n\t\tisKey"),
            ("tables/Lakehouse_Plants.tmdl", "\tcolumn Name\n\t\tdataType: string\n\t\tsourceColumn: Name",
             "\tcolumn Name\n\t\tdataType: string\n\t\tsourceColumn: Name\n"
             "\tcolumn Name\n\t\tdataType: string\n\t\tsourceColumn: Name"),
            ("entities/Lakehouse_Plants.tmdl", "\tkeyProperty: PlantId",
             "\tkeyProperty: PlantId\n\tkeyProperty: PlantId"),
            ("entities/Lakehouse_Plants.tmdl", "\t\tbackingConfiguration\n\t\t\tvalueColumn: Lakehouse_Plants.PlantId",
             "\t\tbackingConfiguration\n\t\t\tvalueColumn: Lakehouse_Plants.PlantId\n"
             "\t\tbackingConfiguration\n\t\t\tvalueColumn: Lakehouse_Plants.PlantId"),
            ("model.tmdl", "ref table Lakehouse_Plants", "ref table Lakehouse_Plants\nref table Lakehouse_Plants"),
        ]
        for filename, old, new in cases:
            with self.subTest(filename=filename, new=new):
                folder = self.write()
                self.change(folder, filename, old, new)
                with self.assertRaisesRegex(ValueError, "duplicate"):
                    sample_tmdl.deserialize(folder)
        for filename in ("expressions.tmdl", "relationships.tmdl", "entityRelationships.tmdl"):
            with self.subTest(filename=filename):
                folder = self.write()
                path = folder / filename
                path.write_text(path.read_text() * 2, encoding="utf-8")
                with self.assertRaisesRegex(ValueError, "duplicate"):
                    sample_tmdl.deserialize(folder)

    def test_missing_and_dangling_model_refs(self):
        for old, new in (("ref table Lakehouse_Plants\n", ""),
                         ("ref table Lakehouse_Plants", "ref table Missing"),
                         ("ref entity Lakehouse_Plants\n", ""),
                         ("ref namespace default\n", "")):
            with self.subTest(new=new, old=old):
                folder = self.write()
                self.change(folder, "model.tmdl", old, new)
                with self.assertRaisesRegex(ValueError, "model refs"):
                    sample_tmdl.deserialize(folder)
        folder = self.write()
        (folder / "model.tmdl").unlink()
        with self.assertRaisesRegex(ValueError, "missing"):
            sample_tmdl.deserialize(folder)

    def test_dangling_bindings_and_keys(self):
        cases = [
            ("tables/Lakehouse_Plants.tmdl", "expressionSource: Lakehouse_Source", "expressionSource: Missing"),
            ("entities/Lakehouse_Plants.tmdl", "backingTable: Lakehouse_Plants", "backingTable: Missing"),
            ("entities/Lakehouse_Plants.tmdl", "keyProperty: PlantId", "keyProperty: Missing"),
            ("entities/Lakehouse_Plants.tmdl", "keyProperty: PlantId", "keyProperty: Name"),
            ("entities/Lakehouse_Plants.tmdl", "valueColumn: Lakehouse_Plants.Name",
             "valueColumn: Lakehouse_Plants.Missing"),
            ("entities/Lakehouse_Plants.tmdl", "valueColumn: Lakehouse_Plants.Name",
             "valueColumn: Missing.Name"),
            ("entities/Lakehouse_Plants.tmdl", "valueColumn: Lakehouse_Plants.Name",
             "valueColumn: Lakehouse_Assets.Name"),
            ("entityRelationships.tmdl", "fromEntity: Lakehouse_Assets", "fromEntity: Missing"),
            ("entityRelationships.tmdl", "fromEntity: Lakehouse_Assets", "fromEntity: Warehouse_Assets"),
            ("entityRelationships.tmdl", "relationship: Lakehouse_Assets_to_Plants", "relationship: Missing"),
            ("relationships.tmdl", "fromColumn: Lakehouse_Assets.PlantId", "fromColumn: Missing.PlantId"),
            ("relationships.tmdl", "toColumn: Lakehouse_Plants.PlantId", "toColumn: Lakehouse_Plants.Missing"),
        ]
        for filename, old, new in cases:
            with self.subTest(filename=filename, new=new):
                folder = self.write()
                self.change(folder, filename, old, new)
                with self.assertRaises(ValueError):
                    sample_tmdl.deserialize(folder)

    def test_valid_mutations_remain_visible_to_verifier(self):
        cases = [
            ("entities/Lakehouse_Plants.tmdl", "valueColumn: Lakehouse_Plants.Name",
             "valueColumn: Lakehouse_Plants.City"),
            ("relationships.tmdl", "fromColumn: Lakehouse_Assets.PlantId",
             "fromColumn: Lakehouse_Assets.AssetId"),
            ("relationships.tmdl", "fromCardinality: many", "fromCardinality: one"),
            ("relationships.tmdl", "toCardinality: one", "toCardinality: many"),
            ("relationships.tmdl", "crossFilteringBehavior: oneDirection",
             "crossFilteringBehavior: bothDirections"),
            ("expressions.tmdl", 'Sql.Database(', 'Different.Database('),
            ("tables/Lakehouse_Plants.tmdl", "sourceColumn: Name", "sourceColumn: Changed"),
        ]
        for filename, old, new in cases:
            with self.subTest(filename=filename, new=new):
                folder = self.write()
                self.change(folder, filename, old, new)
                actual = normalize_tom_defaults(sample_tmdl.deserialize(folder))
                with self.assertRaises(ValueError):
                    verify_definition(self.document, actual)
                verify_definition(actual, normalize_tom_defaults(sample_tmdl.deserialize(self.write(actual))))

    def test_filter_metadata_roundtrip(self):
        relationship = self.document["model"]["relationships"][0]
        relationship.update(crossFilteringBehavior="automatic", securityFilteringBehavior="bothDirections")
        actual = normalize_tom_defaults(sample_tmdl.deserialize(self.write()))
        self.assertEqual(actual["model"]["relationships"][0], relationship)

    def test_canonical_source_schema_annotation_is_preserved(self):
        folder = self.write()
        value = '{"version":1,"columns":[{"name":"City","dataType":"string"},{"name":"Name","dataType":"string"}]}'
        path = folder / "tables" / "Lakehouse_Plants.tmdl"
        with path.open("a", encoding="utf-8") as stream:
            stream.write(f"\n\tannotation ONT_SourceSchema = {value}\n")
        actual = sample_tmdl.deserialize(folder)
        self.assertEqual(actual["model"]["tables"][0]["annotations"],
                         [{"name": "ONT_SourceSchema", "value": value}])
        normalized = normalize_tom_defaults(actual)
        verify_definition(self.document, normalized)
        verify_definition(normalized, normalize_tom_defaults(sample_tmdl.deserialize(self.write(actual))))

    def test_annotations_on_named_objects_roundtrip_without_rewriting(self):
        model = self.document["model"]
        objects = [entries[0] for entries in model.values()]
        objects.extend((model["tables"][0]["columns"][0], model["tables"][0]["partitions"][0],
                        model["entities"][0]["properties"][0]))
        annotations = [{"name": "Synthetic_Metadata", "value": ' {"text":"雪 = \\"quoted\\" // ///","n":1}  '},
                       {"name": "Opaque_Text", "value": "first = second: third"}]
        for obj in objects:
            obj["annotations"] = copy.deepcopy(annotations)
        folder = self.write()
        actual = normalize_tom_defaults(sample_tmdl.deserialize(folder))
        verify_definition(self.document, actual)
        verify_definition(actual, self.document)
        table = actual["model"]["tables"][0]
        self.assertEqual(table["annotations"], annotations)
        self.assertEqual(table["columns"][0]["annotations"], annotations)
        self.assertEqual(table["partitions"][0]["annotations"], annotations)
        self.change(folder, "tables/Lakehouse_Plants.tmdl", "first = second: third", "changed = value")
        changed = normalize_tom_defaults(sample_tmdl.deserialize(folder))
        with self.assertRaises(ValueError):
            verify_definition(self.document, changed)

    def test_annotation_invalid_input_rejected_before_writing(self):
        cases = [
            [], {}, [{"name": "A"}], [{"name": "A", "value": 123}],
            [{"name": "bad name", "value": "x"}], [{"name": "A", "value": ""}],
            [{"name": "A", "value": "x\nannotation B = injected"}],
            [{"name": "A", "value": "x\r\ninjected"}],
            [{"name": "A", "value": "x", "children": []}],
            [{"name": "A", "value": "x"}, {"name": "A", "value": "y"}],
        ]
        for number, annotations in enumerate(cases):
            with self.subTest(case=number):
                document = copy.deepcopy(self.document)
                document["model"]["tables"][0]["annotations"] = annotations
                folder = self.root / f"annotation-invalid-{number}"
                with self.assertRaises(ValueError):
                    sample_tmdl.serialize(document, folder)
                self.assertFalse(folder.exists())

    def test_duplicate_and_unsupported_annotation_syntax(self):
        cases = [
            "\tannotation A = x\n\tannotation A = y\n",
            "\tannotation 'Quoted_Name' = x\n",
            "\tannotation A =\n",
            "\tannotation A = \n",
            "\tannotation A: x\n",
            "\tannotation A\n\t\tvalue: x\n",
            "\tannotation A = x\n\t\tlineageTag: unsupported\n",
            "\tannotation A = x\n\t\tannotation Nested = unsupported\n",
            "\t/// unsupported annotation description\n\tannotation A = x\n",
            "annotation Root = unsupported\n",
        ]
        for text in cases:
            with self.subTest(text=text):
                folder = self.write()
                path = folder / "tables" / "Lakehouse_Plants.tmdl"
                with path.open("a", encoding="utf-8") as stream:
                    stream.write(text)
                with self.assertRaises(ValueError):
                    sample_tmdl.deserialize(folder)
        folder = self.write()
        self.change(folder, "tables/Lakehouse_Plants.tmdl", "\t\t\texpressionSource: Lakehouse_Source",
                    "\t\t\texpressionSource: Lakehouse_Source\n\t\t\tannotation Source = unsupported")
        with self.assertRaises(ValueError):
            sample_tmdl.deserialize(folder)

    def test_no_sdk_process_network_or_auth_dependency(self):
        tree = ast.parse(Path(sample_tmdl.__file__).read_text(encoding="utf-8"))
        imports = {alias.name.split(".")[0] for node in ast.walk(tree) if isinstance(node, ast.Import)
                   for alias in node.names}
        imports.update(node.module.split(".")[0] for node in ast.walk(tree) if isinstance(node, ast.ImportFrom))
        self.assertLessEqual(imports, {"re", "dataclasses", "pathlib"})
        with patch("subprocess.Popen", side_effect=AssertionError("no subprocess")), \
                patch("socket.socket", side_effect=AssertionError("no network")):
            verify_definition(self.document, normalize_tom_defaults(sample_tmdl.deserialize(self.write())))


if __name__ == "__main__":
    unittest.main()
