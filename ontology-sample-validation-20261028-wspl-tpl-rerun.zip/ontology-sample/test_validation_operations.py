import copy
import json
import tempfile
import time
import unittest
from contextlib import nullcontext
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

import validation_operations as adapter
from validate_sample import catalog, execute_scenarios, main, select_scenarios
from validation_common import HttpFailure, InvalidResponse, ScenarioBlocked
from validation_operations import SCENARIOS
from validation_setup import prerequisites


WORKSPACE = "10000000-0000-0000-0000-000000000001"
ONTOLOGY = "10000000-0000-0000-0000-000000000002"
AGENT = "10000000-0000-0000-0000-000000000003"
CAPACITY = "10000000-0000-0000-0000-000000000004"
PLAYBOOK = "10000000-0000-0000-0000-000000000005"
HOST = "test-daily.pbidedicated.windows.net"


def playbook(case="lakehouse"):
    dimensions, readings = adapter.GROUPS[case]
    return {
        "ontology": f"### Entity: `{readings}_Readings`\n#### Properties\n- TemperatureC",
        "rules": f"""<details>
  <summary><strong>Hot readings</strong>: Historical temperature check</summary>

  ```gql
  MATCH (r:{readings}_Readings), (a:{dimensions}_Assets), (p:{dimensions}_Plants)
  WHERE r.AssetId = a.AssetId AND a.PlantId = p.PlantId
  RETURN r.ReadingId, r.TemperatureC, a.AssetId, p.PlantId
  ```

  | Property | Condition | Value |
  |----------|-----------|-------|
  | TemperatureC | Is Above | 32.5 |
</details>
""",
    }


class FakeContext:
    def __init__(self, case="lakehouse"):
        self.config = {"workspace_id": WORKSPACE, "ontology_id": ONTOLOGY,
                       "target_network": "public", "allow_create": True, "poll_seconds": 1}
        self.fabric = SimpleNamespace(base="https://api.fabric.microsoft.com/v1")
        self.api = SimpleNamespace(base="https://" + HOST)
        self.scenario = "operations." + case
        self.state = {}
        self.deadline = time.monotonic() + 1800
        self.calls = []
        self.saved = {}
        self.saved_by_scenario = {}
        self.statuses = [{"state": "Completed"}]
        self.agent_states = ["Unconfigured", "Inactive"]
        self.preview = playbook(case)
        self.generate_result = {"id": PLAYBOOK}
        self.creation_error = None
        self.creation_result = {"id": AGENT}
        self.generation_error = None
        self.status_error = None
        self.state_error = None
        self.preview_error = None

    def next_preview(self, case, index=2):
        self.scenario = "operations." + case
        self.agent_states = ["Unconfigured", "Inactive"]
        self.statuses = [{"state": "Completed"}]
        self.preview = playbook(case)
        self.generate_result = {"id": f"20000000-0000-0000-0000-{index:012d}"}
        self.generation_error = self.status_error = self.state_error = self.preview_error = None

    def save_evidence(self, label, value):
        self.saved[label] = json.loads(json.dumps(value))
        self.saved_by_scenario.setdefault(self.scenario, {})[label] = copy.deepcopy(self.saved[label])

    def mutate(self, api, path, body):
        self.calls.append(("CREATE", path, body, self.deadline))
        if self.creation_error:
            raise self.creation_error
        return self.creation_result

    def request(self, api, method, path, body=None, params=None):
        self.calls.append((method, path, body, self.deadline))
        if path.endswith("/workspaces/" + WORKSPACE):
            return {"capacityId": CAPACITY}
        if path.endswith("/items/" + ONTOLOGY):
            return {"id": ONTOLOGY, "type": "Ontology", "displayName": "Sample ontology"}
        if path.endswith("/settings"):
            if self.state_error and len(self.agent_states) == 1:
                raise self.state_error
            return {"agentState": self.agent_states.pop(0)}
        if path.endswith("/behaviorModel") and method == "POST":
            if self.generation_error:
                raise self.generation_error
            return self.generate_result
        if path.endswith("/status"):
            if self.status_error:
                raise self.status_error
            return self.statuses.pop(0)
        if "/behaviorModel/" in path:
            if self.preview_error:
                raise self.preview_error
            return self.preview
        raise AssertionError(f"Unexpected request: {method} {path}")


def run_case(ctx, case="lakehouse"):
    with patch.object(adapter, "operations_context", return_value=nullcontext(ctx.api)):
        return adapter.authoring(ctx, case)


class OperationsScopeTests(unittest.TestCase):
    def test_runtime_is_not_tested_and_never_uses_context(self):
        context = Mock()
        result = SCENARIOS["operations.runtime"](context)
        self.assertEqual(result["status"], "SKIP")
        self.assertFalse(result["evidence"]["runtimeValidated"])
        self.assertFalse(result["evidence"]["activated"])
        self.assertEqual(context.mock_calls, [])
        self.assertEqual(prerequisites({}, {"operations.runtime"}), {})
        self.assertNotIn("operations.native-import", catalog())

    def test_old_report_migrates_retired_alm_case_without_running_it(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "results.json"
            path.write_text(json.dumps({"results": [
                {"scenario": "operations.native-import", "selected": True, "status": "FAIL"},
                {"scenario": "data-agent.lakehouse", "selected": True, "status": "FAIL"},
            ]}))
            self.assertEqual(select_scenarios(catalog(), previous=path),
                             {"operations.runtime", "data-agent.lakehouse"})

    def test_runtime_only_run_skips_without_auth_or_creation(self):
        with tempfile.TemporaryDirectory() as temporary, \
                patch("azure.identity.AzureCliCredential") as auth, \
                patch("validate_sample.ValidationContext") as context:
            root = Path(temporary)
            path = root / "config.json"
            path.write_text(json.dumps({
                "tenant_id": "11111111-1111-1111-1111-111111111111",
                "workspace_id": "22222222-2222-2222-2222-222222222222",
                "ontology_id": "33333333-3333-3333-3333-333333333333",
                "target_network": "public",
            }))
            self.assertEqual(main(["--config", str(path), "--scenarios", "operations.runtime",
                                   "--allow-create", "--output", str(root / "out")]), 0)
            auth.assert_not_called()
            context.assert_not_called()
            report = json.loads((root / "out" / "results.json").read_text())
            selected = [row for row in report["results"] if row["selected"]]
            self.assertEqual(len(selected), 1)
            self.assertEqual(selected[0]["status"], "SKIP")
            self.assertEqual(report["resources"], {})

    def test_authoring_suite_contains_ten_cases_and_separate_runtime(self):
        self.assertEqual(set(SCENARIOS), {f"operations.{case}" for case in adapter.GROUPS}
                         | {"operations.runtime"})


class PlaybookTests(unittest.TestCase):
    def test_all_ten_source_selections_have_static_contract_coverage(self):
        for case in adapter.GROUPS:
            with self.subTest(case=case):
                result = adapter.assess_playbook(playbook(case), case)
                self.assertEqual(result["status"], "PASS")
                self.assertFalse(result["queryExecuted"])

    def test_prose_without_inspectable_query_is_not_a_pass(self):
        result = adapter.assess_playbook({"ontology": "concepts", "rules": "- Hot asset: TemperatureC > 32.5"}, "lakehouse")
        self.assertEqual(result["status"], "UNVERIFIED")

    def test_empty_or_malformed_payload_is_explicit_error(self):
        for payload in (None, {}, {"ontology": [], "rules": "x"}, {"ontology": "x", "rules": None}):
            with self.subTest(payload=payload), self.assertRaises(InvalidResponse):
                adapter.assess_playbook(payload, "lakehouse")

    def test_wrong_threshold_or_non_strict_condition_fails(self):
        for old, new in (("32.5", "30"), ("Is Above", "Is Above Or Equal"), ("TemperatureC |", "AssetId |")):
            value = playbook()
            value["rules"] = value["rules"].replace(old, new)
            self.assertEqual(adapter.assess_playbook(value, "lakehouse")["status"], "FAIL")

    def test_equivalent_numeric_threshold_is_accepted(self):
        for number in ("32.500", "3.25E1"):
            value = playbook()
            value["rules"] = value["rules"].replace("32.5", number)
            self.assertEqual(adapter.assess_playbook(value, "lakehouse")["status"], "PASS")

    def test_equivalent_celsius_property_name_is_accepted(self):
        for language in ("gql", "kql", "kqldataquery"):
            value = playbook()
            value["ontology"] = value["ontology"].replace("TemperatureC", "TemperatureCelsius")
            value["rules"] = value["rules"].replace("TemperatureC", "TemperatureCelsius")
            value["rules"] = value["rules"].replace("```gql", "```" + language)
            result = adapter.assess_playbook(value, "lakehouse")
            self.assertEqual(result["status"], "PASS")
            self.assertEqual(result["temperatureProperty"], "TemperatureCelsius")
            self.assertFalse(result["queryExecuted"])

    def test_gql_celsius_projection_alias_is_accepted(self):
        value = playbook()
        value["rules"] = value["rules"].replace("r.TemperatureC,", "r.TemperatureC AS TemperatureCelsius,")
        value["rules"] = value["rules"].replace("| TemperatureC |", "| TemperatureCelsius |")
        result = adapter.assess_playbook(value, "lakehouse")
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["temperatureRenameSources"], ["TemperatureC"])

    def test_kql_celsius_projection_alias_is_accepted(self):
        value = playbook()
        start, rest = value["rules"].split("```gql", 1)
        _, end = rest.split("```", 1)
        value["rules"] = (start + "```kql\nReadings | project ReadingId, "
                          "TemperatureCelsius = TemperatureC, AssetId, PlantId\n```" + end)
        value["rules"] = value["rules"].replace("| TemperatureC |", "| TemperatureCelsius |")
        result = adapter.assess_playbook(value, "lakehouse")
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["temperatureRenameSources"], ["TemperatureC"])

    def test_celsius_condition_without_query_property_is_not_a_pass(self):
        value = playbook()
        value["rules"] = value["rules"].replace("| TemperatureC |", "| TemperatureCelsius |")
        result = adapter.assess_playbook(value, "lakehouse")
        self.assertEqual(result["status"], "UNVERIFIED")
        self.assertIn("TemperatureCelsius", result["missingProperties"])

    def test_numeric_celsius_cast_and_timestamp_fallback_are_accepted(self):
        for cast in ("todouble", "toreal"):
            for source, expected in (("TemperatureC", "PASS"), ("TemperatureF", "FAIL")):
                value = playbook()
                start, rest = value["rules"].split("```gql", 1)
                _, end = rest.split("```", 1)
                value["rules"] = (start + "```kqldataquery\nReadings\n"
                                  "| where ObservedAt between (startTime .. endTime)\n"
                                  f"| project ReadingId, TemperatureCelsius = {cast}({source}), "
                                  "AssetId, PlantId, Timestamp = coalesce(ObservedAt, now())\n```" + end)
                value["rules"] = value["rules"].replace("| TemperatureC |", "| TemperatureCelsius |")
                result = adapter.assess_playbook(value, "lakehouse")
                self.assertEqual(result["status"], expected)
                self.assertEqual(result["temperatureRenameSources"], [source])

    def test_timestamp_fallback_is_not_a_relative_time_filter(self):
        value = playbook()
        start, rest = value["rules"].split("```gql", 1)
        _, end = rest.split("```", 1)
        value["rules"] = (start + "```kql\nReadings | where TemperatureC > 32.5\n"
                          "| extend Timestamp = coalesce(ObservedAt, now())\n"
                          "| project ReadingId, TemperatureC, AssetId, PlantId, Timestamp\n```" + end)
        self.assertEqual(adapter.assess_playbook(value, "lakehouse")["status"], "PASS")

    def test_relative_time_filter_still_requires_review(self):
        for predicate in ("r.ObservedAt > ago(1h)", "r.ObservedAt >= now()"):
            value = playbook()
            value["rules"] = value["rules"].replace("WHERE ", f"WHERE {predicate} AND ")
            result = adapter.assess_playbook(value, "lakehouse")
            self.assertEqual(result["status"], "UNVERIFIED")
            self.assertIn("Relative-time filters", result["reason"])

    def test_join_keys_not_returned_are_not_counted_as_output(self):
        value = playbook()
        value["rules"] = value["rules"].replace(", a.AssetId, p.PlantId", "")
        result = adapter.assess_playbook(value, "lakehouse")
        self.assertEqual(result["status"], "UNVERIFIED")
        self.assertEqual(result["missingProperties"], ["AssetId", "PlantId"])

    def test_last_kql_projection_must_retain_requested_fields(self):
        value = playbook()
        start, rest = value["rules"].split("```gql", 1)
        _, end = rest.split("```", 1)
        value["rules"] = (start + "```kql\nReadings | project Id = ReadingId, "
                          "TemperatureCelsius = todouble(TemperatureC), AssetId, PlantId\n"
                          "| project Id, TemperatureCelsius\n```" + end)
        value["rules"] = value["rules"].replace("| TemperatureC |", "| TemperatureCelsius |")
        result = adapter.assess_playbook(value, "lakehouse")
        self.assertEqual(result["status"], "UNVERIFIED")
        self.assertEqual(result["missingProperties"], ["AssetId", "PlantId"])
        value["rules"] = value["rules"].replace("| project Id, TemperatureCelsius\n",
                                               "| project Id, TemperatureCelsius, AssetId, PlantId\n")
        self.assertEqual(adapter.assess_playbook(value, "lakehouse")["status"], "PASS")

    def test_non_celsius_property_and_misleading_renames_fail(self):
        value = playbook()
        value["rules"] = value["rules"].replace("TemperatureC", "TemperatureF")
        self.assertEqual(adapter.assess_playbook(value, "lakehouse")["status"], "FAIL")
        for source in ("TemperatureF", "AssetId"):
            value = playbook()
            value["rules"] = value["rules"].replace("r.TemperatureC,", f"r.{source} AS TemperatureCelsius,")
            value["rules"] = value["rules"].replace("| TemperatureC |", "| TemperatureCelsius |")
            self.assertEqual(adapter.assess_playbook(value, "lakehouse")["status"], "FAIL")
            start, rest = value["rules"].split("```gql", 1)
            _, end = rest.split("```", 1)
            value["rules"] = (start + f"```kql\nReadings | project ReadingId, "
                              f"TemperatureCelsius = {source}, AssetId, PlantId\n```" + end)
            self.assertEqual(adapter.assess_playbook(value, "lakehouse")["status"], "FAIL")

    def test_wrong_source_group_fails(self):
        value = playbook()
        value["rules"] = value["rules"].replace("Lakehouse_Readings", "Warehouse_Readings")
        self.assertEqual(adapter.assess_playbook(value, "lakehouse")["status"], "FAIL")

    def test_entity_mentions_in_comments_or_literals_cannot_supply_scope(self):
        for replacement in ("Unknown /* (r:Lakehouse_Readings) */",
                            "Unknown // (r:Lakehouse_Readings)\n",
                            "Unknown {text: '(r:Lakehouse_Readings)'}"):
            value = playbook()
            value["rules"] = value["rules"].replace("Lakehouse_Readings", replacement)
            self.assertNotEqual(adapter.assess_playbook(value, "lakehouse")["status"], "PASS")

    def test_missing_properties_empty_concepts_or_query_are_not_passes(self):
        for old, new in (("r.TemperatureC", "r.OtherValue"), ("```gql", "```text"),
                         ("RETURN", "YIELD"), ("Lakehouse_Plants", "")):
            value = playbook()
            value["rules"] = value["rules"].replace(old, new)
            self.assertNotEqual(adapter.assess_playbook(value, "lakehouse")["status"], "PASS")
        value = playbook()
        value["ontology"] = ""
        self.assertEqual(adapter.assess_playbook(value, "lakehouse")["status"], "UNVERIFIED")

    def test_more_than_one_rule_fails(self):
        value = playbook()
        value["rules"] *= 2
        self.assertEqual(adapter.assess_playbook(value, "lakehouse")["status"], "FAIL")

    def test_native_kql_is_retained_without_claiming_unproven_source_bindings(self):
        for language in ("kql", "kqldataquery"):
            value = playbook()
            value["rules"] = value["rules"].replace("```gql", "```" + language)
            result = adapter.assess_playbook(value, "lakehouse")
            self.assertEqual(result["status"], "PASS")
            self.assertEqual(result["queryLanguage"], language)
            self.assertIn("query", result)
            self.assertFalse(result["sourceEvidenceRequired"])
            self.assertFalse(result["queryExecuted"])

    def test_missing_entity_labels_are_informational(self):
        value = playbook()
        for label in ("Lakehouse_Readings", "Lakehouse_Assets", "Lakehouse_Plants"):
            value["rules"] = value["rules"].replace(":" + label, "")
        result = adapter.assess_playbook(value, "lakehouse")
        self.assertEqual(result["status"], "PASS")
        self.assertFalse(result["sourceEvidenceVerified"])

    def test_native_kql_missing_requested_fields_remains_incomplete(self):
        value = playbook()
        start, rest = value["rules"].split("```gql", 1)
        _, end = rest.split("```", 1)
        value["rules"] = start + "```kql\nReadings | project ReadingId, TemperatureC\n```" + end
        result = adapter.assess_playbook(value, "lakehouse")
        self.assertEqual(result["status"], "UNVERIFIED")
        self.assertIn("properties", result["reason"])

    def test_native_kql_complete_properties_pass_without_binding_proof(self):
        value = playbook()
        start, rest = value["rules"].split("```gql", 1)
        _, end = rest.split("```", 1)
        value["rules"] = start + "```kql\nReadings | project ReadingId, TemperatureC, AssetId, PlantId\n```" + end
        result = adapter.assess_playbook(value, "lakehouse")
        self.assertEqual(result["status"], "PASS")
        self.assertFalse(result["sourceEvidenceVerified"])

    def test_native_kql_explicit_wrong_source_still_fails(self):
        value = playbook()
        start, rest = value["rules"].split("```gql", 1)
        _, end = rest.split("```", 1)
        value["rules"] = start + "```kql\nWarehouse_Readings | project ReadingId, TemperatureC, AssetId, PlantId\n```" + end
        self.assertEqual(adapter.assess_playbook(value, "lakehouse")["status"], "FAIL")

    def test_mutation_query_is_not_accepted(self):
        value = playbook()
        value["rules"] = value["rules"].replace("RETURN", "DELETE r RETURN")
        self.assertEqual(adapter.assess_playbook(value, "lakehouse")["status"], "FAIL")


class AuthoringTests(unittest.TestCase):
    def test_each_single_case_run_creates_one_agent_and_never_activates(self):
        for case in adapter.GROUPS:
            with self.subTest(case=case):
                ctx = FakeContext(case)
                original_deadline = ctx.deadline
                result = run_case(ctx, case)
                self.assertEqual(result["status"], "PASS")
                self.assertTrue(result["evidence"]["inactiveVerified"])
                self.assertFalse(result["evidence"]["queryExecuted"])
                self.assertFalse(result["evidence"]["runtimeValidated"])
                self.assertEqual(ctx.state["operations_agents"][ctx.scenario], AGENT)
                self.assertEqual(ctx.state["operations_playbooks"][ctx.scenario], PLAYBOOK)
                writes = [call for call in ctx.calls if call[0] != "GET"]
                self.assertEqual([call[0] for call in writes], ["CREATE", "POST"])
                self.assertTrue(writes[0][1].endswith("/operationsAgents"))
                self.assertTrue(writes[1][1].endswith("/configuration/behaviorModel"))
                self.assertEqual(writes[1][2]["actions"], {})
                self.assertEqual(writes[1][2]["dataSources"]["businessOntology"]["id"], ONTOLOGY)
                self.assertEqual(writes[1][2]["dataSources"]["businessOntology"]["displayName"], "Sample ontology")
                self.assertEqual(writes[1][2]["dataSources"]["businessOntology"]["connection"], {"tableName": ""})
                self.assertNotIn("definition", writes[0][2])
                self.assertLess(writes[1][3], original_deadline)
                self.assertEqual(ctx.deadline, original_deadline)
                self.assertEqual(ctx.calls[-1][3], original_deadline)

    def test_ten_cases_share_one_agent_with_independent_preview_ids_and_inputs(self):
        ctx = FakeContext()
        results = []
        for index, case in enumerate(adapter.GROUPS, 1):
            ctx.next_preview(case, index)
            results.append(run_case(ctx, case))
        self.assertTrue(all(result["status"] == "PASS" for result in results))
        self.assertEqual(sum(result["evidence"]["created"] for result in results), 1)
        self.assertEqual(len(ctx.state["operations_agents"]), 10)
        self.assertEqual(set(ctx.state["operations_agents"].values()), {AGENT})
        self.assertEqual(len(set(ctx.state["operations_playbooks"].values())), 10)
        self.assertEqual(sum(call[0] == "CREATE" for call in ctx.calls), 1)
        posts = [call for call in ctx.calls if call[0] == "POST"]
        self.assertEqual(len(posts), 10)
        self.assertEqual(len({call[2]["instructions"] for call in posts}), 10)
        self.assertTrue(all(call[1].endswith(f"/{AGENT}/configuration/behaviorModel") for call in posts))
        self.assertTrue(all(call[2]["actions"] == {} for call in posts))
        self.assertEqual(sum(call[1].endswith("/settings") for call in ctx.calls), 20)
        self.assertTrue(all(call[0] in ("GET", "POST", "CREATE") for call in ctx.calls))
        for case in adapter.GROUPS:
            name = "operations." + case
            preview = ctx.state["operations_previews"][name]
            self.assertEqual(preview["state"], "Completed")
            self.assertTrue(preview["terminalConfirmed"])
            self.assertEqual(preview["playbookId"], ctx.state["operations_playbooks"][name])
            self.assertEqual(ctx.saved_by_scenario[name]["operations-playbook"], playbook(case))

    def test_new_context_creates_fresh_agent_even_with_copied_prior_resource_mappings(self):
        first = FakeContext()
        self.assertEqual(run_case(first)["status"], "PASS")
        second = FakeContext()
        second.state = copy.deepcopy(first.state)
        second.creation_result = {"id": "30000000-0000-0000-0000-000000000001"}
        self.assertEqual(run_case(second)["status"], "PASS")
        self.assertEqual(sum(call[0] == "CREATE" for call in second.calls), 1)
        self.assertNotEqual(first.state["operations_shared"]["agentId"],
                            second.state["operations_shared"]["agentId"])
        self.assertNotEqual(first.state["operations_shared"]["displayName"],
                            second.state["operations_shared"]["displayName"])

    def test_target_identity_cannot_change_mid_run(self):
        for key in ("workspace_id", "ontology_id"):
            with self.subTest(key=key):
                ctx = FakeContext()
                self.assertEqual(run_case(ctx)["status"], "PASS")
                calls = len(ctx.calls)
                ctx.next_preview("kql")
                ctx.config[key] = "30000000-0000-0000-0000-000000000001"
                self.assertEqual(run_case(ctx, "kql")["status"], "BLOCKED")
                self.assertEqual(len(ctx.calls), calls)

    def test_duplicate_scenario_does_not_replay_generation(self):
        ctx = FakeContext()
        self.assertEqual(run_case(ctx)["status"], "PASS")
        calls = len(ctx.calls)
        self.assertEqual(run_case(ctx)["status"], "BLOCKED")
        self.assertEqual(len(ctx.calls), calls)

    def test_safety_stop_persists_without_blocking_other_scenario_families(self):
        ctx = FakeContext()
        ctx.generation_error = TimeoutError("Generation POST outcome unknown")
        ctx.requests = []
        ctx.begin = lambda name: setattr(ctx, "scenario", name)
        available = {
            "operations.lakehouse": lambda current: run_case(current),
            "operations.kql": lambda current: run_case(current, "kql"),
            "ontology.definition": lambda _: {"status": "PASS", "summary": "Independent read still runs"},
        }
        report = {"startedUtc": "test", "state": "running", "results": [
            {"scenario": name, "selected": True, "status": "PENDING", "summary": "Pending"}
            for name in available
        ]}
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            execute_scenarios(available, set(available), ctx, report, directory)
            saved = json.loads((directory / "results.json").read_text())
            self.assertEqual([row["status"] for row in saved["results"]], ["TIMEOUT", "BLOCKED", "PASS"])
            self.assertEqual(saved["resources"]["operations_shared"]["agentId"], AGENT)
            preview = saved["resources"]["operations_previews"]["operations.lakehouse"]
            self.assertFalse(preview["terminalConfirmed"])
            self.assertIn("operations_safety_stop", saved["resources"])
            self.assertEqual(len(list(directory.glob("*.result.json"))), 3)
        self.assertEqual(sum(call[0] == "CREATE" for call in ctx.calls), 1)
        self.assertEqual(sum(call[0] == "POST" for call in ctx.calls), 1)

    def test_creation_requires_flag_even_if_existing_id_is_supplied(self):
        ctx = FakeContext()
        ctx.config.update(allow_create=False, operations_agent_id=AGENT)
        result = run_case(ctx)
        self.assertEqual(result["status"], "BLOCKED")
        self.assertEqual(ctx.calls, [])

    def test_private_route_missing_is_blocked_before_creation(self):
        ctx = FakeContext()
        ctx.config["target_network"] = "wspl"
        self.assertEqual(run_case(ctx)["status"], "BLOCKED")
        self.assertEqual(ctx.calls, [])

    def test_creation_timeout_retains_attempt_name_without_retry(self):
        ctx = FakeContext()
        ctx.creation_error = TimeoutError("ambiguous create")
        self.assertEqual(run_case(ctx)["status"], "TIMEOUT")
        self.assertIn(ctx.scenario, ctx.state["operations_creation_attempts"])
        self.assertEqual(ctx.state["operations_agents"], {})
        self.assertEqual(sum(call[0] == "CREATE" for call in ctx.calls), 1)
        calls = len(ctx.calls)
        ctx.creation_error = None
        ctx.next_preview("kql")
        self.assertEqual(run_case(ctx, "kql")["status"], "BLOCKED")
        self.assertEqual(len(ctx.calls), calls)

    def test_malformed_creation_result_never_creates_a_replacement(self):
        for response in (None, {}, {"id": "not-a-guid"}):
            with self.subTest(response=response):
                ctx = FakeContext()
                ctx.creation_result = response
                self.assertEqual(run_case(ctx)["status"], "ERROR")
                calls = len(ctx.calls)
                ctx.creation_result = {"id": AGENT}
                ctx.next_preview("kql")
                self.assertEqual(run_case(ctx, "kql")["status"], "BLOCKED")
                self.assertEqual(len(ctx.calls), calls)

    def test_active_or_unknown_initial_state_blocks_generation(self):
        for state in ("Active", "Starting", None, 0):
            with self.subTest(state=state):
                ctx = FakeContext()
                ctx.agent_states[0] = state
                self.assertEqual(run_case(ctx)["status"], "ERROR")
                self.assertFalse(any(call[0] == "POST" for call in ctx.calls))
                calls = len(ctx.calls)
                ctx.next_preview("kql")
                self.assertEqual(run_case(ctx, "kql")["status"], "BLOCKED")
                self.assertEqual(len(ctx.calls), calls)

    def test_polling_in_progress_is_read_only(self):
        ctx = FakeContext()
        ctx.statuses.insert(0, {"state": "InProgress"})
        with patch.object(adapter.time, "sleep") as sleep:
            result = run_case(ctx)
        self.assertEqual(result["status"], "PASS")
        sleep.assert_called_once()
        self.assertEqual(sum(call[0] == "POST" for call in ctx.calls), 1)

    def test_server_generation_failure_preserves_error_and_checks_state(self):
        ctx = FakeContext()
        ctx.statuses = [{"state": "Failed", "error": "Source policy denied"}]
        result = run_case(ctx)
        self.assertEqual(result["status"], "FAIL")
        self.assertEqual(result["evidence"]["generationStatus"]["error"], "Source policy denied")
        self.assertTrue(result["evidence"]["inactiveVerified"])
        self.assertTrue(ctx.calls[-1][1].endswith("/settings"))

    def test_ambiguous_generation_post_is_not_replayed(self):
        ctx = FakeContext()
        ctx.generation_error = TimeoutError("generation response lost")
        result = run_case(ctx)
        self.assertEqual(result["status"], "TIMEOUT")
        self.assertEqual(sum(call[0] == "POST" for call in ctx.calls), 1)
        self.assertTrue(result["evidence"]["generationPostAttempted"])
        self.assertTrue(result["evidence"]["inactiveVerified"])

    def test_generation_timeout_keeps_model_and_agent(self):
        ctx = FakeContext()
        ctx.status_error = TimeoutError("status timed out")
        result = run_case(ctx)
        self.assertEqual(result["status"], "TIMEOUT")
        self.assertEqual(result["evidence"]["playbookId"], PLAYBOOK)
        self.assertTrue(result["evidence"]["inactiveVerified"])

    def test_generation_poll_deadline_expires_without_replay(self):
        ctx = FakeContext()
        ctx.statuses = [{"state": "InProgress"}]
        with patch.object(adapter.time, "monotonic", side_effect=[100, 100, 101, 1001, 1002]), \
                patch.object(adapter.time, "sleep"):
            result = run_case(ctx)
        self.assertEqual(result["status"], "TIMEOUT")
        self.assertEqual(result["evidence"]["playbookId"], PLAYBOOK)
        self.assertTrue(result["evidence"]["inactiveVerified"])
        self.assertEqual(sum(call[0] == "POST" for call in ctx.calls), 1)
        self.assertIn("operations_safety_stop", ctx.state)

    def test_unknown_status_or_missing_model_id_is_not_success(self):
        for value in (None, {"state": "Succeeded"}, {"state": 0}):
            ctx = FakeContext()
            ctx.statuses = [value]
            self.assertEqual(run_case(ctx)["status"], "ERROR")
        ctx = FakeContext()
        ctx.generate_result = {"id": "../../settings"}
        self.assertEqual(run_case(ctx)["status"], "ERROR")
        self.assertEqual(sum(call[0] == "POST" for call in ctx.calls), 1)

    def test_completed_with_error_is_not_pass(self):
        ctx = FakeContext()
        ctx.statuses = [{"state": "Completed", "error": "Contradictory status"}]
        self.assertEqual(run_case(ctx)["status"], "ERROR")

    def test_failed_after_state_check_never_yields_pass(self):
        ctx = FakeContext()
        ctx.agent_states[-1] = "Active"
        result = run_case(ctx)
        self.assertEqual(result["status"], "ERROR")
        self.assertFalse(result["evidence"]["inactiveVerified"])
        self.assertIn("safetyError", result["evidence"])
        calls = len(ctx.calls)
        self.assertEqual(run_case(ctx)["status"], "BLOCKED")
        self.assertEqual(len(ctx.calls), calls)

    def test_primary_error_not_masked_by_failed_after_check(self):
        ctx = FakeContext()
        ctx.status_error = TimeoutError("primary timeout")
        ctx.state_error = HttpFailure(403, "after-state denied")
        result = run_case(ctx)
        self.assertEqual(result["status"], "TIMEOUT")
        self.assertIn("primary timeout", result["summary"])
        self.assertIn("after-state denied", result["evidence"]["safetyError"]["message"])

    def test_generation_denial_is_failure_not_setup_block(self):
        ctx = FakeContext()
        ctx.generation_error = HttpFailure(403, "generation denied")
        self.assertEqual(run_case(ctx)["status"], "FAIL")

    def test_terminal_failure_or_static_failure_does_not_block_next_preview(self):
        for failure in ("generation", "contract", "readback"):
            with self.subTest(failure=failure):
                ctx = FakeContext()
                if failure == "generation":
                    ctx.statuses = [{"state": "Failed", "error": "Unsupported source"}]
                elif failure == "contract":
                    ctx.preview["rules"] = ctx.preview["rules"].replace("32.5", "30")
                else:
                    ctx.preview_error = HttpFailure(403, "readback denied")
                first = run_case(ctx)
                self.assertEqual(first["status"], "FAIL")
                self.assertTrue(first["evidence"]["previewLifecycle"]["terminalConfirmed"])
                snapshot = copy.deepcopy(first)
                ctx.next_preview("kql")
                self.assertEqual(run_case(ctx, "kql")["status"], "PASS")
                self.assertEqual(first, snapshot)
                self.assertEqual(sum(call[0] == "CREATE" for call in ctx.calls), 1)
                self.assertEqual(sum(call[0] == "POST" for call in ctx.calls), 2)

    def test_uncertain_generation_blocks_every_later_preview_even_when_agent_is_inactive(self):
        for failure in ("post-timeout", "post-denial", "status-timeout", "missing-id",
                        "unknown-status", "contradictory-status"):
            with self.subTest(failure=failure):
                ctx = FakeContext()
                if failure == "post-timeout":
                    ctx.generation_error = TimeoutError("POST outcome unknown")
                elif failure == "post-denial":
                    ctx.generation_error = HttpFailure(403, "No generation ID")
                elif failure == "status-timeout":
                    ctx.status_error = TimeoutError("Still pending")
                elif failure == "missing-id":
                    ctx.generate_result = {}
                elif failure == "unknown-status":
                    ctx.statuses = [{"state": "Unknown"}]
                else:
                    ctx.statuses = [{"state": "Completed", "error": "Contradictory"}]
                first = run_case(ctx)
                self.assertNotEqual(first["status"], "PASS")
                self.assertTrue(first["evidence"]["inactiveVerified"])
                self.assertFalse(first["evidence"]["previewLifecycle"]["terminalConfirmed"])
                self.assertIn("operations_safety_stop", ctx.state)
                calls = len(ctx.calls)
                ctx.next_preview("kql")
                self.assertEqual(run_case(ctx, "kql")["status"], "BLOCKED")
                self.assertEqual(len(ctx.calls), calls)

    def test_duplicate_preview_id_cannot_be_accepted_as_another_scenarios_result(self):
        ctx = FakeContext()
        self.assertEqual(run_case(ctx)["status"], "PASS")
        ctx.next_preview("kql")
        ctx.generate_result = {"id": PLAYBOOK}
        result = run_case(ctx, "kql")
        self.assertEqual(result["status"], "ERROR")
        self.assertIn("Preview ID was reused", result["summary"])
        self.assertEqual(ctx.state["operations_playbooks"], {"operations.lakehouse": PLAYBOOK})
        calls = len(ctx.calls)
        ctx.next_preview("warehouse")
        self.assertEqual(run_case(ctx, "warehouse")["status"], "BLOCKED")
        self.assertEqual(len(ctx.calls), calls)


class RoutingTests(unittest.TestCase):
    def context(self):
        ctx = SimpleNamespace(
            config={"workspace_id": WORKSPACE, "target_network": "wspl",
                    "operations_metadata_api": "https://private-route.analysis.windows.net",
                    "operations_workload_host": HOST},
            credential=Mock(), timeout=30,
            request=Mock(return_value={"Token": "synthetic-token", "TargetUriHost": HOST,
                                       "CapacityObjectId": CAPACITY}))
        return ctx

    def test_oa_contract_and_token_scheme(self):
        ctx = self.context()
        with adapter.operations_context(ctx, AGENT, CAPACITY) as api:
            self.assertIn("/workloads/OA/OAgentsService/automatic", api.base)
            self.assertEqual(api.auth_scheme, "MwcToken")
        call = ctx.request.call_args
        self.assertEqual(call.args[1], "POST")
        self.assertTrue(call.args[2].endswith("/metadata/v201606/generatemwctokenv2"))
        self.assertEqual(call.args[3]["workloadType"], "OA")
        self.assertEqual(call.args[3]["artifacts"], [{"artifactType": "OperationalAgents", "artifactObjectId": AGENT}])
        ctx.credential.get_token.assert_not_called()

    def test_shared_workspace_route_uses_oa_token_and_rejects_host_mismatch(self):
        ctx = self.context()
        ctx.config["ux_metadata_api"] = ctx.config.pop("operations_metadata_api")
        ctx.config["ux_workload_host"] = ctx.config.pop("operations_workload_host")
        with adapter.operations_context(ctx, AGENT, CAPACITY) as api:
            self.assertIn("/workloads/OA/", api.base)
        self.assertEqual(ctx.request.call_args.args[3]["workloadType"], "OA")
        ctx.request.return_value["TargetUriHost"] = "different.pbidedicated.windows.net"
        with self.assertRaises(ScenarioBlocked):
            with adapter.operations_context(ctx, AGENT, CAPACITY):
                self.fail("Shared routing must still enforce the expected host")

    def test_wrong_returned_host_or_capacity_blocks_workload_call(self):
        for key, value in (("TargetUriHost", "public.pbidedicated.windows.net"),
                           ("CapacityObjectId", ONTOLOGY)):
            ctx = self.context()
            ctx.request.return_value[key] = value
            with self.assertRaises(ScenarioBlocked):
                with adapter.operations_context(ctx, AGENT, CAPACITY):
                    self.fail("Host/capacity mismatch must not yield an API")
            self.assertEqual(ctx.request.call_count, 1)

    def test_missing_token_or_invalid_host_never_yields_api(self):
        for key, value in (("Token", ""), ("TargetUriHost", "example.com")):
            ctx = self.context()
            ctx.request.return_value[key] = value
            with self.assertRaises((InvalidResponse, ValueError)):
                with adapter.operations_context(ctx, AGENT, CAPACITY):
                    self.fail("Invalid MWC response must not yield an API")

    def test_v1_not_allowed(self):
        ctx = self.context()
        ctx.config["ux_token_version"] = "v1"
        with self.assertRaises(ScenarioBlocked):
            adapter.operations_routing(ctx.config)


if __name__ == "__main__":
    unittest.main()
