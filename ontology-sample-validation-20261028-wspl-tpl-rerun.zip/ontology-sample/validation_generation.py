"""Opt-in generation on a newly created disposable item, never the configured ontology.

The current UI contract is MutationMode=0/1 with MutationModeExplicit=true in
JSON-string additionalContext["fabricOntology.context"]. Saying "Act" in prose
does not enable mutation. See extension-ontology commit
885a95c42a5606895dcefc8d968bdb7df83a8416, ontologyAgentRepository.ts:410-432.
"""

import hashlib
import json
import math
import re
import struct
from datetime import datetime, timezone
from uuid import UUID, uuid4

from validation_common import ScenarioBlocked
from validation_queries import EXPECTED

EXPECTED_FIELDS = (
    "PlantCount", "AssetCount", "ReadingCount", "ReadingId", "AssetId",
    "ObservedAt", "TemperatureC", "PlantId", "PlantName", "City",
)
SOURCE_TABLES = {"Plants", "Assets", "Readings"}
MAX_TURNS = 7  # plan, reject, approve, optional additive repair, query, cancel (+ one spare)
SOURCE_SQL = """WITH Counts AS (
 SELECT (SELECT COUNT_BIG(*) FROM dbo.Plants) AS PlantCount,
        (SELECT COUNT_BIG(*) FROM dbo.Assets) AS AssetCount,
        (SELECT COUNT_BIG(*) FROM dbo.Readings) AS ReadingCount
), TopReading AS (
 SELECT TOP (1) r.ReadingId, r.AssetId, r.ObservedAt, r.TemperatureC,
        a.PlantId, p.Name AS PlantName, p.City
 FROM dbo.Readings AS r
 INNER JOIN dbo.Assets AS a ON a.AssetId = r.AssetId
 INNER JOIN dbo.Plants AS p ON p.PlantId = a.PlantId
 ORDER BY r.TemperatureC DESC, r.ObservedAt DESC, r.ReadingId ASC, r.AssetId ASC
)
SELECT c.PlantCount, c.AssetCount, c.ReadingCount, t.ReadingId, t.AssetId,
       t.ObservedAt, t.TemperatureC, t.PlantId, t.PlantName, t.City
FROM Counts AS c CROSS JOIN TopReading AS t;"""


def _context(workspace, item, mode):
    return {"fabricOntology.context": json.dumps({
        "Intent": "", "WorkspaceId": workspace, "OntologyId": item,
        "CurrentOntologyVersion": "", "SelectedSources": [], "UploadedArtifacts": [],
        "MutationMode": mode, "MutationModeExplicit": True, "RequestedChangeScope": "",
    })}


def _normalized(value):
    """Drop response-only resolver annotations, not authored bindings or model fields."""
    if isinstance(value, dict):
        return {key: _normalized(child) for key, child in value.items()}
    if isinstance(value, list):
        return [_normalized(child) for child in value if not (
            isinstance(child, dict) and str(child.get("name", "")).startswith("ONT_RESOLVED_"))]
    return value


def _hash(value):
    return hashlib.sha256(json.dumps(_normalized(value), sort_keys=True,
                                     separators=(",", ":")).encode()).hexdigest()


def _model(document):
    if not isinstance(document, dict) or not isinstance(document.get("model"), dict):
        raise ValueError("Definition response must contain a model object")
    return document["model"]


def _empty(document):
    for key, value in _model(document).items():
        if key == "namespaces":
            if any(entry.get("name") != "default" for entry in value):
                return False
        elif value:
            return False
    return True


def _annotations(partition):
    return {entry["name"]: entry.get("value") for entry in partition.get("annotations", [])
            if isinstance(entry, dict) and "name" in entry}


def _bindings(document, workspace, source_id):
    model = _model(document)
    if len(model.get("entities", [])) < 2 or not model.get("entityRelationships"):
        raise ValueError("Generated definition lacks entities or the required logical relationship")
    if any(not entity.get("keyProperties") for entity in model["entities"]):
        raise ValueError("Generated entity is missing its key")
    observed, table_sources, warnings, columns = set(), {}, [], {}
    expressions = {entry.get("name"): entry.get("expression") for entry in model.get("expressions", [])}
    for table in model.get("tables", []):
        for partition in table.get("partitions", []):
            source = partition.get("source", {})
            annotations = _annotations(partition)
            table_name = source.get("entityName")
            if table_name not in SOURCE_TABLES or source.get("schemaName") != "dbo":
                raise ValueError("Generated binding does not target an approved dbo fixture table")
            # A resolved identifier alone is not proof of the authored binding.
            if annotations.get("ONT_ItemId") != source_id or annotations.get("ONT_WorkspaceId") != workspace:
                raise ValueError("Actual authored source/workspace binding mismatch")
            if annotations.get("ONT_ItemKind") != "Lakehouse":
                raise ValueError("Generated binding changed the approved source kind")
            expression = expressions.get(source.get("expressionSource"))
            expression = "\n".join(expression) if isinstance(expression, list) else expression
            if not isinstance(expression, str) or not re.search(
                    r"/" + re.escape(workspace) + "/" + re.escape(source_id) + r'(?=["/])',
                    expression, re.IGNORECASE):
                raise ValueError("Backing expression does not identify the approved workspace/Lakehouse")
            observed.add(table_name)
            table_sources[table["name"]] = table_name
            columns[table["name"]] = {column.get("name"): column.get("sourceColumn")
                                      for column in table.get("columns", [])}
            state = annotations.get("ONT_RESOLVED_State")
            if state and state != "Resolved":
                warnings.append({"table": table["name"], "state": state,
                                 "details": {k: v for k, v in annotations.items()
                                             if k.startswith("ONT_RESOLVED_")}})
    if observed != SOURCE_TABLES:
        raise ValueError("Generated definition did not bind all three approved source tables")
    for pair, key in (({"Plants", "Assets"}, "PlantId"), ({"Assets", "Readings"}, "AssetId")):
        if not any({table_sources.get(rel.get("fromTable")), table_sources.get(rel.get("toTable"))} == pair
                   and rel.get("fromColumn") == key and rel.get("toColumn") == key
                   for rel in model.get("relationships", [])):
            raise ValueError("Generated model lacks the required source-key relationship")
    reading_id = False
    for entity in model["entities"]:
        for prop in entity.get("properties", []):
            column = prop.get("backingConfiguration", {}).get("valueColumn", {})
            if (column.get("column") == "ReadingId" and table_sources.get(column.get("table")) == "Readings"
                    and columns.get(column["table"], {}).get("ReadingId") == "ReadingId"):
                reading_id = True
    return {"sourceTables": sorted(observed), "readingIdBound": reading_id,
            "resolverWarnings": warnings, "entityCount": len(model["entities"]),
            "tableCount": len(model.get("tables", [])),
            "entityRelationshipCount": len(model["entityRelationships"])}


def _preserved(before, after):
    """An additive fidelity repair must not drop existing objects, properties or keys."""
    old, new = _model(before), _model(after)
    for collection in ("entities", "tables", "relationships", "entityRelationships"):
        old_names = {item["name"] for item in old.get(collection, [])}
        new_names = {item["name"] for item in new.get(collection, [])}
        if not old_names <= new_names:
            raise ValueError(f"Fidelity repair removed existing {collection}")
    for previous in old["entities"]:
        current = next(item for item in new["entities"] if item["name"] == previous["name"])
        if current.get("keyProperties") != previous.get("keyProperties"):
            raise ValueError("Fidelity repair changed an existing entity key")
        if current.get("backingTable") != previous.get("backingTable"):
            raise ValueError("Fidelity repair changed an existing entity backing table")
        if not {p["name"] for p in previous.get("properties", [])} <= {
                p["name"] for p in current.get("properties", [])}:
            raise ValueError("Fidelity repair removed an existing property")
        properties = {prop["name"]: prop for prop in current.get("properties", [])}
        for prop in previous.get("properties", []):
            old_column = prop.get("backingConfiguration", {}).get("valueColumn")
            new_column = properties[prop["name"]].get("backingConfiguration", {}).get("valueColumn")
            if old_column != new_column:
                raise ValueError("Fidelity repair changed an existing property value binding")
    for collection in ("relationships", "entityRelationships"):
        current = {item["name"]: _normalized(item) for item in new.get(collection, [])}
        if any(current[item["name"]] != _normalized(item) for item in old.get(collection, [])):
            raise ValueError("Fidelity repair changed an existing relationship")


def _assistant(messages):
    entries = messages if isinstance(messages, list) else (
        messages.get("messages", messages.get("value", [])) if isinstance(messages, dict) else [])
    entries = [entry for entry in entries if isinstance(entry, dict) and entry.get("role") == "assistant"]
    if not entries:
        return "", []
    entry = entries[-1]
    text = "\n".join(part["text"] for part in entry.get("contents", [])
                     if part.get("$type") == "text" and isinstance(part.get("text"), str))
    calls = entry.get("additionalProperties", {}).get("tool_calls", [])
    return text, calls if isinstance(calls, list) else []


def _success(calls, name):
    return any(call.get("tool_name") == name and isinstance(call.get("success_count"), int)
               and call["success_count"] > 0 and not call.get("failure_count") for call in calls)


def _answer(text):
    decoder = json.JSONDecoder()
    answer = None
    for offset, char in enumerate(text):
        if char == "{":
            try:
                value, _ = decoder.raw_decode(text[offset:])
            except ValueError:
                continue
            if isinstance(value, dict) and set(EXPECTED_FIELDS) <= value.keys():
                answer = {key: value[key] for key in EXPECTED_FIELDS}
    return answer


def _row(value):
    result = {key: value[key] for key in EXPECTED_FIELDS}
    for key in ("PlantCount", "AssetCount", "ReadingCount"):
        if type(result[key]) is not int or result[key] < 0:
            raise ValueError("Counts must be nonnegative integers, not strings or booleans")
    if type(result["TemperatureC"]) not in (int, float) or not math.isfinite(result["TemperatureC"]):
        raise ValueError("TemperatureC must be a finite number")
    timestamp = result["ObservedAt"]
    if isinstance(timestamp, str):
        timestamp = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
    if not isinstance(timestamp, datetime):
        raise ValueError("ObservedAt must be an ISO timestamp")
    # The sample's SQL datetime2 column is UTC without an attached offset.
    timestamp = timestamp.replace(tzinfo=timezone.utc) if timestamp.tzinfo is None else timestamp
    result["ObservedAt"] = timestamp.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
    return result


def _read_source_rows(ctx, source):
    """Independent data evidence, not agent prose or Kusto/backend telemetry."""
    try:
        import pyodbc
    except ImportError as error:
        raise ScenarioBlocked("Independent SQL proof needs pyodbc and ODBC Driver 18") from error
    server, catalog = source["server"], source["catalog"]
    token = ctx.credential.get_token("https://database.windows.net/.default").token.encode("utf-16-le")
    attribute = struct.pack("<I", len(token)) + token

    def quoted(value):
        return "{" + value.replace("}", "}}") + "}"

    connection = pyodbc.connect(
        f"DRIVER={{ODBC Driver 18 for SQL Server}};SERVER={quoted(server)};"
        f"DATABASE={quoted(catalog)};Encrypt=yes;TrustServerCertificate=no;",
        attrs_before={1256: attribute}, timeout=max(1, min(30, int(ctx.timeout))))
    try:
        connection.timeout = max(1, min(90, int(ctx.timeout)))
        cursor = connection.cursor()
        cursor.execute(SOURCE_SQL)
        names = [entry[0] for entry in cursor.description]
        rows = [dict(zip(names, row)) for row in cursor.fetchall()]
        if len(rows) != 1:
            raise ScenarioBlocked("Source fixtures do not have a joined measurement row")
        return {"rows": [_row(rows[0])], "sql": SOURCE_SQL, "server": server, "catalog": catalog,
                "proof": "Independently executed read-only SQL against the verified bound Lakehouse",
                "agentEngineExecutionVerified": False, "networkEnforcementVerified": False}
    finally:
        connection.close()


class _Run:
    def __init__(self, ctx):
        self.ctx = ctx
        self.evidence = {"stages": {}, "turns": [], "snapshots": [], "networkEnforcementVerified": False,
                         "applyRaceCancellation": "NOT RUN", "requestsBound": {"create": 1, "turns": MAX_TURNS}}
        self.stage = "prerequisites"
        self.path = None
        self.item = None
        self.active = False

    def save(self):
        self.ctx.save_evidence("generation", self.evidence)

    def snapshot(self, api, label):
        value = self.ctx.request(api, "GET", self.base + "/definition", params={"expand": "true"})
        _model(value)
        record = {"label": label, "authoredSha256": _hash(value), "definition": value}
        self.evidence["snapshots"].append(record)
        self.save()
        return value

    def turn(self, api, label, text, mode=0, cancel=False):
        if len(self.evidence["turns"]) >= MAX_TURNS:
            raise RuntimeError("Generation turn budget exhausted; no automatic repair loop")
        self.stage = label
        record = {"label": label, "mutationMode": mode, "mutationModeExplicit": True}
        self.evidence["turns"].append(record)
        self.save()
        self.active = True  # A timed-out POST may have been accepted; cancellation must remain possible.
        response = self.ctx.request(api, "POST", self.path + "/messages", {
            "chatMessage": {"role": "user", "text": text, "contents": [{"$type": "text", "text": text}]},
            "additionalContext": _context(self.workspace, self.item, mode),
        }, params={"stream": "false"})
        record["acceptedStatus"] = response.get("status")
        if cancel:
            # Cancel may return an empty 200/204: use exchange, not JSON-only request.
            result = self.ctx.exchange(api, "POST", self.path + "/cancel")
            record["cancelHttpStatus"] = result.status_code
        terminal = self.ctx.poll_conversation(api, self.path)
        self.active = False
        record["terminal"] = terminal.get("status")
        messages = self.ctx.request(api, "GET", self.path + "/messages", params={"stream": "false"})
        text, calls = _assistant(messages)
        record.update(answer=text, toolCalls=calls)
        self.ctx.save_evidence("generation-" + label, messages)
        self.save()
        if not cancel:
            status = str(terminal.get("status", "")).lower()
            if status == "requiresaction":
                raise ScenarioBlocked("Conversation requires an unsupported action envelope; no payload invented")
            if status not in ("completed", "idle"):
                raise RuntimeError(f"{label} did not complete successfully: {terminal.get('status')}")
        return record

    def unchanged(self, before, after, label, turn):
        if _hash(before) != _hash(after) or any(
                str(call.get("tool_name", "")).startswith("fabric_apply_") and call.get("count", 0)
                for call in turn["toolCalls"]):
            raise ValueError(f"{label}: an unapproved mutation was observed")
        self.evidence["stages"][label] = {"status": "PASS", "beforeSha256": _hash(before),
                                          "afterSha256": _hash(after)}

    def run(self):
        ctx, config = self.ctx, self.ctx.config
        if config.get("allow_create") is not True:
            raise ScenarioBlocked("generation.lifecycle requires explicit allow_create=true")
        ids = {}
        for key in ("workspace_id", "generation_lakehouse_id"):
            try:
                ids[key] = str(UUID(str(config.get(key, ""))))
            except ValueError as error:
                raise ScenarioBlocked(f"A valid {key} is required") from error
        self.workspace = ids["workspace_id"]
        source_id = ids["generation_lakehouse_id"]
        try:
            source_workspace = str(UUID(str(config.get("generation_source_workspace_id") or self.workspace)))
        except ValueError as error:
            raise ScenarioBlocked("generation_source_workspace_id must be a UUID") from error
        if source_workspace != self.workspace:
            raise ScenarioBlocked("This bounded generation adapter supports same-workspace Lakehouse only")
        if config.get("ux_token_version", "v2") != "v2":
            raise ScenarioBlocked("Generation requires the supported MWC v2 client contract")
        if ctx.state.get("generationLifecycle"):
            raise ScenarioBlocked("A generation attempt is already retained; it will not be replayed or reused")
        try:
            metadata = ctx.request(ctx.fabric, "GET",
                                   f"{ctx.fabric.base}/workspaces/{self.workspace}/lakehouses/{source_id}")
        except Exception as error:
            raise ScenarioBlocked(f"Lakehouse preflight unavailable: {type(error).__name__}; see HTTP evidence") from error
        endpoint = metadata.get("properties", {}).get("sqlEndpointProperties", {})
        server, catalog = endpoint.get("connectionString"), metadata.get("displayName")
        if metadata.get("id") != source_id or not isinstance(catalog, str) or not catalog:
            raise ScenarioBlocked("Lakehouse metadata did not identify the configured source")
        if not isinstance(server, str) or not re.fullmatch(r"[A-Za-z0-9.-]+(?:,\d+)?", server):
            raise ScenarioBlocked("Lakehouse metadata did not provide a usable SQL endpoint")
        host = server.split(",")[0].lower()
        if not host.endswith((".datawarehouse.fabric.microsoft.com", ".daily-datawarehouse.fabric.microsoft.com")):
            raise ScenarioBlocked("Lakehouse metadata SQL endpoint is outside supported Fabric SQL domains")
        source = {"id": source_id, "workspaceId": source_workspace, "server": server, "catalog": catalog}
        self.evidence["source"] = source
        name = "OntologyGenerationValidation_" + uuid4().hex
        resource = {"creationIntent": {"displayName": name, "type": "Ontology"}, "status": "creating"}
        ctx.state["generationLifecycle"] = resource
        self.evidence["resource"] = resource
        self.stage = "create"
        self.save()
        item = ctx.mutate(ctx.fabric, f"{ctx.fabric.base}/workspaces/{self.workspace}/items",
                          resource["creationIntent"])
        resource["item"] = item
        resource["status"] = "retained"
        self.item = item.get("id") if isinstance(item, dict) else None
        resource["ontologyId"] = self.item
        self.save()  # Persist the returned ID before opening a workload client or reading a definition.
        if (not self.item or str(self.item).lower() == str(config.get("ontology_id", "")).lower() or
                item.get("displayName") != name or item.get("type") != "Ontology"):
            raise ValueError("Creation did not return the uniquely named NEW Ontology; refusing further calls")
        UUID(self.item)
        if item.get("workspaceId", self.workspace).lower() != self.workspace:
            raise ValueError("Creation returned an item from a different workspace")
        self.evidence["ontologyId"] = self.item
        with ctx.workload(self.item) as api:
            self.base = f"{api.base}/v4/workspaces/{self.workspace}/ontologies/{self.item}"
            try:
                return self.lifecycle(api, source)
            except Exception as failure:
                if self.active and self.path and getattr(failure, "status", None) not in (401, 403):
                    try:
                        result = ctx.exchange(api, "POST", self.path + "/cancel")
                        self.evidence["bestEffortCancel"] = {"httpStatus": result.status_code,
                                                            "terminalVerified": False}
                    except Exception as error:
                        self.evidence["bestEffortCancel"] = {"errorType": type(error).__name__}
                raise

    def lifecycle(self, api, source):
        ctx = self.ctx
        empty = self.snapshot(api, "empty")
        if not _empty(empty):
            raise ValueError("New item is not empty; refusing any conversation mutation")
        conversation = ctx.request(api, "POST", self.base + "/conversations", {"mode": "fabricOntology"})
        conversation_id = conversation.get("id")
        if not conversation_id:
            raise ValueError("Conversation response omitted id")
        UUID(conversation_id)
        self.path = self.base + "/conversations/" + conversation_id
        ctx.state["generationLifecycle"]["conversationId"] = conversation_id
        self.evidence["conversationId"] = conversation_id
        self.save()
        self.active = True
        initial = ctx.poll_conversation(api, self.path)
        self.active = False
        if str(initial.get("status", "")).lower() not in ("completed", "idle"):
            raise ScenarioBlocked("Conversation initialization did not reach a ready state")
        scope = (
            f"Only this newly created disposable ontology {self.item}, workspace {self.workspace}, "
            f"using existing Lakehouse {source['id']} in workspace {source['workspaceId']}. "
            "Inspect actual dbo.Plants, dbo.Assets and dbo.Readings. Model Plant and Asset with their "
            "PlantId/AssetId keys and Assets.PlantId -> Plants.PlantId; Readings may be an Asset companion "
            "table joined on AssetId. Bind ReadingId, ObservedAt and TemperatureC, with ObservedAt ordering. "
            "Never modify sources, other items or security settings."
        )
        plan = self.turn(api, "plan", "Plan only; do not save or apply. " + scope)
        planned = self.snapshot(api, "after-plan")
        self.unchanged(empty, planned, "plan-no-save", plan)
        rejected = self.turn(api, "reject", "Reject the proposed draft. Discard pending changes; do not save "
                             "or apply anything. This turn grants no Act approval.")
        rejected_definition = self.snapshot(api, "after-reject")
        self.unchanged(planned, rejected_definition, "reject-no-save", rejected)
        approved = self.turn(api, "approve", "Act and approve. I explicitly approve generating and saving "
                             "the scoped model below. Rebuild and validate the draft discarded by the reject "
                             "control, then apply using the supported generation tool. " + scope, mode=1)
        generated = self.snapshot(api, "after-approve")
        if _empty(generated):
            raise ScenarioBlocked("Act completed without a persisted model; missing apply capability or "
                                  "unsupported generation. Inspect approval answer; no direct-write fallback.")
        binding = _bindings(generated, source["workspaceId"], source["id"])
        apply_proven = _success(approved["toolCalls"], "fabric_apply_ontology_changes_v2")
        if not binding["readingIdBound"]:
            repaired = self.turn(api, "readingid-repair", "Act and approve. I explicitly approve ONLY an "
                                 "additive binding of Asset.ReadingId to dbo.Readings.ReadingId and retention "
                                 "of ObservedAt ordering for TemperatureC on that companion table. Validate "
                                 "before applying. Preserve every existing entity, property, key, relationship "
                                 "and source binding; do not delete objects or change sources.", mode=1)
            updated = self.snapshot(api, "after-readingid-repair")
            _preserved(generated, updated)
            generated = updated
            binding = _bindings(generated, source["workspaceId"], source["id"])
            apply_proven = apply_proven and _success(repaired["toolCalls"], "fabric_apply_ontology_changes_v2")
        self.evidence["bindings"] = binding
        self.evidence["stages"]["apply"] = {"status": "PASS" if apply_proven else "PARTIAL",
                                           "readbackVerified": True, "applyToolReceipt": apply_proven}
        # A fresh client confirms persistence, rather than relying on conversation working state.
        with ctx.workload(self.item) as reopened:
            fresh = ctx.request(reopened, "GET", self.base + "/definition", params={"expand": "true"})
        if _hash(fresh) != _hash(generated):
            raise ValueError("Fresh reopen differs from the saved authored definition")
        self.evidence["stages"]["reopen"] = {"status": "PASS", "authoredSha256": _hash(fresh)}
        query = self.turn(api, "query", "Read-only verification: reload persisted bindings, execute supported "
                          "queries for counts of Plants, Assets, Readings and the global maximum temperature "
                          "row. Use ORDER BY TemperatureC DESC, ObservedAt DESC, ReadingId ASC, AssetId ASC "
                          "before TOP/LIMIT. Return actual ReadingId and plant details, not placeholders. "
                          "Do not mutate anything. Finish with one JSON object with exactly these keys: "
                          + ", ".join(EXPECTED_FIELDS) + ". Never guess values; identify direct-SQL fallback.")
        after_query = self.snapshot(api, "after-query")
        self.unchanged(generated, after_query, "query-no-save", query)
        check = {"structuredAnswer": _answer(query["answer"]), "executionVerifiedByBackendTelemetry": False,
                 "sourceEvidenceRequired": False}
        calls = query["toolCalls"]
        check["agentReportedRoute"] = ("direct-sql-fallback" if _success(calls, "execute_sql_query") else
                                      "unified" if _success(calls, "execute_unified_kql_query") else "unverified")
        check["unifiedEngineExecution"] = "NOT VERIFIED; tool counters alone do not prove engine execution"
        expected = {key: value for key, value in EXPECTED.items() if key != "A012ReadingCount"}
        expected.update(PlantCount=3, AssetCount=12, ReadingCount=120)
        try:
            actual = _row(check["structuredAnswer"]) if check["structuredAnswer"] is not None else None
            check["answerMatchesFixture"] = actual == expected if actual is not None else None
            check["status"] = "PASS" if actual == expected else "PARTIAL" if actual is None else "FAIL"
        except (TypeError, ValueError, KeyError) as error:
            actual = None
            check.update(status="FAIL", reason="Malformed structured answer", detail=str(error))
        try:
            check["independentSourceRead"] = _read_source_rows(ctx, source)
            source_row = check["independentSourceRead"]["rows"][0]
        except Exception as error:
            check["independentSourceReadNote"] = {
                "type": type(error).__name__, "detail": str(error),
                "scope": "Optional source evidence unavailable; does not downgrade a fixture-correct answer"}
        else:
            check["answerMatchesIndependentData"] = actual == source_row if actual is not None else None
            if actual is not None and actual != source_row:
                check.update(status="FAIL", reason="Answer contradicts observed source data")
        self.evidence["stages"]["query"] = check
        self.save()
        cancelled = self.turn(api, "cancel", "Plan-only cancellation control: review existing property "
                              "descriptions without applying changes. No Act approval; do not add, delete "
                              "or modify model elements or source data.", cancel=True)
        after_cancel = self.snapshot(api, "after-cancel")
        self.unchanged(after_query, after_cancel, "cancel-no-save", cancelled)
        cancel_ok = (str(cancelled["acceptedStatus"]).lower() == "inprogress" and
                     str(cancelled["terminal"]).lower() in ("cancelled", "canceled"))
        self.evidence["stages"]["cancel"] = {"status": "PASS" if cancel_ok else "PARTIAL",
                                            "scope": "Active read-only planning, not an apply race"}
        if check["status"] == "FAIL":
            return "FAIL", "Generated ontology query answer is malformed or differs from fixture/observed data"
        if not (apply_proven and binding["readingIdBound"] and check["status"] == "PASS"
                and cancel_ok):
            return "PARTIAL", "Saved model/safety evidence retained; required model, answer or safety checks incomplete"
        return "PASS", ("New-item generation, explicit approval, readback, fixture answer and planning "
                        "safety controls passed; unified engine and Private Link enforcement are not certified")


def generation_lifecycle(ctx):
    run = _Run(ctx)
    try:
        status, summary = run.run()
    except ScenarioBlocked as error:
        status, summary = "BLOCKED", str(error)
    except TimeoutError as error:
        status, summary = "BLOCKED", f"Bounded {run.stage} timeout; resources retained, no write replay: {error}"
    except Exception as error:
        status = "BLOCKED" if getattr(error, "status", None) in (401, 403) else "FAIL"
        summary = f"{run.stage}: {type(error).__name__}: {error}"
    run.evidence.update(status=status, stoppedAt=run.stage)
    run.save()
    return {"status": status, "summary": summary, "evidence": run.evidence}


SCENARIOS = {"generation.lifecycle": generation_lifecycle}
