import copy
import io
import json
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import Mock, patch

import create_sample as sample
import retry_semantic_data as retry
from test_create_ontology import GUID, inventory


class RetrySemanticDataTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.folder = Path(temporary.name)
        self.state = inventory()
        self.state["environment"] = "Daily"
        self.state["deferredValidation"] = {"SemanticModel": ["refresh", "sampleRows"]}
        self.state["verified"].pop("SemanticModel")
        self.source = self.folder / "input.json"
        self.source.write_text(json.dumps(self.state))
        self.argv = ["--sources-manifest", str(self.source), "--run-directory", str(self.folder / "output")]

    def provisioner(self):
        state, args, _ = retry.load_plan(retry.arguments(self.argv))
        manifest = sample.Manifest(self.folder / "result.json", state)
        manifest.data.update(items=copy.deepcopy(state["items"]), verified=copy.deepcopy(state["verified"]))
        p = sample.Provisioner(args, Mock(), manifest)
        p.api.close()
        p.pbi.close()
        p.api = Mock()
        p.pbi = Mock()
        p.api.json.side_effect = [
            {"capacityId": GUID, "displayName": state["workspaceName"]},
            state["items"]["SemanticModel"],
        ]
        p.api.mutate.return_value = {"definition": sample.semantic_definition(p.tables)}
        response = Mock(status_code=202, headers={
            "Location": f"{args.powerbi_api}/v1.0/myorg/groups/{GUID}/datasets/{GUID}/refreshes/job-1",
        })
        p.pbi.request.return_value = response

        def read(method, url, body=None):
            if url.endswith("/refreshes/job-1"):
                return {"status": "Completed"}
            self.assertTrue(url.endswith("/executeQueries"))
            query = body["queries"][0]["query"]
            table = next(t for t in p.tables if f"SELECTCOLUMNS({t.name}," in query)
            return {"results": [{"tables": [{"rows": table.records()}]}]}
        p.pbi.json.side_effect = read
        return p

    def test_preview_has_no_authentication_files_or_resource_changes(self):
        before = self.source.read_bytes()
        with patch("retry_semantic_data.open_credential") as auth, redirect_stdout(io.StringIO()) as output:
            retry.main(self.argv)
        plan = json.loads(output.getvalue())
        self.assertEqual(plan["semanticModelId"], GUID)
        self.assertFalse(plan["createsItems"])
        self.assertFalse(plan["changesOntology"])
        auth.assert_not_called()
        self.assertFalse((self.folder / "output").exists())
        self.assertEqual(self.source.read_bytes(), before)

    def test_explicit_source_origin_and_wrong_workspace_guard(self):
        correct = f"https://{GUID.replace('-', '')}.z11.w.dailyapi.fabric.microsoft.com"
        _, args, plan = retry.load_plan(retry.arguments(self.argv + ["--powerbi-api", correct]))
        self.assertEqual(args.powerbi_api, correct)
        self.assertEqual(plan["powerbiApi"], correct)
        for origin in (
            "https://e60e7807b3914e4988f14223f79e5694.ze6.w.dailyapi.fabric.microsoft.com",
            "https://evil.example", correct + "/metadata/v201606/generatemwctokenv2",
            "https://test.daily-c.fabric.microsoft.com", "http://test.analysis.windows.net",
        ):
            with self.subTest(origin=origin), self.assertRaises(ValueError):
                retry.load_plan(retry.arguments(self.argv + ["--powerbi-api", origin]))

    def test_refresh_existing_model_and_verify_all_exact_rows(self):
        p = self.provisioner()
        before = copy.deepcopy(p.manifest.data["items"])
        retry.run(p, False)
        self.assertEqual(p.manifest.data["items"], before)
        p.api.mutate.assert_called_once()
        self.assertTrue(p.api.mutate.call_args.args[0].endswith("/getDefinition"))
        p.pbi.request.assert_called_once_with(
            "POST", f"{p.args.powerbi_api}/v1.0/myorg/groups/{GUID}/datasets/{GUID}/refreshes",
            {"type": "full", "commitMode": "transactional"})
        self.assertEqual(p.pbi.json.call_count, 4)
        self.assertEqual(p.manifest.data["verified"]["SemanticModel"], {"Plants": 3, "Assets": 12, "Readings": 120})
        self.assertNotIn("SemanticModel", p.manifest.data["deferredValidation"])
        self.assertTrue(p.manifest.data["semanticRefreshCompleted"])
        self.assertEqual(p.manifest.data["status"], "succeeded")

    def test_verify_only_never_refreshes(self):
        p = self.provisioner()
        retry.run(p, True)
        p.pbi.request.assert_not_called()
        self.assertEqual(p.pbi.json.call_count, 3)
        self.assertNotIn("semanticRefreshCompleted", p.manifest.data)

    def test_identity_change_or_invalid_schema_prevents_refresh(self):
        for problem in ("workspace", "item", "schema", "partition"):
            with self.subTest(problem=problem):
                # Each manifest must be exclusively created.
                (self.folder / "result.json").unlink(missing_ok=True)
                p = self.provisioner()
                if problem == "workspace":
                    p.api.json.side_effect = [{"capacityId": GUID, "displayName": "changed"}]
                elif problem == "item":
                    p.api.json.side_effect = [
                        {"capacityId": GUID, "displayName": self.state["workspaceName"]},
                        {"id": GUID, "displayName": "changed"},
                    ]
                else:
                    import base64
                    parts = p.api.mutate.return_value["definition"]["parts"]
                    model = json.loads(base64.b64decode(parts[0]["payload"]))
                    if problem == "schema":
                        model["model"]["tables"].pop()
                    else:
                        model["model"]["tables"][0]["partitions"] = []
                    parts[0]["payload"] = base64.b64encode(json.dumps(model).encode()).decode()
                with self.assertRaises(ValueError):
                    retry.run(p, False)
                p.pbi.request.assert_not_called()

    def test_refresh_failure_does_not_query_or_mark_verified(self):
        p = self.provisioner()
        p.pbi.json.side_effect = None
        p.pbi.json.return_value = {"status": "Failed", "error": "ServiceError"}
        with self.assertRaisesRegex(RuntimeError, "refresh failed"):
            retry.run(p, False)
        self.assertNotIn("SemanticModel", p.manifest.data["verified"])
        self.assertNotIn("semanticRefreshCompleted", p.manifest.data)
        self.assertEqual(p.pbi.json.call_count, 1)

    def test_denial_stops_without_queries_or_fallback(self):
        p = self.provisioner()
        p.pbi.request.side_effect = RuntimeError("HTTP 401 Unauthorized")
        with self.assertRaisesRegex(RuntimeError, "401"):
            retry.run(p, False)
        p.pbi.request.assert_called_once()
        p.pbi.json.assert_not_called()
        self.assertNotIn("SemanticModel", p.manifest.data["verified"])

    def test_cross_origin_refresh_location_is_not_followed(self):
        p = self.provisioner()
        p.pbi.request.return_value.headers = {"Location": "https://evil.example/refresh"}
        with self.assertRaises((ValueError, RuntimeError)):
            retry.run(p, False)
        p.pbi.json.assert_not_called()

    def test_mismatched_values_do_not_clear_deferral(self):
        p = self.provisioner()
        p.pbi.json.side_effect = [
            {"status": "Completed"},
            {"results": [{"tables": [{"rows": []}]}]},
        ]
        with self.assertRaisesRegex(ValueError, "matching rows"):
            retry.run(p, False)
        self.assertTrue(p.manifest.data["semanticRefreshCompleted"])
        self.assertEqual(p.manifest.data["deferredValidation"]["SemanticModel"], ["sampleRows"])
        self.assertNotIn("SemanticModel", p.manifest.data["verified"])

    def test_failed_execution_preserves_input_and_records_failure(self):
        before = self.source.read_bytes()
        origin = f"https://{GUID.replace('-', '')}.z11.w.dailyapi.fabric.microsoft.com"
        with (patch("retry_semantic_data.open_credential"), patch("retry_semantic_data.Provisioner"),
              patch("retry_semantic_data.run", side_effect=RuntimeError("HTTP 401 Unauthorized")),
              redirect_stdout(io.StringIO()), self.assertLogs("ontology-sample", level="ERROR"),
              self.assertRaisesRegex(RuntimeError, "401")):
            retry.main(self.argv + ["--powerbi-api", origin, "--execute"])
        saved = json.loads((self.folder / "output" / "sources.manifest.json").read_text())
        self.assertEqual(saved["status"], "failed")
        self.assertEqual(saved["items"], self.state["items"])
        self.assertEqual(saved["endpoints"]["powerbi"], origin)
        self.assertNotIn("SemanticModel", saved["verified"])
        self.assertEqual(self.source.read_bytes(), before)

    def test_non_daily_or_missing_model_rejected_offline(self):
        for change in ({"environment": "PROD"}, {"items": {}}):
            self.source.write_text(json.dumps({**self.state, **change}))
            with self.assertRaises(ValueError):
                retry.load_plan(retry.arguments(self.argv))


if __name__ == "__main__":
    unittest.main()
