"""Offline TMDL for the synthetic Gen2 sample, not a general-purpose TMDL SDK.

Only simple identifiers, the sample's three column types, entity/M partitions,
and its explicit ontology bindings are supported. M and named annotations are
opaque single-line text: neither is evaluated or rewritten. Unsupported
declarations fail closed.
"""

import re
from dataclasses import dataclass, field
from pathlib import Path


_IDENTIFIER = re.compile(r"[A-Za-z_][A-Za-z0-9_]*\Z")
_TYPES = {"string", "dateTime", "double"}
_COLLECTIONS = {
    "tables": "table", "entities": "entity", "namespaces": "namespace",
    "expressions": "expression", "relationships": "relationship",
    "entityRelationships": "entityRelationship",
}
_FILES = {
    "expressions.tmdl": "expressions",
    "relationships.tmdl": "relationships",
    "entityRelationships.tmdl": "entityRelationships",
}
_DIRECTORIES = {"tables", "entities", "namespaces"}
_REQUIRED = {
    "table": {"name", "columns", "partitions"},
    "column": {"name", "dataType", "sourceColumn"},
    "partition": {"name", "mode", "source"},
    "entitySource": {"type", "entityName", "expressionSource"},
    "mSource": {"type", "expression"},
    "expression": {"name", "kind", "expression"},
    "entity": {"name", "backingTable", "keyProperties", "properties"},
    "property": {"name", "dataType", "backingConfiguration"},
    "valueBacking": {"valueColumn"},
    "relationshipBacking": {"relationship"},
    "relationship": {"name", "fromTable", "fromColumn", "toTable", "toColumn"},
    "entityRelationship": {"name", "fromEntity", "toEntity", "backingConfiguration"},
    "namespace": {"name", "lineageTag"},
}
_OPTIONAL = {
    "column": {"isKey", "isNullable"},
    "entitySource": {"schemaName"},
    "valueBacking": {"type"},
    "relationshipBacking": {"type"},
    "relationship": {"fromCardinality", "toCardinality", "crossFilteringBehavior",
                     "securityFilteringBehavior"},
}
_NAMED = {kind for kind, keys in _REQUIRED.items() if "name" in keys}
_SCALARS = {
    "table": (),
    "column": ("dataType", "isKey", "isNullable", "sourceColumn"),
    "partition": ("mode",),
    "entitySource": ("entityName", "schemaName", "expressionSource"),
    "mSource": (),
    "expression": (),
    "entity": ("backingTable", "keyProperties"),
    "property": ("dataType",),
    "valueBacking": ("valueColumn",),
    "relationshipBacking": ("relationship",),
    "relationship": ("fromColumn", "toColumn", "fromCardinality", "toCardinality",
                     "crossFilteringBehavior", "securityFilteringBehavior"),
    "entityRelationship": ("fromEntity", "toEntity"),
    "namespace": (),
}
_CHILDREN = {
    "table": {"column": ("columns", "column"), "partition": ("partitions", "partition")},
    "entity": {"property": ("properties", "property")},
    "property": {"backingConfiguration": ("backingConfiguration", "valueBacking")},
    "entityRelationship": {"backingConfiguration": ("backingConfiguration", "relationshipBacking")},
}


def _fail(message):
    raise ValueError(f"Unsupported or malformed sample TMDL: {message}")


def _keys(value, required, optional, context):
    if not isinstance(value, dict):
        _fail(f"{context} must be an object")
    if any(not isinstance(key, str) for key in value):
        _fail(f"{context} field names must be strings")
    missing, extra = required - value.keys(), value.keys() - required - optional
    if missing or extra:
        _fail(f"{context}: missing fields {sorted(missing)}, unknown fields {sorted(extra)}")


def _text(value, context, *, multiline=False):
    if not isinstance(value, str) or not value:
        _fail(f"{context} must be nonempty text")
    if any(ord(c) < 32 and not (multiline and c == "\n") for c in value):
        _fail(f"{context} contains unsupported control characters or line breaks")
    return value


def _name(value):
    if not isinstance(value, str) or not _IDENTIFIER.fullmatch(value):
        _fail(f"expected simple identifier, got {value!r}")
    return value


def _enum(value, choices, context):
    if not isinstance(value, str) or value not in choices:
        _fail(f"{context}: unsupported value {value!r}")


def _objects(value, kind):
    if not isinstance(value, list):
        _fail(f"{kind} collection must be a list")
    indexed = {}
    for obj in value:
        _validate_object(kind, obj)
        name = obj["name"]
        if name in indexed:
            _fail(f"duplicate {kind} {name}")
        indexed[name] = obj
    return indexed


def _validate_object(kind, obj):
    optional = _OPTIONAL.get(kind, set()) | (
        {"description", "lineageTag", "annotations"} if kind in _NAMED else set())
    _keys(obj, _REQUIRED[kind], optional, kind)
    if "annotations" in obj:
        annotations = obj["annotations"]
        if not isinstance(annotations, list) or not annotations:
            _fail(f"{kind}.annotations must be a nonempty list")
        names = set()
        for annotation in annotations:
            _keys(annotation, {"name", "value"}, set(), "annotation")
            name = _name(annotation["name"])
            _text(annotation["value"], f"annotation {name}.value")
            if name in names:
                _fail(f"duplicate annotation {name}")
            names.add(name)
    for key in ("name", "sourceColumn", "entityName", "expressionSource", "schemaName",
                "backingTable", "fromTable", "fromColumn", "toTable", "toColumn",
                "fromEntity", "toEntity", "relationship"):
        if key in obj:
            _name(obj[key])
    for key in ("description", "lineageTag", "expression"):
        if key in obj:
            _text(obj[key], f"{kind}.{key}", multiline=key == "description")
    if "lineageTag" in obj and obj["lineageTag"] != obj["lineageTag"].strip():
        _fail("lineageTag cannot have surrounding whitespace")
    if "dataType" in obj:
        _enum(obj["dataType"], _TYPES, f"{kind}.dataType")
    if kind == "column":
        if "isKey" in obj and obj["isKey"] is not True:
            _fail("only bare true isKey is supported")
        if "isNullable" in obj and obj["isNullable"] is not False:
            _fail("only isNullable: false is supported")
    elif kind == "partition":
        _enum(obj["mode"], {"directLake", "directQuery"}, "partition.mode")
        source = obj["source"]
        if not isinstance(source, dict):
            _fail("partition.source must be an object")
        _enum(source.get("type"), {"m", "entity"}, "partition.source.type")
        if source["type"] == "m" and obj["mode"] != "directQuery":
            _fail("M partitions require directQuery")
        _validate_object("mSource" if source["type"] == "m" else "entitySource", source)
    elif kind == "expression":
        _enum(obj["kind"], {"m"}, "expression.kind")
    elif kind in ("entitySource", "mSource"):
        _enum(obj["type"], {"m" if kind == "mSource" else "entity"}, "source.type")
    elif kind == "entity":
        keys = obj["keyProperties"]
        if not isinstance(keys, list) or len(keys) != 1:
            _fail("exactly one explicit keyProperty is required")
        _name(keys[0])
    elif kind in ("valueBacking", "relationshipBacking"):
        if "type" in obj:
            _enum(obj["type"], {"default" if kind == "valueBacking" else "relationship"}, "backing type")
        if kind == "valueBacking":
            _keys(obj["valueColumn"], {"table", "column"}, set(), "valueColumn")
            for value in obj["valueColumn"].values():
                _name(value)
    elif kind == "relationship":
        for key in ("fromCardinality", "toCardinality"):
            if key in obj:
                _enum(obj[key], {"one", "many"}, key)
        for key in ("crossFilteringBehavior", "securityFilteringBehavior"):
            if key in obj:
                choices = {"oneDirection", "bothDirections"}
                if key == "crossFilteringBehavior":
                    choices.add("automatic")
                _enum(obj[key], choices, key)
    elif kind == "namespace":
        if obj["name"] != "default" or obj["lineageTag"] != "default":
            _fail("only namespace default with lineageTag default is supported")
    for key, child_kind in _CHILDREN.get(kind, {}).values():
        if key == "backingConfiguration":
            _validate_object(child_kind, obj[key])
        else:
            _objects(obj[key], child_kind)


def _validate(document):
    _keys(document, {"compatibilityLevel", "model"}, set(), "document")
    if type(document["compatibilityLevel"]) is not int or document["compatibilityLevel"] != 1000000:
        _fail("compatibilityLevel must be 1000000")
    model = document["model"]
    _keys(model, set(_COLLECTIONS), set(), "model")
    collections = {key: _objects(model[key], kind) for key, kind in _COLLECTIONS.items()}
    if set(collections["namespaces"]) != {"default"}:
        _fail("namespace default is required")
    tables, entities = collections["tables"], collections["entities"]
    columns = {name: {c["name"]: c for c in table["columns"]} for name, table in tables.items()}

    def column(table, name):
        if table not in columns or name not in columns[table]:
            _fail(f"dangling column reference {table}.{name}")
        return columns[table][name]

    for table in tables.values():
        if not table["columns"] or len(table["partitions"]) != 1:
            _fail(f"table {table['name']} requires columns and exactly one partition")
        keys = [c for c in table["columns"] if c.get("isKey")]
        if len(keys) != 1 or keys[0].get("isNullable") is not False:
            _fail(f"table {table['name']} requires exactly one nonnullable key column")
        for partition in table["partitions"]:
            source = partition["source"]
            if source["type"] == "entity" and source["expressionSource"] not in collections["expressions"]:
                _fail(f"dangling expressionSource {source['expressionSource']}")
    for entity in entities.values():
        table = entity["backingTable"]
        if table not in tables:
            _fail(f"dangling backingTable {table}")
        props = {p["name"]: p for p in entity["properties"]}
        for prop in props.values():
            value = prop["backingConfiguration"]["valueColumn"]
            bound_column = column(value["table"], value["column"])
            if value["table"] != table or prop["dataType"] != bound_column["dataType"]:
                _fail(f"inconsistent valueColumn binding for {entity['name']}.{prop['name']}")
        key = entity["keyProperties"][0]
        if key not in props:
            _fail(f"missing key property {entity['name']}.{key}")
        key_column = props[key]["backingConfiguration"]["valueColumn"]
        bound_column = column(key_column["table"], key_column["column"])
        if bound_column.get("isKey") is not True or bound_column.get("isNullable") is not False:
            _fail(f"key property {entity['name']}.{key} must bind a nonnullable key column")
    for rel in collections["relationships"].values():
        column(rel["fromTable"], rel["fromColumn"])
        column(rel["toTable"], rel["toColumn"])
    for rel in collections["entityRelationships"].values():
        name = rel["backingConfiguration"]["relationship"]
        if name not in collections["relationships"]:
            _fail(f"dangling relationship {name}")
        backing = collections["relationships"][name]
        for side in ("from", "to"):
            name = rel[f"{side}Entity"]
            if name not in entities or entities[name]["backingTable"] != backing[f"{side}Table"]:
                _fail(f"inconsistent {side}Entity reference {name}")


def _header(kind, obj):
    if kind == "partition":
        return f"partition {obj['name']} = {obj['source']['type']}"
    if kind == "expression":
        return f"expression {obj['name']} = {obj['expression']}"
    if kind in ("valueBacking", "relationshipBacking"):
        return "backingConfiguration"
    if kind == "entitySource":
        return "source"
    return f"{kind} {obj['name']}"


def _emit(kind, obj, depth=0):
    indent = "\t" * depth
    lines = [indent + "/// " + line for line in obj.get("description", "").split("\n")] if "description" in obj else []
    lines.append(indent + _header(kind, obj))
    for key in (*_SCALARS[kind], "lineageTag"):
        if key not in obj:
            continue
        value = obj[key]
        wire = key
        if key == "isKey":
            text = "isKey"
        else:
            if key == "isNullable":
                value = "false"
            elif key == "keyProperties":
                wire, value = "keyProperty", value[0]
            elif kind == "relationship" and key in ("fromColumn", "toColumn"):
                value = f"{obj[key.replace('Column', 'Table')]}.{value}"
            elif key == "valueColumn":
                value = f"{value['table']}.{value['column']}"
            text = f"{wire}: {value}"
        lines.append(indent + "\t" + text)
    for key, child_kind in _CHILDREN.get(kind, {}).values():
        values = [obj[key]] if key == "backingConfiguration" else obj[key]
        for child in values:
            lines.extend(_emit(child_kind, child, depth + 1))
    if kind == "partition":
        source = obj["source"]
        if source["type"] == "m":
            lines.append(indent + "\tsource = " + source["expression"])
        else:
            lines.extend(_emit("entitySource", source, depth + 1))
    for annotation in obj.get("annotations", []):
        lines.append(indent + f"\tannotation {annotation['name']} = {annotation['value']}")
    return lines


def serialize(document: dict, folder: Path) -> None:
    """Write a new, exclusively created folder after validating the entire input."""
    _validate(document)
    model = document["model"]
    parts = {"database.tmdl": ["database", "\tcompatibilityLevel: 1000000"],
             "model.tmdl": ["model Model"]}
    for collection in ("tables", "entities", "namespaces"):
        kind = _COLLECTIONS[collection]
        for obj in model[collection]:
            parts["model.tmdl"].append(f"ref {kind} {obj['name']}")
            parts[f"{collection}/{obj['name']}.tmdl"] = _emit(kind, obj)
    for filename, collection in _FILES.items():
        parts[filename] = [line for obj in model[collection] for line in (*_emit(_COLLECTIONS[collection], obj), "")]
    folder = Path(folder)
    folder.mkdir()
    for filename, lines in parts.items():
        path = folder.joinpath(*filename.split("/"))
        path.parent.mkdir(exist_ok=True)
        path.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")


@dataclass
class _Node:
    text: str
    location: str
    children: list = field(default_factory=list)
    description: str | None = None


def _nodes(path):
    roots, stack = [], []
    for number, raw in enumerate(path.read_text(encoding="utf-8-sig").split("\n"), 1):
        raw = raw.removesuffix("\r")
        if not raw:
            continue
        depth = len(raw) - len(raw.lstrip("\t"))
        text = raw[depth:]
        location = f"{path.name}:{number}"
        if not text or text[0].isspace() or depth > len(stack):
            _fail(f"malformed tab indentation at {location}")
        _text(text, location)
        node = _Node(text, location)
        if depth:
            stack[depth - 1].children.append(node)
        else:
            roots.append(node)
        stack[depth:] = [node]
    return _descriptions(roots)


def _descriptions(nodes):
    result, comments = [], []
    for node in nodes:
        if node.text == "///" or node.text.startswith("/// "):
            if node.children:
                _fail(f"description has children at {node.location}")
            comments.append(node.text[4:] if node.text != "///" else "")
            continue
        if comments:
            node.description = "\n".join(comments)
            comments = []
        node.children = _descriptions(node.children)
        result.append(node)
    if comments:
        _fail("orphan description comments")
    return result


def _put(obj, key, value, node):
    if key in obj:
        _fail(f"duplicate property {key} at {node.location}")
    obj[key] = value


def _reference(value):
    pieces = value.split(".")
    if len(pieces) != 2:
        _fail(f"expected TABLE.COLUMN, got {value!r}")
    return tuple(_name(piece) for piece in pieces)


def _plain(node):
    if node.children or node.description is not None:
        _fail(f"unexpected children/description at {node.location}")


def _parse(kind, node):
    obj = {}
    if kind in ("valueBacking", "relationshipBacking", "entitySource"):
        expected = "source" if kind == "entitySource" else "backingConfiguration"
        if node.text != expected or node.description is not None:
            _fail(f"expected {expected} at {node.location}")
        if kind == "entitySource":
            obj["type"] = "entity"
    else:
        match = re.fullmatch(rf"{kind} ([A-Za-z_][A-Za-z0-9_]*)(?: = (.+))?", node.text)
        if not match:
            _fail(f"expected {kind} declaration at {node.location}")
        obj["name"], rhs = match.groups()
        if kind == "expression":
            if rhs is None:
                _fail(f"missing M expression at {node.location}")
            obj.update(kind="m", expression=rhs)
        elif kind == "partition":
            _enum(rhs, {"m", "entity"}, "partition source type")
        elif rhs is not None:
            _fail(f"unexpected assignment at {node.location}")
        if node.description is not None:
            obj["description"] = node.description
    source_type = rhs if kind == "partition" else None
    for child in node.children:
        word = child.text.split(" ", 1)[0]
        if word == "annotation" and kind in _NAMED:
            _plain(child)
            match = re.fullmatch(r"annotation ([A-Za-z_][A-Za-z0-9_]*) = (.+)", child.text)
            if not match:
                _fail(f"expected single-line annotation NAME = VALUE at {child.location}")
            name, value = match.groups()
            obj.setdefault("annotations", []).append({"name": name, "value": value})
            continue
        if word in _CHILDREN.get(kind, {}):
            key, child_kind = _CHILDREN[kind][word]
            value = _parse(child_kind, child)
            if key == "backingConfiguration":
                _put(obj, key, value, child)
            else:
                obj.setdefault(key, []).append(value)
            continue
        if kind == "partition" and (child.text == "source" or child.text.startswith("source = ")):
            if source_type == "entity":
                source = _parse("entitySource", child)
            else:
                _plain(child)
                if not child.text.startswith("source = "):
                    _fail(f"expected single-line M source at {child.location}")
                source = {"type": "m", "expression": child.text[len("source = "):]}
            _put(obj, "source", source, child)
            continue
        _plain(child)
        if child.text == "isKey" and kind == "column":
            _put(obj, "isKey", True, child)
            continue
        key, separator, value = child.text.partition(":")
        if not separator or not value.startswith(" "):
            _fail(f"unsupported syntax at {child.location}: {child.text!r}")
        value = value[1:]
        if key == "keyProperty":
            key, value = "keyProperties", [_name(value)]
        allowed = set(_SCALARS[kind]) | ({"lineageTag"} if kind in _NAMED else set())
        if key not in allowed or key == "isKey":
            _fail(f"unknown property {key} at {child.location}")
        if key == "isNullable":
            if value != "false":
                _fail(f"expected isNullable: false at {child.location}")
            value = False
        elif key == "valueColumn":
            table, column = _reference(value)
            value = {"table": table, "column": column}
        elif kind == "relationship" and key in ("fromColumn", "toColumn"):
            table, value = _reference(value)
            _put(obj, key.replace("Column", "Table"), table, child)
        _put(obj, key, value, child)
    return obj


def deserialize(folder: Path) -> dict:
    """Decode only known sample parts; validate syntax, uniqueness and bindings."""
    folder = Path(folder)
    if not folder.is_dir() or folder.is_symlink():
        _fail("definition folder must be a real directory")
    files = {}
    for path in folder.rglob("*"):
        relative = path.relative_to(folder)
        if path.is_symlink():
            _fail(f"symbolic links are not definition parts: {relative}")
        if path.is_dir():
            if len(relative.parts) != 1 or relative.name not in _DIRECTORIES:
                _fail(f"unknown definition directory {relative}")
            continue
        if not path.is_file():
            _fail(f"unsupported definition part {relative}")
        parts = relative.parts
        if len(parts) == 1 and parts[0] in {"database.tmdl", "model.tmdl", *_FILES}:
            pass
        elif len(parts) == 2 and parts[0] in _DIRECTORIES and path.suffix == ".tmdl":
            _name(path.stem)
        else:
            _fail(f"unknown definition part {relative}")
        files[relative.as_posix()] = _nodes(path)
    if not {"database.tmdl", "model.tmdl"} <= files.keys():
        _fail("missing database.tmdl or model.tmdl")
    database = files.pop("database.tmdl")
    if (len(database) != 1 or database[0].text != "database" or database[0].description is not None
            or len(database[0].children) != 1
            or database[0].children[0].text != "compatibilityLevel: 1000000"):
        _fail("expected database with compatibilityLevel: 1000000")
    _plain(database[0].children[0])
    roots = files.pop("model.tmdl")
    if not roots or roots[0].text != "model Model":
        _fail("expected model Model")
    _plain(roots[0])
    refs = {collection: [] for collection in _DIRECTORIES}
    for node in roots[1:]:
        _plain(node)
        match = re.fullmatch(r"ref (table|entity|namespace) ([A-Za-z_][A-Za-z0-9_]*)", node.text)
        if not match:
            _fail(f"unsupported model reference at {node.location}")
        kind, name = match.groups()
        collection = {"table": "tables", "entity": "entities", "namespace": "namespaces"}[kind]
        if name in refs[collection]:
            _fail(f"duplicate model reference {kind} {name}")
        refs[collection].append(name)
    model = {collection: [] for collection in _COLLECTIONS}
    for filename, nodes in files.items():
        if filename in _FILES:
            collection = _FILES[filename]
            model[collection].extend(_parse(_COLLECTIONS[collection], node) for node in nodes)
        else:
            collection, filename = filename.split("/")
            if len(nodes) != 1:
                _fail(f"expected one declaration in {collection}/{filename}")
            obj = _parse(_COLLECTIONS[collection], nodes[0])
            if obj["name"] != filename[:-5]:
                _fail(f"declaration name does not match part {collection}/{filename}")
            model[collection].append(obj)
    document = {"compatibilityLevel": 1000000, "model": model}
    _validate(document)
    for collection, names in refs.items():
        objects = {obj["name"]: obj for obj in model[collection]}
        if set(names) != objects.keys():
            _fail(f"dangling or missing model refs for {collection}")
        model[collection] = [objects[name] for name in names]
    return document
