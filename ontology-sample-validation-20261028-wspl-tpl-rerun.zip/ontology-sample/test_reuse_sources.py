import copy
import io
import json
import tempfile
import unittest
from contextlib import ExitStack, redirect_stdout
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
from uuid import UUID

import create_sample as sample
import reuse_sources as reuse
import run_sample
from test_create_ontology import GUID, metadata
from test_run_sample import TARGET


class SourceWorkspaceReuseTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.folder = Path(temporary.name)
        self.args = SimpleNamespace(
            tenant_id=GUID, capacity_id=None, source_workspace_id=GUID, workspace_id=TARGET,
            source_items={}, run_directory=self.folder, timeout=30, kql_request_timeout=600,
        )
        self.workspace = {"id": GUID, "displayName": "Existing sample sources", "capacityId": GUID}
        self.items = [
            {"id": str(UUID(int=index + 1)), "type": kind, "displayName": "Sample_" + kind}
            for index, kind in enumerate(sample.COLLECTIONS)
        ]
        self.by_kind = {item["type"]: item for item in self.items}
        self.properties = metadata()
        self.properties["Eventhouse"] = {}
        self.properties["KQLDatabase"]["parentEventhouseItemId"] = self.by_kind["Eventhouse"]["id"]
        for kind in ("Lakehouse", "MirroredDatabase"):
            self.properties[kind]["sqlEndpointProperties"] = {
                "id": str(UUID(int=100)), "provisioningStatus": "Success", "connectionString": "sample.example.com",
            }
        self.api = Mock(base=reuse.DAILY_ENDPOINTS["fabric"])
        self.api.json.side_effect = self.read
        self.api.mutate.side_effect = self.export
        self.exported = {"definition": sample.semantic_definition(sample.sample_tables())}
        self.kql = Mock(base="https://sample.kusto.fabric.microsoft.com")
        self.kql.json.side_effect = self.query
        self.sql_queries = []
        self.credential = Mock()

    def read(self, method, url, **kwargs):
        self.assertEqual(method, "GET", "Source discovery must never write")
        base = f"{self.api.base}/workspaces/{GUID}"
        if url == base:
            return copy.deepcopy(self.workspace)
        if url == base + "/items":
            if kwargs.get("params"):
                self.assertEqual(kwargs["params"], {"continuationToken": "second"})
                return {"value": copy.deepcopy(self.items[3:])}
            return {"value": copy.deepcopy(self.items[:3]), "continuationToken": "second"}
        for kind, item in self.by_kind.items():
            if url == f"{base}/{sample.COLLECTIONS[kind]}/{item['id']}":
                return {**item, "properties": copy.deepcopy(self.properties[kind])}
        raise AssertionError(f"Unexpected source API call: {url}")

    def export(self, url, *args, **kwargs):
        expected = (f"{self.api.base}/workspaces/{GUID}/semanticModels/"
                    f"{self.by_kind['SemanticModel']['id']}/getDefinition")
        self.assertEqual(url, expected, "Only the read-only definition export POST is allowed")
        self.assertEqual(kwargs, {"params": {"format": "TMSL"}})
        self.assertEqual(args, ())
        return self.exported

    def query(self, method, url, body, **kwargs):
        self.assertEqual((method, url), ("POST", self.kql.base + "/v1/rest/query"))
        self.assertEqual(body["db"], self.by_kind["KQLDatabase"]["id"])
        table = next(table for table in sample.sample_tables() if body["csl"].startswith(table.name + " | project "))
        self.assertEqual(kwargs["request_timeout"], (30, 30))
        return {"Tables": [{"TableName": "PrimaryResult", "Columns": [
            {"ColumnName": name} for name, _ in table.columns
        ], "Rows": table.rows}]}

    def connect(self, server, catalog):
        connection = Mock()

        def execute(query):
            self.sql_queries.append(query)
            if query == "SELECT 1":
                return Mock(fetchone=Mock(return_value=(1,)))
            for table in sample.sample_tables():
                columns = ",".join(f"[{name}]" for name, _ in table.columns)
                if query == f"SELECT {columns} FROM [dbo].[{table.name}]":
                    return Mock(fetchall=Mock(return_value=table.rows))
            raise AssertionError(f"Unexpected SQL statement: {query}")

        connection.cursor.return_value.execute.side_effect = execute
        return connection

    def run_reuse(self):
        with ExitStack() as stack:
            stack.enter_context(patch("reuse_sources.check_local_dependencies"))
            stack.enter_context(patch("create_sample.Api", return_value=self.api))
            stack.enter_context(patch.object(sample.Provisioner, "kql_client", return_value=self.kql))
            stack.enter_context(patch.object(sample.Provisioner, "connect_sql", side_effect=self.connect))
            return reuse.reuse_workspace_sources(self.args, self.credential, self.api)

    def test_full_discovery_and_real_verifiers_use_only_read_operations(self):
        before = copy.deepcopy(self.items)
        state = self.run_reuse()
        self.assertEqual(self.items, before)
        self.assertEqual(state["status"], "succeeded")
        self.assertEqual(state["sourceMode"], "existing-workspace")
        self.assertEqual(state["workspaceName"], self.workspace["displayName"])
        self.assertEqual(state["capacityId"], GUID)
        self.assertEqual(len(state["items"]), 7)
        self.assertEqual(len(state["verified"]), 6)
        self.assertNotIn("SemanticModel", state["verified"])
        self.assertEqual(state["deferredValidation"], {"SemanticModel": ["refresh", "sampleRows"]})
        self.assertEqual(state["verifiedDefinitions"]["SemanticModel"]["tables"], 3)
        self.assertEqual(state["verificationSettleSeconds"], 0)
        self.assertNotIn("sourceLoadsCompleted", state)
        self.api.mutate.assert_called_once()
        self.assertEqual(len(self.sql_queries), 16)
        self.assertEqual(self.kql.json.call_count, 3)
        self.assertEqual(
            [call.args[0] for call in self.credential.get_token.call_args_list],
            [sample.SQL_SCOPE, "https://kusto.kusto.windows.net/.default"],
        )
        self.assertEqual(json.loads((self.folder / "sources.manifest.json").read_text())["status"], "succeeded")

    def test_multiple_candidates_require_explicit_selection(self):
        self.items.append({"id": str(UUID(int=200)), "type": "Lakehouse", "displayName": "AnotherLakehouse"})
        with self.assertRaisesRegex(ValueError, "SourceItemIds"):
            reuse.select_sources(self.api, GUID, {})
        self.api.mutate.assert_not_called()
        chosen = reuse.select_sources(self.api, GUID, {"Lakehouse": self.by_kind["Lakehouse"]["id"]})
        self.assertEqual(chosen["Lakehouse"]["id"], self.by_kind["Lakehouse"]["id"])

    def test_eventhouse_is_selected_from_kql_parent_not_arbitrary_container(self):
        other = str(UUID(int=200))
        self.items.append({"id": other, "type": "Eventhouse", "displayName": "OtherEventhouse"})
        chosen = reuse.select_sources(self.api, GUID, {})
        self.assertEqual(chosen["Eventhouse"]["id"], self.by_kind["Eventhouse"]["id"])
        with self.assertRaisesRegex(ValueError, "does not own"):
            reuse.select_sources(self.api, GUID, {"Eventhouse": other})

    def test_missing_source_invalid_selection_and_missing_parent_fail_before_verification(self):
        for change in ("missing", "selection", "parent", "duplicate"):
            with self.subTest(change=change):
                original = copy.deepcopy(self.items)
                parent = self.properties["KQLDatabase"]["parentEventhouseItemId"]
                if change == "missing":
                    self.items.remove(self.by_kind["Warehouse"])
                elif change == "parent":
                    self.properties["KQLDatabase"]["parentEventhouseItemId"] = str(UUID(int=999))
                elif change == "duplicate":
                    self.items.append(self.items[0])
                selections = {"Lakehouse": str(UUID(int=999))} if change == "selection" else {}
                with self.assertRaises(ValueError):
                    reuse.select_sources(self.api, GUID, selections)
                self.items = original
                self.properties["KQLDatabase"]["parentEventhouseItemId"] = parent
        self.api.mutate.assert_not_called()

    def test_workspace_identity_and_capacity_are_checked(self):
        for changes in ({"id": TARGET}, {"capacityId": None}, {"displayName": ""}):
            with self.subTest(changes=changes):
                original = self.workspace.copy()
                self.workspace.update(changes)
                with self.assertRaises(ValueError):
                    self.run_reuse()
                self.assertEqual(json.loads((self.folder / "sources.manifest.json").read_text())["status"], "failed")
                (self.folder / "sources.manifest.json").unlink()
                self.workspace = original
        self.args.capacity_id = TARGET
        with self.assertRaisesRegex(ValueError, "source capacity"):
            self.run_reuse()
        self.api.mutate.assert_not_called()

    def test_failed_schema_verification_is_persisted_and_no_data_reads_follow(self):
        self.exported = {"definition": {"parts": []}}
        with self.assertRaises(ValueError):
            self.run_reuse()
        state = json.loads((self.folder / "sources.manifest.json").read_text())
        self.assertEqual(state["status"], "failed")
        self.assertEqual(state["verified"], {})
        self.assertEqual(self.sql_queries, [])
        self.kql.json.assert_not_called()

    def test_wrong_sample_rows_fail_without_source_writes(self):
        self.kql.json.side_effect = None
        self.kql.json.return_value = {"Tables": [{"TableName": "PrimaryResult", "Columns": [], "Rows": []}]}
        with self.assertRaises(ValueError):
            self.run_reuse()
        state = json.loads((self.folder / "sources.manifest.json").read_text())
        self.assertEqual(state["status"], "failed")
        self.api.mutate.assert_called_once()
        self.assertEqual(self.sql_queries, [])


class ReuseArgumentsTests(unittest.TestCase):
    def test_skip_prompts_for_source_workspace_instead_of_capacity(self):
        with patch("builtins.input", side_effect=[GUID, GUID, TARGET]) as prompt:
            args = run_sample.arguments(["--skip-source-creation"])
        self.assertEqual(prompt.call_count, 3)
        self.assertIn("containing all sample sources", prompt.call_args_list[1].args[0])
        self.assertIsNone(args.capacity_id)
        self.assertEqual(args.source_workspace_id, GUID)

    def test_source_workspace_id_implies_reuse_and_offline_plan_has_no_authentication(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary) / "new-run"
            with patch("sample_auth.open_credential") as auth, patch("run_sample.run") as run:
                with redirect_stdout(io.StringIO()) as output:
                    run_sample.main([
                        "--tenant-id", GUID, "--workspace-id", TARGET, "--source-workspace-id", GUID,
                        "--run-directory", str(folder), "--source-item", f"Lakehouse={TARGET}",
                    ])
            plan = json.loads(output.getvalue())
            self.assertEqual(plan["sourceMode"], "existing-workspace")
            self.assertEqual(plan["sourceWorkspaceId"], GUID)
            self.assertEqual(plan["selectedSourceItems"], {"Lakehouse": TARGET})
            self.assertIsNone(plan["capacityId"])
            self.assertEqual(plan["verificationSettleSeconds"], 0)
            self.assertFalse(plan["createsSourceWorkspace"])
            self.assertFalse(plan["createsSourceItems"])
            self.assertFalse(folder.exists())
            auth.assert_not_called()
            run.assert_not_called()

    def test_conflicting_or_invalid_reuse_options_fail_before_prompts(self):
        for flags in (
            ["--skip-source-creation", "--sources-manifest", "input.json"],
            ["--skip-source-creation", "--source-workspace-name", "New"],
            ["--source-item", f"Lakehouse={GUID}"],
            ["--skip-source-creation", "--source-item", f"Unknown={GUID}"],
            ["--skip-source-creation", "--source-item", "Lakehouse=not-a-guid"],
            ["--skip-source-creation", "--source-item", f"Lakehouse={GUID}", "--source-item", f"Lakehouse={GUID}"],
        ):
            with self.subTest(flags=flags), patch("builtins.input") as prompt, patch("sys.stderr", io.StringIO()):
                with self.assertRaises(SystemExit):
                    run_sample.arguments(flags)
                prompt.assert_not_called()

    def test_source_and_target_cannot_be_same(self):
        with patch("sys.stderr", io.StringIO()), self.assertRaises(SystemExit):
            run_sample.arguments(["--tenant-id", GUID, "--workspace-id", GUID, "--source-workspace-id", GUID])


if __name__ == "__main__":
    unittest.main()
