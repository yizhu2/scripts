[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$SourcesManifest,
    [string]$Name = 'Ontology_AllSources_Sample',
    [string]$Manifest = 'ontology.manifest.json',
    [string]$OntologyId,
    [switch]$ExtendExisting,
    [string]$XmlaBase = 'powerbi://dailyapi.powerbi.com',
    [int]$Timeout = 1800,
    [string]$PythonPath = "$PSScriptRoot\.venv\Scripts\python.exe",
    [string]$ProfileModule = 'MicrosoftPowerBIMgmt.Profile',
    [switch]$Execute
)

$ErrorActionPreference = 'Stop'
$arguments = @(
    "$PSScriptRoot\create_ontology.py",
    '--sources-manifest', $SourcesManifest, '--name', $Name, '--manifest', $Manifest,
    '--xmla-base', $XmlaBase, '--timeout', "$Timeout", '--auth', 'powerbi-powershell'
)
if ($OntologyId) {
    $arguments += @('--ontology-id', $OntologyId)
}
if ($ExtendExisting) {
    $arguments += '--extend-existing'
}

# Validate the plan before sign-in; previews do not require the Power BI module.
& $PythonPath @arguments
if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
}
if (-not $Execute) {
    return
}
if (Test-Path -LiteralPath $Manifest) {
    throw 'The output manifest already exists. Inspect it and choose a new path before continuing.'
}
$source = Get-Content -LiteralPath $SourcesManifest -Raw -Encoding UTF8 | ConvertFrom-Json
Import-Module $ProfileModule -MinimumVersion 1.3.84 -ErrorAction Stop
MicrosoftPowerBIMgmt.Profile\Connect-PowerBIServiceAccount -Environment Public -Tenant $source.tenantId -ErrorAction Stop |
    Out-Null
$headers = MicrosoftPowerBIMgmt.Profile\Get-PowerBIAccessToken -ErrorAction Stop
try {
    $headers['Authorization'] | & $PythonPath @arguments --execute
    $result = $LASTEXITCODE
}
finally {
    $headers.Clear()
}
exit $result
