"""Create a source-separated Gen2 Ontology over an existing sample workspace."""

import argparse
import base64
import binascii
import copy
import json
import logging
import sys
import time
from contextlib import ExitStack, closing
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import quote, urlsplit
from uuid import UUID

from create_sample import Api, COLLECTIONS, Manifest, PBI_SCOPE, https_url, m_literal, sample_tables

LOG = logging.getLogger("ontology-sample")
GROUPS = ("Lakehouse", "MirroredDatabase", "SQLDatabase", "Warehouse", "SemanticModel", "KQLDatabase")


def token_claims(token):
    try:
        parts = token.split(".")
        if len(parts) != 3 or not all(parts):
            raise ValueError()
        payload = parts[1] + "=" * (-len(parts[1]) % 4)
        claims = json.loads(base64.b64decode(payload, altchars=b"-_", validate=True))
        if not isinstance(claims, dict):
            raise ValueError()
        return claims
    except (ValueError, binascii.Error, UnicodeDecodeError):
        raise ValueError("The authentication client returned a malformed access token") from None


def require_same_user(token, tenant_id, user_id):
    claims = token_claims(token)
    if (str(claims.get("tid", "")).lower() != tenant_id.lower()
            or str(claims.get("oid", "")).lower() != user_id.lower()):
        raise ValueError("Azure CLI and Power BI must be signed in as the same tenant and user")


class PowerBIPowerShellCredential:
    """Use the official Power BI client's delegated token, passed only over stdin."""

    def __init__(self, authorization, tenant_id):
        if not authorization.startswith("Bearer "):
            raise ValueError("Use create_ontology.ps1 to pass the Power BI authorization header over stdin")
        token = authorization.removeprefix("Bearer ").strip()
        claims = token_claims(token)
        if str(claims.get("tid", "")).lower() != tenant_id.lower():
            raise ValueError("Power BI sign-in tenant does not match the source manifest")
        self.user_id = claims.get("oid")
        if not isinstance(self.user_id, str) or not self.user_id:
            raise ValueError("Power BI sign-in returned no user object ID")
        if claims.get("aud") not in (PBI_SCOPE.removesuffix("/.default"), "00000009-0000-0000-c000-000000000000"):
            raise ValueError("Power BI sign-in returned an unexpected token audience")
        accepted_scopes = {"Dataset.Read.All", "Dataset.ReadWrite.All", "SemanticModel.Read.All",
                           "SemanticModel.ReadWrite.All", "Item.Read.All", "Item.ReadWrite.All"}
        if not accepted_scopes.intersection(str(claims.get("scp", "")).split()):
            raise ValueError("Power BI sign-in did not grant a required delegated dataset, semantic-model or item scope")
        expiry = claims.get("exp")
        if type(expiry) is not int:
            raise ValueError("Power BI token has no valid expiry")
        # These are routing/lifetime checks; the service validates the token's signature and permissions.
        self.access_token = SimpleNamespace(token=token, expires_on=expiry)
        self.get_token(PBI_SCOPE)

    def get_token(self, scope):
        if scope != PBI_SCOPE:
            raise ValueError("The Power BI credential cannot be used for another resource")
        if time.time() + 60 >= self.access_token.expires_on:
            raise RuntimeError("Power BI token expired or is about to expire; sign in again and inspect the manifest")
        return self.access_token


def verify_build_probe(response):
    import pyarrow as pa

    reader = pa.ipc.open_file if response.content.startswith(b"ARROW1") else pa.ipc.open_stream
    table = reader(pa.BufferReader(response.content)).read_all()
    if table.column_names != ["[Result]"] or table.num_rows != 1 or table.column(0)[0].as_py() != 1:
        raise ValueError("Semantic Model Build probe did not return the expected Arrow Result = 1")
    return {"result": 1}


def validate_inventory(state, *, allow_deferred_semantic=False):
    if state.get("status") != "succeeded":
        raise ValueError("A successful source manifest is required; do not replay failed source provisioning.")
    for field in ("tenantId", "capacityId", "workspaceId"):
        UUID(state[field])
    for kind in (*GROUPS, "Eventhouse"):
        UUID(state["items"][kind]["id"])
        if not state["items"][kind]["displayName"]:
            raise ValueError(f"Missing display name for {kind}")
    for kind in GROUPS:
        if (kind == "SemanticModel" and allow_deferred_semantic
                and kind not in state["verified"]
                and state.get("deferredValidation") == {"SemanticModel": ["refresh", "sampleRows"]}):
            continue
        expected = {t.name: len(t.rows) for t in sample_tables()}
        if state["verified"].get(kind) != expected:
            raise ValueError(f"{kind} has not passed sample-data verification")
    if not state.get("workspaceName"):
        raise ValueError("Missing workspaceName for the Semantic Model binding")
    for endpoint in ("fabric", "powerbi", "onelake"):
        https_url(state["endpoints"][endpoint])


def group_name(kind):
    return "EventhouseKQL" if kind == "KQLDatabase" else kind


def build_definition(state, metadata, xmla_base, *, groups=GROUPS):
    groups = tuple(groups)
    if not groups or len(set(groups)) != len(groups) or not set(groups).issubset(GROUPS):
        raise ValueError("Select unique supported source groups")
    model = {"expressions": [], "tables": [], "relationships": [],
             "namespaces": [{"name": "default", "lineageTag": "default"}],
             "entities": [], "entityRelationships": []}
    types = {"string": "string", "datetime": "dateTime", "double": "double"}
    for kind in groups:
        group = group_name(kind)
        item = state["items"][kind]
        properties = metadata[kind]
        identity = {
            "ONT_WorkspaceId": state["workspaceId"],
            "ONT_ItemId": item["id"],
            "ONT_ItemKind": "Dataset" if kind == "SemanticModel" else kind,
            "ONT_ItemName": item["displayName"],
            "ONT_WorkspaceName": state["workspaceName"],
        }
        expression_name = f"{group}_Source"
        if kind in ("Lakehouse", "MirroredDatabase"):
            root = properties["oneLakeTablesPath"].removesuffix("/Tables")
            expression = (f"let Source = AzureStorage.DataLake({m_literal(root)}, "
                          "[HierarchicalNavigation=true]) in Source")
        elif kind in ("SQLDatabase", "Warehouse"):
            server = properties["serverFqdn"] if kind == "SQLDatabase" else properties["connectionString"]
            catalog = properties["databaseName"] if kind == "SQLDatabase" else item["displayName"]
            expression = f"let Source = Sql.Database({m_literal(server)}, {m_literal(catalog)}) in Source"
            identity.update(ONT_SqlEndpoint=server, ONT_SqlDatabase=catalog)
        elif kind == "SemanticModel":
            xmla = f"{xmla_base}/v1.0/myorg/{quote(state['workspaceName'], safe='')}"
            expression = (
                f"let Source = AnalysisServices.Database({m_literal(xmla)}, {m_literal(item['id'])}), "
                'Cubes = Table.Combine(Source[Data]), Cube = Cubes{[Id="Model", Kind="Cube"]}[Data] in Cube')
        else:
            expression = None
        if expression:
            model["expressions"].append({"name": expression_name, "kind": "m", "expression": expression})

        for table in sample_tables():
            name = f"{group}_{table.name}"
            description = (f"{table.name} from {group}; source item {item['id']}. "
                           "Synthetic sample copy: do not sum this group with other source groups.")
            if kind == "KQLDatabase":
                source = {"type": "m", "expression":
                          f"let Source = AzureDataExplorer.Contents({m_literal(properties['queryServiceUri'])}, "
                          f"{m_literal(item['id'])}, {m_literal(table.name)}) in Source"}
            else:
                source = {"type": "entity", "entityName": table.name, "expressionSource": expression_name}
                if kind in ("SQLDatabase", "Warehouse", "MirroredDatabase"):
                    source["schemaName"] = "dbo"
            model["tables"].append({
                "name": name, "description": description,
                "columns": [{"name": column, "dataType": types[k], "sourceColumn": column,
                             **({"isKey": True, "isNullable": False} if i == 0 else {})}
                            for i, (column, k) in enumerate(table.columns)],
                "partitions": [{"name": name, "mode": "directLake" if kind in (
                    "Lakehouse", "MirroredDatabase") else "directQuery", "source": source,
                    "annotations": [{"name": key, "value": value} for key, value in identity.items()]}],
            })
            model["entities"].append({
                "name": name, "description": description, "backingTable": name,
                "keyProperties": [table.columns[0][0]],
                "properties": [{
                    "name": column, "dataType": types[k],
                    "backingConfiguration": {"type": "default", "valueColumn": {"table": name, "column": column}},
                } for column, k in table.columns],
            })
        for child, parent, key in (("Assets", "Plants", "PlantId"), ("Readings", "Assets", "AssetId")):
            name = f"{group}_{child}_to_{parent}"
            model["relationships"].append({
                "name": name, "fromTable": f"{group}_{child}", "fromColumn": key,
                "toTable": f"{group}_{parent}", "toColumn": key,
                "fromCardinality": "many", "toCardinality": "one", "crossFilteringBehavior": "oneDirection",
            })
            model["entityRelationships"].append({
                "name": name, "fromEntity": f"{group}_{child}", "toEntity": f"{group}_{parent}",
                "backingConfiguration": {"type": "relationship", "relationship": name},
            })
    return {"compatibilityLevel": 1000000, "model": model}


def entity_key_operation(entity):
    return {"alter": {"object": {"entity": entity["name"]},
                      "entity": {"keyProperties": list(entity["keyProperties"])}}}


def build_extension_script(definition, existing_expanded):
    model = definition["model"]
    existing = existing_expanded["model"]
    for collection in ("expressions", "tables", "relationships", "entities", "entityRelationships"):
        names = {entry["name"] for entry in existing.get(collection, [])}
        conflicts = names.intersection(entry["name"] for entry in model[collection])
        if conflicts:
            raise ValueError(f"Refusing to replace existing {collection}: {', '.join(sorted(conflicts))}")
    if not any(namespace["name"] == "default" for namespace in existing.get("namespaces", [])):
        raise ValueError("Append mode requires the existing default namespace")
    # Each table create projects its entity, but projection does not infer entity keys from column isKey.
    operations = [
        {"create": {kind: entry}}
        for collection, kind in (("expressions", "expression"), ("tables", "table"), ("relationships", "relationship"))
        for entry in model[collection]
    ]
    operations.extend(entity_key_operation(entity) for entity in model["entities"])
    return {"sequence": {"operations": operations}}


def verify_script_result(script, result):
    operations = script["sequence"]["operations"]
    results = result.get("results") if isinstance(result, dict) else None
    if not isinstance(results, list) or len(results) != len(operations):
        raise ValueError("The atomic script returned an unexpected number of operation results; inspect before retrying")
    for index, (operation, outcome) in enumerate(zip(operations, results)):
        if set(operation) == {"create"}:
            verb = "create"
            kind, entry = next(iter(operation["create"].items()))
            target = {kind: entry["name"]}
        elif set(operation) == {"alter"}:
            verb = "alter"
            target = operation["alter"]["object"]
        else:
            raise ValueError("Only create and alter script results are supported")
        if (not isinstance(outcome, dict) or outcome.get("opIndex") != index
                or outcome.get("verb") != verb or outcome.get("target") != target):
            raise ValueError(f"Unexpected atomic script result at operation {index}; inspect before retrying")


def verify_definition(expected, actual, *, allow_extra_named=False):
    """Check authored bindings and topology, tolerating server-generated metadata."""
    def contains(wanted, found, path):
        if isinstance(wanted, dict):
            if not isinstance(found, dict):
                raise ValueError(f"Definition mismatch at {path}")
            for key, value in wanted.items():
                if key not in found:
                    raise ValueError(f"Missing definition field {path}.{key}")
                contains(value, found[key], f"{path}.{key}")
        elif isinstance(wanted, list):
            model_collection = allow_extra_named and path.startswith("model.") and path.count(".") == 1
            annotations = path.endswith(".annotations")
            if not isinstance(found, list) or (not model_collection and not annotations and len(wanted) != len(found)):
                raise ValueError(f"Definition collection mismatch at {path}")
            if model_collection or (wanted and isinstance(wanted[0], dict) and "name" in wanted[0]):
                indexed = {entry["name"]: entry for entry in found}
                if len(indexed) != len(found):
                    raise ValueError(f"Duplicate definition names at {path}")
                for entry in wanted:
                    contains(entry, indexed.get(entry["name"]), f"{path}.{entry['name']}")
            else:
                for index, (left, right) in enumerate(zip(wanted, found)):
                    contains(left, right, f"{path}[{index}]")
        elif wanted != found:
            raise ValueError(f"Definition value mismatch at {path}: {wanted!r} != {found!r}")
    contains(expected["model"], actual["model"], "model")


def resolution_issues(definition):
    issues = []
    for table in definition["model"].get("tables", []):
        for partition in table.get("partitions", []):
            annotations = {entry["name"].upper(): entry["value"] for entry in partition.get("annotations", [])}
            status = annotations.get("ONT_RESOLVED_STATE")
            error = annotations.get("ONT_RESOLVED_ERROR", "")
            if (status is not None and status != "Resolved") or error:
                issues.append({"table": table["name"], "partition": partition["name"], "state": status,
                               "errors": [code.strip() for code in error.split(";") if code.strip()]})
    return issues


def verify_resolution_health(definition):
    issues = resolution_issues(definition)
    if issues:
        raise RuntimeError(
            "Current binding resolution is not healthy; this is not a stored-definition mismatch. "
            f"Retry a read, not ontology creation. Resolution issues: {json.dumps(issues)}")


def without_resolution_annotations(document):
    snapshot = copy.deepcopy(document)

    def strip(node):
        if isinstance(node, dict):
            if "annotations" in node:
                node["annotations"] = [
                    annotation for annotation in node["annotations"]
                    if not annotation["name"].upper().startswith("ONT_RESOLVED_")]
                if not node["annotations"]:
                    del node["annotations"]
            for value in node.values():
                strip(value)
        elif isinstance(node, list):
            for value in node:
                strip(value)

    strip(snapshot)
    return snapshot


def verify_existing_content(expected, actual):
    """Compare persisted content, checking current response-only resolver health separately."""
    verify_definition(without_resolution_annotations(expected), without_resolution_annotations(actual),
                      allow_extra_named=True)
    verify_resolution_health(actual)


def require_empty_definition(definition):
    for key, value in definition["model"].items():
        if key == "namespaces":
            if any(n["name"] != "default" or n.get("annotations") or n.get("description") for n in value):
                raise ValueError("Ontology contains authored namespaces; refusing to replace its definition")
        elif value:
            raise ValueError(f"Ontology contains {key}; refusing to replace its definition")


class MwcCredential:
    """Mint short-lived workload tokens in memory using the authenticated SSP."""

    def __init__(self, pbi, state, item_id, *, validate_host=None, token_version="v2"):
        if token_version not in ("v1", "v2"):
            raise ValueError("MWC token version must be v1 or v2")
        self.pbi = pbi
        self.capacity_id = state["capacityId"]
        self.body = {"workspaceObjectId": state["workspaceId"], "workloadType": "DO"}
        if token_version == "v1":
            self.body["capacityObjectId"] = self.capacity_id
            self.body["artifactObjectIds"] = [item_id]
        else:
            self.body["artifacts"] = [{"artifactType": "Ontology", "artifactObjectId": item_id}]
        self.endpoint = "/metadata/v201606/generatemwctoken" + ("v2" if token_version == "v2" else "")
        self.host = None
        self.token = None
        self.expires = 0
        self.validate_host = validate_host
        self.get_token("")

    def get_token(self, scope):
        if time.monotonic() >= self.expires:
            response = self.pbi.json("POST", self.pbi.base + self.endpoint, self.body)
            if not isinstance(response, dict):
                raise RuntimeError("MWC token response must be an object")
            host = response.get("TargetUriHost") or response.get("targetUriHost")
            token = response.get("Token") or response.get("token")
            if not host or not token:
                raise RuntimeError("MWC token response is missing token or routing host")
            if not isinstance(token, str) or not isinstance(host, str):
                raise RuntimeError("MWC token response has invalid token or routing host types")
            if any(char.isspace() for char in token):
                raise RuntimeError("MWC token response contains invalid token whitespace")
            https_url("https://" + host)
            if self.validate_host:
                self.validate_host(host)
            capacity = response.get("CapacityObjectId") or response.get("capacityObjectId")
            if capacity and str(capacity).lower() != self.capacity_id.lower():
                raise RuntimeError("MWC token capacity differs from the target workspace capacity; inspect routing")
            if self.host and self.host != host:
                raise RuntimeError("MWC routing host changed; stop instead of forwarding a token to another host")
            self.host, self.token = host, token
            self.expires = time.monotonic() + 240
        return SimpleNamespace(token=self.token)


def workload_api(pbi, state, item_id, timeout, *, validate_host=None, routing_mode="automatic", token_version="v2"):
    if routing_mode not in ("automatic", "direct"):
        raise ValueError("Workload routing mode must be automatic or direct")
    credential = MwcCredential(pbi, state, item_id, validate_host=validate_host, token_version=token_version)
    base = (f"https://{credential.host}/webapi/capacities/{state['capacityId']}"
            f"/workloads/DO/DigitalOperationsService/{routing_mode}")
    return Api(base, "", credential, timeout, auth_scheme="MwcToken")


def discover_sources(api, state):
    workspace_url = f"{api.base}/workspaces/{state['workspaceId']}"
    workspace = api.json("GET", workspace_url)
    if (workspace["capacityId"].lower() != state["capacityId"].lower()
            or workspace["displayName"] != state["workspaceName"]):
        raise ValueError("Workspace capacity or name changed since source provisioning")
    result = {}
    for kind in GROUPS:
        item = state["items"][kind]
        found = api.json("GET", f"{workspace_url}/{COLLECTIONS[kind]}/{item['id']}")
        if found["displayName"] != item["displayName"]:
            raise ValueError(f"{kind} was renamed since source provisioning")
        result[kind] = found.get("properties", {})
    if result["KQLDatabase"]["parentEventhouseItemId"].lower() != state["items"]["Eventhouse"]["id"].lower():
        raise ValueError("KQLDatabase does not belong to the expected Eventhouse")
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sources-manifest", type=Path, required=True)
    parser.add_argument("--name", default="Ontology_AllSources_Sample")
    parser.add_argument("--ontology-id", type=UUID, help="Reuse only an EMPTY Ontology with the supplied name")
    parser.add_argument("--extend-existing", action="store_true",
                        help="Append new groups atomically to --ontology-id; requires auto-projection")
    parser.add_argument("--manifest", type=Path, default=Path("ontology.manifest.json"))
    parser.add_argument("--xmla-base", default="powerbi://dailyapi.powerbi.com")
    parser.add_argument("--timeout", type=int, default=1800)
    parser.add_argument("--auth", choices=("azure-cli", "device-code", "powerbi-powershell"), default="azure-cli",
                        help="Use create_ontology.ps1 for official Power BI brokered authentication on Windows")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args(argv)
    if args.extend_existing and not args.ontology_id:
        parser.error("--extend-existing requires --ontology-id")
    state = json.loads(args.sources_manifest.read_text(encoding="utf-8-sig"))
    validate_inventory(state)
    xmla = urlsplit(args.xmla_base)
    if xmla.scheme != "powerbi" or not xmla.hostname or xmla.path or xmla.username or xmla.query or xmla.fragment:
        parser.error("--xmla-base must be a powerbi://hostname endpoint without path or credentials")
    if args.timeout <= 0 or not args.name.strip():
        parser.error("A positive timeout and nonempty item name are required")
    plan = {key: state[key] for key in ("tenantId", "capacityId", "workspaceId", "workspaceName", "endpoints")}
    plan.update({"ontologyName": args.name, "entityGroups": [group_name(k) for k in GROUPS],
                 "entityCount": 18, "relationshipCount": 12, "sourceManifest": str(args.sources_manifest.resolve()),
                 "authenticationMethod": args.auth, "xmlaBase": args.xmla_base,
                 "fabricAuthenticationMethod": "azure-cli" if args.auth == "powerbi-powershell" else args.auth,
                 "extendExisting": args.extend_existing,
                 "reuseOntologyId": str(args.ontology_id) if args.ontology_id else None})
    if not args.execute:
        print(json.dumps(plan, indent=2))
        return

    from azure.identity import AzureCliCredential, DeviceCodeCredential

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logging.getLogger("azure").setLevel(logging.WARNING)
    manifest = Manifest(args.manifest, plan)
    try:
        with ExitStack() as stack:
            manifest.step("Acquiring user access tokens")
            if args.auth == "powerbi-powershell":
                if sys.stdin.isatty():
                    raise ValueError("Run create_ontology.ps1; do not paste access tokens into the terminal")
                credential = PowerBIPowerShellCredential(sys.stdin.read().strip(), state["tenantId"])
                fabric_credential = stack.enter_context(AzureCliCredential(
                    tenant_id=state["tenantId"], process_timeout=60))
                require_same_user(fabric_credential.get_token(PBI_SCOPE).token, state["tenantId"], credential.user_id)
            elif args.auth == "device-code":
                credential = stack.enter_context(DeviceCodeCredential(
                    tenant_id=state["tenantId"], client_id="ea0616ba-638b-4df5-95b9-636659ae5121", timeout=900,
                    connection_timeout=20, read_timeout=30))
            else:
                credential = stack.enter_context(AzureCliCredential(tenant_id=state["tenantId"], process_timeout=60))
            if args.auth != "powerbi-powershell":
                fabric_credential = credential
            api = stack.enter_context(closing(Api(state["endpoints"]["fabric"], PBI_SCOPE, fabric_credential,
                                                 args.timeout, manifest.operation)))
            pbi = stack.enter_context(closing(Api(state["endpoints"]["powerbi"], PBI_SCOPE, credential, args.timeout)))
            credential.get_token(PBI_SCOPE)
            manifest.step("Authenticated; discovering sources without modifying their data")
            metadata = discover_sources(api, state)
            definition = build_definition(state, metadata, args.xmla_base)
            manifest.step("Checking Semantic Model Build-probe access before writing")
            probe = pbi.request(
                "POST", f"{pbi.base}/v1.0/myorg/datasets/{state['items']['SemanticModel']['id']}/executeDaxQueries",
                {"query": 'EVALUATE ROW("Result", 1)', "responseFormat": "arrow"})
            manifest.data["verified"]["semanticModelBuildProbe"] = verify_build_probe(probe)
            items_path = f"{api.base}/workspaces/{state['workspaceId']}/items"
            if args.ontology_id:
                manifest.step("Checking an existing Ontology" if args.extend_existing
                              else "Checking an existing empty Ontology")
                item = api.json("GET", f"{items_path}/{args.ontology_id}")
                if item.get("type") != "Ontology" or item.get("displayName") != args.name:
                    raise ValueError("Existing item must be an Ontology with the supplied name")
            else:
                manifest.step("Creating a new Ontology")
                item = api.mutate(items_path, {"displayName": args.name, "type": "Ontology"})
            if not item.get("id"):
                raise RuntimeError("Ontology creation returned no item id; inspect before retrying")
            manifest.data["items"]["Ontology"] = item
            manifest.save()
            workload = stack.enter_context(closing(workload_api(pbi, state, item["id"], args.timeout)))
            workload.operation_callback = manifest.operation
            path = f"{workload.base}/v4/workspaces/{state['workspaceId']}/ontologies/{item['id']}/definition"
            existing = workload.json("GET", path)
            manifest.data["authoredDefinition"] = definition
            if args.extend_existing:
                expanded_before = workload.json("GET", path, params={"expand": "true"})
                script = build_extension_script(definition, expanded_before)
                manifest.data.update({"beforeDefinition": existing, "beforeExpandedDefinition": expanded_before,
                                      "authoredScript": script})
                manifest.step("Appending new bindings atomically without replacing existing content")
                response = workload.request("POST", path + "/scripts", script, request_timeout=args.timeout)
                manifest.data["scriptResult"] = response.json()
                manifest.save()
                verify_script_result(script, manifest.data["scriptResult"])
            else:
                require_empty_definition(existing)
                manifest.step("Writing source bindings, entities, and relationships")
                workload.mutate(path, definition, result_required=False)
            stored = workload.json("GET", path)
            manifest.data["storedDefinition"] = stored
            manifest.save()
            if args.extend_existing:
                expanded = workload.json("GET", path, params={"expand": "true"})
                manifest.data["expandedDefinition"] = expanded
                manifest.save()
                verify_definition(definition, expanded, allow_extra_named=True)
                verify_existing_content(existing, stored)
                verify_existing_content(expanded_before, expanded)
                manifest.data["verified"]["existingContentPreserved"] = True
            else:
                verify_definition(definition, stored)
            manifest.data["verified"]["definition"] = {"entities": 18, "relationships": 12, "boundTables": 18}
            manifest.data["queryValidation"] = "Not performed; definition read-back is not a data-query test"
            manifest.data["status"] = "succeeded"
            manifest.step("Ontology definition and all authored bindings verified")
            LOG.info("Ontology id: %s", item["id"])
    except Exception as error:
        manifest.data.update({"status": "failed", "error": str(error)})
        manifest.save()
        LOG.exception("Ontology provisioning stopped. Resources were NOT deleted; inspect %s before retrying",
                      args.manifest)
        raise


if __name__ == "__main__":
    main()
