"""Read-only functional probes; source lineage is informational, not a pass gate."""

import json
from functools import partial

from create_ontology import resolution_issues
from validation_common import InvalidResponse

GROUPS = {
    "lakehouse": ("Lakehouse", "Lakehouse"),
    "kql": ("EventhouseKQL", "EventhouseKQL"),
    "warehouse": ("Warehouse", "Warehouse"),
    "sql": ("SQLDatabase", "SQLDatabase"),
    "mirror": ("MirroredDatabase", "MirroredDatabase"),
    "semantic": ("SemanticModel", "SemanticModel"),
    "sm-lakehouse": ("SemanticModel", "Lakehouse"),
    "sm-kql": ("SemanticModel", "EventhouseKQL"),
    "lakehouse-kql": ("Lakehouse", "EventhouseKQL"),
    "lakehouse-warehouse": ("Lakehouse", "Warehouse"),
}
EXPECTED = {"A012ReadingCount": 10, "TemperatureC": 32.9, "AssetId": "A012", "PlantId": "P03",
            "PlantName": "East Plant", "City": "Boston", "ReadingId": "R0120",
            "ObservedAt": "2026-01-01T00:45:00Z"}


def context(config, ontology_id=None, mode=0):
    return {"fabricOntology.context": json.dumps({
        "Intent": "", "WorkspaceId": config["workspace_id"],
        "OntologyId": ontology_id or config["ontology_id"], "CurrentOntologyVersion": "",
        "SelectedSources": [], "UploadedArtifacts": [], "MutationMode": mode,
        "MutationModeExplicit": True, "RequestedChangeScope": "",
    })}


def question(case):
    dimensions, readings = GROUPS[case]
    return (
        f"Read only {dimensions}_Plants, {dimensions}_Assets and {readings}_Readings in this ontology. "
        "Do not sum duplicate source groups. Execute supported read-only queries for the reading count "
        "of A012 and, separately, the global maximum temperature across ALL assets with its asset, plant, "
        "plant name, city, reading ID and UTC timestamp. Show actual execution results and source evidence. "
        "Do not change any data or definition. If execution fails or is unavailable, state that explicitly. "
        "Finish with one JSON object with these exact keys: " + ", ".join(EXPECTED) + ". "
        "Use numeric count/temperature and an ISO8601 UTC timestamp. Never guess missing values."
    )


def answer_check(text):
    decoder = json.JSONDecoder()
    candidates = []
    for offset, char in enumerate(text):
        if char != "{":
            continue
        try:
            value, _ = decoder.raw_decode(text[offset:])
        except ValueError:
            continue
        if isinstance(value, dict) and set(EXPECTED).issubset(value):
            candidates.append(value)
    if not candidates:
        return {"status": "UNVERIFIED", "reason": "No complete structured answer; review retained answer"}
    actual = candidates[-1]
    # These fixtures store UTC even when SQL/semantic results omit the timezone.
    timestamp = actual["ObservedAt"]
    normalization = None
    if isinstance(timestamp, str):
        from datetime import datetime, timezone
        try:
            parsed = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)
                normalization = {"input": timestamp, "assumedTimeZone": "UTC", "scope": "Known-UTC sample fixture"}
            actual["ObservedAt"] = parsed.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
        except ValueError:
            pass
    mismatches = {key: {"expected": expected, "actual": actual[key]} for key, expected in EXPECTED.items()
                  if actual[key] != expected}
    result = {"status": "FAIL" if mismatches else "PASS", "mismatches": mismatches, "actual": actual}
    if normalization is not None:
        result["timestampNormalization"] = normalization
    return result


def definition(ctx):
    with ctx.workload() as api:
        path = f"{api.base}/v4/workspaces/{ctx.config['workspace_id']}/ontologies/{ctx.config['ontology_id']}"
        value = ctx.request(api, "GET", path + "/definition", params={"expand": "true"})
    if not isinstance(value, dict) or not isinstance(value.get("model"), dict):
        raise ValueError("Definition response did not contain a model object")
    issues = resolution_issues(value)
    ctx.save_evidence("definition", value)
    return {"status": "PARTIAL" if issues else "PASS",
            "summary": "Definition read; resolver warnings do not gate independent scenarios",
            "evidence": {"resolverIssues": issues, "scope": "Definition only, not a data-read pass"}}


def ontology(ctx, case):
    with ctx.workload() as api:
        path = f"{api.base}/v4/workspaces/{ctx.config['workspace_id']}/ontologies/{ctx.config['ontology_id']}"
        conversation = ctx.request(api, "POST", path + "/conversations", {
            "mode": "fabricOntology", "initialMessage": {
                "role": "user", "contents": [{"$type": "text", "text": question(case)}]},
            "additionalContext": context(ctx.config)})
        conversation_id = conversation.get("id")
        if not conversation_id:
            raise RuntimeError("Conversation response omitted id")
        ctx.state.setdefault("conversations", []).append(conversation_id)
        ctx.save_evidence("conversation", conversation)
        conversation_path = path + "/conversations/" + conversation_id
        current = ctx.poll_conversation(api, conversation_path)
        messages = ctx.request(api, "GET", conversation_path + "/messages", params={"stream": "false"})
    ctx.save_evidence("messages", messages)
    entries = messages if isinstance(messages, list) else messages.get("value", messages.get("messages", []))
    texts = [content["text"] for entry in entries if entry.get("role") == "assistant"
             for content in entry.get("contents", []) if content.get("$type") == "text"
             and isinstance(content.get("text"), str)]
    check = answer_check("\n".join(texts))
    failed = str(current.get("status", "")).lower() in ("failed", "cancelled", "canceled")
    return {
        "status": "FAIL" if failed else ("PARTIAL" if check["status"] == "UNVERIFIED" else check["status"]),
        "summary": f"Conversation {current.get('status')}; answer check {check['status']}; "
                   "independent source lineage is informational only",
        "evidence": {"conversationId": conversation_id, "terminal": current.get("status"),
                     "answerCheck": check, "answer": "\n".join(texts),
                     "executionVerified": False, "sourceEvidenceRequired": False,
                     "networkEnforcementVerified": False},
    }


def mcp(ctx, case):
    path = (f"{ctx.fabric.base}/mcp/dataPlane/workspaces/{ctx.config['workspace_id']}"
            f"/items/{ctx.config['ontology_id']}/ontologyEndpoint")
    for request_id, method, params in (
        (1, "initialize", {"protocolVersion": "2025-06-18", "capabilities": {},
                           "clientInfo": {"name": "OntologySampleValidation", "version": "1"}}),
        (2, "tools/list", {}),
        (3, "tools/call", {"name": "ask_ontology", "arguments": {"request": question(case)}}),
    ):
        data = ctx.request(ctx.fabric, "POST", path,
                           {"jsonrpc": "2.0", "id": request_id, "method": method, "params": params})
        if not isinstance(data, dict) or data.get("id") != request_id or "error" in data or "result" not in data:
            raise InvalidResponse("Invalid/failed JSON-RPC response; see HTTP evidence")
        result = data["result"]
        if not isinstance(result, dict):
            raise InvalidResponse("JSON-RPC result must be an object")
        if result.get("isError"):
            return {"status": "FAIL", "summary": "MCP tool returned isError",
                    "evidence": {"result": result}}
    texts = [part["text"] for part in result.get("content", [])
             if part.get("type") == "text" and isinstance(part.get("text"), str)]
    if not any(text.strip() for text in texts):
        raise InvalidResponse("MCP returned no usable text content")
    check = answer_check("\n".join(texts))
    return {"status": "PARTIAL" if check["status"] == "UNVERIFIED" else check["status"],
            "summary": f"MCP delivered an answer; fixture check {check['status']}; source lineage is informational only",
            "evidence": {"answerCheck": check, "result": result, "executionVerified": False,
                         "sourceEvidenceRequired": False}}


SCENARIOS = {"ontology.definition": definition}
SCENARIOS.update({f"ontology.{case}": partial(ontology, case=case) for case in GROUPS})
SCENARIOS.update({f"mcp.{case}": partial(mcp, case=case) for case in GROUPS})
