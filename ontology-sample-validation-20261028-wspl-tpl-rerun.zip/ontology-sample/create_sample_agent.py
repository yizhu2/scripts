"""Create an unpublished Data Agent or stopped Operations Agent over existing Daily sample resources."""

import argparse
import base64
import json
import logging
import re
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
from uuid import UUID

from create_ontology import validate_inventory
from create_sample import Api, Manifest, PBI_SCOPE, sample_tables
from create_semantic_ontology import verify_source_schema
from run_sample import workspace_items
from sample_auth import open_credential

LOG = logging.getLogger("ontology-sample")
SCHEMA = "https://developer.microsoft.com/json-schemas/fabric/item/dataAgent/definition"
COLLECTIONS = {"data": ("DataAgent", "dataAgents"), "operations": ("OperationsAgent", "operationsAgents")}


def documents(kind, state, ontology_id=None, ontology_workspace_id=None):
    if kind == "data":
        return {
            "Files/Config/data_agent.json": {"$schema": SCHEMA + "/dataAgent/2.1.0/schema.json"},
            "Files/Config/draft/stage_config.json": {
                "$schema": SCHEMA + "/stageConfiguration/1.0.0/schema.json",
                "aiInstructions": (
                    "Answer from the connected synthetic Plants, Assets and Readings semantic model. "
                    "Join Assets.PlantId to Plants.PlantId and Readings.AssetId to Assets.AssetId. "
                    "Report temperatures in Celsius and timestamps in UTC. Cite the source and do not invent results."
                ),
            },
            "Files/Config/draft/semantic-model-SampleModel/datasource.json": {
                "$schema": SCHEMA + "/dataSource/1.0.0/schema.json",
                "artifactId": state["items"]["SemanticModel"]["id"], "workspaceId": state["workspaceId"],
                "displayName": "SampleModel", "type": "semantic_model",
                "elements": [
                    {"display_name": table.name, "type": "semantic_model.table", "is_selected": True}
                    for table in sample_tables()
                ],
            },
        }
    if kind != "operations" or not ontology_id or not ontology_workspace_id:
        raise ValueError("Operations Agent requires an explicit ontology and its workspace")
    return {"Configurations.json": {
        "configuration": {
            "instructions": (
                "Use the connected ontology to inspect Plants, Assets and Readings. "
                "The source groups contain identical synthetic copies, not different assets. "
                "Use one source group at a time and never sum duplicates across groups. "
                "Temperatures are Celsius and timestamps UTC. This agent must remain stopped until reviewed."
            ),
            "dataSources": {"businessOntology": {
                "id": ontology_id, "type": "Ontology", "workspaceId": ontology_workspace_id,
            }},
            "actions": {},
        },
        "playbook": {},
        "shouldRun": False,
    }}


def definition(parts):
    return {"definition": {"parts": [
        {"path": path, "payloadType": "InlineBase64",
         "payload": base64.b64encode(json.dumps(value).encode("utf-8")).decode("ascii")}
        for path, value in parts.items()
    ]}}


def verify_documents(kind, expected, exported, item):
    actual = {}
    seen = set()
    for part in exported["definition"]["parts"]:
        path = part["path"]
        if path.casefold() in seen:
            raise ValueError(f"Duplicate definition part: {path}")
        seen.add(path.casefold())
        if path == ".platform":
            continue
        if "/published/" in path.casefold() or path.casefold().endswith("/publish_info.json"):
            raise ValueError("Unexpected published Data Agent state")
        if part["payloadType"] != "InlineBase64":
            raise ValueError(f"Unsupported definition payload: {path}")
        actual[path] = json.loads(base64.b64decode(part["payload"], validate=True))
        if kind == "data" and path.endswith("/datasource.json"):
            elements = actual[path].get("elements")
            if not isinstance(elements, list) or not all(isinstance(element, dict) for element in elements):
                raise ValueError("Data Agent must retain explicit table selections")
            # Public export adds null metadata and an empty child list to each selected table.
            for element in elements:
                for field in ("id", "description"):
                    if element.get(field) is None:
                        element.pop(field, None)
                if element.get("children") == []:
                    element.pop("children")

    def contains(expected_value, actual_value, path):
        if isinstance(expected_value, dict):
            if not isinstance(actual_value, dict):
                raise ValueError(f"Expected JSON object at {path}")
            for key, value in expected_value.items():
                if key not in actual_value:
                    raise ValueError(f"Missing definition value at {path}/{key}")
                contains(value, actual_value[key], path + "/" + key)
        elif type(expected_value) is not type(actual_value) or expected_value != actual_value:
            raise ValueError(f"Definition value mismatch at {path}")

    contains(expected, actual, "definition")
    if set(actual) != set(expected):
        raise ValueError("Unexpected additional agent configuration parts; inspect the exported definition")
    if kind == "operations":
        configuration = actual["Configurations.json"]
        if (configuration["shouldRun"] is not False or configuration["playbook"] != {}
                or configuration["configuration"]["actions"] != {}
                or configuration["configuration"]["dataSources"] != expected["Configurations.json"]["configuration"]["dataSources"]
                or configuration["configuration"].get("messageDestination") is not None):
            raise ValueError("Operations Agent must remain stopped with no playbook, actions or message destination")
        if item.get("properties", {}).get("state") != "Inactive":
            raise ValueError("Operations Agent did not report Inactive state")
    return {"definitionMatches": True, "published": False} if kind == "data" else {
        "definitionMatches": True, "state": "Inactive", "shouldRun": False, "actions": 0,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--kind", choices=tuple(COLLECTIONS), required=True)
    parser.add_argument("--sources-manifest", type=Path, required=True)
    parser.add_argument("--workspace-id", type=UUID, help="Agent workspace; defaults to source workspace")
    parser.add_argument("--ontology-id", type=UUID, help="Required for Operations Agent")
    parser.add_argument("--ontology-workspace-id", type=UUID, help="Defaults to agent workspace")
    parser.add_argument("--unconfigured", action="store_true",
                        help="Operations Agent only: create an empty, inactive artifact without ontology/playbook")
    parser.add_argument("--name", required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--auth", choices=("auto", "cli", "browser"), default="auto")
    parser.add_argument("--client-id", type=UUID)
    parser.add_argument("--item-id", type=UUID, help="Only with --verify-only")
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--timeout", type=int, default=1800)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args(argv)
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,88}", args.name) or args.timeout < 30:
        parser.error("Name must start with a letter, use letters/digits/underscores, be under 90 characters; timeout >=30")
    if args.verify_only != bool(args.item_id):
        parser.error("--item-id and --verify-only must be supplied together")
    if args.unconfigured and (args.kind != "operations" or args.ontology_id or args.ontology_workspace_id):
        parser.error("--unconfigured is Operations Agent only and cannot include an ontology reference")
    if (args.kind == "operations" and not args.ontology_id and not args.unconfigured
            or args.kind == "data" and (args.ontology_id or args.ontology_workspace_id)):
        parser.error("Only Operations Agent requires --ontology-id and accepts --ontology-workspace-id")
    state = json.loads(args.sources_manifest.read_text(encoding="utf-8-sig"))
    validate_inventory(state)
    if state["endpoints"]["fabric"].rstrip("/") != "https://dailyapi.fabric.microsoft.com/v1":
        parser.error("This companion targets normal Daily only")
    target_id = str(args.workspace_id or state["workspaceId"])
    ontology_workspace = str(args.ontology_workspace_id or target_id)
    item_type, collection = COLLECTIONS[args.kind]
    expected = {} if args.unconfigured else documents(
        args.kind, state, str(args.ontology_id) if args.ontology_id else None, ontology_workspace)
    plan = {
        "tenantId": state["tenantId"], "workspaceId": target_id, "itemType": item_type, "itemName": args.name,
        "sourceManifest": str(args.sources_manifest.resolve()), "endpoints": state["endpoints"],
        "operation": "verify-only" if args.verify_only else "create", "authoredDocuments": expected,
        "configurationMode": "unconfigured" if args.unconfigured else "configured",
        "queryValidation": "Not performed; this creates configuration only, without publishing or monitoring",
    }
    if not args.execute:
        print(json.dumps(plan, indent=2))
        return
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logging.getLogger("azure").setLevel(logging.WARNING)
    manifest = Manifest(args.manifest, plan)
    try:
        with open_credential(state["tenantId"], mode=args.auth,
                             client_id=str(args.client_id) if args.client_id else None) as credential, \
                closing(Api(state["endpoints"]["fabric"], PBI_SCOPE, credential, args.timeout, manifest.operation)) as api:
            target = f"{api.base}/workspaces/{target_id}"
            manifest.step("Checking capacity, source identities and item name")
            if not api.json("GET", target).get("capacityId"):
                raise ValueError("Agent workspace requires Fabric capacity")
            if args.verify_only:
                item = api.json("GET", f"{target}/items/{args.item_id}")
                if item.get("type") != item_type or item.get("displayName") != args.name:
                    raise ValueError("Verification target type or name does not match")
            elif any(item["displayName"].casefold() == args.name.casefold() for item in workspace_items(api, target)):
                raise ValueError("Item name already exists; use read-only verification instead of creating duplicates")
            if args.kind == "data":
                source = f"{api.base}/workspaces/{state['workspaceId']}/semanticModels/{state['items']['SemanticModel']['id']}"
                source_item = api.json("GET", source)
                if source_item["displayName"] != state["items"]["SemanticModel"]["displayName"]:
                    raise ValueError("Source semantic model was renamed")
                exported = api.mutate(source + "/getDefinition", params={"format": "TMSL"})
                manifest.data["sourcePublicDefinition"] = exported
                manifest.save()
                manifest.data["verified"]["sourceSchema"] = verify_source_schema(exported)
            elif not args.unconfigured:
                source = f"{api.base}/workspaces/{ontology_workspace}/items/{args.ontology_id}"
                source_item = api.json("GET", source)
                if source_item.get("type") != "Ontology":
                    raise ValueError("Operations Agent source must be an Ontology")
            if not args.unconfigured:
                manifest.data["sourceItem"] = source_item
            if not args.verify_only:
                manifest.step(f"Creating {item_type} without publishing or starting it")
                item = api.mutate(target + "/" + collection, {
                    "displayName": args.name, "description": "Synthetic sample agent; not published or started.",
                    **({} if args.unconfigured else definition(expected)),
                })
                if not item.get("id"):
                    raise RuntimeError("Create returned no item ID; inspect the operation before retrying")
                manifest.data["writeCompleted"] = True
            manifest.data["items"][item_type] = item
            manifest.save()
            path = target + "/" + collection + "/" + item["id"]
            manifest.step("Reading back agent properties" if args.unconfigured else "Reading back agent properties and definition")
            item = api.json("GET", path)
            manifest.data["items"][item_type] = item
            if item.get("type") != item_type or item.get("displayName") != args.name:
                raise ValueError("Returned agent identity does not match")
            if args.unconfigured:
                if item.get("properties", {}).get("state") != "Inactive":
                    raise ValueError("Unconfigured Operations Agent did not report Inactive state")
                manifest.data["verified"][item_type] = {
                    "state": "Inactive", "sourceAttached": False, "configurationVerified": False,
                }
            else:
                exported = api.mutate(path + "/getDefinition")
                manifest.data["storedPublicDefinition"] = exported
                manifest.save()
                manifest.data["verified"][item_type] = verify_documents(args.kind, expected, exported, item)
            manifest.data["status"] = "succeeded"
            manifest.data["completedUtc"] = datetime.now(timezone.utc).isoformat()
            manifest.step("Inactive artifact verified; no ontology attached or playbook configured" if args.unconfigured
                          else "Agent configuration verified; queries, publishing and monitoring were not performed")
    except (Exception, KeyboardInterrupt) as error:
        manifest.data.update(status="failed", error=str(error))
        manifest.save()
        LOG.exception("Stopped; inspect %s before retrying. No artifacts were deleted or overwritten.", args.manifest)
        raise


if __name__ == "__main__":
    main()
