# Advanced source scripts and validation history

For the packaged, interactive cross-workspace workflow, start with [README.md](README.md)
and [Start-Sample.ps1](Start-Sample.ps1). This reference retains the individual
scripts, historical internal-authentication attempts, and earlier live evidence.

**Creates a new workspace and seven source item types, then loads and verifies
related synthetic data.** Supports normal Daily and existing Private Link
connectivity; this tool does not configure private endpoints, workspace network policies, or DNS.
An Eventhouse is the container for the populated KQL database, not a second copy
of its data.

Entry point: [create_sample.py](create_sample.py). Dependencies:
[requirements.txt](requirements.txt). Tests: [test_create_sample.py](test_create_sample.py).

## What you get

| Item | Data loading | Verification |
|---|---|---|
| Eventhouse + KQL database | `.set` from typed KQL `datatable` literals | Query every row through KQL |
| Lakehouse | Upload typed Parquet to Files; Load Table API creates Delta tables | Query every row through SQL analytics endpoint |
| Mirrored database | Open Mirroring, no external database required | Wait for replicated rows through SQL analytics endpoint |
| Semantic model | Inline Power Query import partitions, two many-to-one relationships | Refresh this specific model; DAX-query every row |
| SQL database | Parameterized T-SQL inserts into new tables | Query every row |
| Warehouse | Parameterized T-SQL inserts into new tables | Query every row |

Every data-bearing item has **Plants (3 rows), Assets (12), Readings (120)**.
Relationships: `Assets.PlantId -> Plants.PlantId` and
`Readings.AssetId -> Assets.AssetId`. IDs and values are identical across sources.
Readings contain UTC timestamps starting at 2026-01-01, every five minutes, plus
temperature measurements. Source tables have stable unique keys; the script
does not add SQL key constraints. Relationships are explicit in the semantic
model and represented by matching foreign-key values in the other sources.
Parquet timestamps are explicitly UTC-adjusted. Timezone-naive Parquet was
observed to load as Delta `timestamp_ntz`, causing the SQL analytics endpoint
to omit `ObservedAt`; UTC adjustment preserves a queryable `datetime2` column.

The source script does **not** create an Ontology item. For an existing Gen2
ontology, use [replace_ontology.py](replace_ontology.py) to populate source-separated
entity groups through the public API. The older [create_ontology.py](create_ontology.py)
internal-route companion is documented separately below with its remaining
limitations. Source creation alone is not proof of working Ontology bindings or
agent readiness.
Semantic models use the core Fabric Items creation API with `type: SemanticModel`.
In local Daily validation, the typed semantic-model creation route reported a
failed operation despite a successful underlying import; the core route returned
a successful operation for the same definition.

## Prerequisites

- Python 3.10+ and Azure CLI.
- [Microsoft ODBC Driver 18 for SQL Server](https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server).
- A **Daily** tenant and existing active Fabric capacity with all requested
  workloads enabled. The caller needs workspace-creation permission and capacity
  assignment rights. The created workspace gives the caller ownership.
- A user identity with the relevant Fabric item permissions, Power BI model
  creation/refresh/Build permissions, OneLake writes, and SQL/KQL data access.
  The tenant must allow the Power BI **Dataset Execute Queries REST API**.
  This script intentionally uses a tenant-specific `AzureCliCredential`; it
  neither accepts tokens on the command line nor writes tokens to disk.
- Run from a machine on the approved VNet/VPN with the correct private DNS.
  HTTPS access is needed for Entra, Fabric, Power BI, OneLake, and KQL.
  SQL connections need **TDS**, not HTTPS, over TCP 1433 (plus any SQL routing
  requirements for your environment).

**Important:** existing tenant-level Private Link connectivity does not
automatically configure workspace-level Private Link on a new workspace.
If your policy requires workspace-specific private endpoints or associations,
have your network administrator establish that workflow first. The script does
not disable Block Public Access, add network exceptions, forge service access
headers, or fall back to public endpoints. DNS routing/private-IP enforcement
is the responsibility of the existing network setup.

## Run from PowerShell

From this directory:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r .\requirements.txt
az login --tenant '<daily-tenant-guid>' --allow-no-subscriptions

$sampleArgs = @(
    '--tenant-id', '<daily-tenant-guid>',
    '--capacity-id', '<daily-capacity-guid>',
    '--workspace-name', "OntologySources_$(Get-Date -Format yyyyMMdd_HHmmss)",
    '--manifest', '.\daily-sample.manifest.json'
)

# Offline preview: no tokens, resource changes, or manifest writes.
.\.venv\Scripts\python.exe .\create_sample.py @sampleArgs

# Creates billable resources. Add endpoint overrides here if needed.
.\.venv\Scripts\python.exe .\create_sample.py @sampleArgs --execute
```

No sample credentials or environment-specific IDs are embedded in the script.
The CLI uses production Entra authentication and the non-`-int` Power BI token
audience for Daily. Do not use this Daily tool against production.

### Daily / Private Link endpoint overrides

Defaults follow the backend repository's
[Fabric environment registry](https://dev.azure.com/powerbi/MWC/_git/workload-digitaloperations?path=/tools/AIQuestion/aiquestion/fabric/constants.py&version=GBmaster).
The small standalone tool uses the same endpoint/auth conventions without
depending on the larger AIQuestion application or its internal helper APIs.

| Option | Default / discovery |
|---|---|
| `--fabric-api` | `https://dailyapi.fabric.microsoft.com/v1` |
| `--powerbi-api` | `https://wabi-daily-us-east2-redirect.analysis.windows.net` |
| `--onelake-url` | `https://daily-onelake.dfs.fabric.microsoft.com` |
| `--kql-endpoint` | KQL database GET `properties.queryServiceUri` |
| `--kusto-scope` | `https://kusto.kusto.windows.net/.default` |
| `--sql-endpoints` | SQL item GET connection metadata; see below |

Use the **documented connection URLs for your Daily Private Link setup**, not an
arbitrary public endpoint or guessed `privatelink` hostname. OneLake accepts an
origin template containing `{workspaceId}` when the administrator has configured
workspace-scoped routing. It still requires the new workspace's network
association to exist; the template alone does not create it.

SQLDatabase uses returned `serverFqdn` and `databaseName`. Warehouse, Lakehouse,
and MirroredDatabase use their item display name as the SQL catalog and their
returned SQL endpoint host. If Daily exposes a different catalog/host, pass the
actual SQL connection details as a JSON map; for example:

```powershell
$sql = @{
    MirroredDatabase = @{
        server = '<actual-private-sql-fqdn>'
        catalog = '<actual-sql-catalog>'
    }
} | ConvertTo-Json -Compress

.\.venv\Scripts\python.exe .\create_sample.py @sampleArgs --sql-endpoints $sql --execute
```

Endpoint override keys are `Lakehouse`, `MirroredDatabase`, `SQLDatabase`, and
`Warehouse`; each allows `server`, `catalog`, or both. The default item names are
`OntologySample_<ItemType>`; change `--prefix` if needed.

## Recommended: replace an existing Ontology through the public API

[replace_ontology.py](replace_ontology.py) uses the documented Fabric
`getDefinition` and `updateDefinition` APIs with the existing Azure CLI sign-in.
**It does not acquire an MWC token or require the Power BI PowerShell module.**
It replaces the selected ontology's entire definition, including any `test`
entity, without changing the seven populated source items. This also avoids
creating another ontology and its Eventhouse/Graph child resources.

Prerequisites:

- All seven source types have passed verification in the source manifest.
- The target is an existing Gen2 ontology, and its ID and exact display name are
  supplied explicitly. The caller needs the public API's required permissions.
- Python dependencies are installed. Version 7 generates and reads this sample's
  TMDL directly; no AS SDK, PowerShell serializer, or internal feed is required.

```powershell
$replaceArgs = @(
    '--sources-manifest', '.\daily-sample.manifest.json',
    '--ontology-id', '<existing-ontology-id>',
    '--name', '<exact-existing-ontology-display-name>',
    '--manifest', '.\ontology-replacement.manifest.json'
)

# Offline preview: no authentication.
.\.venv\Scripts\python.exe .\replace_ontology.py @replaceArgs

# Replace the definition and independently read it back.
.\.venv\Scripts\python.exe .\replace_ontology.py @replaceArgs --execute

# Later, verify again WITHOUT another replacement, using a fresh output manifest.
.\.venv\Scripts\python.exe .\replace_ontology.py @replaceArgs `
    --manifest .\ontology-verification.manifest.json --verify-only --execute
```

The script discovers the actual source metadata, generates all six source groups,
and uses [sample_tmdl.py](sample_tmdl.py) to serialize and round-trip the
sample's Gen2 definition before sending it.
The manifest retains the old public definition, submitted parts, write completion,
and read-back evidence. Temporary serializer files are cleaned up automatically.
It does not modify the item's name or `.platform` metadata.

Verification checks 18 entities, their keys and property bindings, 18 bound tables,
and 12 table/entity relationships. Public export uses a portable ALM representation:
SQL connections can contain `ONT_ALM_SQL_*` markers instead of runtime hostnames,
and default projected entity properties/descriptions may be omitted. Verification
checks the markers against the intended workspace/item identity or relative
Warehouse name and checks all backing columns; it does not accept arbitrary
markers, missing entities, changed keys, or changed bindings.

There is no automatic rollback or mutation replay. If `writeCompleted` is true but
read-back fails, use `--verify-only` with a fresh manifest rather than replacing
again. A successful definition check is **not** a graph refresh, data-query,
Operations Agent, or Data Agent sign-off.

## Advanced: internal Ontology API workflow

**Internal-route status (2026-10-22): not end-to-end validated.** The official
Power BI client passes the semantic-model query probe, but Daily rejects its
internal MWC token exchange with HTTP 401. The append attempt stopped before
submitting a script. A supported client/configuration authorized for both
operations is still required; the examples below do not imply live completion.

Run [create_ontology.py](create_ontology.py) after **all seven** source types have
passed verification. It reads the successful source manifest, discovers actual
item connection metadata, and creates a new Gen2 Ontology in that workspace.
It does not modify, reload, or recreate any source data.

```powershell
$ontologyArgs = @(
    '--sources-manifest', '.\daily-sample.manifest.json',
    '--name', 'Ontology_AllSources_Sample',
    '--manifest', '.\ontology.manifest.json'
)

# Offline plan.
.\.venv\Scripts\python.exe .\create_ontology.py @ontologyArgs

# For Windows execution, use the official Power BI authentication launcher below.
```

Install Microsoft's Power BI Profile module once, then run the launcher from a
**normal PowerShell window** on your managed Windows device:

```powershell
Install-Module MicrosoftPowerBIMgmt.Profile -RequiredVersion 1.3.84 -Scope CurrentUser -Repository PSGallery

# Keep Azure CLI signed in as the same work account used in the Power BI prompt.
.\create_ontology.ps1 `
    -SourcesManifest .\daily-sample.manifest.json `
    -Name Ontology_AllSources_Sample `
    -Manifest .\ontology.manifest.json `
    -Execute
```

Without `-Execute`, the launcher prints an offline plan without authentication.
Use `-PythonPath` for a virtual environment outside this directory, and
`-ProfileModule` for an isolated installation of the official module. The
Windows broker needs a parent window: a headless agent terminal can fail with
`A window handle must be configured`. Run the launcher in a normal console;
do not disable the broker or switch to device-code to avoid a device policy.

The definition contains **18 entities, 18 bound tables, and 12 relationships**:

| Entity prefix | Binding |
|---|---|
| `Lakehouse_` | OneLake Delta tables, Direct Lake |
| `MirroredDatabase_` | Mirrored OneLake Delta tables in `dbo`, Direct Lake |
| `SQLDatabase_` | Discovered SQL database endpoint/catalog, DirectQuery |
| `Warehouse_` | Discovered Warehouse SQL endpoint/catalog, DirectQuery |
| `SemanticModel_` | DirectQuery to the existing Semantic Model |
| `EventhouseKQL_` | Kusto tables in the KQL database inside the Eventhouse |

Each group has `Plants`, `Assets`, and `Readings`, with many-to-one relationships
from Assets to Plants and Readings to Assets. IDs repeat across groups because
these are **copies for source-comparison testing**, not extra real-world objects.
Eventhouse and KQL are one group, not two copies. Descriptions explicitly warn
agents not to add the identical copies together.

The companion uses the deployed **internal V4 TMSL++ API** and exchanges the
user token for an MWC token in memory. This requires the Gen2 Ontology features
to be enabled in the target Daily tenant. The XMLA default is
`powerbi://dailyapi.powerbi.com`; override `--xmla-base` only with the documented
endpoint for your environment. Its endpoint may differ from the Fabric REST host.

**Authentication:** the Windows launcher uses two clients for the same user:

- Azure CLI handles Fabric item discovery and provisioning, as in the source
  script. Power BI's client does not grant the Fabric Lakehouse API scopes.
- Microsoft's official `MicrosoftPowerBIMgmt.Profile` client handles the
  semantic-model query probe and attempts the MWC token exchange. It signs in
  using the Windows broker and supplies delegated dataset scopes. Those scopes
  do **not** by themselves authorize the internal token-exchange endpoint:
  the latter returned HTTP 401 in the local Daily append attempt.

Both identities must match the source manifest's tenant and each other's user
object ID. The Power BI token travels to Python through stdin, never a command-line
argument, token file, environment variable, or manifest. Its lifetime is checked
before requests; an expiring token stops the run instead of silently switching
credentials. The Public authentication environment is intentional: normal Daily
uses production Entra and the Power BI audience; resource calls use the Daily
endpoints recorded in the source manifest.

Binding a Semantic Model requires the backend's `executeDaxQueries` Build probe.
Ordinary `executeQueries` success is not sufficient. The local Azure CLI token
had only `user_impersonation`; AS rejected its client/scope combination **before
evaluating DAX**. This was not evidence that the owner lacked Build permission.
The official Power BI client passed the same probe, with a decoded Arrow result
of `Result = 1`; the companion now validates this result before creating an item.

The Python-only `--auth azure-cli` and `--auth device-code` modes remain available
for environments where those flows are explicitly supported.
**If sign-in says the requesting device must be managed, stop.** A successful
browser sign-in does not mean a token was granted. Device-code authentication
does not establish device compliance; use an organization-approved managed
device and supported authentication, or ask IT to confirm the compliant setup.
Do not disable or bypass Conditional Access. This tool does not grant permissions
or bypass the Build probe. Tokens stay in memory and are not included in manifests.
The script probes access before creating or writing an ontology.

If a previous attempt created an **empty** ontology, add
`--ontology-id '<existing-id>'` with its exact `--name` and a new manifest path.
Nonempty definitions are refused by default; this is not general resume or
replace support.

To deliberately add the six source groups to a **nonempty** ontology while
preserving existing content, use the explicit append mode:

```powershell
.\create_ontology.ps1 `
    -SourcesManifest .\daily-sample.manifest.json `
    -Name '<exact-existing-ontology-name>' `
    -OntologyId '<existing-ontology-id>' `
    -ExtendExisting `
    -Manifest .\ontology-extension.manifest.json `
    -Execute
```

Append mode requires the tenant's auto-projection feature and its existing default
namespace. It saves canonical and expanded before-snapshots in the manifest, then
submits one transactional `definition/scripts` sequence: five expressions,
18 bound tables, and 12 relationships. Every operation is a strict **create**,
never replace, alter, or delete. Auto-projection supplies the 18 corresponding
entities and 12 entity relationships. Existing authored or projected name
collisions are refused; backend transaction conflicts do not overwrite objects.
Read-back checks both the added bindings and preservation of the existing content.
It ignores only the service-generated partition annotation `ONT_RESOLVED_At`,
which changes when the backend refreshes binding-resolution metadata; source
bindings, user metadata, keys, and relationships remain checked. After a
successful append, an ontology with one pre-existing `test` entity has 19 entities,
not 18.

Inspect the recorded item and operation after failures before rerunning.
In particular, a timeout or failed read-back can occur after a committed write.
Do not replay an append blindly: inspect the saved definition first. The tool
never deletes partial child resources from failed ontology creation.

Success verifies the saved definition's source expressions, column bindings,
entity keys, and relationships, not merely collection counts. **Definition
read-back is not a query, graph-materialization, Operations Agent, or Data Agent
sign-off.** Agent creation and configuration are separate follow-up work.

Suggested later agent checks, repeated for each source prefix:

- List all three plants and their cities.
- Count assets per plant: four each.
- List readings for A012: ten rows.
- Find the maximum temperature: 32.9 C, A012, R0120,
  2026-01-01 00:45:00 UTC.
- Follow R0120 to A012 and then P03 / East Plant / Boston.

Use the explicit sample date, not "today" or "last 24 hours": the deterministic
readings are historical. These are expected answers, not evidence that an agent
has already returned them.

## Completion, failures, and cleanup

For isolated testing of the other five sources, pass `--skip-eventhouse-kql`.
The manifest explicitly records both skipped types; success then covers only
the five requested sources, not all seven. Default runs still include all seven.
To avoid creating another workspace after an early failure, `--workspace-id`
can reuse an **empty** workspace: its display name and capacity must match the
supplied arguments and its item list must be empty. This is not resume support
for a partially populated workspace. Use a new manifest path for each attempt.

- A zero exit code **after `--execute`** means all requested source types passed
  verification. A preview is not a deployment.
- The manifest records workspace/item IDs as creation completes, the current
  step, accepted operation URLs, expected counts, and per-source verification.
  Full row comparisons also detect wrong values, duplicate keys, and missing
  rows. Floating-point measurements are compared to six decimal places.
- HTTP and polling waits are bounded; `--timeout` defaults to 1,800 seconds per
  operation/table wait, not a total run limit. `Retry-After` is honored for HTTP
  retries and Fabric operations. Missing or failed endpoints are not skipped.
- Lakehouse and mirrored-database verification explicitly refresh SQL endpoint
  metadata with `recreateTables: false`. While waiting for missing tables or
  replicated rows, a refresh is retried at most once a minute. Refresh failures
  are surfaced; tables are never dropped or recreated by this refresh.
- The first failure stops the run with a nonzero exit code. There is no automatic
  rollback, resume, mutation replay after ambiguous network failures, or deletion.
  If a create request was accepted but its response was lost, inspect the
  workspace/operation before starting another run.
- An existing manifest path is refused. To run a fresh independent sample, use a
  new workspace name and manifest path. Do not replay Open Mirroring's initial
  INSERT files into an existing mirrored item.
- Open Mirroring uploads metadata first, uploads the initial Parquet file with
  an ignored underscore prefix, then atomically renames it to
  `00000000000000000001.parquet`. The optional CDC marker column is omitted for
  this initial INSERT-only load.
- OneLake uploads use the SDK's create-and-upload path with an `If-None-Match: *`
  condition, so new files are created but existing files are not overwritten.
  Earlier script versions used `overwrite=False`, which skipped file creation
  in the ADLS SDK and could fail with `PathNotFound` on the first append.
  If affected, replace the script with this version and use a new workspace
  name and manifest for a fresh run. Retain the old manifest to identify the
  partially created workspace; this update does not add resume support.
- Use `MatchConditions.IfMissing` without an explicit `etag`: the SDK supplies
  the wildcard header itself. Supplying both leaves the unused `etag` argument
  to reach `requests.Session.request`, which rejects it before sending the file
  creation request. Version 3 of the portable ZIP corrects this argument pairing.
- Delete **only the newly created sample workspace** in the Daily portal when
  finished, after confirming its ID in the manifest. This removes its sample
  items and avoids leaving resources running. The script does not delete
  anything automatically.

For 403/network failures, check the private network path, identity permissions,
and Daily workload flags. For cross-host operation/refresh URLs, configure the
correct Daily API origin; the script deliberately refuses to forward tokens
across hosts. For mirror/lakehouse timeouts, inspect replication and SQL endpoint
provisioning before increasing the timeout. Do not treat `Running` mirroring or
uploaded files alone as proof that sample data is queryable.

## Local validation and environment limitation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s . -p 'test_*.py' -v
```

Tests cover data integrity, definitions, Parquet types, polling/failure handling,
safe publication, SQL/DAX/KQL verification, and offline preview behavior. They
do not replace a live run. Public API contracts were checked against Microsoft
documentation; **Daily Private Link feature availability and end-to-end behavior
must still be validated with your tenant, capacity, and network**.

### Live normal-Daily validation: 2026-10-22

Lakehouse, Open Mirroring, SQL database, Warehouse, and Semantic Model were
created and verified against the same expected 3 Plants, 12 Assets, and 120
Readings. Verification compared every key and value, including UTC timestamps.
Eventhouse and KQL were initially skipped, then created in the same workspace
and verified through KQL against all 3/12/120 expected rows. All seven requested
source types now have local normal-Daily data verification.

The initial run uncovered timestamp encoding and SQL metadata synchronization
issues, now fixed above. Semantic model creation succeeded through the core
Items route. After fixes, a separate pass using the current production helpers
successfully reverified all five existing sources and refreshed/queried the
core-route semantic model. This was **not one uninterrupted run of the final
script from an empty workspace**, nor a Private Link sign-off.

Portable package v4 includes these fixes and the selective-validation options.
After replacing an older package, reinstall `requirements.txt` to include
`tzdata`, needed for timezone-aware Arrow data on Windows.
That package does not include the newer ontology companion or public replacement
scripts.

**Public replacement succeeded:** after approval to discard the existing `test`
definition, `updateDefinition` completed at approximately 21:26 UTC. A separate
read-only verification at approximately 21:32 UTC confirmed **18 entities,
18 bound tables, 12 relationships, and 12 entity relationships**, including
the source identities and entity keys. All seven source types are covered by
six groups because Eventhouse contains the KQL database. Source items were not
modified. This workflow used Azure CLI and the public API without an MWC token
exchange. The local suite passes **74 tests**.

The initial post-write verifier rejected canonical portable SQL references and
omitted default projections even though the write had completed. After correcting
those checks, verification succeeded against both the saved response and a fresh
public export; **the successful write was not replayed**. Actual ontology queries,
graph refresh, Operations Agent, and Data Agent remain unvalidated.

**Earlier internal-route attempts (historical):**

The v5/v6 package's local SDK dependency and internal-feed download were removed
in v7 after the feed requirement blocked the user's machine. The package now
uses a sample-specific Python TMDL writer/reader instead.

The initial companion attempt created a Gen2 Ontology, but its definition save
was rejected by the Semantic Model query probe (HTTP 401). Telemetry established
an Azure CLI client/delegated-scope rejection, before DAX execution. A later
device-code attempt was separately blocked by Conditional Access.

The official Power BI Profile module 1.3.84, using the Windows broker in a normal
console, successfully ran the same probe and decoded `Result = 1` on October 22.
A separate Fabric Lakehouse request exposed the Profile client's limited Fabric
scopes; the companion now uses matching Azure CLI credentials for Fabric item
operations. The combined-client run passed discovery and the decoded query probe,
but **new ontology provisioning failed before any definition write**: the backend's
`GetEventhouseAsync` timed out three times at its 100-second HTTP limit. A later
read of that child Eventhouse also timed out. Increasing the script's polling
timeout does not change this backend limit.

The failed run left Eventhouse, KQL Database, and GraphModel child items visible
while the new parent Ontology was absent from the item list. No automatic cleanup
or additional creation retry was performed. Inspect failed operations and partial
children before retrying. At that point the original ontology contained a
user-created portal `test` binding, which those attempts preserved. The later,
explicitly authorized public replacement removed it.

The subsequent authorized append attempt also stopped **before any definition
write**: the Profile token received HTTP 401 from `generatemwctokenv2`. This is a
separate authorization boundary from the now-successful dataset probe. The
internal endpoint has additional authorization requirements, including its
`Fabric.Embed`/first-party policy; the exact deployed rejection still requires
confirmation. Do not switch off those checks, change tenant policies, substitute
browser tokens, or mistake query-probe success for authorization to mint workload
tokens. Follow-up reads showed only the original `test` entity and table; the
only snapshot differences were service-generated resolution timestamps.

## API references

- [Create workspace](https://learn.microsoft.com/en-us/rest/api/fabric/core/workspaces/create-workspace)
- [Create KQL database](https://learn.microsoft.com/en-us/rest/api/fabric/kqldatabase/items/create-kql-database)
- [Kusto REST response and partial failures](https://learn.microsoft.com/en-us/kusto/api/rest/response)
- [Lakehouse Load Table](https://learn.microsoft.com/en-us/rest/api/fabric/lakehouse/tables/load-table)
- [Open Mirroring definition](https://learn.microsoft.com/en-us/rest/api/fabric/articles/item-management/definitions/mirrored-database-definition)
- [Open Mirroring landing zone](https://learn.microsoft.com/en-us/fabric/mirroring/open-mirroring-landing-zone-format)
- [Open Mirroring publication guidance](https://learn.microsoft.com/en-us/fabric/mirroring/open-mirroring-best-practices)
- [Get SQL database](https://learn.microsoft.com/en-us/rest/api/fabric/sqldatabase/items/get-sql-database)
- [SQL connectivity](https://learn.microsoft.com/en-us/fabric/data-warehouse/connectivity)
- [Refresh SQL endpoint metadata](https://learn.microsoft.com/en-us/rest/api/fabric/sqlendpoint/items/refresh-sql-endpoint-metadata)
- [Semantic model definition](https://learn.microsoft.com/en-us/rest/api/fabric/articles/item-management/definitions/semantic-model-definition)
- [Dataset Execute Queries](https://learn.microsoft.com/en-us/rest/api/power-bi/datasets/execute-queries-in-group)
- [Official Power BI user sign-in](https://learn.microsoft.com/en-us/powershell/module/microsoftpowerbimgmt.profile/connect-powerbiserviceaccount)
- [Get Ontology definition](https://learn.microsoft.com/en-us/rest/api/fabric/ontology/items/get-ontology-definition)
- [Update Ontology definition](https://learn.microsoft.com/en-us/rest/api/fabric/ontology/items/update-ontology-definition)
- [Fabric Private Link](https://learn.microsoft.com/en-us/fabric/security/security-private-links-overview)
