"""Replace an existing sample ontology through the documented Fabric public definition API."""

import argparse
import base64
import copy
import json
import logging
from contextlib import closing
from pathlib import Path, PurePosixPath
from tempfile import TemporaryDirectory
from uuid import UUID

from create_ontology import build_definition, discover_sources, validate_inventory, verify_definition
from create_sample import Api, Manifest, PBI_SCOPE, m_literal
import sample_tmdl

LOG = logging.getLogger("ontology-sample")


def tmdl_parts(folder):
    files = sorted(folder.rglob("*.tmdl"))
    if not (folder / "database.tmdl").is_file() or not (folder / "model.tmdl").is_file():
        raise ValueError("TMDL output must include database.tmdl and model.tmdl")
    return [{"path": file.relative_to(folder).as_posix(), "payloadType": "InlineBase64",
             "payload": base64.b64encode(file.read_bytes()).decode("ascii")} for file in files]


def unpack_tmdl(definition, folder):
    seen = set()
    for part in definition["parts"]:
        name = part["path"]
        if name == ".platform":
            continue
        path = PurePosixPath(name)
        if (path.is_absolute() or ".." in path.parts or "\\" in name or ":" in name
                or path.as_posix() != name or path.suffix != ".tmdl"):
            raise ValueError(f"Unexpected or unsafe public definition part: {name}")
        if name.casefold() in seen or part["payloadType"] != "InlineBase64":
            raise ValueError(f"Duplicate or unsupported public definition part: {name}")
        seen.add(name.casefold())
        target = folder.joinpath(*path.parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(base64.b64decode(part["payload"], validate=True))
    if "database.tmdl" not in seen or "model.tmdl" not in seen:
        raise ValueError("The public definition does not contain the required Gen2 TMDL documents")


def normalize_tom_defaults(document):
    document = copy.deepcopy(document)
    model = document["model"]
    for relationship in model.get("relationships", []):
        relationship.setdefault("fromCardinality", "many")
        relationship.setdefault("toCardinality", "one")
        relationship.setdefault("crossFilteringBehavior", "oneDirection")
    for entity in model.get("entities", []):
        for prop in entity.get("properties", []):
            backing = prop.get("backingConfiguration", {})
            if "valueColumn" in backing:
                backing.setdefault("type", "default")
    for relationship in model.get("entityRelationships", []):
        backing = relationship.get("backingConfiguration", {})
        if "relationship" in backing:
            backing.setdefault("type", "relationship")
    return document


def verify_public_bindings(expected, actual, state, target_workspace_id=None):
    expected_model = copy.deepcopy(expected["model"])
    actual_expressions = {entry["name"]: entry["expression"] for entry in actual["model"]["expressions"]}
    for expression in expected_model["expressions"]:
        kind = expression["name"].removesuffix("_Source")
        if kind not in ("SQLDatabase", "Warehouse"):
            continue
        item = state["items"][kind]
        identities = [f"{kind}:{state['workspaceId']}:{item['id']}"]
        if kind == "Warehouse" and (
            target_workspace_id is None or target_workspace_id.lower() == state["workspaceId"].lower()
        ):
            identities.append(f"RELATIVE-{item['displayName']}")
        for identity in identities:
            portable = (f'let Source = Sql.Database("ONT_ALM_SQL_ENDPOINT", '
                        f'{m_literal("ONT_ALM_SQL_DATABASE-" + identity)}) in Source')
            if actual_expressions.get(expression["name"]) == portable:
                expression["expression"] = portable
    tables = {table["name"]: table for table in expected_model["tables"]}
    entities = {entity["name"]: entity for entity in actual["model"].get("entities", [])}
    for entity in expected_model["entities"]:
        stored = entities.get(entity["name"], {})
        table = tables[entity["backingTable"]]
        if "description" not in stored and entity.get("description") == table.get("description"):
            entity.pop("description", None)
        persisted_properties = {prop["name"] for prop in stored.get("properties", [])}
        expected_properties = {prop["name"] for prop in entity["properties"]}
        if not persisted_properties.issubset(expected_properties):
            raise ValueError(f"Unexpected persisted properties on {entity['name']}")
        # Canonical export omits default projections; their backing columns are still verified in full.
        columns = {column["name"]: column for column in table["columns"]}
        for prop in entity["properties"]:
            if prop["name"] not in persisted_properties and (
                prop["backingConfiguration"] != {
                    "type": "default", "valueColumn": {"table": table["name"], "column": prop["name"]}
                } or prop["dataType"] != columns[prop["name"]]["dataType"]
            ):
                raise ValueError(f"Non-projected property missing from {entity['name']}: {prop['name']}")
        entity["properties"] = [prop for prop in entity["properties"] if prop["name"] in persisted_properties]
    verify_definition({"model": expected_model}, normalize_tom_defaults(actual))


def serialize_definition(expected, folder):
    request_folder = folder / "request"
    sample_tmdl.serialize(expected, request_folder)
    verify_definition(expected, normalize_tom_defaults(sample_tmdl.deserialize(request_folder)))
    return {"definition": {"parts": tmdl_parts(request_folder)}}


def read_and_verify(api, item_path, state, expected, folder, manifest, target_workspace_id):
    manifest.step("Reading back and validating the public definition")
    stored = api.mutate(item_path + "/getDefinition")
    manifest.data["storedPublicDefinition"] = stored
    manifest.save()
    stored_folder = folder / "stored"
    unpack_tmdl(stored["definition"], stored_folder)
    actual = sample_tmdl.deserialize(stored_folder)
    manifest.data["storedDefinition"] = actual
    manifest.save()
    verify_public_bindings(expected, actual, state, target_workspace_id)
    model = expected["model"]
    manifest.data["verified"]["publicDefinition"] = {
        "entities": len(model["entities"]), "boundTables": len(model["tables"]),
        "relationships": len(model["relationships"]), "entityRelationships": len(model["entityRelationships"])
    }
    manifest.data["queryValidation"] = "Not performed; definition validation is not an agent or data-query test"
    manifest.save()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sources-manifest", type=Path, required=True)
    parser.add_argument("--ontology-id", type=UUID, required=True)
    parser.add_argument("--target-workspace-id", type=UUID, help="Defaults to the source workspace")
    parser.add_argument("--name", required=True, help="Exact existing ontology display name")
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--timeout", type=int, default=1800)
    parser.add_argument("--verify-only", action="store_true", help="Read and verify without replacing the definition")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args(argv)
    if args.timeout <= 0 or not args.name.strip():
        parser.error("A positive timeout and nonempty item name are required")
    state = json.loads(args.sources_manifest.read_text(encoding="utf-8-sig"))
    validate_inventory(state)
    target_workspace_id = str(args.target_workspace_id or state["workspaceId"])
    plan = {key: state[key] for key in ("tenantId", "capacityId", "workspaceId", "workspaceName", "endpoints")}
    plan.update({"ontologyId": str(args.ontology_id), "ontologyName": args.name,
                 "sourceManifest": str(args.sources_manifest.resolve()),
                 "targetWorkspaceId": target_workspace_id,
                 "operation": "verify-definition" if args.verify_only else "replace-definition",
                 "authenticationMethod": "azure-cli",
                 "transport": "fabric-public-api", "boundTables": 18, "relationships": 12,
                 "warning": ("Read-only verification; no definition update." if args.verify_only else
                             "Replaces all ontology content, including test. Source items are not modified.")})
    if not args.execute:
        print(json.dumps(plan, indent=2))
        return

    from azure.identity import AzureCliCredential

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logging.getLogger("azure").setLevel(logging.WARNING)
    manifest = Manifest(args.manifest, plan)
    try:
        with TemporaryDirectory(prefix="ontology-public-") as temporary, AzureCliCredential(
            tenant_id=state["tenantId"], process_timeout=60
        ) as credential, closing(Api(state["endpoints"]["fabric"], PBI_SCOPE, credential,
                                     args.timeout, manifest.operation)) as api:
            folder = Path(temporary)
            manifest.step("Checking the existing ontology and source inventory")
            workspace = f"{api.base}/workspaces/{target_workspace_id}"
            item = api.json("GET", f"{workspace}/items/{args.ontology_id}")
            if item.get("type") != "Ontology" or item.get("displayName") != args.name:
                raise ValueError("Existing item must be an Ontology with the exact supplied name")
            manifest.data["items"]["Ontology"] = item
            expected = build_definition(state, discover_sources(api, state), "powerbi://dailyapi.powerbi.com")
            manifest.data["authoredDefinition"] = expected
            manifest.step("Serializing and validating the sample TMDL definition")
            body = serialize_definition(expected, folder)
            manifest.data["publicRequest"] = body
            item_path = f"{workspace}/ontologies/{args.ontology_id}"
            if not args.verify_only:
                manifest.step("Backing up the current public definition")
                manifest.data["beforePublicDefinition"] = api.mutate(item_path + "/getDefinition")
                manifest.step("Replacing the ontology through the Fabric public API")
                api.mutate(item_path + "/updateDefinition", body, result_required=False)
                manifest.data["writeCompleted"] = True
                manifest.save()
            read_and_verify(api, item_path, state, expected, folder, manifest, target_workspace_id)
            manifest.data["status"] = "succeeded"
            manifest.step("All public-definition source bindings verified")
    except Exception as error:
        manifest.data.update({"status": "failed", "error": str(error)})
        manifest.save()
        LOG.exception("Replacement stopped; inspect %s before retrying. No automatic rollback or deletion.",
                      args.manifest)
        raise


if __name__ == "__main__":
    main()
