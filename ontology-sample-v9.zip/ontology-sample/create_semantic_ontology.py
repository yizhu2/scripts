"""Create a second ontology bound only to the verified sample semantic model (not native Import/Promote)."""

import argparse
import base64
import json
import logging
import re
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
from tempfile import TemporaryDirectory
from uuid import UUID

from create_ontology import build_definition, validate_inventory
from create_sample import Api, Manifest, PBI_SCOPE, sample_tables
from replace_ontology import read_and_verify, serialize_definition
from run_sample import workspace_items
from sample_auth import open_credential

LOG = logging.getLogger("ontology-sample")


def verify_source_schema(export):
    parts = [part for part in export["definition"]["parts"] if part["path"] == "model.bim"]
    if len(parts) != 1 or parts[0]["payloadType"] != "InlineBase64":
        raise ValueError("The semantic model must return exactly one inline model.bim in TMSL format")
    source = json.loads(base64.b64decode(parts[0]["payload"], validate=True))["model"]
    tables = source["tables"]
    indexed = {table["name"]: table for table in tables}
    samples = sample_tables()
    if len(indexed) != len(tables) or set(indexed) != {table.name for table in samples}:
        raise ValueError("This companion supports exactly the shipped Plants/Assets/Readings sample, not arbitrary models")
    types = {"string": "string", "datetime": "dateTime", "double": "double"}
    for sample in samples:
        table = indexed[sample.name]
        columns = table["columns"]
        found = {column["name"]: column["dataType"] for column in columns}
        if (len(found) != len(columns) or found != {name: types[kind] for name, kind in sample.columns}
                or table.get("isHidden") or table.get("measures") or table.get("hierarchies")
                or any(column.get("isHidden") or column.get("type", "data") != "data" for column in columns)):
            raise ValueError(f"Unsupported or changed sample schema for {sample.name}")
    relationships = source.get("relationships", [])
    found = {(r["fromTable"], r["fromColumn"], r["toTable"], r["toColumn"]) for r in relationships}
    expected = {("Assets", "PlantId", "Plants", "PlantId"), ("Readings", "AssetId", "Assets", "AssetId")}
    if (len(relationships) != 2 or found != expected or any(
        r.get("fromCardinality", "many") != "many" or r.get("toCardinality", "one") != "one"
        or r.get("crossFilteringBehavior", "oneDirection") != "oneDirection"
        or r.get("isActive", True) is not True for r in relationships
    )):
        raise ValueError("Semantic model relationships do not match the verified sample")
    return {"tables": 3, "relationships": 2, "measures": 0}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sources-manifest", type=Path, required=True)
    parser.add_argument("--workspace-id", type=UUID, help="Destination workspace; defaults to source workspace")
    parser.add_argument("--name", default="Ontology_FromSemanticModel_" + datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S"))
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--auth", choices=("auto", "cli", "browser"), default="auto")
    parser.add_argument("--client-id", type=UUID)
    parser.add_argument("--ontology-id", type=UUID, help="Only with --verify-only; never overwrite an existing item")
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--timeout", type=int, default=1800)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args(argv)
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,88}", args.name) or args.timeout < 30:
        parser.error("Name must start with a letter, use only letters/digits/underscores, be under 90 characters; timeout >=30")
    if args.verify_only != bool(args.ontology_id):
        parser.error("--ontology-id and --verify-only must be supplied together")
    state = json.loads(args.sources_manifest.read_text(encoding="utf-8-sig"))
    validate_inventory(state)
    if state["endpoints"]["fabric"].rstrip("/") != "https://dailyapi.fabric.microsoft.com/v1":
        parser.error("This companion targets normal Daily only")
    target_id = str(args.workspace_id or state["workspaceId"])
    plan = {
        "tenantId": state["tenantId"], "sourceWorkspaceId": state["workspaceId"], "workspaceId": target_id,
        "endpoints": state["endpoints"],
        "semanticModelId": state["items"]["SemanticModel"]["id"], "targetWorkspaceId": target_id,
        "ontologyName": args.name, "sourceManifest": str(args.sources_manifest.resolve()),
        "creationMethod": "Public create-with-definition from verified sample semantic-model schema",
        "nativeImportPromoteValidated": False, "expected": {"entities": 3, "relationships": 2},
        "operation": "verify-only" if args.verify_only else "create",
    }
    if not args.execute:
        print(json.dumps(plan, indent=2))
        return
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logging.getLogger("azure").setLevel(logging.WARNING)
    manifest = Manifest(args.manifest, plan)
    try:
        with open_credential(state["tenantId"], mode=args.auth,
                             client_id=str(args.client_id) if args.client_id else None) as credential, \
                closing(Api(state["endpoints"]["fabric"], PBI_SCOPE, credential, args.timeout, manifest.operation)) as api:
            source = f"{api.base}/workspaces/{state['workspaceId']}"
            target = f"{api.base}/workspaces/{target_id}"
            manifest.step("Validating source and destination workspaces")
            workspace = api.json("GET", source)
            if (workspace["displayName"] != state["workspaceName"]
                    or workspace.get("capacityId", "").lower() != state["capacityId"].lower()):
                raise ValueError("Source workspace identity changed")
            if not api.json("GET", target).get("capacityId"):
                raise ValueError("Destination workspace must have a Fabric capacity")
            source_item = api.json("GET", source + "/semanticModels/" + plan["semanticModelId"])
            if source_item["displayName"] != state["items"]["SemanticModel"]["displayName"]:
                raise ValueError("Source semantic model was renamed")
            if args.verify_only:
                item = api.json("GET", f"{target}/items/{args.ontology_id}")
                if item.get("type") != "Ontology" or item.get("displayName") != args.name:
                    raise ValueError("Verification target must match the exact ontology name")
            elif any(item["displayName"].casefold() == args.name.casefold() for item in workspace_items(api, target)):
                raise ValueError("An item with this name already exists; refusing to create a duplicate")
            manifest.step("Reading and checking the actual semantic model schema")
            exported = api.mutate(source + "/semanticModels/" + plan["semanticModelId"] + "/getDefinition",
                                  params={"format": "TMSL"})
            manifest.data["sourcePublicDefinition"] = exported
            manifest.save()
            manifest.data["verified"]["sourceSchema"] = verify_source_schema(exported)
            expected = build_definition(state, {"SemanticModel": {}}, "powerbi://dailyapi.powerbi.com",
                                        groups=("SemanticModel",))
            manifest.data["authoredDefinition"] = expected
            with TemporaryDirectory(prefix="semantic-sample-") as temporary:
                folder = Path(temporary)
                definition = serialize_definition(expected, folder)
                manifest.data["publicRequest"] = definition
                if not args.verify_only:
                    manifest.step("Creating the semantic-model-only ontology through the public API")
                    item = api.mutate(target + "/ontologies", {
                        "displayName": args.name,
                        "description": "Sample semantic-model bindings; API-derived, not native Import/Promote.",
                        **definition,
                    })
                    if not item.get("id"):
                        raise RuntimeError("Ontology creation returned no ID; inspect the recorded operation before retrying")
                    manifest.data["writeCompleted"] = True
                manifest.data["items"]["Ontology"] = item
                manifest.save()
                read_and_verify(api, target + "/ontologies/" + item["id"], state, expected,
                                folder, manifest, target_id)
            manifest.data["status"] = "succeeded"
            manifest.step("Semantic-model-only ontology bindings verified; native Import/Promote and data queries not tested")
    except (Exception, KeyboardInterrupt) as error:
        manifest.data.update(status="failed", error=str(error))
        manifest.save()
        LOG.exception("Stopped; inspect %s before retrying. No items were deleted or overwritten.", args.manifest)
        raise


if __name__ == "__main__":
    main()
