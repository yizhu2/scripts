import base64
import copy
import io
import json
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import MagicMock, patch

import create_semantic_ontology as companion
from create_ontology import build_definition
from create_sample import sample_tables, semantic_definition
from replace_ontology import serialize_definition
from test_create_ontology import GUID, inventory

NEW_ID = "22222222-2222-4222-8222-222222222222"


def exported(model=None):
    if model is None:
        return {"definition": semantic_definition(sample_tables())}
    return {"definition": {"parts": [{
        "path": "model.bim", "payloadType": "InlineBase64",
        "payload": base64.b64encode(json.dumps({"model": model}).encode()).decode(),
    }]}}


class SemanticOntologyTests(unittest.TestCase):
    def test_actual_sample_schema(self):
        self.assertEqual(companion.verify_source_schema(exported()), {"tables": 3, "relationships": 2, "measures": 0})

    def test_changed_or_unsupported_schema_is_rejected(self):
        definition = semantic_definition(sample_tables())
        part = next(p for p in definition["parts"] if p["path"] == "model.bim")
        source = json.loads(base64.b64decode(part["payload"]))["model"]
        for change in ("type", "column", "duplicate", "table", "measure", "hidden", "inactive", "relationship"):
            with self.subTest(change=change):
                model = copy.deepcopy(source)
                table = model["tables"][0]
                if change == "type":
                    table["columns"][0]["dataType"] = "int64"
                elif change == "column":
                    table["columns"].pop()
                elif change == "duplicate":
                    table["columns"].append(table["columns"][0])
                elif change == "table":
                    model["tables"].pop()
                elif change == "measure":
                    table["measures"] = [{"name": "Extra", "expression": "1"}]
                elif change == "hidden":
                    table["isHidden"] = True
                elif change == "inactive":
                    model["relationships"][0]["isActive"] = False
                else:
                    model["relationships"][0]["toColumn"] = "Name"
                with self.assertRaises(ValueError):
                    companion.verify_source_schema(exported(model))

    def test_group_selection_rejects_invalid_values(self):
        for groups in ((), ("SemanticModel", "SemanticModel"), ("Unknown",)):
            with self.assertRaises(ValueError):
                build_definition(inventory(), {"SemanticModel": {}}, "powerbi://dailyapi.powerbi.com", groups=groups)

    def run_flow(self, folder, extra=(), collision=False, fail_create=False):
        state = inventory()
        source = folder / "source.json"
        source.write_text(json.dumps(state), encoding="utf-8")
        result = folder / "result.json"
        expected = build_definition(state, {"SemanticModel": {}}, "powerbi://dailyapi.powerbi.com",
                                    groups=("SemanticModel",))
        definition = serialize_definition(expected, folder)
        api = MagicMock()
        api.base = state["endpoints"]["fabric"]

        def get(method, path, **kwargs):
            self.assertEqual(method, "GET")
            if path.endswith("/items"):
                return {"value": [{"displayName": "Second"}] if collision else []}
            if "/semanticModels/" in path:
                return state["items"]["SemanticModel"]
            if "/items/" in path:
                return {"id": NEW_ID, "displayName": "Second", "type": "Ontology"}
            return {"displayName": state["workspaceName"], "capacityId": GUID}

        def mutate(path, body=None, **kwargs):
            if "/semanticModels/" in path:
                self.assertEqual(kwargs, {"params": {"format": "TMSL"}})
                return exported()
            if path.endswith("/ontologies"):
                if fail_create:
                    raise TimeoutError("Ambiguous create")
                self.assertEqual(body["definition"], definition["definition"])
                return {"id": NEW_ID, "displayName": "Second", "type": "Ontology"}
            self.assertTrue(path.endswith(NEW_ID + "/getDefinition"))
            return definition

        api.json.side_effect = get
        api.mutate.side_effect = mutate
        with patch.object(companion, "Api", return_value=api), \
                patch.object(companion, "open_credential") as authentication, redirect_stdout(io.StringIO()):
            companion.main(["--sources-manifest", str(source), "--manifest", str(result), "--name", "Second", *extra])
        return api, authentication, result

    def test_offline_preview_does_not_authenticate_or_create_manifest(self):
        with tempfile.TemporaryDirectory() as temporary:
            api, auth, result = self.run_flow(Path(temporary))
            auth.assert_not_called()
            api.mutate.assert_not_called()
            self.assertFalse(result.exists())

    def test_create_and_readback_preserve_three_entity_counts(self):
        with tempfile.TemporaryDirectory() as temporary:
            api, _, result = self.run_flow(Path(temporary), ["--execute"])
            state = json.loads(result.read_text())
            self.assertEqual(state["status"], "succeeded")
            self.assertFalse(state["nativeImportPromoteValidated"])
            self.assertTrue(state["writeCompleted"])
            self.assertEqual(state["verified"]["publicDefinition"],
                             {"entities": 3, "boundTables": 3, "relationships": 2, "entityRelationships": 2})
            self.assertEqual(sum(call.args[0].endswith("/ontologies") for call in api.mutate.call_args_list), 1)

    def test_verify_only_has_no_create(self):
        with tempfile.TemporaryDirectory() as temporary:
            api, _, result = self.run_flow(Path(temporary), ["--execute", "--verify-only", "--ontology-id", NEW_ID])
            self.assertNotIn("writeCompleted", json.loads(result.read_text()))
            self.assertTrue(all(call.args[0].endswith("/getDefinition") for call in api.mutate.call_args_list))

    def test_collision_and_ambiguous_creation_leave_failed_manifests(self):
        for failure in ("collision", "ambiguous"):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as temporary:
                folder = Path(temporary)
                with self.assertRaises((ValueError, TimeoutError)):
                    self.run_flow(folder, ["--execute"], collision=failure == "collision",
                                  fail_create=failure == "ambiguous")
                state = json.loads((folder / "result.json").read_text())
                self.assertEqual(state["status"], "failed")
                self.assertNotIn("writeCompleted", state)


if __name__ == "__main__":
    unittest.main()
