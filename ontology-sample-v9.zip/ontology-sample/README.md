# Daily Fabric: seven sources and one bound ontology

Run **[Start-Sample.ps1](Start-Sample.ps1)** from the extracted ZIP. It prepares a
local Python environment and asks for:

1. **Tenant ID**.
2. **Capacity ID** for a new source workspace.
3. **Workspace ID** of the existing workspace where the ontology should be created.

**Version 9 requires no Analysis Services SDK, NuGet feed access, Azure DevOps
permissions, .NET SDK, or PowerShell 7.** It writes and reads the sample's TMDL
definition directly in Python. If v5/v6 stopped at SDK setup, extract this version
into a fresh folder and restart; SDK setup failed before any Fabric creation.

The source workspace and target workspace are **different**. A Lakehouse cannot
contain other Fabric item types; the seven sources are sibling items in the new
source workspace. The existing target workspace is not cleared, reassigned to
another capacity, or otherwise reused for source storage.

## Result and covered scenarios

| Scenario | This package |
|---|---|
| Create a new source workspace on your supplied capacity | Implemented |
| Populate Eventhouse, KQL database, Lakehouse, Open Mirrored database, Semantic Model, SQL database, and Warehouse | Implemented, with source-row verification |
| Create a new Gen2 ontology in your supplied target workspace | Implemented through Fabric public APIs |
| Bind every source group to that ontology | 18 entities/bound tables and 12 relationships, verified by public read-back |
| Browser sign-in when cached CLI credentials are unavailable | Interactive CLI browser login, then optional approved-client browser authentication |
| Generate and verify the ontology definition without an AS SDK | Implemented directly in Python; no package-feed calls |
| Reuse successfully verified sources after inspecting a failed ontology creation | Explicit `-SourcesManifest` option; never replays source loads |
| Verify an existing ontology without writing | `-VerifyOnly`, with source manifest and exact ontology ID/name |
| Create a **second** ontology bound only to the sample semantic model | Optional companion; checks the actual source schema, then creates and verifies 3 entities and 2 relationships |
| Test native semantic-model Import/Promote | Not covered: the companion uses public create-with-definition, not native Import/Promote |
| Create a Data Agent artifact | Optional companion; unpublished draft referencing the sample semantic model |
| Create an Operations Agent artifact | Optional companion; inactive, unconfigured artifact. Ontology-connected creation hit the Daily playbook limitation below |
| Query through the ontology, refresh its graph, or validate agent answers/actions | Separate validation; not performed by this package |

Each data-bearing source contains the same **Plants (3 rows), Assets (12), and
Readings (120)**, with stable keys and UTC timestamps. The relationships are
`Assets.PlantId -> Plants.PlantId` and `Readings.AssetId -> Assets.AssetId`.
Eventhouse is the KQL database container, so seven source types produce **six**
source groups, not seven copies of the data. Fabric can additionally create
service-managed child items; seven source types does not imply exactly seven
total workspace items.

The ontology groups are `EventhouseKQL`, `Lakehouse`, `MirroredDatabase`,
`SemanticModel`, `SQLDatabase`, and `Warehouse`, each with Plants/Assets/Readings.
Bindings retain the **source** workspace/item identities; the target workspace
is used only for the ontology. Do not sum the identical source copies together.

## Prerequisites

- Windows, **Python 3.10+**, and **Windows PowerShell 5.1 or newer**.
- [Microsoft ODBC Driver 18 for SQL Server](https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server).
- Azure CLI for the preferred authentication route. It is optional if you use
  an approved application for direct browser authentication.
- A **normal Daily** tenant/capacity with all required workloads enabled.
  The target workspace must already be assigned to a Fabric capacity; it may
  have a different capacity from the new source workspace.
- Permission to create/assign workspaces and create ontology items in the target;
  access to all source items, OneLake, SQL/KQL, and Semantic Model
  creation/refresh/Build. The tenant must allow the Power BI **Dataset Execute
  Queries REST API**.
- Approved network access to Entra, Fabric, Power BI, OneLake, Kusto and SQL.
  SQL requires TDS connectivity, including TCP 1433 and applicable routing ports.
  Existing Private Link/VPN/DNS policies remain unchanged. The launcher does
  not establish workspace-specific private endpoints or bypass network policies.

This package does **not** install system prerequisites, download or bundle AS SDK
binaries, change Conditional Access, or create app registrations/admin consent.

## Run

Extract the entire ZIP into a writable directory, open a normal interactive
PowerShell window there, and run:

```powershell
.\Start-Sample.ps1
```

No virtual-environment activation is required. The launcher creates
`.venv\Scripts\python.exe` when missing, installs [requirements.txt](requirements.txt)
when dependencies are missing or the requirements change, asks for the three
IDs, and requires typing **CREATE** before executing. It may also request an
approved browser-client ID when CLI authentication is unavailable.
Follow your organization's script-signing/execution policy if execution is
blocked; this package does not disable that policy.
If Python is installed but not on PATH, provide
`-PythonExecutable 'C:\path\to\python.exe'` for initial setup.

For an offline plan without Fabric calls or resource creation:

```powershell
.\Start-Sample.ps1 -PlanOnly
```

The launcher may still install local Python dependencies for that first preview.
The underlying Python preview needs no authentication.

Optional explicit values:

```powershell
.\Start-Sample.ps1 `
    -TenantId '<tenant-guid>' `
    -CapacityId '<source-capacity-guid>' `
    -WorkspaceId '<target-workspace-guid>' `
    -OntologyName 'Ontology_AllSources_Demo'
```

Unique source workspace/item names and a unique default ontology name are
generated automatically. A matching name in the target workspace is rejected,
including matches on later item-list pages. Existing ontologies are never
overwritten by this launcher.

## Sign-in

The default `-Auth auto` tries the cached Azure CLI identity in the requested
tenant. If unavailable, it offers interactive **browser** login through the
actual Azure CLI client, without device-code login or changing global CLI
settings. Use a normal interactive terminal on the requesting machine.

If CLI is unavailable/blocked or you decline it, the launcher can use
`InteractiveBrowserCredential` with an **organization-approved public-client
application ID**. It prompts for that ID, or you can supply:

```powershell
.\Start-Sample.ps1 -Auth browser -ClientId '<approved-public-client-app-guid>'
```

The registration must have a **Mobile and desktop applications** redirect URI
of **`http://localhost:8400`**; local port **8400** must be available. It also
needs delegated permissions/consent for the required resources: Fabric/Power BI, Azure Storage,
Azure SQL and Azure Data Explorer. No Azure DevOps scope or package-feed
permission is requested. Relevant Fabric operations include workspace
creation and item read/write; Power BI also needs dataset refresh and query
permissions. Have your administrator approve the exact permissions for your
tenant. API authorization and data-plane access are separate from successful
sign-in. Do not substitute arbitrary first-party app IDs.

All required token audiences are checked before new source provisioning.
The same credential is reused throughout the workflow. Authentication fallback
occurs only before resource creation, not silently after a service rejects an
operation. Browser authentication cannot overcome missing permissions, consent,
or a managed-device requirement. `-Auth cli` restricts authentication to Azure CLI.

Tokens are not passed on command lines or written to package manifests. Direct
browser tokens are held in memory; Azure CLI manages its own normal user cache.
The public ontology route does not require a client-side MWC token exchange.

## SDK-free definition handling

[sample_tmdl.py](sample_tmdl.py) writes the database, model, tables, entities,
relationships, expressions and namespace TMDL documents needed by this sample.
The generated files are parsed back and structurally checked before submission.
After the public API write, the returned definition is independently parsed and
verified for source identity, keys, columns and relationships.

This is a deliberately limited **sample-format codec**, not a general-purpose
TMDL implementation or replacement for TOM. Unsupported syntax and malformed or
duplicate declarations fail explicitly rather than being ignored. It does not
fetch packages, load DLLs, invoke a serializer subprocess, or request an Azure
DevOps token. Fabric still performs its normal server-side authorization and
definition validation.

## Evidence, failures and safe follow-up

Outputs are written under a new `runs\<unique-run-id>` directory in your current
working directory, or the explicit `-RunDirectory`:

- `sources.manifest.json`: source workspace, seven source item IDs, stages,
  operations, and expected-data verification.
- `run.manifest.json`: target workspace, created ontology ID, submitted/read-back
  definition, verified binding counts, and success/failure status.

Existing run directories are refused. **No automatic rollback or deletion is
performed.** Source provisioning is not generally resumable: do not replay
Open Mirroring INSERT files or blindly rerun after a failed creation. Inspect
both manifests and any pending operation first.

If sources succeeded but ontology creation failed, inspect the target for
partial child resources before deliberately creating a new ontology using:

```powershell
.\Start-Sample.ps1 -SourcesManifest '.\runs\<old-run>\sources.manifest.json'
```

If `writeCompleted` is true but verification failed, **do not create again**.
Use a fresh output directory and a read-only check:

```powershell
.\Start-Sample.ps1 -VerifyOnly `
    -TenantId '<tenant-guid>' -CapacityId '<source-capacity-guid>' `
    -WorkspaceId '<target-workspace-guid>' `
    -SourcesManifest '.\runs\<old-run>\sources.manifest.json' `
    -OntologyId '<created-ontology-guid>' -OntologyName '<exact-name>'
```

If the ontology exists but its definition write failed, the launcher refuses to
overwrite it. Inspect it before using the separate explicit
[replacement utility](replace_ontology.py), which accepts `--target-workspace-id`.
See [advanced instructions and historical diagnostics](ADVANCED.md).

Public export may normalize SQL bindings to portable identity markers and omit
default projected entity properties. Verification checks exact source identity,
keys, columns and topology, not textual equality alone. A target-relative
Warehouse binding is rejected for a cross-workspace ontology.

### SQL login error accompanied by "Database is in transition" (952)

SQL analytics can still be transitioning after Lakehouse load and metadata
refresh report success. ODBC may wrap native SQL error **952** in SQLSTATE
`28000`, alongside `Login failed for user '<token-identified principal>'`
and error `18456`. This combination is not sufficient evidence of a permissions
problem.

Version 9 recognizes native error 952 in the existing bounded SQL-readiness and
asynchronous row-verification retries (including Lakehouse and Open Mirroring).
Each failure is logged; only connection/read checks are repeated, not data
loads or SQL writes. The existing timeout still applies. A genuine login error
18456 **without** a recognized transient diagnostic still fails immediately.

For a run that already stopped here, keep both manifests. The Lakehouse may
contain loaded data, but source verification did not finish and later sources
were not provisioned. **Do not pass this failed source manifest to
`-SourcesManifest`, edit it to say succeeded, or replay its loads.** Failed
source provisioning is not automatically resumable. To retry provisioning,
extract v9 into a fresh directory and run `.\Start-Sample.ps1` normally with
the same tenant/capacity/target workspace inputs. This creates a **new source
workspace**, not a continuation of the old one. Existing resources are retained
and may continue to incur charges; cleanup requires a separate deliberate step.

## Optional next-step artifacts

These companions reuse a **successful source manifest**; they do not load data
again or change the all-source ontology. Run them from the extracted package
after the main launcher has prepared `.venv`. Pass your target workspace
explicitly: otherwise they default to the **source workspace**.

### Second ontology from the sample semantic model

```powershell
.\.venv\Scripts\python.exe .\create_semantic_ontology.py `
    --sources-manifest '.\runs\<old-run>\sources.manifest.json' `
    --workspace-id '<target-workspace-guid>' `
    --name Ontology_FromSemanticModel_Demo `
    --manifest '.\semantic-ontology.manifest.json' --execute
```

The script exports the real model using `getDefinition` with `format=TMSL`,
checks its tables, columns, types and relationships, and creates an ontology
with three `SemanticModel_*` entities and two relationships. Keys follow the
verified Plants/Assets/Readings sample recipe; this is **not a generic model
importer**. Changed/unsupported schemas fail before creation. Public read-back
checks all bindings. **Native Import/Promote, measures/hierarchies import, and
ontology data queries are not tested by this workflow.**

### Data Agent draft

```powershell
.\.venv\Scripts\python.exe .\create_sample_agent.py --kind data `
    --sources-manifest '.\runs\<old-run>\sources.manifest.json' `
    --workspace-id '<target-workspace-guid>' --name DataAgent_Sample_Demo `
    --manifest '.\data-agent.manifest.json' --execute
```

This creates an unpublished draft referencing the sample **Semantic Model**,
with Plants, Assets and Readings selected by name, not either ontology. Public
read-back verifies the source IDs, instructions, selections and absence of
published parts. The published Data Agent datasource schema does not yet
provide a verified Ontology type; the script does not invent one. No published
definition or publish-info part is submitted. Agent answers are not validated.

### Operations Agent artifact

```powershell
.\.venv\Scripts\python.exe .\create_sample_agent.py --kind operations --unconfigured `
    --sources-manifest '.\runs\<old-run>\sources.manifest.json' `
    --workspace-id '<target-workspace-guid>' --name OperationsAgent_Sample_Demo `
    --manifest '.\operations-agent.manifest.json' --execute
```

This deliberately creates an **unconfigured, inactive artifact** and checks its
reported state. It does **not** attach an ontology or author a playbook. Connect
the desired ontology and author/review the playbook in Fabric before testing.
Monitoring, notifications, publishing and external actions remain disabled.
Operations Agent requires an eligible paid capacity, tenant rollout and a user
identity; this is not a service-principal scenario.

**Daily limitation observed on 2026-10-22:** creation with the documented
`Configurations.json`, an Ontology source, `playbook: {}`, `actions: {}`, and
`shouldRun: false` returned HTTP 400:
`No rule definitions available in the playbook.`
Request ID: `486fd276-6c58-42d2-90f0-89820b0b9a60`.
No agent item was found after that rejected request. The documented name-only
creation succeeded and the resulting artifact reported `Inactive`.

The configured request remains available for environments where the documented
empty-playbook contract is accepted: omit `--unconfigured`, supply
`--ontology-id`, and optionally `--ontology-workspace-id` (defaults to agent
workspace). **It is not currently verified to work on Daily.** It never silently
falls back to an unconfigured artifact or fabricates runnable rules/actions.

### Preview, sign-in and recovery

Omit `--execute` for an offline preview. All companions accept `--auth
auto|cli|browser` and `--client-id` using the same browser-capable authentication
as the main launcher. Each execution requires a **new manifest path**. Name
collisions are refused and no resources are deleted or overwritten.

After an ambiguous failure, inspect the saved operation and workspace first.
If an item exists, do not create again. Recheck with the same source/name/
workspace options, a fresh manifest path, `--execute --verify-only`, and:

- Second ontology: `--ontology-id '<existing-id>'`.
- Agent: `--item-id '<existing-id>'`; retain the original `--kind` and
  `--unconfigured` or ontology-source options.

### Remaining acceptance scenarios

- Native semantic-model Import/Promote is a separate validation.
- Configure the Operations Agent ontology/playbook, review its behavior, then
  explicitly authorize starting monitoring or enabling notifications/actions.
- Validate Data Agent answers before publishing.
- For each ontology source group, ask which asset has the highest temperature
  and which plant owns it. Expected: **A012, 32.9 C, P03 / East Plant / Boston**,
  reading R0120 at 2026-01-01 00:45 UTC. Counts are 3 plants, 12 assets and 120
  readings **per copy**, not summed across the identical source groups.

## Validation boundary

All seven source types and a same-workspace public ontology replacement were
live-verified in normal Daily during development. The new **cross-workspace,
single-launcher** workflow is covered by offline orchestration/failure tests and
format-compatibility checks, but has **not yet completed a fresh live
cross-workspace run**. Direct approved-client browser fallback is mock-tested,
not tenant-policy sign-off. Version 7 passed **152 offline tests**, independent
reference-parser checks of its generated TMDL, a fresh **live read-only public
export verification** of all 18 entities and bindings using Python alone, and
a fresh-environment launcher test under Windows PowerShell 5.1. Service-generated
annotations are preserved; unsupported syntax is rejected explicitly.
Version 8 adds **169 passing offline tests** and same-workspace live checks of:

- A newly created semantic-model-only ontology: 3 entities/tables and 2
  relationships/entity relationships.
- A newly created Data Agent draft, including all three selected sample tables.
- A newly created unconfigured Operations Agent reporting `Inactive`.
- The unchanged original all-source ontology: 18 entities/tables and 12
  relationships/entity relationships.

The Data Agent's first post-create check rejected a service-normalized folder
name/default metadata. The verifier was corrected and a fresh **read-only**
check passed; creation was not replayed. Table-selection persistence is not
proof of query-time resolution. Connected Operations Agent creation remains
blocked by the empty-playbook rejection described above.
Version 9 passes **174 offline tests**, including reproduction of the combined
952/18456 diagnostic, recovery during initial connectivity and subsequent table
reads, timeout handling, and immediate failure of genuine authentication errors.
This fix was not live-retested on the affected user's machine; the earlier live
artifact checks above remain the live-validation boundary.
Source data checks and definition verification do
not establish that ontology queries or agents work.

Run offline regression tests after dependency setup:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s . -p 'test_*.py'
```

Public API references:
[create ontology](https://learn.microsoft.com/en-us/rest/api/fabric/ontology/items/create-ontology),
[get definition](https://learn.microsoft.com/en-us/rest/api/fabric/ontology/items/get-ontology-definition),
[update definition](https://learn.microsoft.com/en-us/rest/api/fabric/ontology/items/update-ontology-definition),
[create Data Agent](https://learn.microsoft.com/en-us/rest/api/fabric/dataagent/items/create-data-agent),
[Data Agent definition](https://learn.microsoft.com/en-us/rest/api/fabric/articles/item-management/definitions/data-agent-definition),
[Data Agent datasource schema](https://developer.microsoft.com/json-schemas/fabric/item/dataAgent/definition/dataSource/1.0.0/schema.json),
[create Operations Agent](https://learn.microsoft.com/en-us/rest/api/fabric/operationsagent/items/create-operations-agent),
[Operations Agent definition](https://learn.microsoft.com/en-us/rest/api/fabric/articles/item-management/definitions/operations-agent-definition),
[interactive browser credential](https://learn.microsoft.com/en-us/python/api/azure-identity/azure.identity.interactivebrowsercredential).

The ZIP contains an explicit file allowlist and a `PACKAGE.json` SHA-256 inventory.
To rebuild it from these sources without including local environments, tokens,
manifests, or SDK binaries:

```powershell
.\.venv\Scripts\python.exe .\build_package.py --output .\ontology-sample-v9.zip
```
