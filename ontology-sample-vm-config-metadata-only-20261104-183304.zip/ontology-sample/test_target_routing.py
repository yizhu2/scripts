import unittest
from unittest.mock import Mock, patch

from create_sample import PBI_SCOPE
from target_routing import DAILY_FABRIC_API, DAILY_ONELAKE_DFS, TargetApi, source_onelake_url, target_fabric_api
from test_create_sample import response

WORKSPACE = "38c7f0a3-4987-49fa-b3a1-b800a804d0c7"
TENANT = "aabbccdd-1234-4567-89ab-0123456789ab"
OPERATION = "dd8be01c-5c05-4ad0-8da7-6ebabcc0a7a0"


class TargetRoutingTests(unittest.TestCase):
    def test_onelake_wspl_uses_daily_workspace_dfs_not_global_origin(self):
        for workspace in (WORKSPACE, WORKSPACE.upper(), WORKSPACE.replace("-", "")):
            self.assertEqual(source_onelake_url("wspl", workspace),
                             "https://38c7f0a3498749fab3a1b800a804d0c7.z38.daily-dfs.fabric.microsoft.com")
        for network in ("public", "tenantpl"):
            self.assertEqual(source_onelake_url(network, WORKSPACE), DAILY_ONELAKE_DFS)
        for network, workspace in (("bad", WORKSPACE), ("wspl", "not-a-guid")):
            with self.assertRaises(ValueError):
                source_onelake_url(network, workspace)

    def test_exact_ws_endpoint_and_hexadecimal_zone(self):
        self.assertEqual(target_fabric_api("wspl", WORKSPACE, TENANT),
                         "https://38c7f0a3498749fab3a1b800a804d0c7.z38.w.dailyapi.fabric.microsoft.com/v1")
        self.assertEqual(target_fabric_api("wspl", TENANT.upper(), TENANT),
                         "https://aabbccdd1234456789ab0123456789ab.zaa.w.dailyapi.fabric.microsoft.com/v1")
        self.assertEqual(target_fabric_api("wspl", "00000001-0000-4000-8000-000000000000", TENANT),
                         "https://00000001000040008000000000000000.z00.w.dailyapi.fabric.microsoft.com/v1")

    def test_tenant_endpoint_uses_lowercase_hyphen_free_tenant_id(self):
        for tenant in (TENANT, TENANT.upper(), TENANT.replace("-", "")):
            self.assertEqual(target_fabric_api("tenantpl", WORKSPACE, tenant),
                             "https://aabbccdd1234456789ab0123456789ab-api.analysis.windows.net/v1")
        self.assertEqual(
            target_fabric_api("tenantpl", WORKSPACE, "76cccf45-162c-4574-a613-1468d666a43c"),
            "https://76cccf45162c4574a6131468d666a43c-api.analysis.windows.net/v1")
        self.assertEqual(
            target_fabric_api("tenantpl", WORKSPACE, "00000001-0000-4000-8000-000000000000"),
            "https://00000001000040008000000000000000-api.analysis.windows.net/v1")

    def test_agent_runner_uses_same_corrected_tenant_endpoint(self):
        from validation_common import ValidationContext

        credential = Mock()
        ctx = ValidationContext({"target_network": "tenantpl", "workspace_id": WORKSPACE,
                                 "tenant_id": TENANT}, credential, ".")
        self.addCleanup(ctx.close)
        self.assertEqual(ctx.fabric.base,
                         "https://aabbccdd1234456789ab0123456789ab-api.analysis.windows.net/v1")
        credential.get_token.assert_not_called()

    def test_public_mode_preserves_existing_endpoint(self):
        self.assertEqual(target_fabric_api("public", WORKSPACE, TENANT), DAILY_FABRIC_API)

    def test_invalid_mode_and_ids_are_rejected(self):
        for network, workspace, tenant in (
            ("unknown", WORKSPACE, TENANT), ("wspl", "not-guid", TENANT),
            ("tenantpl", WORKSPACE, "not-guid"),
        ):
            with self.subTest(network=network), self.assertRaises(ValueError):
                target_fabric_api(network, workspace, tenant)

    def api(self, network):
        api = TargetApi(target_fabric_api(network, WORKSPACE, TENANT), PBI_SCOPE, Mock(), 30)
        api.session.close()
        api.session = Mock()
        api.credential.get_token.return_value.token = "test-token"
        self.addCleanup(api.close)
        return api

    @patch("create_sample.time.sleep")
    def test_creation_update_and_readback_poll_only_selected_origin(self, sleep):
        for network in ("wspl", "tenantpl", "public"):
            for route in ("items", f"ontologies/{WORKSPACE}/updateDefinition",
                          f"ontologies/{WORKSPACE}/getDefinition"):
                for link_style in ("selected", "canonical", "relative"):
                    with self.subTest(network=network, route=route, link_style=link_style):
                        api = self.api(network)
                        operation = f"/v1/operations/{OPERATION}"
                        if link_style == "selected":
                            operation = api.base.removesuffix("/v1") + operation
                        elif link_style == "canonical":
                            operation = DAILY_FABRIC_API.removesuffix("/v1") + operation
                        api.operation_callback = Mock()
                        api.session.request.side_effect = [
                            response(202, headers={"Location": operation, "Retry-After": "0"}),
                            response(body={"status": "Running"}, headers={"Retry-After": "0"}),
                            response(body={"status": "Succeeded"}, headers={"Location": operation + "/result"}),
                            response(body={"id": WORKSPACE}),
                        ]
                        target = f"{api.base}/workspaces/{WORKSPACE}/{route}"
                        self.assertEqual(api.mutate(target), {"id": WORKSPACE})
                        self.assertEqual([call.args[1] for call in api.session.request.call_args_list], [
                            target, f"{api.base}/operations/{OPERATION}", f"{api.base}/operations/{OPERATION}",
                            f"{api.base}/operations/{OPERATION}/result",
                        ])
                        api.operation_callback.assert_called_once_with(f"{api.base}/operations/{OPERATION}")
                        for call in api.session.request.call_args_list:
                            self.assertEqual(call.kwargs["headers"]["Authorization"], "Bearer test-token")
                            self.assertFalse(call.kwargs["allow_redirects"])
                        self.assertTrue(all(call.args == (PBI_SCOPE,)
                                            for call in api.credential.get_token.call_args_list))

    @patch("create_sample.time.sleep")
    def test_global_result_link_without_location_and_no_result_operations(self, sleep):
        api = self.api("wspl")
        operation = f"{DAILY_FABRIC_API}/operations/{OPERATION}"
        for result_required in (True, False):
            api.session.request.reset_mock()
            api.session.request.side_effect = [
                response(202, headers={"Location": operation, "Retry-After": "0"}),
                response(body={"status": "Succeeded"}),
                response(body={"id": WORKSPACE}),
            ]
            api.mutate(f"{api.base}/workspaces/{WORKSPACE}/items", result_required=result_required)
            self.assertEqual(api.session.request.call_count, 3 if result_required else 2)
            self.assertTrue(all(call.args[1].startswith(api.base + "/")
                                for call in api.session.request.call_args_list))

    def test_untrusted_or_non_operation_locations_stop_before_polling(self):
        for location in (
            f"https://untrusted.invalid/v1/operations/{OPERATION}",
            f"https://api.fabric.microsoft.com/v1/operations/{OPERATION}",
            f"{DAILY_FABRIC_API}/workspaces/{WORKSPACE}/items",
            f"{DAILY_FABRIC_API}/operations/{OPERATION}?token=unexpected",
            f"{DAILY_FABRIC_API}/operations/{OPERATION}#fragment",
            "https://dailyapi.fabric.microsoft.com/v1/operations/" + "-" * 36,
        ):
            with self.subTest(location=location):
                api = self.api("wspl")
                api.session.request.return_value = response(202, headers={"Location": location})
                with self.assertRaises((ValueError, RuntimeError)):
                    api.mutate(api.base + "/items")
                api.session.request.assert_called_once()

    def test_direct_global_requests_and_redirects_are_not_followed(self):
        api = self.api("tenantpl")
        with self.assertRaises(RuntimeError):
            api.json("GET", DAILY_FABRIC_API + "/workspaces/" + WORKSPACE)
        api.session.request.assert_not_called()
        api.session.request.return_value = response(302, headers={"Location": DAILY_FABRIC_API})
        with self.assertRaisesRegex(RuntimeError, "302"):
            api.json("GET", api.base + "/workspaces/" + WORKSPACE)
        api.session.request.assert_called_once()

    def test_policy_denial_is_not_retried_or_changed_to_public(self):
        api = self.api("wspl")
        api.session.request.return_value = response(403, {"errorCode": "RequestDeniedByInboundPolicy"})
        with self.assertRaisesRegex(RuntimeError, "RequestDeniedByInboundPolicy"):
            api.json("GET", api.base + "/workspaces/" + WORKSPACE)
        api.session.request.assert_called_once()


if __name__ == "__main__":
    unittest.main()
