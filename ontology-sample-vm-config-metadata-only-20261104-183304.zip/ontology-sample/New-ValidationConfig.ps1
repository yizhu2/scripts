#Requires -Version 5.1
<#
.DESCRIPTION
Construct validation configuration from an exact provisioning run and read-only service discovery.
Run inside the intended private-network VM using its existing approved sign-in.
No Fabric items, network policies, permissions, source data or existing configs are changed.
Use -PlanOnly for local manifest checks without authentication or network requests.
Missing settings are prompted in the VM; -NonInteractive blocks instead of prompting.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$RunManifest,
    [string]$SourcesManifest,
    [string]$OutputConfig,
    [ValidateSet('cli', 'browser')][string]$Auth,
    [string]$ClientId,
    [ValidateRange(30, 1800)][int]$Timeout = 120,
    [string]$PythonExecutable,
    [switch]$PlanOnly,
    [switch]$NonInteractive
)

$ErrorActionPreference = 'Stop'
$runPath = (Resolve-Path -LiteralPath $RunManifest -ErrorAction Stop).Path
if ($SourcesManifest) {
    $sourcesPath = (Resolve-Path -LiteralPath $SourcesManifest -ErrorAction Stop).Path
}
if (-not $OutputConfig) {
    $OutputConfig = Join-Path $PSScriptRoot (
        'validation.discovered.' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.' +
        [guid]::NewGuid().ToString('N').Substring(0, 8) + '.json')
}
if (Test-Path -LiteralPath $OutputConfig) {
    throw 'OutputConfig already exists. Choose a new filename; existing configuration is never overwritten.'
}
$launchArguments = @()
if ($PythonExecutable) {
    $python = (Get-Command $PythonExecutable -CommandType Application -ErrorAction Stop | Select-Object -First 1).Source
}
elseif (Test-Path -LiteralPath (Join-Path $PSScriptRoot '.venv\Scripts\python.exe')) {
    $python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
}
elseif (Get-Command py -CommandType Application -ErrorAction SilentlyContinue) {
    $python = (Get-Command py -CommandType Application | Select-Object -First 1).Source
    $launchArguments = @('-3')
}
elseif (Get-Command python -CommandType Application -ErrorAction SilentlyContinue) {
    $python = (Get-Command python -CommandType Application | Select-Object -First 1).Source
}
else {
    throw 'Python 3.10+ is required. Reuse Start-Sample.ps1 setup or provide -PythonExecutable.'
}

& $python @launchArguments -c "import sys, importlib.util; sys.exit(3 if sys.version_info < (3,10) else (0 if all(importlib.util.find_spec(m) for m in ('requests', 'azure')) and importlib.util.find_spec('azure.identity') else 4))"
if ($LASTEXITCODE -eq 3) { throw 'Python 3.10 or later is required.' }
if ($LASTEXITCODE -ne 0) {
    throw 'Python dependencies are missing. Reuse the sample environment or install requirements.txt from an approved source. No automatic download or login was attempted.'
}
$arguments = @(
    (Join-Path $PSScriptRoot 'discover_validation.py'),
    '--run-manifest', $runPath,
    '--output-config', $OutputConfig,
    '--timeout', [string]$Timeout
)
if ($SourcesManifest) { $arguments += @('--sources-manifest', $sourcesPath) }
if ($Auth) { $arguments += @('--auth', $Auth) }
if ($ClientId) { $arguments += @('--client-id', $ClientId) }
if ($NonInteractive) { $arguments += '--non-interactive' }
if (-not $PlanOnly) { $arguments += '--execute' }
& $python @launchArguments @arguments
if ($LASTEXITCODE -ne 0) {
    throw 'Configuration discovery did not complete. Review the safe diagnostic above. No fallback route or resource creation was attempted.'
}
if (-not $PlanOnly) {
    if (-not (Test-Path -LiteralPath $OutputConfig -PathType Leaf)) {
        throw 'Discovery returned without creating the requested config. Validation was not started.'
    }
    Write-Host "Config: $OutputConfig"
    Write-Host 'Next: run Start-Validation.ps1 with this config and your explicit scenario selection, starting with -PlanOnly.'
}
