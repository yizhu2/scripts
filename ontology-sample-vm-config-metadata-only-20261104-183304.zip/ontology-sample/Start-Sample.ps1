#Requires -Version 5.1
[CmdletBinding()]
param(
    [string]$TenantId,
    [string]$CapacityId,
    [string]$WorkspaceId,
    [switch]$SameWorkspace,
    [ValidateSet('Eventhouse', 'KQLDatabase', 'Lakehouse', 'MirroredDatabase', 'SemanticModel', 'SQLDatabase', 'Warehouse')]
    [string[]]$SourceTypes,
    [ValidateSet('public', 'wspl', 'tenantpl')][string]$TargetNetwork,
    [ValidateSet('public', 'ux', 'hybrid')][string]$AuthoringMode = 'public',
    [string]$UxMetadataApi,
    [string]$UxWorkloadHost,
    [ValidateSet('v1', 'v2')][string]$UxTokenVersion,
    [string]$PythonExecutable,
    [ValidateSet('auto', 'cli', 'browser')][string]$Auth = 'auto',
    [string]$ClientId,
    [string]$SourceWorkspaceName,
    [string]$OntologyName,
    [string]$SourcesManifest,
    [switch]$SkipSourceCreation,
    [string]$SourceWorkspaceId,
    [hashtable]$SourceItemIds = @{},
    [ValidateSet('Eventhouse', 'KQLDatabase', 'Lakehouse', 'MirroredDatabase', 'SemanticModel', 'SQLDatabase', 'Warehouse')]
    [string]$RetrySource,
    [string]$OntologyId,
    [string]$RunDirectory,
    [ValidateRange(30, 86400)][int]$TimeoutSeconds = 1800,
    [ValidateRange(0, 86400)][int]$SettleSeconds = 120,
    [ValidateRange(30, 3600)][int]$KqlRequestTimeoutSeconds = 300,
    [switch]$VerifyOnly,
    [switch]$PlanOnly
)

$ErrorActionPreference = 'Stop'
if ($SameWorkspace -and ($CapacityId -or $SourceWorkspaceName -or $RetrySource)) {
    throw '-SameWorkspace reads the existing capacity/name. Omit -CapacityId/-SourceWorkspaceName; -RetrySource inherits topology from its manifest.'
}
if ($SameWorkspace -and $SourceWorkspaceId -and $WorkspaceId -and
    ([guid]$SourceWorkspaceId -ne [guid]$WorkspaceId)) {
    throw '-SameWorkspace requires source and target workspace IDs to match.'
}
$AuthoringMode = $AuthoringMode.ToLowerInvariant()
if ($AuthoringMode -eq 'public' -and ($UxMetadataApi -or $UxWorkloadHost -or $UxTokenVersion)) {
    throw 'UX routing/token options require -AuthoringMode ux or hybrid.'
}
$reuseWorkspace = $SkipSourceCreation -or [bool]$SourceWorkspaceId
if ($reuseWorkspace -and ($SourcesManifest -or $SourceWorkspaceName -or $RetrySource)) {
    throw 'Existing source workspace reuse cannot be combined with -SourcesManifest, -SourceWorkspaceName, or -RetrySource.'
}
if ($SourceItemIds.Count -and -not $reuseWorkspace) {
    throw '-SourceItemIds requires -SkipSourceCreation or -SourceWorkspaceId.'
}
foreach ($kind in $SourceItemIds.Keys) {
    $parsed = [guid]::Empty
    if ($kind -cnotin @('Eventhouse', 'KQLDatabase', 'Lakehouse', 'MirroredDatabase', 'SemanticModel', 'SQLDatabase', 'Warehouse') -or
        -not [guid]::TryParse([string]$SourceItemIds[$kind], [ref]$parsed)) {
        throw 'SourceItemIds must map supported source type names to item GUIDs.'
    }
}
if ($RetrySource) {
    if (-not $SourcesManifest) { throw '-RetrySource requires -SourcesManifest.' }
    foreach ($name in @('SourceTypes', 'TenantId', 'CapacityId', 'WorkspaceId', 'TargetNetwork', 'AuthoringMode', 'UxMetadataApi', 'UxWorkloadHost', 'UxTokenVersion', 'SourceWorkspaceName', 'OntologyName', 'OntologyId')) {
        if ($PSBoundParameters.ContainsKey($name)) { throw "-$name cannot be combined with -RetrySource; identity comes from the source manifest." }
    }
}
function Find-SamplePython {
    param([string]$Executable)
    $candidates = @()
    if ($Executable) {
        $command = Get-Command $Executable -CommandType Application -ErrorAction SilentlyContinue
        if ($command) { $candidates += @{ Path = $command.Source; Arguments = @() } }
    }
    else {
        foreach ($name in @('py', 'python')) {
            $command = Get-Command $name -CommandType Application -ErrorAction SilentlyContinue
            if ($command) {
                $launchArguments = @()
                if ($name -eq 'py') { $launchArguments = @('-3') }
                $candidates += @{ Path = $command.Source; Arguments = $launchArguments }
            }
        }
        if ($env:LOCALAPPDATA) {
            $installedPython = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'
            if (Test-Path -LiteralPath $installedPython) {
                $candidates += @{ Path = $installedPython; Arguments = @() }
            }
        }
    }
    foreach ($candidate in $candidates) {
        $launchArguments = $candidate.Arguments
        $ErrorActionPreference = 'Continue'
        $global:LASTEXITCODE = -1
        & $candidate.Path @launchArguments -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' *> $null
        $exitCode = $LASTEXITCODE
        $ErrorActionPreference = 'Stop'
        if ($exitCode -eq 0) { return $candidate }
    }
}

function Find-SampleAzureCli {
    $command = Get-Command az -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($command) { return $command.Source }
    foreach ($root in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if ($root) {
            $candidate = Join-Path $root 'Microsoft SDKs\Azure\CLI2\wbin\az.cmd'
            if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
        }
    }
}

function Initialize-SampleAzureCli {
    param([ValidateSet('auto', 'cli')][string]$Mode)
    $cliHelp = 'Install Azure CLI from https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-windows or your approved software source. For a nonstandard installation, put its az.cmd directory on PATH and reopen PowerShell.'
    $az = Find-SampleAzureCli
    if (-not $az) {
        Write-Host 'Azure CLI was not found on PATH or in its standard Windows installation locations.'
        $winget = Get-Command winget -CommandType Application -ErrorAction SilentlyContinue
        $unavailable = $null
        if (-not $winget) { $unavailable = 'WinGet is unavailable.' }
        else {
            $install = Read-Host 'Install Azure CLI using WinGet? Administrator approval may be required. [y/N]'
            if ($install -notin @('y', 'yes')) { $unavailable = 'Azure CLI installation was not approved.' }
        }
        if ($unavailable) {
            if ($Mode -eq 'cli') { throw "$unavailable $cliHelp" }
            Write-Warning "$unavailable Auto authentication will still offer organization-approved client browser sign-in; an approved application ID is required. $cliHelp"
            return
        }
        & $winget.Source install --exact --id Microsoft.AzureCLI --source winget --scope machine
        if ($LASTEXITCODE -ne 0) {
            throw "Azure CLI installation failed (WinGet exit code $LASTEXITCODE). Review the installer output. $cliHelp"
        }
        $az = Find-SampleAzureCli
        if (-not $az) { throw "WinGet finished, but Azure CLI could not be located. $cliHelp" }
    }
    $global:LASTEXITCODE = -1
    & $az version --output json | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Azure CLI was found but its version check failed. $cliHelp" }
    $cliDirectory = Split-Path -Parent $az
    if ($cliDirectory -notin ($env:PATH -split ';')) {
        $env:PATH = "$cliDirectory;$env:PATH"
    }
    Write-Host 'Azure CLI is available to this launcher and its Python process. Sign-in will be handled by the authentication workflow.'
}

function Get-SampleOdbcDrivers {
    param([string]$Python)
    $output = & $Python -c 'import json, pyodbc; print(json.dumps(pyodbc.drivers()))'
    if ($LASTEXITCODE -ne 0) {
        throw 'Could not check ODBC drivers using the sample Python environment. Review the Python error before installing a driver.'
    }
    $drivers = $output | ConvertFrom-Json
    foreach ($driver in $drivers) { $driver }
}

function Initialize-SampleOdbc {
    param([string]$Python)
    $driver = 'ODBC Driver 18 for SQL Server'
    $drivers = @(Get-SampleOdbcDrivers -Python $Python)
    if ($driver -in $drivers) { return }
    $odbcHelp = 'Install Microsoft ODBC Driver 18 for SQL Server from https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server or your approved software source, then rerun. The driver must be visible to the sample Python environment; installing pyodbc alone is not sufficient.'
    Write-Host "$driver is required for this workflow. Found: $($drivers -join ', ')"
    $winget = Get-Command winget -CommandType Application -ErrorAction SilentlyContinue
    if (-not $winget) { throw "WinGet is unavailable. $odbcHelp" }
    $install = Read-Host 'Install ODBC Driver 18 and its required dependencies using WinGet? Administrator approval may be required. [y/N]'
    if ($install -notin @('y', 'yes')) { throw "ODBC driver installation was not approved. $odbcHelp" }
    & $winget.Source install --exact --id Microsoft.msodbcsql.18 --source winget --scope machine
    if ($LASTEXITCODE -ne 0) {
        throw "ODBC driver installation failed (WinGet exit code $LASTEXITCODE). Review the installer output, including any permission or restart requirement. $odbcHelp"
    }
    $drivers = @(Get-SampleOdbcDrivers -Python $Python)
    if ($driver -notin $drivers) {
        throw "WinGet finished, but $driver is still unavailable to the sample Python environment. Found: $($drivers -join ', '). $odbcHelp"
    }
    Write-Host "$driver is available to the sample Python environment."
}

$python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $python)) {
    $pythonHelp = 'Install Python 3.10+ from https://www.python.org/downloads/windows/ or your approved software source. Select Add Python to PATH, reopen PowerShell, and rerun. Alternatively use -PythonExecutable with the full path to python.exe.'
    $launcher = Find-SamplePython -Executable $PythonExecutable
    if (-not $launcher -and $PythonExecutable) {
        throw "The specified Python executable is missing or is not a working Python 3.10+: $PythonExecutable. $pythonHelp"
    }
    if (-not $launcher) {
        Write-Host 'No working Python 3.10+ was found. The Windows Microsoft Store shortcut is not a Python installation.'
        $winget = Get-Command winget -CommandType Application -ErrorAction SilentlyContinue
        if (-not $winget) { throw "WinGet is unavailable. $pythonHelp" }
        $install = Read-Host 'Install Python 3.12 for the current user using WinGet? [y/N]'
        if ($install -notin @('y', 'yes')) { throw "Python installation was not approved. $pythonHelp" }
        & $winget.Source install --exact --id Python.Python.3.12 --source winget --scope user
        if ($LASTEXITCODE -ne 0) {
            throw "Python installation failed (WinGet exit code $LASTEXITCODE). Review the installer output. $pythonHelp"
        }
        $launcher = Find-SamplePython
        if (-not $launcher) {
            throw "WinGet finished, but a working Python 3.10+ could not be located. $pythonHelp"
        }
        Write-Host "Using Python launcher: $($launcher.Path)"
    }
    $pythonArgs = $launcher.Arguments
    & $launcher.Path @pythonArgs -m venv (Join-Path $PSScriptRoot '.venv')
    if ($LASTEXITCODE -ne 0) { throw 'Python virtual environment creation failed. Install a working Python 3.10+.' }
}

$requirements = Join-Path $PSScriptRoot 'requirements.txt'
$stamp = Join-Path $PSScriptRoot '.venv\ontology-sample.requirements.sha256'
$hash = & $python -c 'import hashlib, pathlib, sys; print(hashlib.sha256(pathlib.Path(sys.argv[1]).read_bytes()).hexdigest())' $requirements
if ($LASTEXITCODE -ne 0) { throw 'Could not read the package requirements.' }
& $python -c 'import azure.identity, azure.storage.filedatalake, pyarrow.parquet, pyodbc, requests, tzdata'
$missingDependencies = $LASTEXITCODE -ne 0
$changedRequirements = -not (Test-Path -LiteralPath $stamp)
if (-not $changedRequirements) { $changedRequirements = (Get-Content -LiteralPath $stamp -Raw).Trim() -ne $hash }
if ($missingDependencies -or $changedRequirements) {
    Write-Host 'Installing the package requirements into the local .venv...'
    & $python -m pip install -r $requirements
    if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Check the pip error and your approved package feed.' }
    Set-Content -LiteralPath $stamp -Value $hash -Encoding ASCII
}

$needsAzureCli = -not $PlanOnly -and $Auth -ne 'browser'
if ($needsAzureCli) { Initialize-SampleAzureCli -Mode $Auth }

$needsSql = -not $PlanOnly -and (
    ($RetrySource -in @('Lakehouse', 'MirroredDatabase', 'SQLDatabase', 'Warehouse')) -or
    (-not $RetrySource -and -not $SourcesManifest -and (-not $VerifyOnly -or $reuseWorkspace) -and
        (-not $SourceTypes -or @($SourceTypes | Where-Object { $_ -in @('Lakehouse', 'MirroredDatabase', 'SQLDatabase', 'Warehouse') }).Count -gt 0))
)
if ($needsSql) { Initialize-SampleOdbc -Python $python }

if (-not $RetrySource) {
    if (-not $TenantId) { $TenantId = Read-Host 'Tenant ID' }
    if ($reuseWorkspace -and -not $SameWorkspace) {
        if (-not $SourceWorkspaceId) { $SourceWorkspaceId = Read-Host 'Existing workspace ID containing all sample sources' }
    }
    elseif (-not $SourcesManifest -and -not $CapacityId -and -not $SameWorkspace) {
        $CapacityId = Read-Host 'Capacity ID for the NEW source workspace'
    }
    if (-not $WorkspaceId) { $WorkspaceId = Read-Host 'Existing target workspace ID where the ontology should be created' }
    if ($SameWorkspace -and $SourceWorkspaceId -and ([guid]$SourceWorkspaceId -ne [guid]$WorkspaceId)) {
        throw '-SameWorkspace requires source and target workspace IDs to match.'
    }
    if ($SameWorkspace -and $reuseWorkspace) { $SourceWorkspaceId = $WorkspaceId }
    $ids = @($TenantId, $WorkspaceId)
    if ($reuseWorkspace) { $ids += $SourceWorkspaceId }
    if ($CapacityId) { $ids += $CapacityId }
    foreach ($id in $ids) {
        $parsed = [guid]::Empty
        if (-not [guid]::TryParse($id, [ref]$parsed)) { throw "Invalid GUID: $id" }
    }
    if ($reuseWorkspace -and -not $SameWorkspace -and ([guid]$SourceWorkspaceId -eq [guid]$WorkspaceId)) {
        throw 'Source and target workspaces must be different.'
    }
    if (-not $TargetNetwork) {
        $network = (Read-Host 'Target workspace network (wspl / tenantpl / public)').Trim().ToLowerInvariant()
        if ($network -notin @('wspl', 'tenantpl', 'public')) {
            throw 'Choose wspl, tenantpl, or public; no endpoint is selected automatically.'
        }
        $TargetNetwork = $network
    }
    $TargetNetwork = $TargetNetwork.ToLowerInvariant()
    if ($AuthoringMode -in @('ux', 'hybrid')) {
        if (-not $UxTokenVersion) { $UxTokenVersion = 'v2' }
        $UxTokenVersion = $UxTokenVersion.ToLowerInvariant()
    }
    if ($AuthoringMode -in @('ux', 'hybrid') -and $TargetNetwork -ne 'public') {
        Write-Host 'Private-link UX authoring needs the routes from a working UX generatemwctoken call. Never paste tokens or headers.'
        if (-not $UxMetadataApi) {
            $UxMetadataApi = Read-Host 'UX metadata HTTPS origin (without the /metadata/... path)'
        }
        if (-not $UxWorkloadHost) {
            $UxWorkloadHost = Read-Host 'UX TargetUriHost (hostname only, from the token response)'
        }
        if (-not $UxMetadataApi -or -not $UxWorkloadHost) {
            throw 'Both UX routing values are required for private-link mode; public fallback is disabled.'
        }
    }
}

$arguments = @(
    '--auth', $Auth, '--timeout', "$TimeoutSeconds",
    '--settle-seconds', "$SettleSeconds", '--kql-request-timeout', "$KqlRequestTimeoutSeconds"
)
if ($RetrySource) {
    $arguments = @((Join-Path $PSScriptRoot 'retry_source.py'), '--source-type', $RetrySource) + $arguments
}
else {
    $arguments = @(
        (Join-Path $PSScriptRoot 'run_sample.py'),
        '--tenant-id', $TenantId, '--workspace-id', $WorkspaceId, '--target-network', $TargetNetwork,
        '--authoring-mode', $AuthoringMode
    ) + $arguments
}
foreach ($pair in @(
    @('--client-id', $ClientId),
    @('--ux-metadata-api', $UxMetadataApi), @('--ux-workload-host', $UxWorkloadHost),
    @('--ux-token-version', $UxTokenVersion),
    @('--capacity-id', $CapacityId), @('--source-workspace-id', $SourceWorkspaceId),
    @('--source-workspace-name', $SourceWorkspaceName), @('--ontology-name', $OntologyName),
    @('--sources-manifest', $SourcesManifest), @('--ontology-id', $OntologyId),
    @('--run-directory', $RunDirectory)
)) {
    if ($pair[1]) { $arguments += $pair }
}
foreach ($kind in ($SourceItemIds.Keys | Sort-Object)) {
    $arguments += @('--source-item', "$kind=$($SourceItemIds[$kind])")
}
if ($VerifyOnly) { $arguments += '--verify-only' }
if ($SourceTypes) { $arguments += @('--source-types') + $SourceTypes }
if ($SameWorkspace) { $arguments += '--same-workspace' }
if ($SkipSourceCreation) { $arguments += '--skip-source-creation' }
if (-not $PlanOnly) {
    if (-not $VerifyOnly) {
        if ($RetrySource) {
            Write-Host "Create NEW $RetrySource source items in the existing source workspace; dependencies may be included."
            Write-Host 'Old items remain. No other source types are reloaded and no ontology is created or updated.'
        }
        else {
            Write-Host "Daily: create a NEW ontology in target workspace $WorkspaceId using $TargetNetwork routing."
            Write-Host "Ontology authoring mode: $AuthoringMode. UX and hybrid modes use internal scripting and require server auto-projection."
            if ($SameWorkspace) {
                Write-Host "Sources and ontology share existing workspace $WorkspaceId and $TargetNetwork Fabric routing."
                Write-Host 'No workspace creation/capacity assignment or network-policy changes. Data-plane DNS/routes must already work.'
            }
            if ($reuseWorkspace) {
                Write-Host "Read and verify existing sample sources in workspace $SourceWorkspaceId."
                Write-Host 'No source workspace/items are created and no source data is loaded or refreshed.'
            }
            elseif ($SourcesManifest) { Write-Host 'Reusing successful selected-source provisioning; recorded validation deferrals are respected.' }
            elseif ($SourceTypes) {
                Write-Host "Creating selected source types: $($SourceTypes -join ', '). Eventhouse includes KQLDatabase."
                if ('SemanticModel' -in $SourceTypes) { Write-Host 'SemanticModel refresh and row queries are deferred.' }
            }
            else { Write-Host 'Creating all seven source types; SemanticModel refresh and row queries are deferred.' }
        }
        Write-Host 'This consumes capacity. Existing target items are not overwritten or deleted.'
        if ((Read-Host 'Type CREATE to proceed') -cne 'CREATE') { throw 'Cancelled; no Fabric resources created.' }
    }
    $arguments += '--execute'
}
& $python @arguments
if ($LASTEXITCODE -ne 0) {
    throw 'Sample workflow failed. Read the original Python exception above and the run manifests before retrying; resources were not deleted.'
}
