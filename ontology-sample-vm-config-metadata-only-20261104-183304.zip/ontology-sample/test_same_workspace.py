import copy
import io
import json
import tempfile
import unittest
from contextlib import ExitStack, redirect_stdout
from pathlib import Path
from unittest.mock import MagicMock, Mock, patch
from uuid import uuid4

import create_sample as sample
import retry_source
import run_sample
from target_routing import DAILY_ONELAKE_DFS, TargetApi, source_onelake_url, target_fabric_api
from create_ontology import GROUPS, build_definition, discover_sources
from replace_ontology import read_and_verify, serialize_definition, verify_public_bindings
from test_create_ontology import GUID, inventory, metadata
from test_create_sample import response
from test_run_sample import TARGET, ONTOLOGY


class SameWorkspaceTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.folder = Path(directory.name)

    def flags(self, network="wspl"):
        return ["--tenant-id", GUID, "--workspace-id", TARGET, "--same-workspace",
                "--target-network", network, "--ontology-name", "BoundSample",
                "--run-directory", str(self.folder / "run")]

    def state(self, network="wspl"):
        state = inventory()
        state.update(workspaceId=TARGET, existingWorkspaceId=TARGET,
                     sameWorkspace=True, targetNetwork=network)
        state["endpoints"]["fabric"] = target_fabric_api(network, TARGET, GUID)
        return state

    def source_args(self, network="wspl", extra=()):
        return sample.arguments([
            "--tenant-id", GUID, "--workspace-id", TARGET, "--same-workspace",
            "--target-network", network, "--settle-seconds", "0", *extra,
        ])

    def test_plans_need_no_new_capacity_and_never_authenticate(self):
        for network in ("public", "wspl", "tenantpl"):
            with self.subTest(network=network), patch("builtins.input") as prompt, \
                    patch("run_sample.run") as run, redirect_stdout(io.StringIO()) as output:
                run_sample.main(self.flags(network))
                plan = json.loads(output.getvalue())
                self.assertIsNone(plan["capacityId"])
                self.assertTrue(plan["sameWorkspace"])
                self.assertFalse(plan["createsSourceWorkspace"])
                self.assertTrue(plan["createsSourceItems"])
                self.assertEqual(plan["sourceWorkspaceId"], TARGET)
                self.assertEqual(plan["sourceFabricApi"], plan["targetFabricApi"])
                self.assertEqual(plan["sourceOneLakeUrl"], source_onelake_url(network, TARGET))
                self.assertEqual(plan["deferredValidation"], {"SemanticModel": ["refresh", "sampleRows"]})
                prompt.assert_not_called()
                run.assert_not_called()
                self.assertFalse((self.folder / "run").exists())

    def test_incompatible_inputs_fail_before_prompts_or_outputs(self):
        for flags in (["--capacity-id", GUID], ["--source-workspace-name", "Other"],
                      ["--source-workspace-id", GUID], ["--verify-only"],
                      ["--source-item", f"Lakehouse={GUID}"],
                      ["--skip-source-creation", "--sources-manifest", "sources.json"]):
            with self.subTest(flags=flags), patch("builtins.input") as prompt, \
                    patch("sys.stderr", io.StringIO()), self.assertRaises(SystemExit):
                run_sample.arguments(self.flags() + flags)
            prompt.assert_not_called()
        for flags in (["--capacity-id", GUID], ["--workspace-name", "Other"],
                      ["--skip-eventhouse-kql"], ["--fabric-api", run_sample.DAILY_ENDPOINTS["fabric"]],
                      ["--kql-endpoint", "https://invented.invalid"],
                      ["--sql-endpoints", '{"Warehouse":{"server":"invented.invalid"}}'],
                      ["--onelake-url", "https://invented.invalid"]):
            with self.subTest(flags=flags), patch("sys.stderr", io.StringIO()), self.assertRaises(SystemExit):
                self.source_args(extra=flags)

    def test_equal_ids_require_opt_in_and_discovery_uses_target_without_prompt(self):
        with patch("builtins.input") as prompt:
            args = run_sample.arguments(self.flags() + ["--skip-source-creation"])
        self.assertTrue(args.skip_source_creation)
        self.assertEqual(args.source_workspace_id, TARGET)
        prompt.assert_not_called()
        flags = self.flags()
        flags.remove("--same-workspace")
        with patch("sys.stderr", io.StringIO()), self.assertRaises(SystemExit):
            run_sample.arguments(flags + ["--source-workspace-id", TARGET])

    def provisioner(self, network="wspl"):
        args = self.source_args(network)
        manifest = sample.Manifest(self.folder / f"{uuid4().hex}.json", sample.source_plan(args))
        p = sample.Provisioner(args, Mock(), manifest)
        self.addCleanup(p.close)
        self.assertIsInstance(p.api, TargetApi)
        p.api.session.close()
        p.api.session = Mock()
        for name in ("seed_lakehouse", "seed_mirror", "seed_sql", "seed_kql",
                     "refresh_sql_metadata", "seed_semantic", "verify_semantic"):
            setattr(p, name, Mock())
        counts = {table.name: len(table.rows) for table in p.tables}
        p.verify_kql = Mock(side_effect=lambda: manifest.data["verified"].update(
            Eventhouse={"viaKqlDatabaseId": manifest.data["items"]["KQLDatabase"]["id"]},
            KQLDatabase=counts))
        p.verify_sql = Mock(side_effect=lambda kind, **kwargs: manifest.data["verified"].update({kind: counts}))
        return p

    def configure_creation(self, p, existing=None):
        workspace = {"id": TARGET, "capacityId": GUID, "displayName": "Protected"}
        items = existing or [{"id": ONTOLOGY, "displayName": "KeepMe", "type": "Ontology"}]
        p.api.session.request.side_effect = [
            response(body=workspace),
            response(body={"value": items[:1], "continuationToken": "next"}),
            response(body={"value": items[1:]}),
            *[response(201, {"id": str(uuid4())}) for _ in sample.COLLECTIONS],
        ]

    def test_existing_nonempty_workspace_creates_all_sources_without_workspace_or_assignment(self):
        for network in ("public", "wspl", "tenantpl"):
            with self.subTest(network=network):
                p = self.provisioner(network)
                self.configure_creation(p)
                p.run()
                state = p.manifest.data
                self.assertEqual(state["workspaceName"], "Protected")
                self.assertEqual(state["capacityId"], GUID)
                self.assertEqual(state["workspaceId"], TARGET)
                self.assertTrue(state["sameWorkspace"])
                self.assertEqual(state["targetNetwork"], network)
                self.assertEqual(set(state["items"]), set(sample.COLLECTIONS))
                requests = p.api.session.request.call_args_list
                self.assertEqual(len(requests), 10)
                base = target_fabric_api(network, TARGET, GUID) + "/workspaces/" + TARGET
                self.assertTrue(all(call.args[1].startswith(base) for call in requests))
                self.assertEqual([call.args[0] for call in requests], ["GET"] * 3 + ["POST"] * 7)
                self.assertTrue(all("/assign" not in call.args[1] for call in requests))
                p.seed_semantic.assert_not_called()
                p.verify_semantic.assert_not_called()
                sample_state = json.loads(p.manifest.path.read_text())
                self.assertEqual(sample_state["status"], "succeeded")

    def test_collision_on_later_page_and_old_id_stop_before_loading(self):
        p = self.provisioner()
        self.configure_creation(p, [
            {"id": ONTOLOGY, "displayName": "KeepMe"},
            {"id": GUID, "displayName": p.args.prefix + "_Lakehouse"},
        ])
        with self.assertRaisesRegex(ValueError, "name already exists"):
            p.run()
        self.assertEqual(p.api.session.request.call_count, 3)
        p.seed_lakehouse.assert_not_called()
        p = self.provisioner()
        self.configure_creation(p)
        responses = list(p.api.session.request.side_effect)
        responses[3] = response(201, {"id": ONTOLOGY})
        p.api.session.request.side_effect = responses
        with self.assertRaisesRegex(RuntimeError, "existing item ID"):
            p.run()
        p.seed_lakehouse.assert_not_called()

    def test_missing_capacity_and_changed_identity_prevent_creation(self):
        for workspace in ({"id": TARGET, "displayName": "Protected"},
                          {"id": GUID, "displayName": "Protected", "capacityId": GUID}):
            p = self.provisioner()
            p.api.session.request.return_value = response(body=workspace)
            with self.assertRaises(ValueError):
                p.run()
            p.api.session.request.assert_called_once()

    @patch("create_sample.time.sleep")
    def test_source_lros_use_selected_route_for_poll_and_result(self, sleep):
        operation = f"{run_sample.DAILY_ENDPOINTS['fabric']}/operations/{GUID}"
        for network in ("public", "wspl", "tenantpl"):
            for kind in sample.COLLECTIONS:
                p = self.provisioner(network)
                p.workspace = TARGET
                p.api.session.request.side_effect = [
                    response(202, headers={"Location": operation, "Retry-After": "0"}),
                    response(body={"status": "Succeeded"}, headers={"Location": operation + "/result"}),
                    response(body={"id": str(uuid4())}),
                ]
                p.create(kind)
                urls = [call.args[1] for call in p.api.session.request.call_args_list]
                self.assertTrue(all(url.startswith(p.api.base + "/") for url in urls))
                self.assertEqual(urls[1:], [f"{p.api.base}/operations/{GUID}",
                                            f"{p.api.base}/operations/{GUID}/result"])

    def test_manifest_provenance_rejected_before_authentication(self):
        for change in ("old", "workspace", "network", "endpoint", "existing"):
            state = self.state()
            if change == "old":
                del state["sameWorkspace"]
            elif change == "workspace":
                state["workspaceId"] = GUID
            elif change == "network":
                state["targetNetwork"] = "public"
            elif change == "endpoint":
                state["endpoints"]["fabric"] = run_sample.DAILY_ENDPOINTS["fabric"]
            else:
                state["existingWorkspaceId"] = GUID
            source = self.folder / "input.json"
            source.write_text(json.dumps(state))
            with self.subTest(change=change), patch("run_sample.run") as run, self.assertRaises(ValueError):
                run_sample.main(self.flags() + ["--sources-manifest", str(source), "--execute"])
            run.assert_not_called()
            self.assertFalse((self.folder / "run").exists())

    def test_matching_manifest_plan_and_live_capacity_change_fail_closed(self):
        state = self.state()
        source = self.folder / "input.json"
        source.write_text(json.dumps(state))
        with redirect_stdout(io.StringIO()) as output:
            run_sample.main(self.flags() + ["--sources-manifest", str(source)])
        plan = json.loads(output.getvalue())
        self.assertFalse(plan["createsSourceWorkspace"])
        self.assertFalse(plan["createsSourceItems"])
        args = run_sample.arguments(self.flags())
        api = Mock(base=args.target_fabric_api)
        api.json.side_effect = [{"id": TARGET, "capacityId": ONTOLOGY}, {"value": []}]
        manifest = sample.Manifest(self.folder / "capacity.json", {})
        with patch("run_sample.TargetApi", return_value=api), \
                patch("run_sample.discover_sources") as discover, \
                self.assertRaisesRegex(ValueError, "actual shared workspace"):
            run_sample.run(args, Mock(), manifest, None, state)
        api.mutate.assert_not_called()
        discover.assert_not_called()

    def test_service_reported_data_endpoints_and_same_workspace_binding_roundtrip(self):
        state = self.state()
        properties = metadata()
        api = Mock(base=state["endpoints"]["fabric"])
        api.json.side_effect = [
            {"id": TARGET, "capacityId": GUID, "displayName": state["workspaceName"]},
            *[{"id": state["items"][kind]["id"], "displayName": state["items"][kind]["displayName"],
               "properties": properties[kind]} for kind in GROUPS],
        ]
        found = discover_sources(api, state)
        self.assertEqual(found, properties)
        self.assertTrue(all(call.args[1].startswith(api.base + "/workspaces/" + TARGET)
                            for call in api.json.call_args_list))
        expected = build_definition(state, found, "powerbi://dailyapi.powerbi.com")
        body = serialize_definition(expected, self.folder)
        api.mutate.return_value = body
        manifest = sample.Manifest(self.folder / "readback.json", {})
        read_and_verify(api, f"{api.base}/workspaces/{TARGET}/ontologies/{ONTOLOGY}",
                        state, expected, self.folder, manifest, TARGET)
        self.assertEqual(manifest.data["verified"]["publicDefinition"]["entities"], 18)
        actual = copy.deepcopy(expected)
        warehouse = next(entry for entry in actual["model"]["expressions"] if entry["name"] == "Warehouse_Source")
        warehouse["expression"] = (
            'let Source = Sql.Database("ONT_ALM_SQL_ENDPOINT", '
            f'"ONT_ALM_SQL_DATABASE-RELATIVE-{state["items"]["Warehouse"]["displayName"]}") in Source'
        )
        verify_public_bindings(expected, actual, state, TARGET)
        with self.assertRaises(ValueError):
            verify_public_bindings(expected, actual, state, GUID)

        p = self.provisioner()
        p.workspace = TARGET
        p.manifest.data["items"] = state["items"]
        p.properties = Mock(side_effect=lambda kind, ready: properties[kind])
        client = p.kql_client()
        self.addCleanup(client.close)
        self.assertEqual(client.base, properties["KQLDatabase"]["queryServiceUri"])
        self.assertEqual(p.sql_target("SQLDatabase"),
                         (properties["SQLDatabase"]["serverFqdn"], properties["SQLDatabase"]["databaseName"]))
        self.assertEqual(p.sql_target("Warehouse"),
                         (properties["Warehouse"]["connectionString"], state["items"]["Warehouse"]["displayName"]))
        with patch("azure.storage.filedatalake.DataLakeServiceClient") as storage:
            p.upload(state["items"]["Lakehouse"]["id"], "Files/OntologySample/test.parquet", b"sample")
            self.assertEqual(storage.call_args.args[0], source_onelake_url("wspl", TARGET))
            service = storage.return_value.__enter__.return_value
            service.get_file_system_client.assert_called_once_with(TARGET)

    def test_onelake_denial_stops_without_global_fallback_or_file_upload(self):
        from azure.core.exceptions import HttpResponseError

        p = self.provisioner()
        p.workspace = TARGET
        with patch("azure.storage.filedatalake.DataLakeServiceClient") as storage:
            filesystem = storage.return_value.__enter__.return_value.get_file_system_client.return_value
            directory = filesystem.get_directory_client.return_value
            directory.create_directory.side_effect = HttpResponseError("DeniedByPolicy")
            with self.assertRaisesRegex(HttpResponseError, "DeniedByPolicy"):
                p.upload(GUID, "Files/OntologySample/Plants.parquet", b"sample")
            storage.assert_called_once()
            self.assertEqual(storage.call_args.args[0], source_onelake_url("wspl", TARGET))
            directory.create_directory.assert_called_once()
            directory.get_file_client.assert_not_called()

    def test_legacy_retry_records_corrected_onelake_route_without_changing_input(self):
        state = self.state()
        state["status"] = "failed"
        source = self.folder / "failed.json"
        source.write_text(json.dumps(state))
        before = source.read_bytes()
        output = self.folder / "retry"
        observed = []

        def verify_route(provisioner, selected, verify_only):
            observed.append(provisioner.args.onelake_url)
            self.assertEqual(selected, ("Lakehouse",))
            self.assertFalse(verify_only)
            provisioner.manifest.data["status"] = "partial"
            provisioner.manifest.save()

        with patch("retry_source.open_credential", MagicMock()), \
                patch("retry_source.check_local_dependencies"), \
                patch("retry_source.run", side_effect=verify_route), redirect_stdout(io.StringIO()):
            retry_source.main(["--sources-manifest", str(source), "--source-type", "Lakehouse",
                               "--run-directory", str(output), "--execute"])
        expected = source_onelake_url("wspl", TARGET)
        self.assertEqual(observed, [expected])
        result = json.loads((output / "sources.manifest.json").read_text())
        self.assertEqual(result["endpoints"]["onelake"], expected)
        self.assertEqual(result["sourceAttempt"]["endpoints"]["onelake"], DAILY_ONELAKE_DFS)
        self.assertEqual(result["retry"]["sourceOneLakeUrl"], expected)
        self.assertEqual(source.read_bytes(), before)
        self.assertEqual(result["items"], state["items"])

    def test_successful_manifests_accept_recorded_legacy_or_workspace_dfs_without_rewriting(self):
        for endpoint in (DAILY_ONELAKE_DFS, source_onelake_url("wspl", TARGET)):
            state = self.state()
            state["endpoints"]["onelake"] = endpoint
            source = self.folder / "successful.json"
            source.write_text(json.dumps(state))
            before = source.read_bytes()
            with redirect_stdout(io.StringIO()) as output:
                run_sample.main(self.flags() + ["--sources-manifest", str(source)])
            self.assertEqual(json.loads(output.getvalue())["sourceOneLakeUrl"], endpoint)
            self.assertEqual(source.read_bytes(), before)
        for endpoint in (source_onelake_url("wspl", GUID), "https://untrusted.invalid"):
            state["endpoints"]["onelake"] = endpoint
            source.write_text(json.dumps(state))
            with self.assertRaisesRegex(ValueError, "endpoints"):
                run_sample.main(self.flags() + ["--sources-manifest", str(source)])

    def test_manifest_verify_and_new_creation_route_both_clients_and_readback(self):
        for network in ("public", "wspl", "tenantpl"):
            for mode in ("create", "manifest", "verify", "workspace"):
                with self.subTest(network=network, mode=mode), ExitStack() as stack:
                    flags = self.flags(network)
                    if mode == "verify":
                        flags += ["--sources-manifest", "input.json", "--verify-only", "--ontology-id", ONTOLOGY]
                    elif mode == "workspace":
                        flags += ["--skip-source-creation"]
                    args = run_sample.arguments(flags)
                    source_args = self.source_args(network)
                    source_args.manifest = self.folder / f"{uuid4().hex}.json"
                    api = Mock(base=args.target_fabric_api)
                    api.json.side_effect = [
                        {"id": TARGET, "capacityId": GUID},
                        ({"id": ONTOLOGY, "type": "Ontology", "displayName": "BoundSample"}
                         if mode == "verify" else {"value": []}),
                    ]
                    api.mutate.return_value = {"id": ONTOLOGY}
                    source_api = Mock(base=args.target_fabric_api)
                    clients = stack.enter_context(patch("run_sample.TargetApi", side_effect=[api, source_api]))
                    public = stack.enter_context(patch("run_sample.Api"))
                    state = self.state(network)
                    provision = stack.enter_context(patch("run_sample.provision_sources", return_value=state))
                    reused = stack.enter_context(patch("run_sample.reuse_workspace_sources", return_value=state))
                    discover = stack.enter_context(patch("run_sample.discover_sources", return_value=metadata()))
                    stack.enter_context(patch("run_sample.serialize_definition", return_value={}))
                    readback = stack.enter_context(patch("run_sample.read_and_verify"))
                    manifest = sample.Manifest(self.folder / f"{uuid4().hex}.json", {})
                    run_sample.run(args, Mock(), manifest, source_args if mode == "create" else None,
                                   state if mode in ("manifest", "verify") else None)
                    self.assertEqual(clients.call_count, 2)
                    self.assertTrue(all(call.args[0] == args.target_fabric_api for call in clients.call_args_list))
                    public.assert_not_called()
                    discover.assert_called_once_with(source_api, state)
                    self.assertEqual(readback.call_args.args[0], api)
                    self.assertEqual(readback.call_args.args[-1], TARGET)
                    self.assertEqual(provision.call_count, int(mode == "create"))
                    self.assertEqual(reused.call_count, int(mode == "workspace"))
                    if mode == "verify":
                        api.mutate.assert_not_called()
                    self.assertEqual(manifest.data["sourceWorkspaceId"], TARGET)
                    self.assertEqual(manifest.data["capacityId"], GUID)

    def test_retry_inherits_route_and_provenance_without_creating_workspace(self):
        for network in ("public", "wspl", "tenantpl"):
            state = self.state(network)
            args = retry_source.arguments(["--sources-manifest", "input.json", "--source-type", "Lakehouse"])
            selected, source_args = retry_source.prepare(args, state)
            self.assertEqual(selected, ("Lakehouse",))
            self.assertTrue(source_args.same_workspace)
            self.assertEqual(source_args.workspace_id, TARGET)
            self.assertEqual(source_args.fabric_api, state["endpoints"]["fabric"])
            self.assertEqual(source_args.onelake_url, source_onelake_url(network, TARGET))
            manifest = sample.Manifest(self.folder / f"{uuid4().hex}.json", state)
            manifest.data.update(items=copy.deepcopy(state["items"]), verified=copy.deepcopy(state["verified"]))
            p = sample.Provisioner(source_args, Mock(), manifest)
            self.addCleanup(p.close)
            self.assertIsInstance(p.api, TargetApi)
            p.api.json = Mock(side_effect=[
                {"id": TARGET, "capacityId": GUID, "displayName": state["workspaceName"]},
                state["items"]["Lakehouse"],
            ])
            p.verify_sql = Mock()
            with patch.object(p.api, "mutate") as mutate, patch.object(p, "run") as create_workspace:
                retry_source.run(p, selected, True)
                create_workspace.assert_not_called()
                mutate.assert_not_called()
            self.assertEqual(manifest.data["endpoints"], state["endpoints"])
            self.assertTrue(manifest.data["sameWorkspace"])
