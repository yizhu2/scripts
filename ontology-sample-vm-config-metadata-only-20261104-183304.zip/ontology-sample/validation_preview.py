"""Read-only replay of the UX child-Eventhouse data-preview protocol (not browser automation)."""

import math
import re
from collections import Counter
from contextlib import closing
from datetime import datetime, timezone
from functools import partial
from urllib.parse import urlsplit
from uuid import UUID

from create_sample import Api, sample_tables
from validation_common import HttpFailure, InvalidResponse, ScenarioBlocked, sanitize

CASES = ("lakehouse", "kql", "warehouse", "sql", "mirror", "semantic")
KUSTO_SCOPE = "https://kusto.kusto.windows.net/.default"
LIMIT = 1000
FRONTEND_COMMIT = "3c3fb3f49a8752c18060b5cf44a582ff05aa98bc"
KUSTO_SUFFIXES = (".kusto.fabric.microsoft.com", ".kusto.windows.net")
SQL_SUFFIXES = (".datawarehouse.fabric.microsoft.com", ".daily-datawarehouse.fabric.microsoft.com",
                ".database.fabric.microsoft.com", ".daily-database.fabric.microsoft.com",
                ".database.windows.net", ".database.windows-int.net")


def _object(value, required, optional=()):
    if not isinstance(value, dict) or set(value) - set(required) - set(optional):
        raise ValueError("Preview settings must be objects with only documented keys; never supply queries or tokens")
    if set(required) - set(value):
        raise ValueError("Missing preview settings: " + ", ".join(sorted(set(required) - set(value))))
    return value


def _guid(value):
    result = UUID(str(value))
    if not result.int:
        raise ValueError("Preview identifiers must be nonempty GUIDs")
    return str(result)


def _text(value):
    if (not isinstance(value, str) or not value.strip() or len(value) > 256
            or any(ord(char) < 32 for char in value)):
        raise ValueError("Preview identifiers must be nonempty single-line strings of at most 256 characters")
    return value


def _host(host, suffixes):
    if (not isinstance(host, str) or not re.fullmatch(r"[a-zA-Z0-9]+(?:[a-zA-Z0-9.-]*[a-zA-Z0-9])?", host)
            or ".." in host or not host.lower().endswith(suffixes)):
        raise ValueError("Preview host is not an approved service hostname")
    return host.lower()


def cluster_origin(value):
    if not isinstance(value, str):
        raise ValueError("Preview cluster must be an explicit HTTPS origin")
    parsed = urlsplit(value)
    if (parsed.scheme != "https" or parsed.username or parsed.password or parsed.port
            or parsed.path not in ("", "/") or parsed.query or parsed.fragment
            or "?" in value or "#" in value):
        raise ValueError("Preview cluster must be a bare HTTPS origin without credentials, port, path or query")
    host = _host(parsed.hostname, KUSTO_SUFFIXES)
    if value.lower() not in ("https://" + host, "https://" + host + "/"):
        raise ValueError("Preview cluster must be an unambiguous HTTPS origin")
    return "https://" + host


def settings(config, case):
    """Require operator-observed execution context, never infer it from a source or authoring route."""
    try:
        if config.get("preview") is None:
            raise ValueError("Missing preview configuration: add preview.execution and preview.sources")
        preview = _object(config.get("preview"), ("execution", "sources"))
        execution = _object(preview["execution"],
                            ("workspace_id", "ontology_id", "eventhouse_id", "database_id",
                             "cluster_uri", "provenance"))
        if execution["provenance"] != "ontology-child-eventhouse":
            raise ValueError("Preview execution provenance must be ontology-child-eventhouse")
        for key in ("workspace_id", "ontology_id"):
            if _guid(execution[key]) != _guid(config[key]):
                raise ValueError(f"Preview execution {key} must match the target ontology")
        _guid(execution["eventhouse_id"])
        _guid(execution["database_id"])
        origin = cluster_origin(execution["cluster_uri"])
        if not isinstance(preview["sources"], dict) or set(preview["sources"]) - set(CASES):
            raise ValueError("preview.sources must map documented source cases to explicit settings")
        if case not in preview["sources"]:
            raise ValueError(f"Missing preview.sources.{case}")
        required = ("workspace_id", "item_id")
        if case == "kql":
            required += ("cluster_uri", "database")
        elif case == "semantic":
            required += ("api_host",)
        else:
            required += ("sql_endpoint", "sql_database", "schema")
        source = _object(preview["sources"].get(case), required)
        _guid(source["workspace_id"])
        source_id = _guid(source["item_id"])
        if source_id in (_guid(execution["eventhouse_id"]), _guid(execution["database_id"])):
            raise ValueError("Source item must not be the ontology execution Eventhouse/database")
        if case == "kql":
            cluster_origin(source["cluster_uri"])
            _text(source["database"])
            if source["database"].lower() == execution["database_id"].lower():
                raise ValueError("Source KQL database must not substitute for the ontology execution database")
        elif case == "semantic":
            # This harness provisions Daily fixtures; never silently substitute PROD or a Fabric API host.
            if source["api_host"] != "https://dailyapi.powerbi.com":
                raise ValueError("Daily semantic preview requires the explicit UX host https://dailyapi.powerbi.com")
        else:
            _host(source["sql_endpoint"], SQL_SUFFIXES)
            _text(source["sql_database"])
            if source["schema"]:
                _text(source["schema"])
            elif source["schema"] != "":
                raise ValueError("SQL schema must be a string (empty means the UX unqualified table)")
        return execution, source, origin
    except (ValueError, KeyError, TypeError, AttributeError) as error:
        raise ScenarioBlocked(f"preview.{case}: {error}. Configure preview.execution and preview.sources; "
                              "no UX authoring endpoint, public fallback or source-endpoint substitution is used") from None


def kql_string(value):
    return "'" + value.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "\\r") + "'"


def _identifier(value):
    return "[" + kql_string(value) + "]"


def build_query(case, source, table):
    """Fixed fixture tables/columns only; follows federatedKqlBuilder.ts at FRONTEND_COMMIT."""
    if case not in CASES or table not in sample_tables():
        raise ValueError("Only canonical fixture tables may be previewed")
    columns = [name for name, _ in table.columns]
    if case == "kql":
        expression = (f"cluster({kql_string(source['cluster_uri'].rstrip('/'))})"
                      f".database({kql_string(source['database'])}).table({kql_string(table.name)})")
    elif case == "semantic":
        connection = f"{source['api_host']}/v1.0/myorg/datasets/{source['item_id']};Impersonate"
        projection = ", ".join(f'"{name}", \'{table.name}\'[{name}]' for name in columns)
        dax = f"EVALUATE TOPN({LIMIT}, SELECTCOLUMNS('{table.name}', {projection}))"
        expression = f"evaluate dax_request(\n  {kql_string(connection)},\n  {kql_string(dax)}\n)"
        expression += "\n| project-rename " + ", ".join(
            f"{_identifier(name)} = {_identifier('[' + name + ']')}" for name in columns)
    else:
        def connection_value(value):
            return '"' + value.replace('"', '""') + '"'

        connection = (f"Server={connection_value('tcp:' + source['sql_endpoint'] + ',1433')};"
                      'Authentication="Active Directory Integrated";'
                      f"Initial Catalog={connection_value(source['sql_database'])};")
        relation = f"[{table.name}]"
        if source["schema"]:
            relation = "[" + source["schema"].replace("]", "]]") + "]." + relation
        sql = f"SELECT TOP ({LIMIT}) " + ", ".join(f"[{name}]" for name in columns) + f" FROM {relation}"
        expression = f"evaluate sql_request(\n  {kql_string(connection)},\n  {kql_string(sql)}\n)"
    return (expression + "\n| project " + ", ".join(f"{_identifier(name)} = {_identifier(name)}" for name in columns)
            + f"\n| take {LIMIT}")


def _check_errors(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key.lower() in ("error", "errors", "oneapierrors", "haserrors", "cancelled", "iscancelled") and item:
                raise InvalidResponse("Kusto reported an error/cancellation, including possible HTTP-200 partial failure")
            _check_errors(item)
    elif isinstance(value, list):
        for item in value:
            _check_errors(item)


def result_table(response):
    _check_errors(response)
    if not isinstance(response, list) or not all(isinstance(frame, dict) for frame in response):
        raise InvalidResponse("Expected Kusto v2 frames, not a v1/direct-source response")
    headers = [frame for frame in response if frame.get("FrameType") == "DataSetHeader"]
    if len(headers) != 1 or response[0] is not headers[0] or headers[0].get("IsProgressive") is not False:
        raise InvalidResponse("Expected one non-progressive Kusto v2 header")
    completions = [frame for frame in response if frame.get("FrameType") == "DataSetCompletion"]
    if len(completions) != 1 or completions[0].get("HasErrors") is not False:
        raise InvalidResponse("Missing or invalid successful Kusto completion; result may be truncated")
    if response[-1] is not completions[0]:
        raise InvalidResponse("Kusto completion must terminate the response")
    for frame in response:
        if frame.get("FrameType") not in ("DataSetHeader", "DataTable", "DataSetCompletion"):
            raise InvalidResponse("Unsupported/progressive Kusto frame; completeness cannot be verified")
        if frame.get("TableKind") in ("QueryCompletionInformation", "QueryStatus"):
            fields = [column.get("ColumnName") for column in frame.get("Columns", [])]
            severity = "LevelName" if frame["TableKind"] == "QueryCompletionInformation" else "SeverityName"
            if severity not in fields:
                raise InvalidResponse("Malformed Kusto status table")
            for row in frame.get("Rows", []):
                if not isinstance(row, list) or len(row) != len(fields):
                    raise InvalidResponse("Malformed Kusto status row")
                if str(row[fields.index(severity)]).lower() in ("fatal", "exception", "error", "warning"):
                    raise InvalidResponse("Kusto status reported error/warning; partial results are not a pass")
    tables = [frame for frame in response if frame.get("FrameType") == "DataTable"
              and frame.get("TableKind") == "PrimaryResult"]
    if len(tables) != 1:
        raise InvalidResponse("Expected exactly one Kusto primary result")
    return tables[0]


def compare_fixture(response, table):
    result = result_table(response)
    columns, rows = result.get("Columns"), result.get("Rows")
    if not isinstance(columns, list) or not all(isinstance(column, dict) for column in columns):
        raise InvalidResponse("Missing preview schema")
    expected_names = [name for name, _ in table.columns]
    names = [column.get("ColumnName") for column in columns]
    if len(names) != len(expected_names) or set(names) != set(expected_names):
        raise InvalidResponse(f"{table.name}: unexpected/missing/duplicate columns: {names}")
    accepted_types = {"string": {"string"}, "datetime": {"datetime"}, "double": {"real", "double", "decimal"}}
    for column in columns:
        kind = dict(table.columns)[column["ColumnName"]]
        if str(column.get("ColumnType", "")).lower() not in accepted_types[kind]:
            raise InvalidResponse(f"{table.name}.{column['ColumnName']}: unexpected or missing ColumnType")
    if not isinstance(rows, list) or len(rows) != len(table.rows):
        raise InvalidResponse(f"{table.name}: expected {len(table.rows)} rows, got "
                              f"{len(rows) if isinstance(rows, list) else 'no row array'}; no refresh attempted")

    def normalize(value, kind):
        if kind == "string":
            if not isinstance(value, str):
                raise InvalidResponse("Expected a non-null fixture string")
            return value
        if kind == "double":
            if type(value) not in (int, float) or not math.isfinite(value):
                raise InvalidResponse("Expected a finite fixture number")
            return value
        if not isinstance(value, (str, datetime)):
            raise InvalidResponse("Expected a fixture timestamp")
        try:
            parsed = value if isinstance(value, datetime) else datetime.fromisoformat(value.replace("Z", "+00:00"))
            return parsed.replace(tzinfo=timezone.utc) if parsed.tzinfo is None else parsed.astimezone(timezone.utc)
        except ValueError as error:
            raise InvalidResponse("Invalid fixture timestamp") from error

    actual = []
    for row in rows:
        if not isinstance(row, list) or len(row) != len(columns):
            raise InvalidResponse("Malformed or partial preview row")
        actual.append(tuple(normalize(row[names.index(name)], kind) for name, kind in table.columns))
    expected = [tuple(normalize(value, kind) for value, (_, kind) in zip(row, table.columns)) for row in table.rows]
    if Counter(actual) != Counter(expected):
        raise InvalidResponse(f"{table.name}: fixture values/keys/duplicates differ (all rows compared, order ignored)")
    return {"columns": columns, "expectedRows": len(expected), "actualRows": len(actual),
            "comparison": "Exact complete fixture multiset; known-UTC timestamps normalized"}


def preview(ctx, case):
    execution, source, origin = settings(ctx.config, case)
    topology = {"ontologyWorkspaceId": ctx.config["workspace_id"], "ontologyId": ctx.config["ontology_id"],
                "sourceWorkspaceId": source["workspace_id"], "sourceItemId": source["item_id"],
                "execution": execution, "source": source, "targetNetwork": ctx.config["target_network"],
                "topologyVerification": "Configured/observed by operator, not independently verified",
                "networkEnforcementVerified": False, "browserUiTested": False,
                "protocolReferenceCommit": FRONTEND_COMMIT}
    ctx.save_evidence("routing", topology)
    tables = []
    with closing(Api(origin, KUSTO_SCOPE, ctx.credential, ctx.timeout)) as api:
        for table in sample_tables():
            body = {"db": execution["database_id"], "csl": build_query(case, source, table), "properties": None}
            entry = {"table": table.name, "url": origin + "/v2/rest/query", "request": body}
            ctx.save_evidence(table.name + ".request", entry)
            try:
                response = ctx.request(api, "POST", entry["url"], body)
                ctx.save_evidence(table.name + ".response", response)
                entry.update(status="PASS", check=compare_fixture(response, table))
            except Exception as error:
                status = ("TIMEOUT" if isinstance(error, TimeoutError) else
                          "BLOCKED" if isinstance(error, HttpFailure) and error.status in (401, 403) else "FAIL")
                entry.update(status=status, errorType=type(error).__name__, error=ctx.redact(str(error)))
            tables.append(entry)
            ctx.save_evidence("tables", tables)
    statuses = {table["status"] for table in tables}
    status = next((value for value in ("FAIL", "TIMEOUT", "BLOCKED") if value in statuses), "PASS")
    return {"status": status, "summary": f"UX backend preview {case}: "
            f"{sum(table['status'] == 'PASS' for table in tables)}/3 fixture tables; no browser/policy certification",
            "evidence": sanitize({"routing": topology, "tables": tables, "readOnly": True})}


SCENARIOS = {f"preview.{case}": partial(preview, case=case) for case in CASES}
