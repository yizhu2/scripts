import base64
import copy
import io
import json
import tempfile
import unittest
from pathlib import Path
from contextlib import redirect_stdout
from types import SimpleNamespace
from unittest.mock import Mock, patch

import requests

from create_sample import Api, sample_tables
from test_validation_preview import config, frames
from validation_common import HttpFailure, InvalidResponse, ScenarioBlocked, ValidationContext
from validation_p0_access import SCENARIOS, access, baseline, denial, prerequisites, principal
from validate_sample import catalog, main, select_scenarios, validate_config
from validation_setup import prerequisites as all_prerequisites, unselected_source_reason
from validation_preview import KUSTO_SCOPE

OBJECT = "77777777-7777-7777-7777-777777777777"
OTHER_OBJECT = "88888888-8888-8888-8888-888888888888"
POLICY = {"error": {"code": "DeniedByPolicy", "message": "Private link validation failed"}}
PERMISSION = {"error": {"code": "Forbidden", "message": "Caller is not authorized to perform this action"}}


def token(tenant, oid=OBJECT):
    claims = base64.urlsafe_b64encode(json.dumps({"tid": tenant, "oid": oid}).encode()).decode().rstrip("=")
    return "header." + claims + ".signature"


def configuration():
    value = config()
    value["source_types"] = ["Lakehouse", "Eventhouse"]
    value["p0_access"] = {"context": "authorized"}
    for source in value["preview"]["sources"].values():
        source["workspace_id"] = value["workspace_id"]
    return value


def probe_frames():
    value = frames(sample_tables()[0])
    value[1].update(Columns=[{"ColumnName": "P0Probe", "ColumnType": "long"}], Rows=[[1]])
    return value


class AccessTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)

    def context(self, value=None, responses=None, oid=OBJECT):
        value = value or configuration()
        credential = Mock()
        credential.get_token.return_value = SimpleNamespace(token=token(value["tenant_id"], oid))
        ctx = ValidationContext(value, credential, self.directory)
        self.addCleanup(ctx.close)
        ctx.begin("p0.access-baseline.lakehouse")
        if responses is None:
            responses = [(200, {"id": value["ontology_id"], "type": "Ontology"}),
                         (200, probe_frames())] + [(200, frames(table)) for table in sample_tables()]
        iterator = iter(responses)

        def exchange(api, method, url, body=None):
            status, data = next(iterator)
            ctx.requests.append({"method": method, "url": url, "request": body,
                                 "httpStatus": status, "response": data})
            if status != 200:
                raise HttpFailure(status, "See evidence")
            return SimpleNamespace(status_code=status, json=lambda: data)

        ctx.exchange = Mock(side_effect=exchange)
        return ctx

    def saved_baseline(self, case="lakehouse"):
        value = configuration()
        result = access(self.context(value), "access-baseline", case)
        self.assertEqual(result["status"], "PASS")
        row = dict(result, selected=True, scenario=f"p0.access-baseline.{case}",
                   finishedUtc="2026-11-05T00:00:00+00:00")
        path = self.directory / f"baseline-{case}.json"
        path.write_text(json.dumps({"results": [row]}), encoding="utf-8")
        return value, path, row

    def challenge(self, mode, responses, case="lakehouse", oid=OBJECT):
        value, path, _ = self.saved_baseline(case)
        value["p0_access"] = {"context": mode, "baseline_results": str(path)}
        ctx = self.context(value, responses, oid)
        scenario = "network-denied" if mode == "outside-network" else "source-denied"
        ctx.begin(f"p0.{scenario}.{case}")
        return ctx, access(ctx, scenario, case)

    def test_exact_registry_and_same_workspace_private_baseline(self):
        self.assertEqual(len(SCENARIOS), 6)
        for case in ("lakehouse", "kql"):
            self.assertEqual(prerequisites(configuration(), f"p0.access-baseline.{case}"), [])
        value = configuration()
        value["preview"]["sources"]["lakehouse"]["workspace_id"] = OTHER_OBJECT
        self.assertIn("ontology workspace", prerequisites(value, "p0.access-baseline.lakehouse")[0])
        value = configuration()
        value["target_network"] = "public"
        self.assertIn("private target", prerequisites(value, "p0.access-baseline.lakehouse")[0])

    def test_registry_selection_and_source_inventory_integration(self):
        names = select_scenarios(catalog(), agents=["p0"])
        self.assertTrue(set(SCENARIOS) <= names)
        self.assertTrue(all(name.rpartition(".")[2] in ("lakehouse", "kql") for name in names))
        value = configuration()
        self.assertEqual(all_prerequisites(value, set(SCENARIOS) & {
            "p0.access-baseline.lakehouse", "p0.access-baseline.kql"}), {})
        value["source_types"] = ["Lakehouse"]
        self.assertTrue(unselected_source_reason(value, "p0.access-baseline.kql"))
        self.assertFalse(unselected_source_reason(value, "p0.access-baseline.lakehouse"))
        value["source_types"] = ["Eventhouse"]
        self.assertTrue(unselected_source_reason(value, "generation.lifecycle"))
        self.assertFalse(unselected_source_reason(value, "generation.kql"))

    def test_p0_resolution_cannot_treat_default_origin_as_explicit_configuration(self):
        value = configuration()
        value.update(target_network="public", authoring_mode="ux",
                     ux_workload_host="test.daily-c.fabric.microsoft.com")
        checked = validate_config(value)
        self.assertTrue(checked.get("ux_metadata_api"))
        self.assertFalse(checked["_explicit_ux_routing"])
        errors = all_prerequisites(checked, {"p0.resolution.lakehouse"})
        self.assertTrue(any("default origin inferred" in message for message in errors["p0.resolution.lakehouse"]))
        explicit = configuration()
        explicit.update(target_network="public", authoring_mode="ux",
                        ux_workload_host="test.daily-c.fabric.microsoft.com",
                        ux_metadata_api=checked["ux_metadata_api"])
        self.assertTrue(validate_config(explicit)["_explicit_ux_routing"])

    def test_missing_p0_config_blocks_before_auth_and_has_separate_report(self):
        value = configuration()
        value.pop("p0_access")
        path = self.directory / "config.json"
        path.write_text(json.dumps(value), encoding="utf-8")
        output = self.directory / "out"
        with patch("azure.identity.AzureCliCredential") as credential, redirect_stdout(io.StringIO()):
            code = main(["--config", str(path), "--output", str(output),
                         "--scenarios", "p0.access-baseline.*", "--strict"])
        self.assertEqual(code, 1)
        credential.assert_not_called()
        report = (output / "report.md").read_text()
        self.assertIn("Individual-source P0 backend checks", report)
        self.assertIn("externally prepared", report)
        rows = json.loads((output / "results.json").read_text())["results"]
        self.assertTrue(all(row["status"] == "BLOCKED" for row in rows if row["selected"]))

    def test_missing_context_or_baseline_blocks_without_auth(self):
        for mode in ("network-denied", "source-denied"):
            ctx = self.context()
            with self.assertRaises(ScenarioBlocked):
                access(ctx, mode, "lakehouse")
            ctx.credential.get_token.assert_not_called()
            ctx.exchange.assert_not_called()
        value = configuration()
        value["p0_access"] = {"context": "outside-network", "baseline_results": "missing.json"}
        self.assertIn("Invalid authorized baseline", prerequisites(value, "p0.network-denied.lakehouse")[0])

    def test_positive_baseline_compares_all_rows_and_records_only_identity(self):
        for case in ("lakehouse", "kql"):
            ctx = self.context()
            result = access(ctx, "access-baseline", case)
            self.assertEqual(result["status"], "PASS")
            self.assertEqual([row["rows"] for row in result["evidence"]["tables"]], [3, 12, 120])
            self.assertEqual(result["evidence"]["principal"]["objectId"], OBJECT)
            self.assertEqual(ctx.exchange.call_count, 5)
            self.assertNotIn(".signature", json.dumps(result))
        data = [(200, {"id": config()["ontology_id"], "type": "Ontology"}), (200, probe_frames()),
                (200, frames(sample_tables()[1]))]
        with self.assertRaises(InvalidResponse):
            access(self.context(responses=data), "access-baseline", "lakehouse")

    def test_baseline_mismatch_or_incomplete_positive_evidence_blocks(self):
        value, path, row = self.saved_baseline()
        value["p0_access"] = {"context": "outside-network", "baseline_results": str(path)}
        for field, replacement in (("status", "PARTIAL"), ("finishedUtc", None), ("selected", False)):
            changed = copy.deepcopy(row)
            changed[field] = replacement
            path.write_text(json.dumps({"results": [changed]}), encoding="utf-8")
            with self.assertRaises(ScenarioBlocked):
                baseline(value, "lakehouse")
        path.write_text(json.dumps({"results": [row]}), encoding="utf-8")
        value["preview"]["sources"]["lakehouse"]["sql_database"] = "different"
        with self.assertRaisesRegex(ScenarioBlocked, "does not match"):
            baseline(value, "lakehouse")

    def test_explicit_network_denial_requires_all_five_rejections(self):
        for case in ("lakehouse", "kql"):
            _, result = self.challenge("outside-network", [(403, POLICY)] * 5, case)
            self.assertEqual(result["status"], "PASS")
            self.assertFalse(result["evidence"]["policyConfigurationVerified"])
        _, result = self.challenge("outside-network",
                                   [(200, {"id": config()["ontology_id"], "type": "Ontology"})]
                                   + [(403, POLICY)] * 4)
        self.assertEqual(result["status"], "FAIL")

    def test_network_identity_mismatch_blocks_before_requests(self):
        value, path, _ = self.saved_baseline()
        value["p0_access"] = {"context": "outside-network", "baseline_results": str(path)}
        ctx = self.context(value, oid=OTHER_OBJECT)
        with self.assertRaisesRegex(ScenarioBlocked, "same principal"):
            access(ctx, "network-denied", "lakehouse")
        ctx.exchange.assert_not_called()

    def test_source_denial_requires_successful_ontology_and_gateway_controls(self):
        positive = [(200, {"id": config()["ontology_id"], "type": "Ontology"}), (200, probe_frames())]
        for case in ("lakehouse", "kql"):
            _, result = self.challenge("source-denied", positive + [(403, PERMISSION)] * 3, case, OTHER_OBJECT)
            self.assertEqual(result["status"], "PASS")
            self.assertEqual(result["evidence"]["principal"]["objectId"], OTHER_OBJECT)
        with self.assertRaisesRegex(ScenarioBlocked, "Positive ontology"):
            self.challenge("source-denied", [(403, PERMISSION)])
        with self.assertRaisesRegex(ScenarioBlocked, "Positive gateway"):
            self.challenge("source-denied", positive[:1] + [(403, PERMISSION)])
        _, result = self.challenge("source-denied", positive + [(403, POLICY)] * 3)
        self.assertEqual(result["status"], "BLOCKED")

    def test_wrong_item_or_wrong_gateway_control_fails(self):
        with self.assertRaises(InvalidResponse):
            access(self.context(responses=[(200, {"id": OTHER_OBJECT, "type": "Ontology"})]),
                   "access-baseline", "lakehouse")
        control = probe_frames()
        control[1]["Rows"] = [[2]]
        with self.assertRaises(InvalidResponse):
            access(self.context(responses=[
                (200, {"id": config()["ontology_id"], "type": "Ontology"}), (200, control)]),
                "access-baseline", "lakehouse")

    def test_401_timeout_generic403_and_other_http_errors_are_not_pass(self):
        for status, data in ((401, POLICY), (403, "DeniedByPolicy"), (403, {"error": {"message": "Denied"}}),
                             (302, POLICY), (500, POLICY), (404, PERMISSION)):
            for mode in ("network-denied", "source-denied"):
                with self.subTest(status=status, mode=mode):
                    self.assertNotEqual(denial(status, data, mode)[0], "PASS")
        ctx = self.context()
        ctx.exchange.side_effect = TimeoutError("Network unavailable")
        with self.assertRaises(TimeoutError):
            access(ctx, "access-baseline", "lakehouse")

    def test_success_and_partial_protected_rows_always_fail_negative_checks(self):
        for mode in ("network-denied", "source-denied"):
            for status in (200, 403):
                data = frames(sample_tables()[0])
                data[-1].update(HasErrors=True, OneApiErrors=[PERMISSION["error"], POLICY["error"]])
                self.assertEqual(denial(status, data, mode)[0], "FAIL")
            self.assertEqual(denial(200, frames(sample_tables()[0]), mode)[0], "FAIL")
            self.assertEqual(denial(200, [], mode)[0], "FAIL")
        self.assertEqual(denial(200, {"OneApiErrors": [PERMISSION["error"]]}, "source-denied")[0], "PASS")

    def test_nested_sql_policy_error_cannot_pass_as_source_denial(self):
        data = {"error": {"code": "Forbidden", "@message": "Forbidden: " + json.dumps(POLICY)}}
        self.assertEqual(denial(403, data, "network-denied")[0], "PASS")
        self.assertEqual(denial(403, data, "source-denied")[0], "BLOCKED")
        data = {"error": {"code": "UnsupportedPlugin", "message": "Forbidden"}}
        self.assertEqual(denial(403, data, "source-denied")[0], "BLOCKED")
        for message in ("Private link feature unsupported", "Invalid IP address parameter"):
            data = {"error": {"code": "UnsupportedPlugin", "message": message}}
            self.assertEqual(denial(403, data, "network-denied")[0], "BLOCKED")

    def test_identity_failures_never_persist_token_or_attempt_requests(self):
        for secret in ("opaque-secret", "a.invalid-json.c"):
            ctx = self.context()
            ctx.credential.get_token.return_value = SimpleNamespace(token=secret)
            with self.assertRaises(ScenarioBlocked):
                principal(ctx)
            self.assertIn(secret, ctx._secrets)
            ctx.exchange.assert_not_called()
        ctx = self.context()
        ctx.credential.get_token.side_effect = [
            SimpleNamespace(token=token(ctx.config["tenant_id"], OBJECT)),
            SimpleNamespace(token=token(ctx.config["tenant_id"], OTHER_OBJECT))]
        with self.assertRaisesRegex(ScenarioBlocked, "different principals"):
            principal(ctx)

    def test_p0_query_transport_preserves_ux_headers_and_scrubs_denial_evidence(self):
        value = configuration()
        credential = Mock()
        secret = token(value["tenant_id"])
        credential.get_token.return_value.token = secret
        ctx = ValidationContext(value, credential, self.directory)
        self.addCleanup(ctx.close)
        ctx.begin("p0.source-denied.lakehouse")
        origin = value["preview"]["execution"]["cluster_uri"]
        api = Api(origin, KUSTO_SCOPE, credential, 30)
        self.addCleanup(api.close)
        api.session = Mock()
        response = requests.Response()
        response.status_code = 403
        response._content = json.dumps({"error": {"code": "Forbidden", "message": secret}}).encode()
        response._content_consumed = True
        api.session.request.return_value.__enter__ = Mock(return_value=response)
        api.session.request.return_value.__exit__ = Mock(return_value=False)
        with self.assertRaises(HttpFailure):
            ctx.exchange(api, "POST", origin + "/v2/rest/query",
                         {"db": value["preview"]["execution"]["database_id"], "csl": "print P0Probe=1",
                          "properties": None})
        arguments = api.session.request.call_args.kwargs
        self.assertFalse(arguments["allow_redirects"])
        self.assertTrue(arguments["headers"]["x-ms-client-request-id"].startswith("Ontology;"))
        self.assertEqual(arguments["headers"]["x-ms-app"], "Ontology")
        saved = (self.directory / "p0.source-denied.lakehouse.http.json").read_text()
        self.assertNotIn(secret, saved)
        self.assertIn('"request"', saved)


if __name__ == "__main__":
    unittest.main()
