import copy
import unittest
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from unittest.mock import Mock, patch

from create_sample import sample_tables
from validation_common import HttpFailure, InvalidResponse, ScenarioBlocked
from validation_p0_sources import SCENARIOS, prerequisites, resolution, topology

WORKSPACE = "11111111-1111-1111-1111-111111111111"
ONTOLOGY = "22222222-2222-2222-2222-222222222222"
SOURCE = "33333333-3333-3333-3333-333333333333"
PARENT = "44444444-4444-4444-4444-444444444444"
EXECUTION_EH = "55555555-5555-5555-5555-555555555555"
EXECUTION_DB = "66666666-6666-6666-6666-666666666666"
SQL_ENDPOINT = "77777777-7777-7777-7777-777777777777"
OTHER_WORKSPACE = "88888888-8888-8888-8888-888888888888"
CLUSTER = "https://source.z4.kusto.fabric.microsoft.com"
SQL_HOST = "sample.daily-datawarehouse.fabric.microsoft.com"


def config():
    return {
        "workspace_id": WORKSPACE, "ontology_id": ONTOLOGY, "target_network": "tenantpl",
        "authoring_mode": "ux",
        "ux_metadata_api": "https://private.analysis.windows.net",
        "ux_workload_host": "private.pbidedicated.windows.net",
        "preview": {
            "execution": {"workspace_id": WORKSPACE, "ontology_id": ONTOLOGY,
                          "eventhouse_id": EXECUTION_EH, "database_id": EXECUTION_DB,
                          "cluster_uri": "https://execution.z4.kusto.fabric.microsoft.com",
                          "provenance": "ontology-child-eventhouse"},
            "sources": {
                "lakehouse": {"workspace_id": WORKSPACE, "item_id": SOURCE,
                              "sql_endpoint": SQL_HOST, "sql_database": "SampleLH", "schema": "dbo"},
                "kql": {"workspace_id": WORKSPACE, "item_id": SOURCE,
                        "cluster_uri": CLUSTER, "database": "SampleKQL"},
            },
        },
    }


def definition(case):
    prefix = "Lakehouse" if case == "lakehouse" else "EventhouseKQL"
    model = {"entities": [], "tables": []}
    for table in sample_tables():
        name = f"{prefix}_{table.name}"
        values = {
            "State": "Resolved", "At": datetime.now(timezone.utc).isoformat(),
            "WorkspaceId": WORKSPACE, "ItemId": SOURCE,
            "ItemKind": "Lakehouse" if case == "lakehouse" else "KQLDatabase", "ContractVersion": "1",
        }
        if case == "lakehouse":
            values.update(Connector="AzureStorage.DataLake", SqlEndpoint=SQL_HOST,
                          SqlDatabase="SampleLH", SqlEndpointItemId=SQL_ENDPOINT)
            source = {"type": "entity", "entityName": table.name, "expressionSource": prefix + "_Source"}
        else:
            values.update(Connector="AzureDataExplorer.Contents", KustoClusterUri=CLUSTER,
                          KustoDatabase=SOURCE, SourceItem=table.name)
            source = {"type": "m", "expression":
                      f'let Source = AzureDataExplorer.Contents("{CLUSTER}", "{SOURCE}", "{table.name}") in Source'}
        model["entities"].append({
            "name": name, "backingTable": name, "keyProperties": [table.columns[0][0]],
            "properties": [{"name": column, "backingConfiguration": {
                "type": "default", "valueColumn": {"table": name, "column": column}}}
                for column, _ in table.columns],
        })
        model["tables"].append({
            "name": name, "columns": [{"name": column, "sourceColumn": column} for column, _ in table.columns],
            "partitions": [{"name": name, "source": source, "annotations": [
                {"name": "ONT_RESOLVED_" + key, "value": value} for key, value in values.items()]}],
        })
    return {"model": model}


class Context:
    def __init__(self, case):
        self.config = config()
        self.fabric = SimpleNamespace(base="https://explicit.fabric.microsoft.com/v1")
        self.api = SimpleNamespace(base="https://private.pbidedicated.windows.net")
        self.calls = []
        self.evidence = {}
        self.document = definition(case)
        kind, name = ("Lakehouse", "SampleLH") if case == "lakehouse" else ("KQLDatabase", "SampleKQL")
        self.item = {"id": SOURCE, "type": kind, "displayName": name}
        self.detail = {**self.item, "properties": (
            {"sqlEndpointProperties": {"connectionString": SQL_HOST, "id": SQL_ENDPOINT,
                                       "provisioningStatus": "Success"}} if case == "lakehouse" else
            {"queryServiceUri": CLUSTER, "parentEventhouseItemId": PARENT})}
        self.parent = {"id": PARENT, "type": "Eventhouse", "displayName": "Source EH"}
        self.workload_calls = 0

    def save_evidence(self, label, value):
        self.evidence[label] = copy.deepcopy(value)

    @contextmanager
    def workload(self):
        self.workload_calls += 1
        yield self.api

    def request(self, api, method, url, body=None, params=None):
        self.calls.append((api, method, url, body, params))
        if url.endswith("/definition"):
            return self.document
        if url.endswith("/items/" + PARENT):
            return self.parent
        if url.endswith("/items/" + SOURCE):
            return self.item
        if "/lakehouses/" in url or "/kqlDatabases/" in url:
            return self.detail
        return {"id": self.config["preview"]["sources"]["lakehouse"]["workspace_id"]}


class P0SourcesTests(unittest.TestCase):
    def test_exact_registry_no_unverified_instances(self):
        self.assertEqual(set(SCENARIOS), {f"p0.{mode}.{case}" for mode in ("topology", "resolution")
                                         for case in ("lakehouse", "kql")})
        for case in ("lakehouse", "kql"):
            self.assertIn("primary-backing-table", prerequisites(config(), f"p0.instances.{case}")[0])
        self.assertTrue(prerequisites(config(), "p0.topology.warehouse"))

    def test_offline_prerequisites_and_alm_block_before_any_call(self):
        with patch("requests.sessions.Session.request", side_effect=AssertionError("No network")):
            for name in SCENARIOS:
                self.assertEqual(prerequisites(config(), name), [])
        for case in ("lakehouse", "kql"):
            ctx = Context(case)
            ctx.config["authoring_mode"] = "public"
            self.assertEqual(prerequisites(ctx.config, f"p0.topology.{case}"), [])
            with self.assertRaisesRegex(ScenarioBlocked, "ALM"):
                resolution(ctx, case)
            self.assertEqual(ctx.calls, [])
            self.assertEqual(ctx.workload_calls, 0)

    def test_explicit_routes_even_on_public_network(self):
        for key in ("ux_metadata_api", "ux_workload_host"):
            ctx = Context("lakehouse")
            ctx.config["target_network"] = "public"
            ctx.config.pop(key)
            with self.assertRaisesRegex(ScenarioBlocked, "explicit"):
                resolution(ctx, "lakehouse")
            self.assertEqual(ctx.calls, [])
        value = config()
        value["ux_metadata_api"] = "https://untrusted.example"
        self.assertTrue(prerequisites(value, "p0.resolution.kql"))

    def test_topology_metadata_and_explicit_nonbaseline(self):
        for case in ("lakehouse", "kql"):
            ctx = Context(case)
            result = topology(ctx, case)
            self.assertEqual(result["status"], "PASS")
            self.assertTrue(result["evidence"]["sameWorkspaceBaseline"])
            self.assertFalse(result["evidence"]["bpaCertified"])
            self.assertEqual(ctx.workload_calls, 0)
            self.assertEqual(len(ctx.calls), 3 if case == "lakehouse" else 4)
            self.assertTrue(all(call[1] == "GET" and call[3] is None for call in ctx.calls))
            for source in ctx.config["preview"]["sources"].values():
                source["workspace_id"] = OTHER_WORKSPACE
            with self.assertRaisesRegex(ScenarioBlocked, "nonbaseline"):
                topology(ctx, case)
            ctx.config["p0_sources"] = {"topology": "cross-workspace-nonbaseline"}
            self.assertFalse(topology(ctx, case)["evidence"]["sameWorkspaceBaseline"])

    def test_bad_metadata_never_passes(self):
        for case, field, value in (("lakehouse", "type", "Warehouse"), ("kql", "id", ONTOLOGY),
                                  ("lakehouse", "workspaceId", OTHER_WORKSPACE)):
            ctx = Context(case)
            ctx.detail[field] = value
            with self.assertRaises(InvalidResponse):
                topology(ctx, case)
        ctx = Context("lakehouse")
        ctx.detail["properties"]["sqlEndpointProperties"]["connectionString"] = "wrong"
        with self.assertRaisesRegex(InvalidResponse, "endpoint"):
            topology(ctx, "lakehouse")
        ctx = Context("kql")
        ctx.parent["type"] = "Lakehouse"
        with self.assertRaises(InvalidResponse):
            topology(ctx, "kql")
        ctx = Context("kql")
        ctx.detail["properties"]["queryServiceUri"] = "https://other.kusto.fabric.microsoft.com"
        with self.assertRaises(InvalidResponse):
            topology(ctx, "kql")

    def test_live_resolution_uses_refresh_not_alm_or_preview(self):
        for case in ("lakehouse", "kql"):
            ctx = Context(case)
            result = resolution(ctx, case)
            self.assertEqual(result["status"], "PASS")
            self.assertEqual(len(result["evidence"]["entities"]), 3)
            self.assertEqual(ctx.workload_calls, 1)
            self.assertEqual(ctx.calls[-1][1:], (
                "GET", f"{ctx.api.base}/v4/workspaces/{WORKSPACE}/ontologies/{ONTOLOGY}/definition",
                None, {"expand": "true", "refreshBindingResolution": "true"}))
            self.assertFalse(result["evidence"]["dataRecordsVerified"])
            self.assertIn("resolved-definition", ctx.evidence)

    def test_authored_or_missing_annotations_block_not_pass(self):
        ctx = Context("lakehouse")
        for table in ctx.document["model"]["tables"]:
            for annotation in table["partitions"][0]["annotations"]:
                annotation["name"] = annotation["name"].replace("ONT_RESOLVED_", "ONT_")
        with self.assertRaisesRegex(ScenarioBlocked, "resolver annotations"):
            resolution(ctx, "lakehouse")
        self.assertIn("resolved-definition", ctx.evidence)

    def test_failed_stale_wrong_or_duplicate_resolution_fails(self):
        for key, value in (("State", "Failed"), ("Error", "ResolutionUnavailable"),
                           ("At", (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()),
                           ("WorkspaceId", OTHER_WORKSPACE), ("ItemId", ONTOLOGY),
                           ("SqlEndpoint", "wrong"), ("SqlEndpointItemId", ONTOLOGY)):
            ctx = Context("lakehouse")
            annotations = ctx.document["model"]["tables"][0]["partitions"][0]["annotations"]
            annotations[:] = [a for a in annotations if a["name"] != "ONT_RESOLVED_" + key]
            annotations.append({"name": "ONT_RESOLVED_" + key, "value": value})
            with self.subTest(key=key), self.assertRaises(InvalidResponse):
                resolution(ctx, "lakehouse")
        ctx = Context("kql")
        annotations = ctx.document["model"]["tables"][0]["partitions"][0]["annotations"]
        annotations.append({"name": "ont_resolved_state", "value": "Resolved"})
        with self.assertRaisesRegex(InvalidResponse, "Duplicate"):
            resolution(ctx, "kql")

    def test_wrong_entities_backing_columns_and_kql_table_fail(self):
        for mutate in (
            lambda m: m["entities"].pop(),
            lambda m: m["entities"][0].update(backingTable="Lakehouse_Assets"),
            lambda m: m["tables"][0]["columns"][0].update(sourceColumn="Wrong"),
            lambda m: m["tables"][0]["partitions"].append(copy.deepcopy(m["tables"][0]["partitions"][0])),
        ):
            ctx = Context("lakehouse")
            mutate(ctx.document["model"])
            with self.assertRaises(InvalidResponse):
                resolution(ctx, "lakehouse")
        ctx = Context("kql")
        source = ctx.document["model"]["tables"][0]["partitions"][0]["source"]
        source["expression"] = source["expression"].replace('"Plants"', '"Assets"')
        with self.assertRaisesRegex(InvalidResponse, "table query"):
            resolution(ctx, "kql")

    def test_unsupported_kql_expression_blocks_no_guessing(self):
        ctx = Context("kql")
        ctx.document["model"]["tables"][0]["partitions"][0]["source"]["expression"] = "arbitrary M"
        with self.assertRaisesRegex(ScenarioBlocked, "canonical"):
            resolution(ctx, "kql")

    def test_unavailable_route_blocks_without_replay(self):
        ctx = Context("lakehouse")
        original = ctx.request

        def request(*args, **kwargs):
            if args[2].endswith("/definition"):
                raise HttpFailure(400, "expand disabled")
            return original(*args, **kwargs)

        ctx.request = Mock(side_effect=request)
        with self.assertRaisesRegex(ScenarioBlocked, "no ALM fallback"):
            resolution(ctx, "lakehouse")
        self.assertEqual(ctx.request.call_count, 4)
        self.assertEqual(ctx.workload_calls, 1)


if __name__ == "__main__":
    unittest.main()
