import copy
import json
import sys
import unittest
from contextlib import contextmanager
from types import SimpleNamespace
from unittest.mock import Mock, patch

import validation_generation as generation
from validation_common import ScenarioBlocked

WORKSPACE = "11111111-1111-4111-8111-111111111111"
SOURCE = "22222222-2222-4222-8222-222222222222"
ORIGINAL = "33333333-3333-4333-8333-333333333333"
NEW = "44444444-4444-4444-8444-444444444444"
CONVERSATION = "55555555-5555-4555-8555-555555555555"
CLUSTER = "https://fixture.kusto.fabric.microsoft.com"
EMPTY = {"model": {"entities": [], "tables": [], "entityRelationships": [], "relationships": [],
                   "namespaces": [{"name": "default"}]}}
ROW = {"PlantCount": 3, "AssetCount": 12, "ReadingCount": 120, "ReadingId": "R0120",
       "AssetId": "A012", "ObservedAt": "2026-01-01T00:45:00Z", "TemperatureC": 32.9,
       "PlantId": "P03", "PlantName": "East Plant", "City": "Boston"}


def receipt(tool):
    return {"tool_name": tool, "count": 1, "success_count": 1, "failure_count": 0}


def definition(reading_id=True, warnings=False, kql=False):
    asset = {"name": "Asset", "keyProperties": ["AssetId"], "properties": [
        {"name": "AssetId"}, {"name": "TemperatureC"}]}
    if reading_id:
        asset["properties"].append({
            "name": "ReadingId", "dataType": "string",
            "backingConfiguration": {"type": "default",
                                     "valueColumn": {"table": "Readings", "column": "ReadingId"}}})
    tables = []
    for name in ("Plants", "Assets", "Readings"):
        tables.append({"name": name, "columns": [{"name": "ReadingId", "sourceColumn": "ReadingId"}]
                       if name == "Readings" and reading_id else [], "partitions": [{"source": {
            **({"type": "m", "expression":
                f'let Source = AzureDataExplorer.Contents("{CLUSTER}", "{SOURCE}", "{name}") in Source'}
               if kql else {"entityName": name, "schemaName": "dbo", "expressionSource": "DatabaseQuery"})},
            "annotations": [
                {"name": "ONT_ItemId", "value": SOURCE},
                {"name": "ONT_WorkspaceId", "value": WORKSPACE},
                {"name": "ONT_ItemKind", "value": "KQLDatabase" if kql else "Lakehouse"},
                {"name": "ONT_RESOLVED_State", "value": "Failed" if warnings else "Resolved"},
                {"name": "ONT_RESOLVED_Error", "value": "ResolutionUnavailable" if warnings else ""},
                {"name": "ONT_RESOLVED_At", "value": "2026-01-01T00:00:00Z"},
            ]}]})
    return {"model": {"entities": [asset, {"name": "Plant", "keyProperties": ["PlantId"],
                                          "properties": [{"name": "PlantId"}]}],
                      "tables": tables, "entityRelationships": [{"name": "AssetLocatedAtPlant"}],
                      "relationships": [
                          {"name": "AssetReadings", "fromTable": "Readings", "toTable": "Assets",
                           "fromColumn": "AssetId", "toColumn": "AssetId"},
                          {"name": "AssetPlant", "fromTable": "Assets", "toTable": "Plants",
                           "fromColumn": "PlantId", "toColumn": "PlantId"}],
                      "expressions": [] if kql else [{"name": "DatabaseQuery", "expression":
                          f'AzureStorage.DataLake("https://onelake.dfs.fabric.microsoft.com/{WORKSPACE}/{SOURCE}")'}],
                      "namespaces": [{"name": "default"}]}}


class FakeContext:
    def __init__(self, **options):
        self.options = options
        self.is_kql = options.get("kql", False)
        self.state_key = "generationKql" if self.is_kql else "generationLifecycle"
        self.config = {"workspace_id": WORKSPACE, "ontology_id": ORIGINAL,
                       "generation_lakehouse_id": SOURCE, "allow_create": True,
                       "target_network": "wspl", "ux_token_version": "v2"}
        if self.is_kql:
            del self.config["generation_lakehouse_id"]
            self.config["generation_kql_database_id"] = SOURCE
        self.fabric = SimpleNamespace(base="https://target-private.example/v1")
        self.credential = object()
        self.timeout = 10
        self.state = {}
        self.saved = []
        self.calls = []
        self.workloads = []
        self.document = copy.deepcopy(EMPTY)
        self.phase = "create"
        self.answer = ""
        self.tool_calls = []
        self.applies = 0
        self.cancelled = False

    def save_evidence(self, label, value):
        self.saved.append((label, copy.deepcopy(value), copy.deepcopy(self.state)))
        return "memory://" + label

    @contextmanager
    def workload(self, ontology_id=None):
        self.workloads.append(ontology_id)
        assert ontology_id == NEW, "Original or unknown ontology must never be opened for writes"
        assert self.state[self.state_key]["ontologyId"] == NEW
        assert any(state.get(self.state_key, {}).get("ontologyId") == NEW
                   for _, _, state in self.saved), "ID must be durable before follow-up"
        yield SimpleNamespace(base="https://private-workload.example/direct")

    def mutate(self, api, path, body):
        self.calls.append(("CREATE", path, copy.deepcopy(body)))
        self.state.setdefault("operations", []).append("https://target-private.example/v1/operations/op")
        if self.options.get("provisioning_failure"):
            raise RuntimeError("Provisioning failed")
        if self.options.get("provisioning_timeout"):
            raise TimeoutError("Provisioning pending")
        self.document = definition(kql=self.is_kql) if self.options.get("not_empty") else copy.deepcopy(EMPTY)
        return {"id": ORIGINAL if self.options.get("returned_original") else NEW,
                "type": "Ontology", "displayName": body["displayName"], "workspaceId": WORKSPACE}

    def request(self, api, method, url, body=None, params=None):
        self.calls.append((method, url, copy.deepcopy(body)))
        if "/kqlDatabases/" in url:
            if self.options.get("missing_source"):
                raise RuntimeError("HTTP 404")
            return {"id": self.options.get("metadata_id", SOURCE), "displayName": "FixtureKQL",
                    "properties": {"queryServiceUri": self.options.get("cluster_uri", CLUSTER),
                                   "parentEventhouseItemId": CONVERSATION}}
        if "/lakehouses/" in url:
            if self.options.get("missing_source"):
                raise RuntimeError("HTTP 404")
            return {"id": SOURCE, "displayName": "FixtureLakehouse",
                    "properties": {"sqlEndpointProperties": {
                        "connectionString": "private-sql.datawarehouse.fabric.microsoft.com"}}}
        if method == "GET" and url.endswith("/definition"):
            value = copy.deepcopy(self.document)
            for table in value["model"].get("tables", []):
                for annotation in table["partitions"][0]["annotations"]:
                    if annotation["name"] == "ONT_RESOLVED_At":
                        annotation["value"] = str(len(self.calls))
            return value
        if method == "POST" and url.endswith("/conversations"):
            return {"id": CONVERSATION, "status": "completed"}
        if method == "GET" and url.endswith("/messages"):
            return [{"role": "assistant", "contents": [{"$type": "text", "text": self.answer}],
                     "additionalProperties": {"tool_calls": self.tool_calls}}]
        if method == "POST" and url.endswith("/messages"):
            context = json.loads(body["additionalContext"]["fabricOntology.context"])
            assert context["OntologyId"] == NEW
            assert context["WorkspaceId"] == WORKSPACE
            assert context["MutationModeExplicit"] is True
            assert context["SelectedSources"] == []
            text = body["chatMessage"]["contents"][0]["text"]
            assert body["chatMessage"]["text"] == text
            self.tool_calls = []
            if text.startswith("Plan only"):
                self.phase, self.answer = "plan", "Validated a plan; no writes"
                if self.options.get("plan_mutates"):
                    self.document = definition(kql=self.is_kql)
            elif text.startswith("Reject"):
                self.phase, self.answer = "reject", "Rejected without saving"
                if self.options.get("reject_mutates"):
                    self.document["model"]["entities"].append({"name": "Unapproved"})
            elif text.startswith("Act and approve"):
                assert context["MutationMode"] == 1
                self.phase = "approve" if self.applies == 0 else "repair"
                self.applies += 1
                self.answer = "Applied"
                if self.options.get("missing_apply"):
                    self.answer = "The registered apply tool is unavailable"
                else:
                    missing = self.options.get("missing_readingid") and (
                        self.applies == 1 or self.options.get("repair_unsupported"))
                    self.document = definition(reading_id=not missing, warnings=self.options.get("warnings"),
                                               kql=self.is_kql)
                    if self.options.get("binding_mismatch"):
                        self.document["model"]["tables"][0]["partitions"][0]["annotations"][0]["value"] = ORIGINAL
                    if self.options.get("expression_mismatch"):
                        if self.is_kql:
                            source = self.document["model"]["tables"][0]["partitions"][0]["source"]
                            source["expression"] = source["expression"].replace(SOURCE, ORIGINAL)
                        else:
                            self.document["model"]["expressions"][0]["expression"] = (
                                f'AzureStorage.DataLake("https://onelake.dfs.fabric.microsoft.com/{WORKSPACE}/{ORIGINAL}")')
                    if self.options.get("unsupported_kql"):
                        self.document["model"]["tables"][0]["partitions"][0]["source"]["expression"] = "SourceVariable"
                    if self.options.get("relationship_mismatch"):
                        self.document["model"]["relationships"][0]["toColumn"] = "PlantId"
                    if self.options.get("repair_drops_key") and self.applies == 2:
                        self.document["model"]["entities"][0]["keyProperties"] = ["ReadingId"]
                    if self.options.get("repair_changes_binding") and self.applies == 2:
                        self.document["model"]["entities"][0]["properties"][0]["backingConfiguration"] = {
                            "valueColumn": {"table": "Readings", "column": "PlantId"}}
                    if not self.options.get("missing_apply_receipt"):
                        self.tool_calls = [receipt("fabric_apply_ontology_changes_v2")]
            elif text.startswith("Read-only verification"):
                self.phase = "query"
                row = dict(ROW)
                if self.options.get("wrong_answer"):
                    row["ReadingId"] = "invented"
                if self.options.get("invalid_count"):
                    row["PlantCount"] = True
                self.answer = "Only prose" if self.options.get("no_json") else json.dumps(row)
                if not self.options.get("missing_query_receipt"):
                    self.tool_calls = [receipt("execute_sql_query" if self.options.get("fallback") else
                                               "execute_unified_kql_query")]
            elif text.startswith("Plan-only cancellation"):
                self.phase, self.answer = "cancel", "Cancelled"
                if self.options.get("cancel_mutates"):
                    self.document["model"]["entities"][0]["properties"].append({"name": "Unapproved"})
            else:
                raise AssertionError(text)
            if self.phase not in ("approve", "repair"):
                assert context["MutationMode"] == 0
            if self.options.get("post_timeout") == self.phase:
                raise TimeoutError("Ambiguous POST timeout")
            return {"id": CONVERSATION, "status": "inProgress"}
        raise AssertionError((method, url))

    def poll_conversation(self, api, path):
        self.calls.append(("POLL", path, None))
        if self.options.get("timeout_phase") == self.phase:
            raise TimeoutError("Bounded poll timeout")
        if self.options.get("requires_action") == self.phase:
            return {"id": CONVERSATION, "status": "requiresAction"}
        return {"id": CONVERSATION, "status": "cancelled" if self.cancelled and
                not self.options.get("cancel_too_late") else "completed"}

    def exchange(self, api, method, url, body=None, params=None):
        self.calls.append((method, url, copy.deepcopy(body)))
        assert method == "POST" and url.endswith("/cancel")
        self.cancelled = True
        return SimpleNamespace(status_code=200, content=b"")


class GenerationTests(unittest.TestCase):
    def run_case(self, ctx, sql_error=None):
        with patch.object(generation, "_read_source_rows",
                          side_effect=sql_error, return_value={"rows": [ROW], "proof": "SQL execution"}) as sql:
            result = generation.SCENARIOS["generation.lifecycle"](ctx)
        return result, sql

    def test_success_uses_supported_contract_and_only_new_item(self):
        ctx = FakeContext()
        result, sql = self.run_case(ctx)
        self.assertEqual(result["status"], "PASS", result)
        sql.assert_called_once()
        self.assertEqual(ctx.applies, 1)
        self.assertEqual(ctx.workloads, [NEW, NEW])
        self.assertEqual(ctx.state["generationLifecycle"]["ontologyId"], NEW)
        self.assertEqual(len([c for c in ctx.calls if c[0] == "CREATE"]), 1)
        self.assertLessEqual(len(result["evidence"]["turns"]), generation.MAX_TURNS)
        self.assertEqual(result["evidence"]["stages"]["reject-no-save"]["status"], "PASS")
        self.assertEqual(result["evidence"]["stages"]["cancel"]["status"], "PASS")
        self.assertFalse(result["evidence"]["networkEnforcementVerified"])
        self.assertEqual(result["evidence"]["applyRaceCancellation"], "NOT RUN")
        self.assertFalse(any(c[0] in ("DELETE", "PUT", "PATCH") for c in ctx.calls))

    def test_no_allow_create_never_makes_request(self):
        for value in (False, None, "true", 1):
            with self.subTest(value=value):
                ctx = FakeContext()
                ctx.config["allow_create"] = value
                result, _ = self.run_case(ctx)
                self.assertEqual(result["status"], "BLOCKED")
                self.assertEqual(ctx.calls, [])

    def test_source_config_or_source_unavailable_is_isolated_block(self):
        for option in ("missing_id", "missing_source", "other_workspace"):
            ctx = FakeContext(missing_source=option == "missing_source")
            if option == "missing_id":
                del ctx.config["generation_lakehouse_id"]
            if option == "other_workspace":
                ctx.config["generation_source_workspace_id"] = ORIGINAL
            with self.subTest(option=option):
                result, _ = self.run_case(ctx)
                self.assertEqual(result["status"], "BLOCKED")
                self.assertFalse(any(call[0] == "CREATE" for call in ctx.calls))

    def test_failed_provisioning_retains_intent_and_operation_without_replay(self):
        ctx = FakeContext(provisioning_failure=True)
        result, _ = self.run_case(ctx)
        self.assertEqual(result["status"], "FAIL")
        self.assertIn("creationIntent", ctx.state["generationLifecycle"])
        self.assertTrue(ctx.state["operations"])
        self.assertEqual(ctx.workloads, [])
        self.assertEqual(sum(call[0] == "CREATE" for call in ctx.calls), 1)
        again, _ = self.run_case(ctx)
        self.assertEqual(again["status"], "BLOCKED")
        self.assertEqual(sum(call[0] == "CREATE" for call in ctx.calls), 1)

    def test_provisioning_timeout_does_not_create_again(self):
        ctx = FakeContext(provisioning_timeout=True)
        result, _ = self.run_case(ctx)
        self.assertEqual(result["status"], "BLOCKED")
        self.assertTrue(ctx.state["operations"])
        self.assertEqual(sum(call[0] == "CREATE" for call in ctx.calls), 1)

    def test_existing_or_nonempty_item_is_never_mutated(self):
        for option in ("returned_original", "not_empty"):
            with self.subTest(option=option):
                ctx = FakeContext(**{option: True})
                result, _ = self.run_case(ctx)
                self.assertEqual(result["status"], "FAIL")
                self.assertFalse(any(c[0] == "POST" for c in ctx.calls))

    def test_missing_apply_is_blocked_not_prose_success(self):
        ctx = FakeContext(missing_apply=True)
        result, sql = self.run_case(ctx)
        self.assertEqual(result["status"], "BLOCKED")
        self.assertEqual(ctx.applies, 1)
        sql.assert_not_called()
        self.assertEqual(ctx.state["generationLifecycle"]["ontologyId"], NEW)

    def test_resolver_warning_is_nonblocking_but_binding_mismatch_fails(self):
        result, _ = self.run_case(FakeContext(warnings=True))
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(len(result["evidence"]["bindings"]["resolverWarnings"]), 3)
        result, _ = self.run_case(FakeContext(warnings=True, binding_mismatch=True))
        self.assertEqual(result["status"], "FAIL")
        self.assertIn("binding mismatch", result["summary"])
        result, _ = self.run_case(FakeContext(expression_mismatch=True))
        self.assertEqual(result["status"], "FAIL")
        self.assertIn("Backing expression", result["summary"])
        result, _ = self.run_case(FakeContext(relationship_mismatch=True))
        self.assertEqual(result["status"], "FAIL")
        self.assertIn("source-key relationship", result["summary"])

    def test_only_one_bounded_readingid_repair_and_preservation(self):
        ctx = FakeContext(missing_readingid=True)
        result, _ = self.run_case(ctx)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(ctx.applies, 2)
        ctx = FakeContext(missing_readingid=True, repair_unsupported=True)
        result, _ = self.run_case(ctx)
        self.assertEqual(result["status"], "PARTIAL")
        self.assertEqual(ctx.applies, 2)
        ctx = FakeContext(missing_readingid=True, repair_drops_key=True)
        result, _ = self.run_case(ctx)
        self.assertEqual(result["status"], "FAIL")
        self.assertIn("key", result["summary"])
        result, _ = self.run_case(FakeContext(missing_readingid=True, repair_changes_binding=True))
        self.assertEqual(result["status"], "FAIL")
        self.assertIn("value binding", result["summary"])

    def test_incomplete_answer_and_missing_apply_receipt_cannot_pass(self):
        for option in ("no_json", "missing_apply_receipt"):
            with self.subTest(option=option):
                result, _ = self.run_case(FakeContext(**{option: True}))
                self.assertEqual(result["status"], "PARTIAL")
        result, _ = self.run_case(FakeContext(wrong_answer=True))
        self.assertEqual(result["status"], "FAIL")
        result, _ = self.run_case(FakeContext(invalid_count=True))
        self.assertEqual(result["status"], "FAIL")

    def test_missing_independent_sql_and_query_receipt_are_informational(self):
        result, _ = self.run_case(FakeContext(missing_query_receipt=True), ScenarioBlocked("ODBC unavailable"))
        self.assertEqual(result["status"], "PASS")
        query = result["evidence"]["stages"]["query"]
        self.assertFalse(query["sourceEvidenceRequired"])
        self.assertEqual(query["independentSourceReadNote"]["detail"], "ODBC unavailable")
        self.assertFalse(query["executionVerifiedByBackendTelemetry"])
        result, _ = self.run_case(FakeContext(wrong_answer=True), ScenarioBlocked("ODBC unavailable"))
        self.assertEqual(result["status"], "FAIL")

    def test_observed_source_contradiction_still_fails(self):
        with patch.object(generation, "_read_source_rows", return_value={"rows": [{**ROW, "PlantCount": 4}]}):
            result = generation.SCENARIOS["generation.lifecycle"](FakeContext())
        self.assertEqual(result["status"], "FAIL")
        self.assertFalse(result["evidence"]["stages"]["query"]["answerMatchesIndependentData"])

    def test_direct_sql_fallback_is_distinct_from_unified_certification(self):
        result, _ = self.run_case(FakeContext(fallback=True))
        self.assertEqual(result["status"], "PASS")
        query = result["evidence"]["stages"]["query"]
        self.assertEqual(query["agentReportedRoute"], "direct-sql-fallback")
        self.assertFalse(query["executionVerifiedByBackendTelemetry"])
        self.assertIn("NOT VERIFIED", query["unifiedEngineExecution"])

    def test_unapproved_mutations_fail(self):
        for option in ("plan_mutates", "reject_mutates", "cancel_mutates"):
            with self.subTest(option=option):
                result, _ = self.run_case(FakeContext(**{option: True}))
                self.assertEqual(result["status"], "FAIL")
                self.assertIn("unapproved mutation", result["summary"])

    def test_timeout_attempts_cancellation_once_and_retains_resources(self):
        ctx = FakeContext(timeout_phase="approve")
        result, _ = self.run_case(ctx)
        self.assertEqual(result["status"], "BLOCKED")
        self.assertEqual(ctx.applies, 1)
        self.assertEqual(sum(c[1].endswith("/cancel") for c in ctx.calls), 1)
        self.assertEqual(ctx.state["generationLifecycle"]["ontologyId"], NEW)
        self.assertEqual(ctx.state["generationLifecycle"]["conversationId"], CONVERSATION)
        self.assertFalse(result["evidence"]["bestEffortCancel"]["terminalVerified"])

    def test_cancel_after_completion_is_partial_not_race_pass(self):
        result, _ = self.run_case(FakeContext(cancel_too_late=True))
        self.assertEqual(result["status"], "PARTIAL")
        self.assertEqual(result["evidence"]["stages"]["cancel"]["status"], "PARTIAL")

    def test_ambiguous_message_timeout_cancels_without_retry(self):
        ctx = FakeContext(post_timeout="approve")
        result, _ = self.run_case(ctx)
        self.assertEqual(result["status"], "BLOCKED")
        self.assertEqual(ctx.applies, 1)
        self.assertEqual(sum(c[1].endswith("/cancel") for c in ctx.calls), 1)
        self.assertFalse(result["evidence"]["bestEffortCancel"]["terminalVerified"])

    def test_unknown_action_contract_is_blocked_without_fabricated_reply(self):
        ctx = FakeContext(requires_action="plan")
        result, _ = self.run_case(ctx)
        self.assertEqual(result["status"], "BLOCKED")
        self.assertEqual(ctx.applies, 0)
        self.assertEqual(len(result["evidence"]["turns"]), 1)

    def test_normalization_does_not_hide_authored_changes(self):
        before = definition()
        after = copy.deepcopy(before)
        after["model"]["tables"][0]["partitions"][0]["annotations"][-1]["value"] = "new timestamp"
        self.assertEqual(generation._hash(before), generation._hash(after))
        after["model"]["tables"][0]["partitions"][0]["annotations"][0]["value"] = ORIGINAL
        self.assertNotEqual(generation._hash(before), generation._hash(after))


class GenerationKqlTests(unittest.TestCase):
    def run_case(self, ctx, source_error=None):
        with patch.object(generation, "_read_source_rows", side_effect=source_error,
                          return_value={"rows": [ROW], "proof": "KQL execution"}) as read:
            result = generation.SCENARIOS["generation.kql"](ctx)
        return result, read

    def test_lifecycle_scopes_individual_kql_and_retains_new_item(self):
        ctx = FakeContext(kql=True)
        result, read = self.run_case(ctx)
        self.assertEqual(result["status"], "PASS", result)
        read.assert_called_once()
        self.assertEqual(read.call_args.args[1]["clusterUri"], CLUSTER)
        self.assertEqual(ctx.workloads, [NEW, NEW])
        self.assertEqual(ctx.state["generationKql"]["ontologyId"], NEW)
        self.assertNotIn("generationLifecycle", ctx.state)
        self.assertEqual(sum(call[0] == "CREATE" for call in ctx.calls), 1)
        for stage in ("plan-no-save", "reject-no-save", "apply", "reopen", "query-no-save", "cancel-no-save"):
            self.assertEqual(result["evidence"]["stages"][stage]["status"], "PASS")
        messages = [call[2] for call in ctx.calls if call[0] == "POST" and call[1].endswith("/messages")]
        self.assertIn(f"Eventhouse KQLDatabase {SOURCE} at {CLUSTER}", messages[0]["chatMessage"]["text"])
        self.assertNotIn("dbo.", messages[0]["chatMessage"]["text"])
        self.assertNotIn("Lakehouse", messages[0]["chatMessage"]["text"])
        self.assertFalse(any(call[0] in ("DELETE", "PATCH", "PUT") for call in ctx.calls))
        self.assertFalse(any("/lakehouses/" in call[1] for call in ctx.calls))
        self.assertEqual(result["evidence"]["applyRaceCancellation"], "NOT RUN")
        self.assertFalse(result["evidence"]["networkEnforcementVerified"])
        again, _ = self.run_case(ctx)
        self.assertEqual(again["status"], "BLOCKED")
        self.assertEqual(sum(call[0] == "CREATE" for call in ctx.calls), 1)

    def test_configuration_checks_before_any_network_or_creation(self):
        for changes in ({"allow_create": value} for value in (False, None, "true", 1)):
            ctx = FakeContext(kql=True)
            ctx.config.update(changes)
            result, _ = self.run_case(ctx)
            self.assertEqual(result["status"], "BLOCKED")
            self.assertEqual(ctx.calls, [])
        for changes in ({"generation_kql_database_id": None}, {"generation_kql_database_id": "bad"},
                        {"generation_source_workspace_id": ORIGINAL}, {"ux_token_version": "v1"}):
            with self.subTest(changes=changes):
                ctx = FakeContext(kql=True)
                ctx.config.update(changes)
                self.assertTrue(generation.prerequisites(ctx.config, "generation.kql"))
                result, _ = self.run_case(ctx)
                self.assertEqual(result["status"], "BLOCKED")
                self.assertEqual(ctx.calls, [])
        self.assertEqual(generation.prerequisites(FakeContext(kql=True).config, "generation.kql"), [])
        self.assertEqual(generation.prerequisites(FakeContext().config, "generation.lifecycle"), [])
        self.assertTrue(generation.prerequisites({}, "generation.mixed"))

    def test_source_preflight_blocks_without_creation(self):
        for options in ({"missing_source": True}, {"metadata_id": ORIGINAL},
                        {"cluster_uri": None}, {"cluster_uri": "https://untrusted.example"},
                        {"cluster_uri": CLUSTER + "/v1/rest/query"},
                        {"cluster_uri": CLUSTER + "?token=do-not-send"}):
            with self.subTest(options=options):
                ctx = FakeContext(kql=True, **options)
                result, _ = self.run_case(ctx)
                self.assertEqual(result["status"], "BLOCKED", result)
                self.assertFalse(any(call[0] == "CREATE" for call in ctx.calls))

    def test_safety_and_incomplete_protocols_never_pass(self):
        cases = {
            "plan_mutates": "FAIL", "reject_mutates": "FAIL", "cancel_mutates": "FAIL",
            "binding_mismatch": "FAIL", "expression_mismatch": "FAIL", "relationship_mismatch": "FAIL",
            "not_empty": "FAIL", "returned_original": "FAIL", "wrong_answer": "FAIL",
            "invalid_count": "FAIL", "missing_apply": "BLOCKED", "unsupported_kql": "BLOCKED",
            "missing_apply_receipt": "PARTIAL", "no_json": "PARTIAL", "cancel_too_late": "PARTIAL",
            "provisioning_timeout": "BLOCKED",
        }
        for option, status in cases.items():
            with self.subTest(option=option):
                ctx = FakeContext(kql=True, **{option: True})
                result, _ = self.run_case(ctx)
                self.assertEqual(result["status"], status, result)
                self.assertLessEqual(ctx.applies, 1)
                self.assertFalse(any(call[0] in ("DELETE", "PUT", "PATCH") for call in ctx.calls))

    def test_bounded_additive_repair_and_read_only_source_evidence(self):
        for options, status in (({"missing_readingid": True}, "PASS"),
                                ({"missing_readingid": True, "repair_unsupported": True}, "PARTIAL"),
                                ({"missing_readingid": True, "repair_drops_key": True}, "FAIL"),
                                ({"missing_readingid": True, "repair_changes_binding": True}, "FAIL")):
            ctx = FakeContext(kql=True, **options)
            result, _ = self.run_case(ctx)
            self.assertEqual(result["status"], status, result)
            self.assertEqual(ctx.applies, 2)
            self.assertLessEqual(len(result["evidence"]["turns"]), generation.MAX_TURNS)
        result, _ = self.run_case(FakeContext(kql=True), ScenarioBlocked("KQL source unavailable"))
        self.assertEqual(result["status"], "PASS", result)
        self.assertIn("independentSourceReadNote", result["evidence"]["stages"]["query"])
        with patch.object(generation, "_read_source_rows", return_value={"rows": [{**ROW, "PlantCount": 4}]}):
            result = generation.generation_kql(FakeContext(kql=True))
        self.assertEqual(result["status"], "FAIL", result)

    def test_ambiguous_timeout_cancels_once_without_replay(self):
        for option in ("timeout_phase", "post_timeout"):
            ctx = FakeContext(kql=True, **{option: "approve"})
            result, _ = self.run_case(ctx)
            self.assertEqual(result["status"], "BLOCKED", result)
            self.assertEqual(ctx.applies, 1)
            self.assertEqual(sum(call[1].endswith("/cancel") for call in ctx.calls), 1)
            self.assertEqual(ctx.state["generationKql"]["conversationId"], CONVERSATION)
            self.assertFalse(result["evidence"]["bestEffortCancel"]["terminalVerified"])
        ctx = FakeContext(kql=True, requires_action="plan")
        result, _ = self.run_case(ctx)
        self.assertEqual(result["status"], "BLOCKED")
        self.assertEqual(ctx.applies, 0)

    def test_kql_bindings_verify_authored_identity_and_supported_shapes(self):
        source = {"id": SOURCE, "catalog": "FixtureKQL", "clusterUri": CLUSTER}
        document = definition(kql=True)
        for table in document["model"]["tables"]:
            table["partitions"][0]["source"]["expression"] = (
                f'let Db = AzureDataExplorer.Contents("{CLUSTER}", "FixtureKQL"), '
                f'Nav = Db{{[Name="{table["name"]}"]}}[Data] in Nav')
        self.assertEqual(generation._bindings(document, WORKSPACE, SOURCE, source)["sourceTables"],
                         sorted(generation.SOURCE_TABLES))
        for name, value in (("ONT_WorkspaceId", ORIGINAL), ("ONT_ItemKind", "Lakehouse")):
            bad = definition(kql=True)
            for entry in bad["model"]["tables"][0]["partitions"][0]["annotations"]:
                if entry["name"] == name:
                    entry["value"] = value
            with self.assertRaises(ValueError):
                generation._bindings(bad, WORKSPACE, SOURCE, source)
        for expression, error in (
                (f'let S = AzureDataExplorer.Contents("https://other.kusto.fabric.microsoft.com", "{SOURCE}", "Plants") in S', ValueError),
                (f'let S = AzureDataExplorer.Contents("{CLUSTER}", "{SOURCE}", "Other") in S', ValueError),
                (f'let S = AzureDataExplorer.Contents("{CLUSTER}", "{SOURCE}", "Plants"), Evil = Other in Evil', ScenarioBlocked)):
            with self.subTest(expression=expression), self.assertRaises(error):
                generation._kql_table({"type": "m", "expression": expression}, source)


class IndependentKqlTests(unittest.TestCase):
    def test_read_only_query_uses_existing_credential_and_closes(self):
        ctx = SimpleNamespace(credential=object(), timeout=10, request=Mock())
        ctx.request.return_value = {"Tables": [{"Columns": [{"ColumnName": key} for key in generation.EXPECTED_FIELDS],
                                                "Rows": [[ROW[key] for key in generation.EXPECTED_FIELDS]]}]}
        source = {"kind": "KQLDatabase", "id": SOURCE, "clusterUri": CLUSTER}
        with patch.object(generation, "Api") as api:
            api.return_value.base = CLUSTER
            proof = generation._read_source_rows(ctx, source)
        api.assert_called_once_with(CLUSTER, generation.KUSTO_SCOPE, ctx.credential, 10)
        ctx.request.assert_called_once_with(api.return_value, "POST", CLUSTER + "/v1/rest/query",
                                            {"db": SOURCE, "csl": generation.SOURCE_KQL})
        api.return_value.close.assert_called_once()
        self.assertEqual(proof["rows"], [ROW])
        self.assertFalse(proof["agentEngineExecutionVerified"])
        self.assertNotIn(".set", generation.SOURCE_KQL)
        self.assertIn("ReadingId asc, AssetId asc", generation.SOURCE_KQL)

    def test_failure_closes_and_never_retries(self):
        ctx = SimpleNamespace(credential=object(), timeout=10, request=Mock(side_effect=RuntimeError("unavailable")))
        with patch.object(generation, "Api") as api, self.assertRaises(RuntimeError):
            api.return_value.base = CLUSTER
            generation._read_source_rows(ctx, {"kind": "KQLDatabase", "id": SOURCE, "clusterUri": CLUSTER})
        ctx.request.assert_called_once()
        api.return_value.close.assert_called_once()


class IndependentSqlTests(unittest.TestCase):
    def test_read_only_sql_uses_current_credential_and_closes_connection(self):
        credential = Mock()
        credential.get_token.return_value.token = "in-memory-test-token"
        context = SimpleNamespace(credential=credential, timeout=10)
        connection = Mock()
        cursor = connection.cursor.return_value
        cursor.description = [(key,) for key in generation.EXPECTED_FIELDS]
        cursor.fetchall.return_value = [tuple(ROW[key] for key in generation.EXPECTED_FIELDS)]
        pyodbc = Mock()
        pyodbc.connect.return_value = connection
        with patch.dict(sys.modules, {"pyodbc": pyodbc}):
            proof = generation._read_source_rows(context, {"server": "sql.datawarehouse.fabric.microsoft.com",
                                                          "catalog": "FixtureLakehouse"})
        self.assertEqual(proof["rows"], [ROW])
        credential.get_token.assert_called_once_with("https://database.windows.net/.default")
        cursor.execute.assert_called_once_with(generation.SOURCE_SQL)
        connection.close.assert_called_once()
        self.assertNotIn("in-memory-test-token", json.dumps(proof))
        self.assertIn("Encrypt=yes;TrustServerCertificate=no", pyodbc.connect.call_args.args[0])

    def test_read_failure_closes_connection_and_does_not_retry(self):
        credential = Mock()
        credential.get_token.return_value.token = "in-memory-test-token"
        connection = Mock()
        connection.cursor.return_value.execute.side_effect = RuntimeError("SQL unavailable")
        pyodbc = Mock()
        pyodbc.connect.return_value = connection
        with patch.dict(sys.modules, {"pyodbc": pyodbc}), self.assertRaises(RuntimeError):
            generation._read_source_rows(SimpleNamespace(credential=credential, timeout=10),
                                         {"server": "sql.datawarehouse.fabric.microsoft.com", "catalog": "fixture"})
        connection.close.assert_called_once()
        pyodbc.connect.assert_called_once()


if __name__ == "__main__":
    unittest.main()
