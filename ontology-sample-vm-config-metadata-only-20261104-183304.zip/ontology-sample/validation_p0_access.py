"""Paired, read-only access probes; environment/permission preparation remains external."""

import base64
import json
from contextlib import closing
from functools import partial
from pathlib import Path
from uuid import UUID

from create_sample import Api, PBI_SCOPE, sample_tables
from validation_common import HttpFailure, InvalidResponse, ScenarioBlocked
from validation_preview import KUSTO_SCOPE, build_query, compare_fixture, result_table, settings

CASES = ("lakehouse", "kql")
MODES = {"access-baseline": "authorized", "network-denied": "outside-network",
         "source-denied": "source-denied"}
CONTRACT = "p0-access-v1"
NETWORK_MARKERS = ("deniedbypolicy", "private link", "privatelink", "public access",
                   "ip address", "networkpolicy")
NETWORK_DENIAL_MARKERS = ("private link validation failed",
                         "while private links are enabled, you cannot connect from this ip address")
AUTHORIZATION_CODES = {"forbidden", "accessdenied", "authorizationfailed",
                       "kusto.data.exceptions.kustorequestdeniedexception",
                       "kustorequestdeniedexception"}


def target(config, case):
    execution, source, origin = settings(config, case)
    if source["workspace_id"].lower() != config["workspace_id"].lower():
        raise ScenarioBlocked("P0 Lakehouse/KQL baseline requires the source in the ontology workspace")
    if config["target_network"] not in ("wspl", "tenantpl"):
        raise ScenarioBlocked("P0 access checks require an explicit private target route, not public")
    return {"tenantId": config["tenant_id"], "workspaceId": config["workspace_id"],
            "ontologyId": config["ontology_id"], "targetNetwork": config["target_network"],
            "execution": execution, "source": source, "origin": origin, "case": case}


def baseline(config, case):
    value = config["p0_access"].get("baseline_results")
    if not isinstance(value, str) or not value:
        raise ScenarioBlocked("Supply p0_access.baseline_results from an authorized access-baseline run")
    try:
        path = Path(value)
        if path.stat().st_size > 16 * 1024 * 1024:
            raise ValueError("Baseline results exceed 16 MiB")
        report = json.loads(path.read_text(encoding="utf-8-sig"))
        rows = [row for row in report["results"]
                if row["scenario"] == f"p0.access-baseline.{case}" and row.get("selected")]
        if len(rows) != 1 or rows[0]["status"] != "PASS" or not rows[0].get("finishedUtc"):
            raise ValueError("A completed, selected PASS baseline is required for this source")
        evidence = rows[0]["evidence"]
        if evidence["contract"] != CONTRACT or evidence["target"] != target(config, case):
            raise ValueError("Baseline target, source, execution route or contract does not match")
        if evidence["controls"] != {"ontology": "PASS", "gateway": "PASS"}:
            raise ValueError("Baseline must have successful ontology and gateway controls")
        if evidence["tables"] != [
            {"table": table.name, "status": "PASS", "rows": len(table.rows)} for table in sample_tables()
        ]:
            raise ValueError("Baseline must verify every complete fixture table")
        principal = evidence["principal"]
        if str(UUID(principal["tenantId"])) != str(UUID(config["tenant_id"])):
            raise ValueError("Baseline principal tenant mismatch")
        if not UUID(principal["objectId"]).int:
            raise ValueError("Baseline principal object ID must be nonempty")
        return evidence, {"path": str(path.resolve()), "finishedUtc": rows[0]["finishedUtc"]}
    except (OSError, ValueError, KeyError, TypeError) as error:
        raise ScenarioBlocked(f"Invalid authorized baseline: {error}") from None


def prerequisites(config, scenario):
    try:
        _, mode, case = scenario.split(".")
        if mode not in MODES or case not in CASES:
            raise ScenarioBlocked("Unknown P0 access scenario")
        target(config, case)
        access = config.get("p0_access")
        if (not isinstance(access, dict) or set(access) - {"context", "baseline_results"}
                or access.get("context") != MODES[mode]):
            raise ScenarioBlocked(f"Set p0_access.context to {MODES[mode]!r} after preparing that "
                                  "network/identity externally; no policy or permission changes are automated")
        if mode != "access-baseline":
            baseline(config, case)
        return []
    except (ScenarioBlocked, ValueError) as error:
        return [str(error)]


def principal(ctx):
    """Record only identity claims, never the token; accepted controls establish authentication."""
    identities = []
    for scope in (PBI_SCOPE, KUSTO_SCOPE):
        token = ctx.credential.get_token(scope).token
        if isinstance(token, str):
            ctx._secrets.add(token)
        try:
            payload = token.split(".")[1]
            claims = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
            identity = {"tenantId": str(UUID(claims["tid"])), "objectId": str(UUID(claims["oid"]))}
            if not UUID(identity["objectId"]).int or identity["tenantId"] != str(UUID(ctx.config["tenant_id"])):
                raise ValueError("Identity mismatch")
        except (ValueError, KeyError, TypeError, IndexError, AttributeError):
            raise ScenarioBlocked("Cannot record tenant/object identity claims for paired access checks; "
                                  "tokens are not persisted and no alternate login is attempted") from None
        identities.append(identity)
    if identities[0] != identities[1]:
        raise ScenarioBlocked("Fabric and Kusto credentials identify different principals")
    return identities[0]


def observe(ctx, api, method, url, body=None):
    start = len(ctx.requests)
    try:
        response = ctx.exchange(api, method, url, body)
    except HttpFailure:
        if len(ctx.requests) <= start:
            raise
        entry = ctx.requests[-1]
        return entry["httpStatus"], entry.get("response")
    try:
        return response.status_code, response.json()
    except ValueError as error:
        raise InvalidResponse("Access probe response was not JSON; inspect HTTP evidence") from error


def _errors(value):
    found = []
    if isinstance(value, dict):
        for key, item in value.items():
            if key.lower() in ("error", "errors", "oneapierrors") and item:
                found.append(item)
            else:
                found.extend(_errors(item))
    elif isinstance(value, list):
        for item in value:
            found.extend(_errors(item))
    return found


def _error_fields(value, depth=0):
    codes, texts = set(), []
    if depth > 12:
        return codes, texts
    if isinstance(value, dict):
        for key, item in value.items():
            if key.lower() in ("code", "errorcode", "@type") and isinstance(item, str):
                codes.add(item.lower())
            child_codes, child_texts = _error_fields(item, depth + 1)
            codes.update(child_codes)
            texts.extend(child_texts)
    elif isinstance(value, list):
        for item in value:
            child_codes, child_texts = _error_fields(item, depth + 1)
            codes.update(child_codes)
            texts.extend(child_texts)
    elif isinstance(value, str):
        texts.append(value.lower())
        # Kusto wraps the downstream error JSON in @message prose.
        decoder = json.JSONDecoder()
        attempts = 0
        for offset, char in enumerate(value):
            if char != "{":
                continue
            attempts += 1
            if attempts > 32:
                break
            try:
                nested, _ = decoder.raw_decode(value[offset:])
            except ValueError:
                continue
            child_codes, child_texts = _error_fields(nested, depth + 1)
            codes.update(child_codes)
            texts.extend(child_texts)
            break
    return codes, texts


def _has_rows(value):
    if isinstance(value, dict):
        if value.get("Rows") and value.get("TableKind") not in ("QueryStatus", "QueryCompletionInformation"):
            return True
        return any(_has_rows(item) for item in value.values())
    return isinstance(value, list) and any(_has_rows(item) for item in value)


def denial(status, data, mode):
    if _has_rows(data):
        return "FAIL", "Protected rows returned, including partial rows alongside an error"
    if status == 401:
        return "BLOCKED", "Authentication failure is not proof of network/source authorization enforcement"
    if status not in (200, 403):
        return "BLOCKED", f"HTTP {status} is not a classified policy/authorization denial"
    errors = _errors(data)
    if not errors:
        return ("FAIL", "Request was not denied") if status == 200 else (
            "BLOCKED", "Unclassified 403; a generic error page is not enforcement proof")
    codes, texts = _error_fields(errors)
    network = any(marker in text for marker in NETWORK_MARKERS for text in texts)
    if mode == "network-denied":
        if ("deniedbypolicy" in codes
                or any(marker in text for marker in NETWORK_DENIAL_MARKERS for text in texts)):
            return "PASS", "Explicit network-policy rejection observed"
        return "BLOCKED", "Authorization-only or unknown denial cannot establish network enforcement"
    if network:
        return "BLOCKED", "Network-policy rejection is not a source-permission test"
    if codes & AUTHORIZATION_CODES:
        return "PASS", "Authorization rejection with no returned rows"
    return "BLOCKED", "Source authorization denial was not identified; review retained service error"


def controls(ctx, api, execution, origin, mode):
    item_url = (f"{ctx.fabric.base}/workspaces/{ctx.config['workspace_id']}"
                f"/items/{ctx.config['ontology_id']}")
    query = {"db": execution["database_id"], "csl": "print P0Probe=1", "properties": None}
    checks = {}
    for name, client, method, url, body in (
        ("ontology", ctx.fabric, "GET", item_url, None),
        ("gateway", api, "POST", origin + "/v2/rest/query", query),
    ):
        status, data = observe(ctx, client, method, url, body)
        ctx.save_evidence(name + ".control", {"httpStatus": status, "response": data})
        if mode == "network-denied":
            outcome, reason = denial(status, data, mode)
            checks[name] = outcome
            ctx.save_evidence(name + ".control-check", {"status": outcome, "reason": reason})
        elif status != 200:
            raise ScenarioBlocked(f"Positive {name} control failed (HTTP {status}); "
                                  "source-denial verdict would be ambiguous")
        elif name == "ontology":
            if (not isinstance(data, dict) or data.get("type") != "Ontology"
                    or str(data.get("id", "")).lower() != ctx.config["ontology_id"].lower()):
                raise InvalidResponse("Ontology access control returned the wrong item/type")
            checks[name] = "PASS"
        else:
            table = result_table(data)
            if ([column.get("ColumnName") for column in table.get("Columns", [])] != ["P0Probe"]
                    or table.get("Rows") != [[1]]):
                raise InvalidResponse("Gateway access control did not return print P0Probe=1")
            checks[name] = "PASS"
    return checks


def access(ctx, mode, case):
    errors = prerequisites(ctx.config, f"p0.{mode}.{case}")
    if errors:
        raise ScenarioBlocked("; ".join(errors))
    configured_target = target(ctx.config, case)
    identity = principal(ctx)
    evidence = {"contract": CONTRACT, "target": configured_target, "principal": identity,
                "readOnly": True, "browserUiTested": False, "policyConfigurationVerified": False,
                "scope": "Ontology-item ingress and child-Eventhouse reads only; not agent/MCP/UI enforcement"}
    if mode != "access-baseline":
        authorized, reference = baseline(ctx.config, case)
        if mode == "network-denied" and authorized["principal"] != identity:
            raise ScenarioBlocked("Outside-network probe must use the same principal as the authorized baseline")
        evidence.update(baseline=reference, baselinePrincipal=authorized["principal"],
                        contextDeclaration=ctx.config["p0_access"]["context"])
    execution, source, origin = settings(ctx.config, case)
    rows = []
    with closing(Api(origin, KUSTO_SCOPE, ctx.credential, ctx.timeout)) as api:
        evidence["controls"] = controls(ctx, api, execution, origin, mode)
        ctx.save_evidence("access", evidence)
        for table in sample_tables():
            body = {"db": execution["database_id"], "csl": build_query(case, source, table), "properties": None}
            ctx.save_evidence(table.name + ".request", body)
            status, data = observe(ctx, api, "POST", origin + "/v2/rest/query", body)
            ctx.save_evidence(table.name + ".response", {"httpStatus": status, "response": data})
            if mode == "access-baseline":
                if status != 200:
                    raise ScenarioBlocked(f"Authorized {table.name} baseline failed with HTTP {status}")
                compare_fixture(data, table)
                row = {"table": table.name, "status": "PASS", "rows": len(table.rows)}
            else:
                outcome, reason = denial(status, data, mode)
                row = {"table": table.name, "status": outcome, "reason": reason}
            rows.append(row)
            evidence["tables"] = rows
            ctx.save_evidence("access", evidence)
    statuses = set(evidence["controls"].values()) | {row["status"] for row in rows}
    status = next((value for value in ("FAIL", "BLOCKED") if value in statuses), "PASS")
    return {"status": status, "summary": f"{mode} {case}: {sum(row['status'] == 'PASS' for row in rows)}/3 "
            "table checks; ontology/gateway controls recorded; no automatic policy/permission changes",
            "evidence": evidence}


SCENARIOS = {f"p0.{mode}.{case}": partial(access, mode=mode, case=case)
             for mode in MODES for case in CASES}
