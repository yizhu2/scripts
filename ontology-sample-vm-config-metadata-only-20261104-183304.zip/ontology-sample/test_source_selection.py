import copy
import io
import json
import tempfile
import unittest
from contextlib import ExitStack, redirect_stdout
from pathlib import Path
from unittest.mock import Mock, patch
from uuid import uuid4

import create_ontology
import create_sample as sample
import retry_source
import reuse_sources
import run_sample
import validation_queries
from replace_ontology import serialize_definition, verify_public_bindings
from source_selection import (
    SOURCE_TYPES, expected_counts, manifest_source_types, normalize_source_types, source_groups,
)
from target_routing import TargetApi, target_fabric_api
from test_create_ontology import GUID, inventory, metadata
from test_run_sample import TARGET, ONTOLOGY
from validate_sample import main as validation_main, validate_config
from validation_setup import configure, import_sample_settings, prerequisites, unselected_source_reason

SELECTED = ("Eventhouse", "KQLDatabase", "Lakehouse")


def selected_state(network="wspl"):
    state = inventory()
    state.update(workspaceId=TARGET, existingWorkspaceId=TARGET, sameWorkspace=True,
                 targetNetwork=network, sourceTypes=list(SELECTED), sources=list(SELECTED))
    state["items"] = {kind: item for kind, item in state["items"].items() if kind in SELECTED}
    state["verified"] = {kind: count for kind, count in state["verified"].items() if kind in SELECTED}
    state["endpoints"]["fabric"] = target_fabric_api(network, TARGET, GUID)
    return state


class SelectionTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.folder = Path(directory.name)

    def flags(self, network="wspl"):
        return ["--tenant-id", GUID, "--workspace-id", TARGET, "--same-workspace",
                "--target-network", network, "--authoring-mode", "public",
                "--source-types", "Lakehouse", "Eventhouse", "--ontology-name", "SelectedSample",
                "--run-directory", str(self.folder / "run")]

    def source_args(self, network="wspl", types=SELECTED):
        return sample.arguments(["--tenant-id", GUID, "--workspace-id", TARGET, "--same-workspace",
                                 "--target-network", network, "--settle-seconds", "0",
                                 "--source-types", *types])

    def manifest(self, state=None):
        manifest = sample.Manifest(self.folder / (uuid4().hex + ".json"), state or {})
        if state and "items" in state:
            manifest.data.update(items=copy.deepcopy(state["items"]), verified=copy.deepcopy(state["verified"]))
        return manifest

    def serialize(self, expected):
        folder = self.folder / uuid4().hex
        folder.mkdir()
        return serialize_definition(expected, folder)

    def mock_provisioner(self, args, manifest):
        p = sample.Provisioner(args, Mock(), manifest)
        self.addCleanup(p.close)
        self.assertIsInstance(p.api, TargetApi)
        p.api.close()
        p.api = Mock(base=args.fabric_api)
        for name in ("seed_lakehouse", "seed_mirror", "seed_sql", "seed_kql",
                     "refresh_sql_metadata", "seed_semantic", "verify_semantic"):
            setattr(p, name, Mock())
        counts = {"Plants": 3, "Assets": 12, "Readings": 120}
        p.verify_kql = Mock(side_effect=lambda: manifest.data["verified"].update(
            KQLDatabase=counts, Eventhouse={"viaKqlDatabaseId": manifest.data["items"]["KQLDatabase"]["id"]}))
        p.verify_sql = Mock(side_effect=lambda kind, **kwargs: manifest.data["verified"].update({kind: counts}))
        return p

    def test_canonical_selection_and_all_source_default(self):
        self.assertEqual(normalize_source_types(), SOURCE_TYPES)
        self.assertEqual(normalize_source_types(["Lakehouse", "Eventhouse"]), SELECTED)
        self.assertEqual(normalize_source_types(["KQLDatabase"]), ("Eventhouse", "KQLDatabase"))
        self.assertEqual(source_groups(SELECTED), ("Lakehouse", "KQLDatabase"))
        self.assertEqual(expected_counts(SELECTED),
                         {"sourceItemTypes": 3, "sourceGroups": 2, "entities": 6, "relationships": 4})
        self.assertEqual(expected_counts()["entities"], 18)
        for invalid in ([], ["Lakehouse", "Lakehouse"], ["Wrong"], "Lakehouse"):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                normalize_source_types(invalid)

    def test_public_selected_plans_no_auth_outputs_prompts_or_ux_routes(self):
        for network in ("wspl", "tenantpl", "public"):
            with self.subTest(network=network), patch("builtins.input") as prompt, \
                    patch("run_sample.ux_routing") as ux, patch("run_sample.run") as run, \
                    redirect_stdout(io.StringIO()) as out:
                run_sample.main(self.flags(network))
                plan = json.loads(out.getvalue())
                self.assertEqual(plan["sourceTypes"], list(SELECTED))
                self.assertEqual(plan["expected"], expected_counts(SELECTED))
                self.assertEqual(plan["deferredValidation"], {})
                self.assertEqual(plan["sourceFabricApi"], plan["targetFabricApi"])
                self.assertFalse(plan["createsSourceWorkspace"])
                prompt.assert_not_called()
                ux.assert_not_called()
                run.assert_not_called()
                self.assertFalse((self.folder / "run").exists())

    def test_selected_creation_loads_verifies_only_requested_items_and_dependencies(self):
        for network in ("wspl", "tenantpl"):
            args = self.source_args(network)
            manifest = self.manifest(sample.source_plan(args))
            p = self.mock_provisioner(args, manifest)
            p.api.json.side_effect = [
                {"id": TARGET, "capacityId": GUID, "displayName": "Protected"},
                {"value": [{"id": ONTOLOGY, "displayName": args.prefix + "_Warehouse"}]},
            ]
            p.api.mutate.side_effect = [{"id": str(uuid4())} for _ in SELECTED]
            p.run()
            self.assertEqual(set(manifest.data["items"]), set(SELECTED))
            self.assertEqual(manifest.data["sourceTypes"], list(SELECTED))
            self.assertEqual(manifest.data["deferredValidation"], {})
            self.assertEqual(manifest.data["status"], "succeeded")
            self.assertEqual([call.args[0].rsplit("/", 1)[-1] for call in p.api.mutate.call_args_list],
                             ["eventhouses", "kqlDatabases", "lakehouses"])
            p.seed_lakehouse.assert_called_once_with()
            p.seed_kql.assert_called_once_with()
            p.seed_mirror.assert_not_called()
            p.seed_sql.assert_not_called()
            p.seed_semantic.assert_not_called()
            p.verify_semantic.assert_not_called()
            p.verify_sql.assert_called_once_with("Lakehouse", asynchronous=True, refresh_before_read=False)
            p.refresh_sql_metadata.assert_called_once_with("Lakehouse")
            create_ontology.validate_inventory(manifest.data)

    def test_single_source_groups_and_default_all_roundtrip_without_other_metadata(self):
        for selected in ([kind] for kind in (*create_ontology.GROUPS, "Eventhouse")):
            with self.subTest(selected=selected):
                types = normalize_source_types(selected)
                state = inventory()
                state["sourceTypes"] = list(types)
                state["items"] = {kind: item for kind, item in state["items"].items() if kind in types}
                state["verified"] = {kind: value for kind, value in state["verified"].items() if kind in types}
                create_ontology.validate_inventory(state)
                properties = {kind: value for kind, value in metadata().items() if kind in types}
                expected = create_ontology.build_definition(state, properties, "powerbi://dailyapi.powerbi.com")
                self.assertEqual(len(expected["model"]["entities"]), 3)
                self.assertEqual(len(expected["model"]["relationships"]), 2)
                self.serialize(expected)
        expected = create_ontology.build_definition(inventory(), metadata(), "powerbi://dailyapi.powerbi.com")
        self.assertEqual(len(expected["model"]["entities"]), 18)
        self.serialize(expected)

    def test_no_unselected_auth_or_dependency_requirements(self):
        args = self.source_args(types=("Eventhouse",))
        self.assertEqual(sample.source_scopes(args), [sample.PBI_SCOPE, args.kusto_scope])
        with patch("pyodbc.drivers", side_effect=AssertionError("Unselected SQL dependency")), \
                patch("create_sample.importlib.import_module") as imported:
            sample.check_local_dependencies(args)
        self.assertEqual([call.args[0] for call in imported.call_args_list], ["requests"])
        args = self.source_args(types=("Lakehouse",))
        self.assertEqual(sample.source_scopes(args),
                         [sample.PBI_SCOPE, sample.STORAGE_SCOPE, sample.SQL_SCOPE])

    def test_manifest_conflicts_and_unselected_items_rejected_before_outputs_or_calls(self):
        state = selected_state()
        path = self.folder / "source.json"
        path.write_text(json.dumps(state))
        with patch("run_sample.run") as run, self.assertRaisesRegex(ValueError, "conflicts"):
            run_sample.main(self.flags() + ["--sources-manifest", str(path),
                                           "--source-types", "Warehouse", "--execute"])
        run.assert_not_called()
        self.assertFalse((self.folder / "run").exists())
        for field in ("items", "verified", "verifiedDefinitions", "deferredValidation"):
            bad = copy.deepcopy(state)
            bad[field] = {**bad.get(field, {}), "SemanticModel": {}}
            with self.subTest(field=field), self.assertRaisesRegex(ValueError, "unselected"):
                manifest_source_types(bad)
        state["sources"] = ["Lakehouse"]
        with self.assertRaisesRegex(ValueError, "disagree"):
            manifest_source_types(state)

    def test_resume_inherits_manifest_selection_and_selected_verification(self):
        path = self.folder / "sources.json"
        path.write_text(json.dumps(selected_state()))
        flags = self.flags()
        del flags[flags.index("--source-types"):flags.index("--source-types") + 3]
        with redirect_stdout(io.StringIO()) as output:
            run_sample.main(flags + ["--sources-manifest", str(path), "--verify-only", "--ontology-id", ONTOLOGY])
        self.assertEqual(json.loads(output.getvalue())["expected"], expected_counts(SELECTED))
        self.assertFalse((self.folder / "run").exists())

    def test_selected_public_alm_roundtrip_and_verify_only_never_call_ux(self):
        for network in ("wspl", "tenantpl"):
            for verify in (False, True):
                with self.subTest(network=network, verify=verify), ExitStack() as stack:
                    flags = self.flags(network)
                    if verify:
                        flags += ["--sources-manifest", "unused.json", "--verify-only", "--ontology-id", ONTOLOGY]
                    args = run_sample.arguments(flags)
                    state = selected_state(network)
                    target = Mock(base=args.target_fabric_api)
                    source = Mock(base=args.target_fabric_api)
                    target.json.side_effect = [
                        {"id": TARGET, "capacityId": GUID, "displayName": state["workspaceName"]},
                        {"id": ONTOLOGY, "type": "Ontology", "displayName": args.ontology_name}
                        if verify else {"value": []},
                    ]
                    source.json.side_effect = [
                        {"capacityId": GUID, "displayName": state["workspaceName"]},
                        *[{"displayName": state["items"][kind]["displayName"], "properties": metadata()[kind]}
                          for kind in source_groups(SELECTED)],
                    ]
                    expected = create_ontology.build_definition(state, metadata(), "powerbi://dailyapi.powerbi.com")
                    exported = self.serialize(expected)
                    target.mutate.side_effect = ([exported] if verify else [
                        {"id": ONTOLOGY, "displayName": args.ontology_name}, {}, exported])
                    stack.enter_context(patch("run_sample.TargetApi", side_effect=[target, source]))
                    ux = stack.enter_context(patch("run_sample.author_and_verify", side_effect=AssertionError("UX")))
                    manifest = self.manifest()
                    run_sample.run(args, Mock(), manifest, None, state)
                    ux.assert_not_called()
                    self.assertEqual(manifest.data["status"], "succeeded")
                    self.assertEqual(manifest.data["verified"]["publicDefinition"],
                                     {"entities": 6, "boundTables": 6, "relationships": 4, "entityRelationships": 4})
                    names = {entity["name"] for entity in manifest.data["storedDefinition"]["model"]["entities"]}
                    self.assertEqual(names, {f"{group}_{table}" for group in ("Lakehouse", "EventhouseKQL")
                                             for table in ("Plants", "Assets", "Readings")})
                    calls = [call.args[0] for call in target.mutate.call_args_list]
                    self.assertTrue(all(path.startswith(args.target_fabric_api) for path in calls))
                    self.assertEqual(len(calls), 1 if verify else 3)
                    if verify:
                        self.assertTrue(calls[0].endswith("/getDefinition"))
                    source.mutate.assert_not_called()

    def test_stored_extra_group_fails_exact_selected_definition_verification(self):
        state = selected_state()
        expected = create_ontology.build_definition(state, metadata(), "powerbi://dailyapi.powerbi.com")
        actual = create_ontology.build_definition(inventory(), metadata(), "powerbi://dailyapi.powerbi.com")
        with self.assertRaises(ValueError):
            verify_public_bindings(expected, actual, state, TARGET)
        with self.assertRaisesRegex(ValueError, "supported source groups"):
            create_ontology.build_definition(state, metadata(), "", groups=("Warehouse",))

    def test_selected_alm_failure_is_not_replayed_or_fallen_back_to_ux(self):
        args = run_sample.arguments(self.flags())
        state = selected_state()
        target = Mock(base=args.target_fabric_api)
        source = Mock(base=args.target_fabric_api)
        target.json.side_effect = [
            {"id": TARGET, "capacityId": GUID, "displayName": state["workspaceName"]}, {"value": []}]
        target.mutate.side_effect = [{"id": ONTOLOGY}, RuntimeError("Ambiguous update outcome")]
        manifest = self.manifest()
        with patch("run_sample.TargetApi", side_effect=[target, source]), \
                patch("run_sample.discover_sources", return_value=metadata()), \
                patch("run_sample.author_and_verify") as ux, \
                self.assertRaisesRegex(RuntimeError, "Ambiguous"):
            run_sample.run(args, Mock(), manifest, None, state)
        self.assertEqual(target.mutate.call_count, 2)
        ux.assert_not_called()
        self.assertEqual(json.loads(manifest.path.read_text())["items"]["Ontology"]["id"], ONTOLOGY)

    def test_discovery_ignores_unselected_types_and_checks_eventhouse_dependency(self):
        state = selected_state()
        items = [{**item, "type": kind} for kind, item in state["items"].items()]
        for item in items:
            item["id"] = str(uuid4())
        by_kind = {item["type"]: item for item in items}
        items += [{"type": "SemanticModel", "id": "irrelevant"}, {"type": "SemanticModel", "id": "irrelevant"}]
        api = Mock(base=state["endpoints"]["fabric"])
        api.json.side_effect = [
            {"value": items}, by_kind["Lakehouse"],
            {**by_kind["KQLDatabase"], "properties": {"parentEventhouseItemId": by_kind["Eventhouse"]["id"]}},
            by_kind["Eventhouse"],
        ]
        found = reuse_sources.select_sources(api, TARGET, {}, SELECTED)
        self.assertEqual(set(found), set(SELECTED))
        self.assertFalse(any("semanticModels" in call.args[1] for call in api.json.call_args_list))
        with self.assertRaisesRegex(ValueError, "unselected"):
            reuse_sources.select_sources(api, TARGET, {"Warehouse": GUID}, SELECTED)

    def test_reuse_selected_sources_no_semantic_export_loads_or_refresh(self):
        args = run_sample.arguments(self.flags() + ["--skip-source-creation"])
        args.run_directory.mkdir()
        state = selected_state()
        api = Mock(base=args.target_fabric_api)
        api.json.return_value = {"id": TARGET, "capacityId": GUID, "displayName": state["workspaceName"]}
        credential = Mock()
        readers = []

        def reader_factory(source_args, credential, manifest):
            p = self.mock_provisioner(source_args, manifest)
            readers.append(p)
            return p

        with patch("reuse_sources.select_sources", return_value=state["items"]) as select, \
                patch("reuse_sources.check_local_dependencies"), \
                patch("reuse_sources.Provisioner", side_effect=reader_factory):
            result = reuse_sources.reuse_workspace_sources(args, credential, api)
        self.assertEqual(result["status"], "succeeded")
        self.assertEqual(result["deferredValidation"], {})
        select.assert_called_once_with(api, TARGET, {}, SELECTED)
        p = readers[0]
        p.api.mutate.assert_not_called()
        p.seed_lakehouse.assert_not_called()
        p.seed_kql.assert_not_called()
        p.refresh_sql_metadata.assert_not_called()
        p.verify_sql.assert_called_once_with("Lakehouse", asynchronous=False, refresh_before_read=False)

    def test_retry_immutable_inventory_and_partial_completion_only_selected_sources(self):
        state = selected_state()
        args = retry_source.arguments(["--sources-manifest", "unused.json", "--source-type", "Eventhouse",
                                       "--run-directory", str(self.folder / "retry"), "--settle-seconds", "0"])
        selected, source_args = retry_source.prepare(args, state)
        self.assertEqual(selected, ("Eventhouse", "KQLDatabase"))
        self.assertEqual(source_args.source_types, SELECTED)
        state["status"] = "failed"
        del state["items"]["KQLDatabase"]
        del state["verified"]["KQLDatabase"]
        self.assertEqual(retry_source.remaining_sources(state), ["KQLDatabase"])
        p = self.mock_provisioner(source_args, self.manifest(state))
        p.api.json.side_effect = [
            {"capacityId": GUID, "displayName": state["workspaceName"]}, {"value": []}]
        p.api.mutate.side_effect = [{"id": str(uuid4())}, {"id": str(uuid4())}]
        retry_source.run(p, selected, False)
        self.assertEqual(p.manifest.data["status"], "succeeded")
        self.assertEqual(p.manifest.data["remainingSources"], [])
        self.assertEqual(set(p.manifest.data["items"]), set(SELECTED))
        p.seed_lakehouse.assert_not_called()
        p.seed_sql.assert_not_called()
        args.source_type = "SemanticModel"
        with self.assertRaisesRegex(ValueError, "unselected"):
            retry_source.prepare(args, state)

    def test_retry_verify_selected_sources_is_read_only(self):
        state = selected_state()
        args = retry_source.arguments(["--sources-manifest", "unused.json", "--source-type", "Lakehouse",
                                       "--verify-only", "--settle-seconds", "0"])
        selected, source_args = retry_source.prepare(args, state)
        p = self.mock_provisioner(source_args, self.manifest(state))
        p.api.json.side_effect = [
            {"capacityId": GUID, "displayName": state["workspaceName"]}, state["items"]["Lakehouse"]]
        retry_source.run(p, selected, True)
        p.api.mutate.assert_not_called()
        p.seed_lakehouse.assert_not_called()
        p.refresh_sql_metadata.assert_not_called()
        p.verify_kql.assert_not_called()
        self.assertEqual(p.manifest.data["remainingSources"], [])

    def test_public_manifest_validation_import_setup_and_alm_read_without_ux(self):
        path = self.folder / "run.json"
        path.write_text(json.dumps({
            "environment": "Daily", "authoringMode": "public", "tenantId": GUID,
            "targetWorkspaceId": TARGET, "items": {"Ontology": {"id": ONTOLOGY}},
            "targetNetwork": "wspl", "sourceTypes": list(SELECTED),
        }))
        config = {}
        import_sample_settings(config, path)
        checked = validate_config(copy.deepcopy(config))
        self.assertEqual(prerequisites(checked, {"ontology.definition"}), {})
        self.assertIn("ontology.lakehouse", prerequisites(checked, {"ontology.lakehouse"}))
        self.assertTrue(unselected_source_reason(checked, "data-agent.semantic"))
        self.assertFalse(unselected_source_reason(checked, "operations.lakehouse-kql"))
        ask = Mock(side_effect=lambda prompt: "SAVE" if prompt.startswith("Type SAVE") else "")
        self.assertEqual(configure(self.folder / "config.json", {"ontology.definition"}, path, ask), 0)
        self.assertFalse(any("HTTPS origin" in call.args[0] or "TargetUriHost" in call.args[0]
                             for call in ask.call_args_list))
        ctx = Mock(config=checked, directory=self.folder)
        ctx.fabric.base = target_fabric_api("wspl", TARGET, GUID)
        expected = create_ontology.build_definition(selected_state(), metadata(), "powerbi://dailyapi.powerbi.com")
        ctx.mutate.return_value = self.serialize(expected)
        result = validation_queries.definition(ctx)
        self.assertEqual(result["status"], "PASS")
        ctx.workload.assert_not_called()
        self.assertTrue(ctx.mutate.call_args.args[1].startswith(ctx.fabric.base))

    def test_unselected_validation_cases_skip_without_authentication(self):
        config = {
            "tenant_id": GUID, "workspace_id": TARGET, "ontology_id": ONTOLOGY,
            "target_network": "wspl", "authoring_mode": "public", "source_types": list(SELECTED),
        }
        path = self.folder / "config.json"
        path.write_text(json.dumps(config))
        with patch("azure.identity.AzureCliCredential") as auth, redirect_stdout(io.StringIO()):
            code = validation_main([
                "--config", str(path), "--scenarios", "ontology.semantic", "data-agent.warehouse",
                "--output", str(self.folder / "validation")])
        self.assertEqual(code, 0)
        auth.assert_not_called()
        results = json.loads((self.folder / "validation" / "results.json").read_text())
        rows = [row for row in results["results"] if row["selected"]]
        self.assertEqual([row["status"] for row in rows], ["SKIP", "SKIP"])
        self.assertTrue(all("Not selected" in row["summary"] for row in rows))

if __name__ == "__main__":
    unittest.main()
