"""Discover and verify existing sample sources without creating or loading source items."""

from contextlib import closing
from uuid import UUID

from create_ontology import validate_inventory
from create_sample import (
    COLLECTIONS, Manifest, Provisioner, arguments as source_arguments,
    check_local_dependencies, source_plan, source_scopes, workspace_items,
)
from create_semantic_ontology import verify_source_schema
from target_routing import target_fabric_api
from source_selection import normalize_source_types, source_groups

DAILY_ENDPOINTS = {
    "fabric": "https://dailyapi.fabric.microsoft.com/v1",
    "powerbi": "https://wabi-daily-us-east2-redirect.analysis.windows.net",
    "onelake": "https://daily-onelake.dfs.fabric.microsoft.com",
}


def select_sources(api, workspace_id, selections, source_types=None):
    selected = normalize_source_types(source_types)
    if set(selections) - set(selected):
        raise ValueError("Explicit source items include unselected source types")
    base = f"{api.base}/workspaces/{workspace_id}"
    listed = list(workspace_items(api, base))
    supported = [item for item in listed if item.get("type") in selected]
    ids = [str(UUID(item["id"])) for item in supported]
    if len(ids) != len(set(ids)):
        raise ValueError("Source item listing contains duplicate IDs; refusing ambiguous discovery")

    def select(kind, required_id=None):
        candidates = [item for item in supported if item["type"] == kind]
        selected_id = selections.get(kind)
        if required_id:
            if selected_id and selected_id != required_id:
                raise ValueError("Selected Eventhouse does not own the selected KQLDatabase")
            selected_id = required_id
        if selected_id:
            candidates = [item for item in candidates if str(UUID(item["id"])) == selected_id]
        if len(candidates) != 1:
            available = "; ".join(
                f"{item['displayName']} ({item['id']})" for item in supported if item["type"] == kind
            ) or "none"
            raise ValueError(
                f"Expected one {kind} in the source workspace, found {len(candidates)} matching items. "
                f"Available: {available}. Select explicitly with -SourceItemIds @{{{kind}='<item-id>'}} "
                f"or --source-item {kind}=<item-id>."
            )
        item = candidates[0]
        item_id = str(UUID(item["id"]))
        found = api.json("GET", f"{base}/{COLLECTIONS[kind]}/{item_id}")
        if (str(UUID(found["id"])) != item_id or found.get("displayName") != item["displayName"]
                or found.get("type", kind) != kind):
            raise ValueError(f"{kind} identity changed during discovery; stop and inspect the workspace")
        if not isinstance(item["displayName"], str) or not item["displayName"].strip():
            raise ValueError(f"Missing display name for {kind}")
        return {"id": item_id, "displayName": item["displayName"]}, found.get("properties", {})

    items = {}
    for kind in source_groups(selected):
        items[kind], properties = select(kind)
        if kind == "KQLDatabase":
            parent = str(UUID(properties["parentEventhouseItemId"]))
            items["Eventhouse"], _ = select("Eventhouse", parent)
    return items


def reuse_workspace_sources(args, credential, api):
    selected = normalize_source_types(getattr(args, "source_types", None))
    same_workspace = getattr(args, "same_workspace", False)
    if same_workspace and api.base != target_fabric_api(
            args.target_network, args.source_workspace_id, args.tenant_id):
        raise ValueError("Source discovery API must match the selected shared-workspace route")
    manifest = Manifest(args.run_directory / "sources.manifest.json", {
        "environment": "Daily", "tenantId": args.tenant_id, "workspaceId": args.source_workspace_id,
        "endpoints": {**DAILY_ENDPOINTS, "fabric": api.base}, "sourceMode": "existing-workspace",
        "sameWorkspace": same_workspace, "existingWorkspaceId": args.source_workspace_id,
        "targetNetwork": args.target_network if same_workspace else None,
        "selectedSourceItems": args.source_items, "verificationSettleSeconds": 0,
    })
    try:
        manifest.step("Discovering existing sample sources; no source items or data will be changed")
        workspace = api.json("GET", f"{api.base}/workspaces/{args.source_workspace_id}")
        if str(UUID(workspace["id"])) != args.source_workspace_id:
            raise ValueError("Source workspace identity does not match the supplied ID")
        if not workspace.get("capacityId") or not workspace.get("displayName"):
            raise ValueError("Existing source workspace must have a name and an assigned Fabric capacity")
        capacity_id = str(UUID(workspace["capacityId"]))
        if args.capacity_id and capacity_id != args.capacity_id:
            raise ValueError("Existing source workspace does not match the supplied source capacity")
        values = [
            "--tenant-id", args.tenant_id, "--manifest", str(manifest.path),
            "--timeout", str(args.timeout), "--settle-seconds", "0",
            "--kql-request-timeout", str(args.kql_request_timeout),
            "--source-types", *selected,
        ]
        values += (["--same-workspace", "--workspace-id", args.source_workspace_id,
                    "--target-network", args.target_network] if same_workspace else
                   ["--capacity-id", capacity_id, "--workspace-name", workspace["displayName"]])
        source_args = source_arguments(values)
        source_args.capacity_id = capacity_id
        source_args.workspace_name = workspace["displayName"]
        manifest.data.update(
            source_plan(source_args), workspaceId=args.source_workspace_id,
            existingWorkspaceId=args.source_workspace_id,
        )
        manifest.data["items"] = select_sources(api, args.source_workspace_id, args.source_items, selected)
        manifest.save()
        check_local_dependencies(source_args)
        for scope in source_scopes(source_args, read_only=True)[1:]:
            credential.get_token(scope)
        with closing(Provisioner(source_args, credential, manifest)) as reader:
            reader.workspace = args.source_workspace_id
            if "SemanticModel" in selected:
                manifest.step("Checking existing SemanticModel schema; refresh and row queries remain deferred")
                exported = reader.api.mutate(
                    reader.item_path("SemanticModel") + "/getDefinition", params={"format": "TMSL"})
                manifest.data["verifiedDefinitions"] = {"SemanticModel": verify_source_schema(exported)}
                manifest.save()
            if "KQLDatabase" in selected:
                reader.verify_kql()
            for kind in ("Lakehouse", "MirroredDatabase", "SQLDatabase", "Warehouse"):
                if kind in selected:
                    reader.verify_sql(kind, asynchronous=False, refresh_before_read=False)
        manifest.data["status"] = "succeeded"
        validate_inventory(manifest.data, allow_deferred_semantic=True)
        manifest.step("Existing sources verified without source creation, loading, or refresh")
        return manifest.data
    except (Exception, KeyboardInterrupt) as error:
        manifest.data.update(status="failed", error=str(error))
        manifest.save()
        raise
