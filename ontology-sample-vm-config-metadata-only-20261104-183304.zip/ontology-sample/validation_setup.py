"""Offline configuration and prerequisite checks using shared workspace routing."""

import json
import shutil
import tempfile
from pathlib import Path
from uuid import UUID, uuid4

from ux_authoring import workspace_routing
from validation_common import console
from source_selection import normalize_source_types, source_groups

MANUAL_SCENARIOS = {
    "operations.runtime": "This runtime entry performs no calls; activation, monitoring, actions and "
                          "notifications are not tested. Authoring entries may create one shared inactive artifact per run.",
}


def unselected_source_reason(config, name):
    if "source_types" not in config:
        return None
    from validation_queries import GROUPS
    available = {"EventhouseKQL" if kind == "KQLDatabase" else kind
                 for kind in source_groups(config["source_types"])}
    family, _, case = name.partition(".")
    if family == "p0":
        case = name.rpartition(".")[2]
    required = ({"EventhouseKQL" if case == "kql" else "Lakehouse"} if family == "generation" else
                set(GROUPS.get(case, ())) if family in ("ontology", "mcp", "data-agent", "operations", "preview") else set())
    if family == "p0":
        required = set(GROUPS.get(case, ()))
    missing = required - available
    return "Not selected in the source inventory: " + ", ".join(sorted(missing)) if missing else None


def data_agent_reference(config, scenario):
    """Resolve explicit reuse without allowing multiple agents in shared mode."""
    mode = config.get("data_agent_mode", "shared")
    if mode not in ("shared", "isolated"):
        raise ValueError("data_agent_mode must be shared or isolated")
    ids = config.get("data_agent_ids")
    if ids is None:
        ids = {}
    if not isinstance(ids, dict):
        raise ValueError("data_agent_ids must be an object mapping scenario names to draft GUIDs")
    agent = ids.get(scenario)
    if agent is None or agent == "":
        agent = config.get("data_agent_id")
    candidates = [config.get("data_agent_id"), *ids.values()] if mode == "shared" else [agent]
    try:
        normalized = {str(UUID(str(agent))) for agent in candidates if agent is not None and agent != ""}
    except ValueError as error:
        raise ValueError("Configured Data Agent draft ID must be a GUID") from error
    if len(normalized) > 1:
        raise ValueError("Shared Data Agent mode requires one existing draft ID. Clear data_agent_id/data_agent_ids "
                         "for a fresh run, or set data_agent_mode to isolated for per-case diagnostic drafts.")
    return next(iter(normalized), None)


def prerequisites(config, selected, check_creation=True):
    problems = {}
    for name in sorted(selected):
        if name in MANUAL_SCENARIOS or unselected_source_reason(config, name):
            continue
        family = name.split(".")[0]
        errors = []
        if config.get("auth") == "browser":
            try:
                UUID(str(config.get("client_id", "")))
            except ValueError:
                errors.append("Browser auth requires an organization-approved client_id GUID")
        prefix = {"data-agent": "data_agent", "operations": "operations"}.get(family)
        if family == "p0":
            if name.split(".")[1] in ("topology", "resolution"):
                from validation_p0_sources import prerequisites as source_prerequisites
                errors.extend(source_prerequisites(config, name))
                if name.split(".")[1] == "resolution" and config.get("_explicit_ux_routing") is False:
                    errors.append("P0 live resolution requires both UX routing inputs explicitly supplied; "
                                  "a default origin inferred during config validation is not sufficient")
            else:
                from validation_p0_access import prerequisites as access_prerequisites
                errors.extend(access_prerequisites(config, name))
            if errors:
                problems[name] = errors
            continue
        if family == "preview":
            from validation_preview import settings
            from validation_common import ScenarioBlocked
            try:
                settings(config, name.partition(".")[2])
            except ScenarioBlocked as error:
                errors.append(str(error))
            if errors:
                problems[name] = errors
            continue
        if family == "mcp":
            # MCP uses the selected Fabric item endpoint, not a workload MWC route.
            if errors:
                problems[name] = errors
            continue
        if config.get("authoring_mode") == "public" and name != "ontology.definition":
            origin = config.get((prefix or "ux") + "_metadata_api") or config.get("ux_metadata_api")
            host = config.get((prefix or "ux") + "_workload_host") or config.get("ux_workload_host")
            if not origin or not host:
                errors.append("This agent scenario needs explicitly configured UX endpoints; ALM has no UX fallback")
        if prefix:
            try:
                workspace_routing(config, prefix)
            except ValueError as error:
                errors.append(f"Invalid workspace routing or {prefix}_metadata_api / "
                              f"{prefix}_workload_host override: {error}")
        elif config.get("authoring_mode") == "public" and name != "ontology.definition":
            try:
                workspace_routing(config, "ux")
            except ValueError as error:
                errors.append(f"This agent scenario needs explicitly configured UX routing; ALM has no UX fallback: {error}")
        if family == "operations":
            if config.get("ux_token_version", "v2") != "v2":
                errors.append("Operations Agent requires OA MWC v2 (ux_token_version v2); no v1 fallback")
            if check_creation and not config.get("allow_create"):
                errors.append("Operations authoring creates one fresh inactive artifact per run; "
                              "explicit -AllowCreate is required (no reuse across runs)")
            if config.get("scenario_timeout", 1800) <= config.get("operations_generation_timeout", 900):
                errors.append("scenario_timeout must exceed operations_generation_timeout for Operations authoring")
        if family == "data-agent":
            if config.get("ux_token_version", "v2") != "v2":
                errors.append("Data Agent requires ux_token_version v2")
            try:
                agent = data_agent_reference(config, name)
            except ValueError as error:
                errors.append(str(error))
            else:
                if not agent and check_creation and not config.get("allow_create"):
                    errors.append("No existing draft configured; run with -AllowCreate to authorize a new test draft")
        if family == "generation":
            from validation_generation import prerequisites as generation_prerequisites
            checked = config if check_creation else {**config, "allow_create": True}
            errors.extend(generation_prerequisites(checked, name))
        if errors:
            problems[name] = errors
    return problems


def import_sample_settings(config, manifest_path):
    saved = json.loads(Path(manifest_path).read_text(encoding="utf-8-sig"))
    if saved.get("environment") != "Daily" or saved.get("authoringMode") not in ("public", "ux", "hybrid"):
        raise ValueError("Use a Daily public/UX/hybrid run.manifest.json, not a source manifest")
    values = {
        "tenant_id": saved.get("tenantId"),
        "workspace_id": saved.get("targetWorkspaceId"),
        "ontology_id": saved.get("items", {}).get("Ontology", {}).get("id"),
    }
    for key, value in values.items():
        values[key] = str(UUID(str(value)))
        if config.get(key) and str(UUID(str(config[key]))) != values[key]:
            raise ValueError(f"Sample manifest conflicts with {key}; use a separate config file")
    values.update(
        target_network=saved.get("targetNetwork"),
        ux_metadata_api=saved.get("uxMetadataApi"),
        ux_workload_host=saved.get("uxExpectedWorkloadHost"),
        ux_token_version=saved.get("uxTokenVersion") or "v2",
    )
    if saved["authoringMode"] == "public":
        values["authoring_mode"] = "public"
    elif config.get("authoring_mode") == "public":
        values["authoring_mode"] = saved["authoringMode"]
    selected = normalize_source_types(saved.get("sourceTypes"))
    if "source_types" in config and normalize_source_types(config["source_types"]) != selected:
        raise ValueError("Sample manifest conflicts with source_types; use a separate config file")
    if "sourceTypes" in saved:
        values["source_types"] = list(selected)
    if saved.get("authentication") in ("cli", "browser"):
        values["auth"] = saved["authentication"]
    config.update(values)
    console("Imported target/workspace routing settings. A saved manifest does not prove its route still works.")
    if saved["authoringMode"] == "public":
        console("Imported ALM authoring mode; no UX route was inferred. Agent APIs require explicit UX configuration.")
    else:
        console("Data Agent and Operations share this route unless overridden; no source data or credentials were imported.")


def reuse_data_agents(config, results_path, selected):
    saved = json.loads(Path(results_path).read_text(encoding="utf-8-sig"))
    if not isinstance(saved, dict) or not isinstance(saved.get("config"), dict):
        raise ValueError("Reuse requires results.json with target configuration, not resources.json")
    for key in ("tenant_id", "workspace_id", "ontology_id"):
        if str(UUID(str(saved["config"].get(key)))) != str(UUID(str(config[key]))):
            raise ValueError(f"Prior results conflict with {key}; retained drafts were not imported")
    resources = saved.get("resources")
    drafts = resources.get("data_agents") if isinstance(resources, dict) else None
    if not isinstance(drafts, dict):
        raise ValueError("Prior results do not contain a retained data_agents mapping")
    imported = {name: str(UUID(str(agent))) for name, agent in drafts.items()
                if name in selected and name.startswith("data-agent.")}
    if not imported:
        raise ValueError("Prior results contain no retained drafts for the selected Data Agent scenarios")
    existing = config.get("data_agent_ids")
    if existing is None:
        existing = {}
    if not isinstance(existing, dict):
        raise ValueError("data_agent_ids must be an object mapping scenario names to draft GUIDs")
    merged = {**config, "data_agent_ids": {**existing, **imported}}
    for name in imported:
        data_agent_reference(merged, name)
    config["data_agent_ids"] = merged["data_agent_ids"]
    console(f"Reusing {len(set(imported.values()))} retained Data Agent draft(s); no export or configuration edits. "
            "Answer correctness determines functional coverage; source lineage is informational.")


def configure(path, selected, sample_manifest=None, input_fn=None):
    from validate_sample import validate_config

    ask = input_fn or input
    path = Path(path)
    original = path.read_bytes() if path.exists() else None
    value = json.loads(original.decode("utf-8-sig")) if original is not None else {}
    if not isinstance(value, dict):
        raise ValueError("Configuration must be a JSON object")
    if sample_manifest:
        import_sample_settings(value, sample_manifest)
    console("Offline configuration only: no login, network calls, provisioning or agent creation.")
    console("Use identifiers and observed service origins/hosts only; never paste tokens, headers or full responses.")

    def prompt(key, label, default=""):
        current = value.get(key) or default
        entered = ask(f"{label} [{current or 'blank = unconfigured'}]: ").strip()
        value[key] = entered or current

    for key, label in (("tenant_id", "Tenant ID"), ("workspace_id", "Target workspace ID"),
                       ("ontology_id", "Existing ontology ID")):
        prompt(key, label)
    prompt("target_network", "Network: wspl / tenantpl / public")
    prompt("auth", "Authentication: cli / browser", "cli")
    if value["auth"] == "browser":
        prompt("client_id", "Organization-approved public client application ID")
        UUID(str(value["client_id"]))
    families = {name.split(".")[0] for name in selected if name not in MANUAL_SCENARIOS}
    if families and families <= {"preview", "p0", "mcp"} and "authoring_mode" not in value:
        value["authoring_mode"] = "public"
    needs_resolution = any(name.startswith("p0.resolution.") for name in selected)
    if needs_resolution and value.get("authoring_mode", "public") == "public":
        prompt("authoring_mode", "Live resolution requires authoring mode ux / hybrid", "ux")
        if value["authoring_mode"] not in ("ux", "hybrid"):
            console("Live resolution remains BLOCKED until authoring_mode is ux or hybrid.")
    needs_workload = needs_resolution or any(
        name not in MANUAL_SCENARIOS and name != "ontology.definition"
        and name.split(".")[0] in ("ontology", "data-agent", "operations", "generation")
        for name in selected)
    if value.get("authoring_mode") == "public" and not needs_workload:
        console("Selected ALM/MCP/preview/backend checks need no UX authoring endpoints. "
                "Preview and P0 JSON settings are still required where applicable.")
    else:
        prompt("ux_token_version", "DO token version: v1 / v2", "v2")
        console("Workspace: use the working provisioning/UX MWC route. A tenant-wide origin is not automatically "
                "the correct route for a WSPL workspace.")
        prompt("ux_metadata_api", "Workspace metadata HTTPS origin (no path)")
        prompt("ux_workload_host", "Workspace TargetUriHost (hostname only)")
    families = {name.split(".")[0] for name in selected if name not in MANUAL_SCENARIOS}
    if "preview" in families:
        console("Preview needs explicit preview.execution (ONTOLOGY child Eventhouse, not source KQL database) "
                "and preview.sources settings in JSON; see validation.example.json and VALIDATION.md. "
                "No authoring route, refresh, automatic discovery or public fallback is used. "
                "Missing settings remain BLOCKED; the wizard never guesses preview routing.")
    if "p0" in families:
        console("P0 checks currently target individual Lakehouse/Eventhouse sources. Configure preview routes "
                "and p0_access in JSON; authorized / outside-network / source-denied contexts are separate runs. "
                "Prepare network and permissions externally; the script never changes them. "
                "Resolution requires explicit UX routes; Instances remains manual. "
                "Missing prerequisites remain BLOCKED.")
    if "operations.runtime" in selected:
        console(MANUAL_SCENARIOS["operations.runtime"])
    for family, prefix, label in (("data-agent", "data_agent", "ML / Data Agent"),
                                  ("operations", "operations", "OA / Operations Agent")):
        if family not in families:
            continue
        if value.get(prefix + "_metadata_api") or value.get(prefix + "_workload_host"):
            console(f"{label}: keeping existing service routing override; clear both {prefix}_metadata_api "
                    f"and {prefix}_workload_host in JSON to use the workspace route.")
        else:
            console(f"{label}: using workspace routing; no separate endpoint configuration needed.")
        if family == "data-agent":
            console(f"Data Agent mode: {value.get('data_agent_mode', 'shared')}. Shared mode creates one fresh "
                    "ontology-only draft per run with all entities selected; questions are independent. "
                    "Existing draft IDs explicitly opt into reuse; clear them for a fresh run.")
        if family == "operations":
            console("OA requires generatemwctokenv2. One fresh inactive artifact per run is shared by sequential "
                    "case-specific previews; no cross-run reuse, activation, monitoring, actions or notifications.")
    if "generation" in families:
        console("Generation supports individual populated Lakehouse or Eventhouse/KQL sources in the target "
                "workspace; live execution requires -AllowCreate and MWC v2.")
        if "generation.lifecycle" in selected:
            prompt("generation_lakehouse_id", "Generation Lakehouse item ID")
        if "generation.kql" in selected:
            prompt("generation_kql_database_id", "Generation KQL database item ID (not Eventhouse ID)")
        prompt("generation_source_workspace_id", "Generation source workspace ID", value["workspace_id"])
    # Validate without persisting runtime-only creation authorization or derived defaults.
    checked = validate_config(dict(value))
    value.pop("allow_create", None)
    issues = prerequisites(checked, selected, check_creation=False)
    for name, errors in issues.items():
        console(f"{name}: SETUP REQUIRED - {'; '.join(errors)}")
    if ask("Type SAVE to persist this configuration (does not run tests): ").strip() != "SAVE":
        raise ValueError("Configuration cancelled; no file changes")
    current = path.read_bytes() if path.exists() else None
    if current != original:
        raise ValueError("Configuration changed during setup; not overwritten")
    path.parent.mkdir(parents=True, exist_ok=True)
    if original is not None:
        backup = path.with_name(path.name + "." + uuid4().hex[:12] + ".bak")
        shutil.copy2(path, backup)
        console(f"Backup: {backup.resolve()}")
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(value, stream, indent=2)
            stream.write("\n")
        temporary.replace(path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    console(f"Configuration saved: {path.resolve()}")
    console("Next: run -PlanOnly with the same selectors and intended -AllowCreate to check prerequisites offline.")
    return int(bool(issues))
