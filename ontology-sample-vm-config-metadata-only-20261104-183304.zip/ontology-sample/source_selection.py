"""Canonical source selection shared by provisioning, authoring and recovery."""

SOURCE_TYPES = ("Eventhouse", "KQLDatabase", "Lakehouse", "MirroredDatabase",
                "SemanticModel", "SQLDatabase", "Warehouse")
GROUPS = ("Lakehouse", "MirroredDatabase", "SQLDatabase", "Warehouse", "SemanticModel", "KQLDatabase")
SQL_TYPES = ("Lakehouse", "MirroredDatabase", "SQLDatabase", "Warehouse")


def normalize_source_types(values=None):
    if values is None:
        return SOURCE_TYPES
    if (not isinstance(values, (list, tuple)) or not values
            or any(kind not in SOURCE_TYPES for kind in values) or len(set(values)) != len(values)):
        raise ValueError("Select unique supported source types (at least one)")
    selected = set(values)
    if selected & {"Eventhouse", "KQLDatabase"}:
        selected.update(("Eventhouse", "KQLDatabase"))
    return tuple(kind for kind in SOURCE_TYPES if kind in selected)


def manifest_source_types(state, requested=None):
    """Old manifests without selection metadata retain the all-source contract."""
    selected = normalize_source_types(state.get("sourceTypes", state.get("sources")))
    if "sources" in state and normalize_source_types(state["sources"]) != selected:
        raise ValueError("Source manifest selection fields disagree")
    if requested is not None and normalize_source_types(requested) != selected:
        raise ValueError("Source selection conflicts with the source manifest; do not replay provisioning")
    for field in ("items", "verified", "deferredValidation", "verifiedDefinitions"):
        if set(state.get(field, {})) - set(selected):
            raise ValueError(f"Source manifest {field} contains unselected source types")
    return selected


def source_groups(values=None):
    selected = normalize_source_types(values)
    return tuple(kind for kind in GROUPS if kind in selected)


def deferred_validation(values=None):
    return {"SemanticModel": ["refresh", "sampleRows"]} if "SemanticModel" in normalize_source_types(values) else {}


def expected_counts(values=None):
    selected = normalize_source_types(values)
    groups = len(source_groups(selected))
    return {"sourceItemTypes": len(selected), "sourceGroups": groups,
            "entities": 3 * groups, "relationships": 2 * groups}
