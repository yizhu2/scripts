import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


SHELL = shutil.which("powershell") or shutil.which("pwsh")


@unittest.skipUnless(SHELL, "PowerShell is required to exercise the VM discovery launcher")
class DiscoveryLauncherTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.script = self.root / "New-ValidationConfig.ps1"
        shutil.copy2(Path(__file__).with_name(self.script.name), self.script)
        self.capture = self.root / "arguments.json"
        (self.root / "discover_validation.py").write_text(
            "import json, sys\nfrom pathlib import Path\n"
            "Path(__file__).with_name('arguments.json').write_text(json.dumps(sys.argv[1:]))\n"
            "if '--execute' in sys.argv:\n"
            "    Path(sys.argv[sys.argv.index('--output-config') + 1]).write_text('{}')\n",
            encoding="utf-8")
        self.run = self.root / "run manifest.json"
        self.run.write_text("{}", encoding="utf-8")
        self.sources = self.root / "sources manifest.json"
        self.sources.write_text("{}", encoding="utf-8")
        self.output = self.root / "validation config.json"

    def launch(self, *arguments):
        return subprocess.run(
            [SHELL, "-NoProfile", "-NonInteractive", "-File", str(self.script),
             "-RunManifest", str(self.run), "-OutputConfig", str(self.output),
             "-PythonExecutable", sys.executable, *arguments],
            capture_output=True, text=True, timeout=60)

    def test_explicit_live_discovery_forwards_paths_without_splitting(self):
        result = self.launch("-SourcesManifest", str(self.sources), "-Auth", "cli", "-Timeout", "60")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        arguments = json.loads(self.capture.read_text())
        self.assertEqual(arguments[arguments.index("--run-manifest") + 1], str(self.run))
        self.assertEqual(arguments[arguments.index("--sources-manifest") + 1], str(self.sources))
        self.assertEqual(arguments[arguments.index("--output-config") + 1], str(self.output))
        self.assertEqual(arguments[arguments.index("--timeout") + 1], "60")
        self.assertIn("--execute", arguments)
        self.assertNotIn("--allow-create", arguments)
        self.assertNotIn("--client-id", arguments)

    def test_plan_never_requests_execution_or_changes_authentication(self):
        result = self.launch("-PlanOnly", "-NonInteractive")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        arguments = json.loads(self.capture.read_text())
        self.assertNotIn("--execute", arguments)
        self.assertNotIn("--auth", arguments)
        self.assertNotIn("--sources-manifest", arguments)
        self.assertIn("--non-interactive", arguments)
        self.assertFalse(self.output.exists())

    def test_existing_config_is_preserved_without_invoking_python_discovery(self):
        self.output.write_text("existing configuration", encoding="utf-8")
        result = self.launch()
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(self.capture.exists())
        self.assertEqual(self.output.read_text(), "existing configuration")

    def test_discovery_failure_is_not_reported_as_success(self):
        (self.root / "discover_validation.py").write_text("raise SystemExit(2)\n", encoding="utf-8")
        result = self.launch()
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn("Next: run Start-Validation", result.stdout)
        self.assertFalse(self.output.exists())

    def test_success_without_output_is_rejected(self):
        (self.root / "discover_validation.py").write_text("raise SystemExit(0)\n", encoding="utf-8")
        result = self.launch()
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn("Next: run Start-Validation", result.stdout)


if __name__ == "__main__":
    unittest.main()
