"""Read-only LH/EH topology and fresh service binding resolution (not ALM or preview).

Config reuses preview.execution and preview.sources.{lakehouse,kql}. Optional
p0_sources = {"topology": "same-workspace"}; the only other accepted value is
"cross-workspace-nonbaseline", which never certifies a BPA baseline.
Resolution additionally requires authoring_mode="ux" (or "hybrid"), and BOTH
ux_metadata_api and ux_workload_host explicitly supplied for every network mode.

Protocol: workload-digitaloperations e0c44d7a616bafac2bc7c3f6a6e70e8daa3db8b0,
OntologyDefinitionController.GetOntologyAsync -> OntologyDefinitionRepository ->
OntologyReadAnnotator -> OntologyBindingResolutionService -> OntologyBindingResolver.
refreshBindingResolution bypasses the response/binding caches; ONT_RESOLVED_* is
response-only, removed/recomputed by the service, not an authored identity claim.
This is a resolving read, not an invented /compute/resolve endpoint.

Instances are deliberately not registered. extension-ontology
538e27ecbfabdf3feb152e4c776484958c538e1a uses useFlaggedFederatedQuery and the V3
query service; the inspected GraphEngine consumes V2 mappings and explicitly
rejects Kusto EntityType queries. A V4 primary-backing-table Instances protocol
has not been established. Child-Eventhouse data preview is not that protocol.
"""

import re
from datetime import datetime, timedelta, timezone
from functools import partial
from uuid import UUID

from create_sample import sample_tables
from ux_authoring import routing
from validation_common import HttpFailure, InvalidResponse, ScenarioBlocked
from validation_preview import cluster_origin, settings

CASES = {"lakehouse": ("Lakehouse", "lakehouses", "Lakehouse"),
         "kql": ("KQLDatabase", "kqlDatabases", "EventhouseKQL")}
INSTANCES_BLOCKED = (
    "A supported V4 primary-backing-table Instances query protocol is required. "
    "The inspected V3 GraphEngine uses V2 mappings and rejects Kusto EntityType queries; "
    "the V4 Lakehouse bridge is not established. Preview is not an Instances check."
)
SERVICE_COMMIT = "e0c44d7a616bafac2bc7c3f6a6e70e8daa3db8b0"


def _id(value):
    try:
        result = UUID(str(value))
        if not result.int:
            raise ValueError()
        return str(result)
    except (ValueError, TypeError, AttributeError):
        raise InvalidResponse("Expected a nonempty GUID in service metadata") from None


def _same(actual, expected, label):
    if actual != expected:
        raise InvalidResponse(f"{label} differs from the explicitly configured/verified source")


def _configuration(config, case, resolve=False):
    _, source, _ = settings(config, case)
    options = config.get("p0_sources", {})
    if not isinstance(options, dict) or set(options) - {"topology"}:
        raise ScenarioBlocked("p0_sources accepts only topology; never supply query text or tokens")
    topology = options.get("topology", "same-workspace")
    if topology not in ("same-workspace", "cross-workspace-nonbaseline"):
        raise ScenarioBlocked("p0_sources.topology must be same-workspace or cross-workspace-nonbaseline")
    same = _id(source["workspace_id"]) == _id(config["workspace_id"])
    if same != (topology == "same-workspace"):
        raise ScenarioBlocked("Source workspace differs from p0_sources.topology; cross-workspace requires "
                              "explicit cross-workspace-nonbaseline, never BPA baseline certification")
    if resolve:
        if config.get("authoring_mode", "ux") not in ("ux", "hybrid"):
            raise ScenarioBlocked("Live resolution needs UX mode; an ALM-only definition is not live resolution")
        if not config.get("ux_metadata_api") or not config.get("ux_workload_host"):
            raise ScenarioBlocked("Live resolution requires explicit ux_metadata_api AND ux_workload_host; "
                                  "no inferred public UX route or ALM fallback")
        try:
            routing(config["target_network"], config["ux_metadata_api"], config["ux_workload_host"])
        except (ValueError, KeyError) as error:
            raise ScenarioBlocked(f"Invalid explicit UX resolution routing: {error}") from None
    return source, topology


def prerequisites(config, scenario):
    """Offline only: no credentials, metadata calls, source reads or changes."""
    try:
        parts = scenario.split(".")
        if len(parts) != 3 or parts[0] != "p0" or parts[2] not in CASES:
            raise ScenarioBlocked("Unknown P0 source scenario")
        if parts[1] == "instances":
            raise ScenarioBlocked(INSTANCES_BLOCKED)
        if parts[1] not in ("topology", "resolution"):
            raise ScenarioBlocked("Unknown P0 source scenario")
        _configuration(config, parts[2], parts[1] == "resolution")
        return []
    except (ScenarioBlocked, InvalidResponse, ValueError, TypeError, AttributeError) as error:
        return [str(error)]


def _object(value, label):
    if not isinstance(value, dict):
        raise InvalidResponse(f"{label} must be a JSON object")
    return value


def _read(ctx, path, label):
    value = ctx.request(ctx.fabric, "GET", f"{ctx.fabric.base}/{path}")
    ctx.save_evidence(label, value)
    return _object(value, label)


def _item(value, workspace, item_id, kind):
    _same(_id(value.get("id")), _id(item_id), "Source item ID")
    _same(value.get("type"), kind, "Source item type")
    # Fabric Get Item is workspace-scoped; not all versions echo workspaceId.
    if "workspaceId" in value:
        _same(_id(value["workspaceId"]), _id(workspace), "Source item workspace")
    if not isinstance(value.get("displayName"), str) or not value["displayName"]:
        raise InvalidResponse("Source item metadata omitted displayName")
    return value


def _topology(ctx, case):
    source, topology = _configuration(ctx.config, case)
    workspace, item_id = _id(source["workspace_id"]), _id(source["item_id"])
    kind, collection, _ = CASES[case]
    root = f"workspaces/{workspace}"
    metadata = _read(ctx, root, "source-workspace")
    _same(_id(metadata.get("id")), workspace, "Source workspace ID")
    item = _item(_read(ctx, root + f"/items/{item_id}", "source-item"), workspace, item_id, kind)
    detail = _item(_read(ctx, root + f"/{collection}/{item_id}", "source-details"),
                   workspace, item_id, kind)
    _same(detail["displayName"], item["displayName"], "Source display name across metadata reads")
    properties = _object(detail.get("properties"), "Source properties")
    checked = {"case": case, "source": source, "sourceType": kind, "sourceName": item["displayName"],
               "topology": topology, "sameWorkspaceBaseline": topology == "same-workspace",
               "workspaceVerification": "Workspace GET and workspace-scoped generic/typed item GETs",
               "bpaCertified": False, "networkEnforcementVerified": False, "browserUiTested": False,
               "executionTopologyVerified": False, "readOnly": True}
    if case == "lakehouse":
        endpoint = _object(properties.get("sqlEndpointProperties"), "Lakehouse SQL endpoint")
        if endpoint.get("provisioningStatus") != "Success":
            raise ScenarioBlocked("Lakehouse SQL analytics endpoint must be provisioned successfully")
        _same(str(endpoint.get("connectionString", "")).lower(), source["sql_endpoint"].lower(),
              "Lakehouse SQL endpoint")
        _same(item["displayName"], source["sql_database"], "Lakehouse SQL catalog")
        checked["sqlEndpointItemId"] = _id(endpoint.get("id"))
    else:
        try:
            _same(cluster_origin(properties.get("queryServiceUri")), cluster_origin(source["cluster_uri"]),
                  "KQL query service endpoint")
        except ValueError as error:
            raise InvalidResponse(f"Invalid KQL endpoint metadata: {error}") from None
        if source["database"] not in (item_id, item["displayName"]):
            raise InvalidResponse("KQL database must match the verified database ID or display name")
        parent_id = _id(properties.get("parentEventhouseItemId"))
        execution = ctx.config["preview"]["execution"]
        if parent_id == _id(execution["eventhouse_id"]):
            raise InvalidResponse("Source Eventhouse must not be the ontology child execution Eventhouse")
        parent = _read(ctx, root + f"/items/{parent_id}", "source-eventhouse")
        _item(parent, workspace, parent_id, "Eventhouse")
        checked["eventhouseId"] = parent_id
    ctx.save_evidence("topology", checked)
    return checked


def topology(ctx, case):
    missing = prerequisites(ctx.config, f"p0.topology.{case}")
    if missing:
        raise ScenarioBlocked("; ".join(missing))
    checked = _topology(ctx, case)
    return {"status": "PASS", "summary": f"{case} source metadata verified ({checked['topology']}); "
            "not BPA/network certification", "evidence": checked}


def _named(items, label):
    if not isinstance(items, list) or not all(isinstance(item, dict) for item in items):
        raise InvalidResponse(f"{label} must be an array of named objects")
    names = [item.get("name") for item in items]
    if any(not isinstance(name, str) or not name for name in names) or len(set(names)) != len(names):
        raise InvalidResponse(f"{label} contains missing or duplicate names")
    return dict(zip(names, items))


def _annotations(partition):
    annotations = _named(partition.get("annotations", []), "Partition annotations")
    result = {}
    for name, annotation in annotations.items():
        if name.upper().startswith("ONT_RESOLVED_"):
            key = name[len("ONT_RESOLVED_"):].lower()
            if key in result:
                raise InvalidResponse("Duplicate case-insensitive resolver annotations")
            result[key] = annotation.get("value")
    return result


def _resolved(annotation, source, checked, case, started):
    if annotation.get("state") and (annotation["state"] != "Resolved" or annotation.get("error")):
        raise InvalidResponse("Service reported unsuccessful binding resolution")
    required = {"state", "at", "workspaceid", "itemid", "itemkind", "connector", "contractversion"}
    required |= ({"sqlendpoint", "sqldatabase", "sqlendpointitemid"} if case == "lakehouse"
                 else {"kustoclusteruri", "kustodatabase"})
    if any(annotation.get(key) in (None, "") for key in required):
        raise ScenarioBlocked("Fresh service resolver annotations/connector coordinates are unavailable; "
                              "requires deployed resolving-read contract and enabled feature gates, not ALM annotations")
    if annotation["contractversion"] != "1":
        raise ScenarioBlocked("Unsupported service resolver annotation contract; requires version 1")
    try:
        at = datetime.fromisoformat(annotation["at"].replace("Z", "+00:00"))
        if at.tzinfo is None or not started - timedelta(minutes=5) <= at <= datetime.now(timezone.utc) + timedelta(minutes=5):
            raise ValueError()
    except (ValueError, TypeError, AttributeError):
        raise InvalidResponse("Resolver timestamp is missing, invalid or stale despite refreshBindingResolution") from None
    _same(_id(annotation["workspaceid"]), _id(source["workspace_id"]), "Resolved workspace")
    _same(_id(annotation["itemid"]), _id(source["item_id"]), "Resolved item")
    _same(annotation["itemkind"], checked["sourceType"], "Resolved item kind")
    if case == "lakehouse":
        _same(annotation["connector"], "AzureStorage.DataLake", "Resolved fixture connector")
        _same(str(annotation["sqlendpoint"]).lower(), source["sql_endpoint"].lower(), "Resolved SQL endpoint")
        _same(annotation["sqldatabase"], source["sql_database"], "Resolved SQL catalog")
        _same(_id(annotation["sqlendpointitemid"]), checked["sqlEndpointItemId"], "Resolved SQL endpoint item")
    else:
        _same(annotation["connector"], "AzureDataExplorer.Contents", "Resolved fixture connector")
        try:
            _same(cluster_origin(annotation["kustoclusteruri"]), cluster_origin(source["cluster_uri"]),
                  "Resolved KQL cluster")
        except ValueError as error:
            raise InvalidResponse(f"Invalid resolved KQL endpoint: {error}") from None
        if annotation["kustodatabase"] not in (_id(source["item_id"]), checked["sourceName"]):
            raise InvalidResponse("Resolved KQL database is not the verified database ID/name")


def _verify_definition(document, checked, case, started):
    model = _object(_object(document, "Resolved definition").get("model"), "Resolved model")
    entities = _named(model.get("entities"), "Entities")
    tables = _named(model.get("tables"), "Backing tables")
    source, prefix = checked["source"], CASES[case][2]
    expected_names = {f"{prefix}_{table.name}" for table in sample_tables()}
    _same({name for name in entities if name.startswith(prefix + "_")}, expected_names,
          "Selected source's three fixture entities")
    results = []
    for table in sample_tables():
        name = f"{prefix}_{table.name}"
        entity = entities[name]
        _same(entity.get("backingTable"), name, name + " primary backing table")
        backing = tables.get(name)
        if backing is None:
            raise InvalidResponse(f"{name} backing table is missing")
        _same(entity.get("keyProperties"), [table.columns[0][0]], name + " entity key")
        columns = _named(backing.get("columns"), name + " columns")
        properties = _named(entity.get("properties"), name + " properties")
        names = {column for column, _ in table.columns}
        _same(set(columns), names, name + " columns")
        _same(set(properties), names, name + " properties")
        for column in names:
            _same(columns[column].get("sourceColumn"), column, name + " source column")
            _same(properties[column].get("backingConfiguration"),
                  {"type": "default", "valueColumn": {"table": name, "column": column}},
                  name + " property backing")
        partitions = backing.get("partitions")
        if not isinstance(partitions, list) or len(partitions) != 1:
            raise InvalidResponse(f"{name} must have exactly one backing partition")
        partition = _object(partitions[0], name + " partition")
        binding = _object(partition.get("source"), name + " partition source")
        annotations = _annotations(partition)
        _resolved(annotations, source, checked, case, started)
        if case == "lakehouse":
            _same(binding.get("type"), "entity", name + " binding type")
            _same(binding.get("entityName"), table.name, name + " source table")
            _same(binding.get("schemaName") or "dbo", source["schema"] or "dbo", name + " source schema")
        else:
            _same(binding.get("type"), "m", name + " binding type")
            if "sourceitem" in annotations:
                _same(annotations["sourceitem"], table.name, name + " resolved source selector")
            expression = binding.get("expression")
            if isinstance(expression, list) and all(isinstance(line, str) for line in expression):
                expression = "\n".join(expression)
            # Only the fixture's literal M table query is understood; do not infer a table from arbitrary M/KQL.
            literal = r'"((?:[^"]|"")*)"'
            match = re.fullmatch(r"\s*let\s+Source\s*=\s*AzureDataExplorer\.Contents\(\s*" + literal
                                + r"\s*,\s*" + literal + r"\s*,\s*" + literal
                                + r"\s*\)\s*in\s+Source\s*", expression or "")
            if not match:
                raise ScenarioBlocked("Unsupported KQL backing expression; requires the canonical literal fixture table query")
            cluster, database, query = [value.replace('""', '"') for value in match.groups()]
            _same(cluster.rstrip("/").lower(), source["cluster_uri"].rstrip("/").lower(), name + " M cluster")
            if database not in (_id(source["item_id"]), checked["sourceName"]):
                raise InvalidResponse(name + " M database differs from verified source")
            _same(query, table.name, name + " M table query")
        results.append({"entity": name, "backingTable": name, "sourceTable": table.name,
                        "resolved": annotations})
    return results


def resolution(ctx, case):
    missing = prerequisites(ctx.config, f"p0.resolution.{case}")
    if missing:
        raise ScenarioBlocked("; ".join(missing))
    checked = _topology(ctx, case)
    with ctx.workload() as api:
        path = (f"{api.base}/v4/workspaces/{ctx.config['workspace_id']}"
                f"/ontologies/{ctx.config['ontology_id']}/definition")
        params = {"expand": "true", "refreshBindingResolution": "true"}
        ctx.save_evidence("resolution-request", {"method": "GET", "url": path, "params": params,
                                               "serviceReferenceCommit": SERVICE_COMMIT})
        started = datetime.now(timezone.utc)
        try:
            document = ctx.request(api, "GET", path, params=params)
        except HttpFailure as error:
            if error.status in (400, 404, 405, 501):
                raise ScenarioBlocked("Resolving-read endpoint/expand feature unavailable; requires deployed "
                                      "UX resolving-read support; inspect HTTP evidence, no ALM fallback") from error
            raise
    ctx.save_evidence("resolved-definition", document)
    entities = _verify_definition(document, checked, case, started)
    evidence = {"topology": checked, "entities": entities, "resolution": "Fresh service resolving read",
                "serviceReferenceCommit": SERVICE_COMMIT, "dataRecordsVerified": False,
                "browserUiTested": False, "bpaCertified": False, "readOnly": True}
    ctx.save_evidence("resolution", evidence)
    return {"status": "PASS", "summary": f"{case}: 3 entities' fresh source identities/endpoints verified; "
            "not Instances/data-preview/BPA certification", "evidence": evidence}


SCENARIOS = {f"p0.{name}.{case}": partial(operation, case=case)
             for name, operation in (("topology", topology), ("resolution", resolution)) for case in CASES}
