"""Daily Fabric API routing for the target ontology and opt-in shared source workspace."""

import re
from urllib.parse import urlsplit
from uuid import UUID

from create_sample import Api, https_url

DAILY_FABRIC_API = "https://dailyapi.fabric.microsoft.com/v1"
DAILY_ONELAKE_DFS = "https://daily-onelake.dfs.fabric.microsoft.com"


def target_fabric_api(network, workspace_id, tenant_id):
    workspace = UUID(workspace_id).hex
    tenant = UUID(tenant_id).hex
    if network == "public":
        return DAILY_FABRIC_API
    if network == "wspl":
        return f"https://{workspace}.z{workspace[:2]}.w.dailyapi.fabric.microsoft.com/v1"
    if network == "tenantpl":
        return f"https://{tenant}-api.analysis.windows.net/v1"
    raise ValueError("Target network must be public, wspl, or tenantpl")


def source_onelake_url(network, workspace_id):
    workspace = UUID(workspace_id).hex
    if network == "wspl":
        return f"https://{workspace}.z{workspace[:2]}.daily-dfs.fabric.microsoft.com"
    if network in ("public", "tenantpl"):
        return DAILY_ONELAKE_DFS
    raise ValueError("Source network must be public, wspl, or tenantpl")


class TargetApi(Api):
    def operation_url(self, location):
        # Fabric may advertise canonical LRO links. Keep their operation path on the selected route.
        parsed = urlsplit(https_url(location)) if location.startswith("https://") else None
        if (parsed and self.base != DAILY_FABRIC_API
                and parsed.netloc.lower() == "dailyapi.fabric.microsoft.com"
                and re.fullmatch(r"/v1/operations/[0-9a-fA-F-]{36}(?:/result)?", parsed.path)):
            UUID(parsed.path.split("/")[3])
            return self.base + parsed.path[len("/v1"):]
        return super().operation_url(location)


def validate_same_workspace_manifest(state, workspace_id, tenant_id, network):
    """Require explicit topology provenance, not just coincidentally equal workspace IDs."""
    expected = target_fabric_api(network, workspace_id, tenant_id)
    if (state.get("sameWorkspace") is not True
            or state.get("targetNetwork") != network
            or str(UUID(state["workspaceId"])) != str(UUID(workspace_id))
            or str(UUID(state["existingWorkspaceId"])) != str(UUID(workspace_id))
            or str(UUID(state["tenantId"])) != str(UUID(tenant_id))
            or state["endpoints"]["fabric"] != expected):
        raise ValueError("Same-workspace sources require matching workspace, tenant, network and explicit "
                         "sameWorkspace manifest provenance; separate-workspace manifests are not accepted")
