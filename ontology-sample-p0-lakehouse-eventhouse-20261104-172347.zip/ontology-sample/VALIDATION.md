# Standalone agent and UX backend preview validation on Daily / Private Link

Use [Start-Validation.ps1](Start-Validation.ps1) **after provisioning**, including when
[Start-Sample.ps1](Start-Sample.ps1) stopped at a resolver/readback check but retained
an ontology. This runner does not call the provisioning workflow or require its
final verification to pass. It never needs a coding assistant, Azure DevOps,
Kusto investigation access, or a local backend.

**This is a functional test runner, not automatic Private Link certification.**
It records missing network/identity acceptance checks explicitly. An answer or
HTTP 200 is not proof of actual source reads or enforced private connectivity.
**ALM import/export tests are excluded for every agent.** Existing Data Agents
are queried without `getDefinition` or a replacement configuration-read gate.
Operations native playbook generation is tested only as **inactive authoring**;
runtime is explicitly SKIP, not substituted with an ALM import or execution test.
The separate `ontology.definition` probe can use ALM read-back when importing an
ALM/public provisioning manifest; this does not add ALM gates to agent tests.

### Lakehouse + Eventhouse inventories and ALM-only verification

Provisioning with `-SourceTypes Lakehouse,Eventhouse -AuthoringMode public`
requires no UX endpoints. The simplest exact persisted-binding verification
remains `Start-Sample.ps1 -SameWorkspace -TargetNetwork wspl -AuthoringMode public
-SourcesManifest ... -VerifyOnly -OntologyId ... -OntologyName ...` plus tenant/workspace
IDs. It inherits the selected sources and compares all 6 entities / 4 relationships.
Use `tenantpl` instead of `wspl` for tenant-private routing.

The validation wizard also accepts the resulting **run** manifest:

```powershell
.\Start-Validation.ps1 -Config .\validation.selected.json -Configure `
    -Scenarios ontology.definition -SampleManifest .\runs\YOUR_RUN\run.manifest.json
.\Start-Validation.ps1 -Config .\validation.selected.json -Scenarios ontology.definition
```

This imports `authoring_mode: public` and `source_types`, skips UX endpoint
prompts, and reads the ontology through routed Fabric `getDefinition`, never UX.
That standalone probe checks the response model, not exact source bindings or
live resolver/data-query health; use the provisioning `-VerifyOnly` comparison
above for exact bindings.
Agent scenarios still use their own APIs and require explicitly configured UX
routes: they are blocked when absent, without guessed endpoints or ALM/UX fallback.
Scenarios requiring unselected groups (such as `semantic`, `warehouse`, or
`sm-lakehouse`) are **SKIP**, not failures; no unwanted source is queried or provisioned.
Supported two-group query cases are `lakehouse`, `kql`, and `lakehouse-kql`.
Selection metadata is retained through config import; conflicting selections are rejected.

## Read-only UX data previews: every fixture source

**New dedicated coverage; live runs have not been performed as part of implementation.**
Agent/MCP fixture answers and Operations playbook generation do **not** establish
`sql_request` or UX binding data-preview success. Select `-Agents preview` to replay
the UX **backend protocol**, separately from those agent tests. This is not a full
browser UI test, binding-resolution test or BPA enforcement certification.

| Scenario | Source read from the ontology's child Eventhouse | Tables checked |
|---|---|---|
| `preview.lakehouse` | `evaluate sql_request(...)` to Lakehouse SQL analytics endpoint | Plants / Assets / Readings |
| `preview.warehouse` | `evaluate sql_request(...)` to Warehouse | Plants / Assets / Readings |
| `preview.sql` | `evaluate sql_request(...)` to SQLDatabase | Plants / Assets / Readings |
| `preview.mirror` | `evaluate sql_request(...)` to MirroredDatabase SQL analytics endpoint | Plants / Assets / Readings |
| `preview.kql` | Native `cluster(...).database(...).table(...)` cross-cluster KQL | Plants / Assets / Readings |
| `preview.semantic` | `evaluate dax_request(...;Impersonate, ...)` | Plants / Assets / Readings |

### Configure the execution context, not a source substitute

Use the `preview` object in [validation.example.json](validation.example.json).
For an ALM-only config set `"authoring_mode": "public"` and omit
`ux_metadata_api` / `ux_workload_host`: these tests do not acquire a workload MWC
token and never prompt for UX authoring endpoints. The offline preview-only
wizard defaults a new config to this mode; it explains missing preview settings
instead of guessing or silently running another route.

1. Copy the **ontology child** Eventhouse origin and KQL database ID from the
   working UX data-preview request (Developer Tools Network, `/v2/rest/query`).
   `preview.execution.database_id` is its JSON `db`, not a source database name.
   Record the associated child Eventhouse item ID from
   `extendedProperties.ChildItems.OntologyEventhouse`, and verify its
   cascade-delete child KQL database relation. The frontend resolves exactly
   these values; the execution database is **not** assumed to be `ontology_kustodb`.
2. Set execution `workspace_id` / `ontology_id` to the target, and
   `provenance` to `ontology-child-eventhouse` only after this check. These are
   **operator-configured observations**, not independently verified metadata.
   Wrong target IDs, missing settings and direct reuse of the source database
   identity are blocked. The runner cannot prove that a pasted cluster belongs
   to an ontology, or that a catalog belongs to the pasted item ID.
3. Configure each selected source under `preview.sources` using **its own**
   workspace/item ID and observed endpoint/catalog:
   - SQL: bare `sql_endpoint` hostname (no `tcp:`, port or connection string),
     `sql_database` catalog, and `schema` (`"dbo"` or `""` for the UX unqualified table).
     SQLDatabase uses its database name, not necessarily its display name.
   - KQL: source KQL database item ID, source cluster origin and actual database
     name. It is federated **from the ontology child gateway**, never queried
     directly as a replacement for that gateway.
   - Semantic: semantic-model item ID and explicit
     `api_host: "https://dailyapi.powerbi.com"` for this Daily sample harness.
     No generic Power BI `executeQueries`, ODBC, model refresh or direct dataset
     API is used as substitute preview coverage.
4. Preserve intended DNS and routing. The selected `target_network` records
   topology; it does not rewrite a Kusto cluster into a guessed private hostname.
   Keep the canonical observed cluster origin resolving over the intended private
   route. Only HTTPS bare Kusto service origins and allowlisted SQL hosts are
   accepted; redirects, automatic public fallback and endpoint substitution are
   prohibited. Verify WSPL/TPL/BPA separately. The semantic plugin host is the
   exact frontend Daily host, not an automatic fallback from a private route.

The manifest import supplies target IDs and source selection, **not** execution
child metadata or source preview routes. Supply only selected source records;
missing records for selected sources are **BLOCKED**. With
`source_types: ["Lakehouse", "Eventhouse"]`, the other four previews are intentional
**SKIP**. Missing/unmaterialized semantic rows or plugin failures are non-passing;
the runner never refreshes or populates a model to make a test pass.

```powershell
# Optional offline skeleton/import; edit the documented preview object afterwards.
.\Start-Validation.ps1 -Config .\validation.preview.json -Agents preview -Configure `
    -SampleManifest .\runs\YOUR_RUN\run.manifest.json

# No authentication/network calls during planning.
.\Start-Validation.ps1 -Config .\validation.preview.json -Agents preview -PlanOnly `
    -OutputDirectory .\runs\preview_plan

# Explicit live read-only run; do NOT add -AllowCreate.
.\Start-Validation.ps1 -Config .\validation.preview.json -Agents preview `
    -Strict -OutputDirectory ".\runs\preview_$(Get-Date -Format 'yyyyMMdd-HHmmss')"

# Only the Lakehouse and Eventhouse/KQL previews.
.\Start-Validation.ps1 -Config .\validation.preview.json `
    -Scenarios preview.lakehouse,preview.kql `
    -Strict -OutputDirectory ".\runs\preview_lh_kql_$(Get-Date -Format 'yyyyMMdd-HHmmss')"
```

The approved CLI/browser credential requests only
`https://kusto.kusto.windows.net/.default` for preview POSTs. SQL uses
`Active Directory Integrated`; semantic uses `;Impersonate` (no embedded token).
Each table sends `{"db": "<child database>", "csl": "<fixed bounded query>",
"properties": null}` to `<child cluster>/v2/rest/query`, with an
`Ontology;<uuid>` client request ID. Queries select fixed fixture columns, cap
source SQL/DAX and final KQL at 1000, and compare **all 3 / 12 / 120 rows** plus
column names/types against canonical fixtures, ignoring row order and normalizing
known-UTC timestamps. Errors, duplicate/missing/wrong rows, incomplete frames,
HTTP-200 Kusto partial errors, cancellation, and status warnings are not PASS.
Failing tables/sources retain individual errors while other independent reads continue.

The report has a separate preview section and per-source/table request/response
JSON, with configured source vs ontology workspace/item IDs, exact selected
route, UTC, client/server correlation, response status and sanitized raw
responses. Access tokens (including nested KQL token directives and opaque
credential echoes) are scrubbed; never paste tokens, HARs or arbitrary queries
into config. Review evidence before sharing because it contains sample rows and
resource identifiers. No provisioning, source mutation, activation, policy change,
refresh, monitoring, definition read or UX authoring call is made by this family.

### Protocol source of truth

Implementation was checked against `Trident/extension-ontology` **main at
`3c3fb3f49a8752c18060b5cf44a582ff05aa98bc`**, not inferred from agent answers:

- [childEventhouseQueryRepository.ts](https://dev.azure.com/powerbi/Trident/_git/extension-ontology?path=/src/tmsl/data/repositories/childEventhouseQueryRepository.ts&version=GC3c3fb3f49a8752c18060b5cf44a582ff05aa98bc):
  child Eventhouse / cascade-delete database resolution and all-source preview calls.
- [federatedKqlBuilder.ts](https://dev.azure.com/powerbi/Trident/_git/extension-ontology?path=/src/tmsl/data/utils/builders/federatedKqlBuilder.ts&version=GC3c3fb3f49a8752c18060b5cf44a582ff05aa98bc):
  relational SQL plugin, native KQL callout, DAX `TOPN` / `SELECTCOLUMNS`,
  bracketed DAX-column rename and final projection/take.
- [tsql.ts](https://dev.azure.com/powerbi/Trident/_git/extension-ontology?path=/src/tmsl/data/utils/builders/tsql.ts&version=GC3c3fb3f49a8752c18060b5cf44a582ff05aa98bc)
  and [kusto.ts](https://dev.azure.com/powerbi/Trident/_git/extension-ontology?path=/src/tmsl/data/utils/builders/kusto.ts&version=GC3c3fb3f49a8752c18060b5cf44a582ff05aa98bc):
  connection-string and identifier escaping.
- [eventHouseService/index.ts](https://dev.azure.com/powerbi/Trident/_git/extension-ontology?path=/src/tmsl/data/services/eventHouseService/index.ts&version=GC3c3fb3f49a8752c18060b5cf44a582ff05aa98bc)
  and [clusterUri.ts](https://dev.azure.com/powerbi/Trident/_git/extension-ontology?path=/src/tmsl/data/utils/query/clusterUri.ts&version=GC3c3fb3f49a8752c18060b5cf44a582ff05aa98bc):
  POST body, v2 route, request headers and partial-result error contract.
- [semanticModelResourceScopeHelper.ts](https://dev.azure.com/powerbi/Trident/_git/extension-ontology?path=/src/tmsl/data/utils/helpers/semanticModelResourceScopeHelper.ts&version=GC3c3fb3f49a8752c18060b5cf44a582ff05aa98bc):
  explicit Daily Power BI host; no guessed public fallback.

`dax_request` may report a downstream
`/groups/{workspaceId}/datasets/{datasetId}/executeDaxQueries` failure in backend
diagnostics. The actual current UX **client** query uses
`https://dailyapi.powerbi.com/v1.0/myorg/datasets/{datasetId};Impersonate`;
the runner reproduces that plugin connection, not a direct HTTP dataset request.
The previously observed TPL `KustoSqlRequestForbiddenException` remains historical
manual evidence; new tests do not retroactively change any matrix verdict.

## P0: individual Lakehouse and Eventhouse access checks

These checks are deliberately limited to **individual Lakehouse and Eventhouse/KQL**
in the **same workspace as the ontology**. They do not add mixed-source or other-source
acceptance claims. Existing `preview.lakehouse` and `preview.kql` remain unchanged.

Use explicit families in selectors. Broad patterns such as `*.lakehouse` / `*.kql`
also match the new P0 checks, whose positive and negative contexts cannot run
together. `-Agents p0 -PlanOnly` inventories prerequisites; it is not a single
all-context live run. Keep `source_types: ["Lakehouse", "Eventhouse"]` in the
two-source config so unrelated source scenarios remain intentionally skipped.

| Scenario family (suffix `.lakehouse` or `.kql`) | Required result |
|---|---|
| `p0.topology` | Fabric source metadata agrees with the configured workspace, item type and source endpoint/catalog; same-workspace baseline by default |
| `p0.resolution` | A fresh server resolving read matches all three fixture entities to source metadata; authored annotations alone cannot pass |
| `p0.access-baseline` | Authenticated ontology-item GET, successful child-Eventhouse `print` control, and exact schema/all rows from all three fixture tables |
| `p0.network-denied` | Same principal and exact routes/source as the saved successful baseline; ontology-item GET, child-Eventhouse control and all three source reads explicitly denied by network policy |
| `p0.source-denied` | Matching successful baseline; current principal can read ontology-item metadata and run the child-Eventhouse control, but every source-table read is rejected for authorization, with no returned rows |

These are **read-only backend probes**, not browser, Ontology Agent, Data Agent or
MCP denial tests. A successful metadata GET does not prove access to every ontology
operation. The script does not change BPA, source permissions, DNS, policy or data,
and does not switch accounts. Prepare the required network/identity context outside
the runner. Record actual BPA settings and the principal's intended permissions in
your test record; those settings are not independently certified by these probes.

### Source topology and live resolution

Both checks reuse `preview.execution` and the selected `preview.sources` record.
`p0_sources` is optional; its `topology` defaults to `"same-workspace"`.
An explicitly configured `"cross-workspace-nonbaseline"` topology is diagnostic
coverage only, not a pass of the required same-workspace baseline. Access probes
below still require same-workspace sources.

```powershell
# Source metadata only; no UX authoring route is required.
.\Start-Validation.ps1 -Config .\validation.preview.json `
    -Scenarios p0.topology.lakehouse,p0.topology.kql `
    -Strict -OutputDirectory .\runs\p0-topology

# Requires UX/hybrid mode and BOTH explicit UX routing inputs.
.\Start-Validation.ps1 -Config .\validation.p0-resolver.json `
    -Scenarios p0.resolution.lakehouse,p0.resolution.kql `
    -Strict -OutputDirectory .\runs\p0-resolution
```

For resolution, use `"authoring_mode": "ux"` (or `"hybrid"`), explicit
`ux_metadata_api` and `ux_workload_host`, and the approved working workspace route.
The check requests `/v4/workspaces/{workspace}/ontologies/{ontology}/definition`
with `expand=true&refreshBindingResolution=true` and verifies the returned resolved
source fields against actual Fabric metadata. The service performs binding
resolution on this read; this is not an ALM `getDefinition` readback or a browser
binding-edit/save test. A default origin inferred during configuration normalization
does not qualify as an explicitly supplied resolver route.

If you do not want to supply UX routes, run topology, preview and access checks
in ALM mode; live resolution stays **BLOCKED**, with no fallback.
No Instances scenario is registered: a supported current primary-backing-table
enumeration protocol has not been established. The inspected older V3 query path
rejects Kusto EntityType queries; it is not substituted or relabeled as coverage.

### Authorized baseline

Use the preview configuration documented above, with both source workspace IDs
equal to the target workspace, and `target_network` set to `wspl` or `tenantpl`.
For these access checks `"authoring_mode": "public"` needs no UX authoring endpoints.
Add this to the existing config:

```json
"p0_access": {
  "context": "authorized",
  "baseline_results": ""
}
```

```powershell
.\Start-Validation.ps1 -Config .\validation.p0-authorized.json `
    -Scenarios 'p0.access-baseline.*' -PlanOnly -OutputDirectory .\runs\p0-plan

# From the approved network, with an identity authorized for ontology and sources.
.\Start-Validation.ps1 -Config .\validation.p0-authorized.json `
    -Scenarios 'p0.access-baseline.*' -Strict -OutputDirectory .\runs\p0-authorized
```

Both baselines must PASS before using their results for negative tests. The baseline
records tenant/object identity claims, controls, exact routing and all-table checks.
Claims are recorded for comparison, not independently signature-validated by this
script; successful service responses establish that the credential was accepted.
Tokens are kept only in memory and scrubbed from evidence. Use fresh baselines after
source, routing or authorization changes; evidence files are operator-managed, not
tamper-proof attestations.

### Outside-network run

Copy the config and baseline evidence to the intended **outside-network** test host.
Preserve the same principal, workspace, ontology, source and endpoint settings.
Change only the access context and baseline file location:

```json
"p0_access": {
  "context": "outside-network",
  "baseline_results": ".\\runs\\p0-authorized\\results.json"
}
```

```powershell
.\Start-Validation.ps1 -Config .\validation.p0-outside.json `
    -Scenarios 'p0.network-denied.*' -Strict -OutputDirectory .\runs\p0-outside
```

Paths are relative to the shell's current directory unless absolute. Do not select
baseline and negative scenarios together: they require different contexts. A selected
scenario with the wrong context is BLOCKED before authentication.

Only explicit `DeniedByPolicy` or recognized Private Link rejection messages qualify.
A generic 403, HTTP 401, DNS/connection failure or timeout does **not** prove policy
enforcement; it remains non-passing for investigation. Successful protected reads,
including partial rows returned with an error, FAIL. No retries or alternate routes
are used. Whether the test host is actually outside the approved network remains
an operator-verified prerequisite.

### Source-denied run

From the approved network, use an externally prepared identity that can access the
ontology and its child query gateway but lacks the selected source's read permission.
Alternatively, remove source access externally from the baseline identity while
retaining those controls. Do not revoke access as part of this script.

Set `p0_access.context` to `"source-denied"` and `baseline_results` to the authorized
results file. Source-denied runs may use a different principal; outside-network runs
must use the baseline principal. If Fabric's permission model cannot isolate source
access from the required controls for this fixture, the scenario remains BLOCKED.

```powershell
.\Start-Validation.ps1 -Config .\validation.p0-source-denied.json `
    -Scenarios 'p0.source-denied.*' -Strict -OutputDirectory .\runs\p0-source-denied
```

Positive ontology/gateway controls are mandatory. Network-policy failures do not count
as source-permission enforcement. Known structured authorization errors may arrive as
HTTP 403 or HTTP-200 partial-error payloads; neither may contain source rows.
Unsupported-plugin errors, unclassified denials and authentication failures are not PASS.

**Remaining P0 manual checks:** catalog/browser selection, binding edits and
save/reopen, Instances grid rendering, BPA/private-route configuration, and
agent/MCP/browser-specific denial behavior. These results cannot be inferred from
backend preview or access-control PASS. Generation is a separate, explicitly
creation-authorized lifecycle check. Live P0 outcomes remain Not Run until executed.

## 1. Prepare once

Use the existing sample Python environment (Python 3.10+ and
[requirements.txt](requirements.txt)); the launcher finds `.venv\Scripts\python.exe`
next to it. Otherwise supply `-PythonExecutable`. No automatic package download,
system installation, or login fallback occurs. If packages are missing, install
them from your approved source before entering the restricted network.
`-InstallDependencies` explicitly permits pip to install the existing requirements.

Use the offline configuration wizard instead of editing JSON or running inline Python:

```powershell
# New or existing config; configure the workspace route once for all agents.
.\Start-Validation.ps1 -Config .\validation.local.json `
  -Agents ontology,mcp,data-agent,generation,operations -Configure

# Optional: explicitly reuse target IDs and DO routing from a provisioning run.
# This is a run.manifest.json, NOT sources.manifest.json.
.\Start-Validation.ps1 -Config .\validation.local.json `
  -Agents data-agent -Configure `
  -SampleManifest .\runs\YOUR_PROVISIONING_RUN\run.manifest.json
```

`-Configure` makes no network calls, authenticates nobody and creates no Fabric
items. It preserves unrelated settings/draft IDs, requires typing `SAVE`, and backs
up an existing config before replacing it. Conflicting manifest target IDs are
rejected: use a separate config for a different workspace. Importing a saved run
does not prove that run succeeded or its route still works. Only target/workspace settings
and source selection are imported, never tokens or source data. For UX/hybrid runs the
imported workspace route is shared by ML/OA; ALM-only runs do not supply one.

Enter the tenant, target workspace and **existing ontology** IDs, not the source
workspace IDs. Configuration contains identifiers/routes, never tokens. You can
also use [validation.example.json](validation.example.json) as a manual template.
Setup exits 0 when saved with complete static settings, 1 when saved with missing
scenario prerequisites, and 2 when cancelled/invalid. Resource creation remains
disabled until a separate execution explicitly passes `-AllowCreate`.

**One workspace route is shared by default across Ontology, Data Agent and Operations.**
Existing `ux_metadata_api` and `ux_workload_host` values are sufficient; no separate
ML/OA endpoint prompts or browser capture are required. This applies in public,
WSPL and tenant-private modes. Each workload still acquires its own artifact-scoped
token (ML/OA require v2) and validates the returned host before using it. A mismatch
stops that scenario; it never triggers a public fallback.

Existing paired `data_agent_*` or `operations_*` routing overrides remain supported
and are preserved by the wizard, without additional prompts. To inherit the workspace
route, remove or clear both fields of that pair. In private mode an incomplete
override is rejected; public mode retains its per-field fallback for compatibility.
Invalid routes are reported explicitly rather than silently ignored. Never copy tokens, cookies,
authorization headers or a full HAR into configuration.

If a blank UI draft was used to observe routing, do not set it as `data_agent_id`;
validation drafts need the exact ontology attachment and entity selection. The
normal runner creates one shared draft with `-AllowCreate`; no bootstrap Python is needed.

| Setting | Meaning |
|---|---|
| `target_network` | Explicit `wspl`, `tenantpl`, or `public` (normal Daily only) |
| `authoring_mode` | `public` enables ALM-only `ontology.definition` without UX configuration; other scenarios still require their explicit routes |
| `source_types` | Canonical selected inventory imported from the run manifest; scenarios requiring absent groups are skipped. Omit for legacy/all-source configs |
| `ux_metadata_api` | Workspace HTTPS metadata **origin**, shared by all agents by default |
| `ux_workload_host` | Workspace expected `TargetUriHost`, hostname only; checked for each workload |
| `auth` | `cli` uses the existing Azure CLI identity/cache only; `browser` uses an explicitly approved client |
| `client_id` | Required approved public-client application ID when using browser authentication |
| `ux_token_version` | `v2` required for ML/OA scenarios; DO-only checks may use `v1` |
| `timeout` | HTTP/operation/conversation budget in seconds, default 240 |
| `scenario_timeout` | Overall scenario budget, default 1800; must be at least `timeout` |
| `operations_generation_timeout` | Native preview-generation budget, default 900; integer 30–3600 seconds. Selected Operations authoring cases require `scenario_timeout` strictly greater than this; unrelated checks are not blocked by that relationship |
| `poll_seconds` | Poll interval, default 5 |
| `generation_lakehouse_id` | Existing Lakehouse containing Plants/Assets/Readings for generation |
| `generation_kql_database_id` | Existing populated KQL database item ID for `generation.kql`, not the containing Eventhouse ID |
| `generation_source_workspace_id` | Workspace containing the selected generation source; defaults to and must equal the target workspace |
| `data_agent_metadata_api`, `data_agent_workload_host` | Optional paired ML route override; omit both to use workspace routing |
| `data_agent_mode` | `shared` (default): one fresh ontology-only draft per run with all entities selected. `isolated`: opt-in per-case diagnostic drafts selecting only that question's entities |
| `data_agent_id` | Explicit opt-in to reuse one existing ontology-backed draft as-is, instead of creating a fresh one |
| `data_agent_ids` | Optional scenario-to-draft GUID mapping. Shared mode accepts only one unique ID across this mapping and `data_agent_id`, reused for every question. Isolated mode allows distinct IDs, overriding `data_agent_id` per scenario |
| `operations_metadata_api`, `operations_workload_host` | Optional paired OA route override; omit both to use workspace routing |

Never paste a token, authorization header, or full captured request into this file.
Invalid agent routing overrides block only their scenarios, not other agents.
Before authentication, the runner lists missing selected-scenario prerequisites
and includes them in the report. If all selected scenarios are blocked, it does
not authenticate. `-PlanOnly` performs the same offline checks, including explicit
creation authorization; it is not just a scenario list and does not verify connectivity.

```powershell
# Inspect all static prerequisites before starting a long run.
.\Start-Validation.ps1 -Config .\validation.local.json `
  -Agents ontology,mcp,data-agent,generation,operations -AllowCreate -PlanOnly

# With no data_agent_id/data_agent_ids, create one fresh draft and ask all ten questions.
.\Start-Validation.ps1 -Config .\validation.local.json `
  -Agents data-agent -AllowCreate
```

For an MWC 403, first compare DO routing with the working provisioning/UX request.
In particular, a tenant-wide metadata origin may be wrong for a WSPL workspace
whose working request uses its workspace-specific origin. Preserve CLI/browser
identity and token version unless evidence requires a change. Do not silently
switch endpoints, clients, or private-network policies to obtain success.

If an older run created drafts and then failed `getDefinition`, leave those
artifacts untouched. That export failure does not establish a query failure,
and the functional runner no longer calls that API. You may explicitly reuse
them instead of creating a fresh draft. For an older run containing multiple
per-source drafts, first set `"data_agent_mode": "isolated"` in the local config:

```powershell
.\Start-Validation.ps1 -Config .\validation.local.json `
  -Agents data-agent -ReuseResults .\runs\YOUR_FAILED_RUN\results.json -PlanOnly

.\Start-Validation.ps1 -Config .\validation.local.json `
  -Agents data-agent -ReuseResults .\runs\YOUR_FAILED_RUN\results.json
```

`-ReuseResults` checks tenant/workspace/ontology identity, imports only selected
Data Agent IDs, and leaves the config file unchanged. Imported IDs override that
scenario's configured ID for this invocation. Shared mode requires all configured
and imported IDs to resolve to one agent; conflicting IDs fail before any live call.
Existing drafts are never edited;
their saved configuration is not exported or certified. The requested entities
and actual execution-source IDs determine runtime coverage. Reused IDs remain
in the new report even if the question fails.
It cannot be combined with `-AllowCreate`; missing drafts remain blocked rather
than being silently created. Use a new output directory for each invocation.
`-RerunFailed` alone selects scenarios; it does not import retained resources.
You may pair it with `-ReuseResults` pointing to the same previous results file.
Reuse applies **only to Data Agents**. Operations has no reuse flag or ID setting;
each run requires one newly authorized artifact shared by its selected authoring cases.

Private mode refuses the normal public metadata default and checks returned MWC
hosts before using workload credentials. Requests do not follow redirects or switch
to a public route. This protects routing intent; it does not prove DNS/egress policy.
The runner does not create private endpoints or change WSPL, BPA, RBAC, or Copilot settings.

For CLI authentication, sign in **before** running, using your normal approved
tenant/application. An expired or denied login is reported; the runner never opens
another login or changes client identity automatically.

The sample fixture must already be populated: 3 Plants, 12 Assets, 120 Readings per
source group. Semantic Model refresh remains a separate setup operation. A failed
data check is not automatically attributed to Private Link or the resolver.

Generation covers **individual same-workspace Lakehouse and Eventhouse/KQL**
fixtures: `generation.lifecycle` retains the Lakehouse lifecycle, while
`generation.kql` selects the KQL database. Both require explicit `-AllowCreate`,
MWC v2 and the working UX routes; each creates a separate retained test ontology,
never edits the original, and performs no source writes.

The lifecycle checks plan/reject without saving, explicit approval, save/readback,
fixture answers and cancellation of active read-only planning. It does **not**
test cancellation racing an active apply or browser save/reopen interaction.
KQL generation discovers `properties.queryServiceUri` from source metadata and
verifies supported literal KQL M bindings; unsupported binding shapes remain
BLOCKED rather than being accepted as verified source identity. The actual
client contract retains `SelectedSources: []`; source identity is prompt-scoped
and checked in the generated authored bindings.

Lakehouse's optional independent source-result observation needs **ODBC Driver 18
for SQL Server** and TDS access. KQL uses a read-only source query. Missing
independent proof is informational and does not downgrade a complete
fixture-correct agent answer; observed contradictions still fail. These functional
generation outcomes do not replace the strict P0 resolver and preview checks.
Mixed-source, other-source and cross-workspace generation remain outside this adapter.

```powershell
.\Start-Validation.ps1 -Config .\validation.generation.json `
    -Scenarios generation.lifecycle,generation.kql -AllowCreate -Strict `
    -OutputDirectory .\runs\p0-generation
```

## 2. Choose tests

```powershell
# Offline catalog: exact selectable scenario IDs.
.\Start-Validation.ps1 -ListScenarios

# Validate configuration and write a plan/report, without authentication or live calls.
.\Start-Validation.ps1 -Config .\validation.local.json -Agents ontology,mcp -PlanOnly

# Default: definition read only. Resolver warnings are recorded, not prerequisites.
.\Start-Validation.ps1 -Config .\validation.local.json

# Run two independent queries. Failure of the first does not stop the second.
.\Start-Validation.ps1 -Config .\validation.local.json `
  -Scenarios ontology.lakehouse,mcp.lakehouse `
  -OutputDirectory .\runs\pl-query-01

# All ontology and MCP source/combo probes, without provisioning or agent activation.
.\Start-Validation.ps1 -Config .\validation.local.json -Agents ontology,mcp

# Explicitly authorize NEW test artifacts. Existing source data/ontology are preserved.
.\Start-Validation.ps1 -Config .\validation.local.json `
  -Agents generation,data-agent,operations -AllowCreate
```

Select one of `-Agents`, `-Scenarios`, or `-RerunFailed`, not multiple selectors.
`-Scenarios` also accepts quoted wildcard patterns, for example `'mcp.*'`.
No selector defaults to **ontology.definition**, not a long all-agent run.
Use `-ListScenarios` for the current catalog; `-Agents operations` selects ten authoring
cases and the separate manual `operations.runtime`.

| Family | Coverage / limits |
|---|---|
| `ontology` | Definition plus six source and four combination queries. Explicit Plan/read-only context. No source mutation. Complete fixture-correct answers PASS; independent execution/source lineage is informational |
| `mcp` | Initialize/list-tools/ask through the selected Fabric item endpoint. Empty HTTP 200, JSON-RPC errors, tool errors and incorrect structured answers are failures |
| `data-agent` | One fresh ontology-backed draft shared by ten independent source-specific questions (not the older direct-SM helper). Complete fixture-correct answers can PASS without independent source proof; observed contradictions and service failures still fail |
| `generation` | Separate retained test ontologies from individual Lakehouse or Eventhouse/KQL, using the explicit Plan/Act client contract. Never applies to the original ontology |
| `preview` | Six source-specific child-Eventhouse backend previews; full fixture/schema assertions, not browser coverage |
| `p0` | Individual Lakehouse/KQL topology, fresh resolution, authorized access baselines and separately prepared denial runs; no mixed-source or other-source acceptance claims |
| `operations` | One fresh inactive artifact shared by ten sequential, separately identified native playbook previews; no ALM gates, activation, monitoring, external actions or notification destinations. `operations.runtime` remains manual SKIP |

Creation is disabled unless `-AllowCreate` is present **for that invocation**.
Putting `allow_create` in JSON does not grant authorization. Missing creation
permission is a BLOCKED result, and unrelated read-only checks still run.

With no explicit reuse IDs, shared mode creates **one fresh unpublished Data Agent
per invocation**, attaching only the configured ontology and selecting all its
entities (18 for the full sample). Questions explicitly restrict which entities
to query and prohibit aggregating identical copies from other groups. Each question
starts an independent response, with its own status, timings and evidence; a query
failure does not stop later questions or create a replacement agent. No prior-run
agent is discovered or reused automatically. A failed or ambiguous creation stops
further shared-agent creation attempts in that run; inspect retained operation
evidence before explicitly retrying in a new run.

An existing Data Agent draft is reused as-is. The question targets the configured
ontology's fixture entities; runtime source evidence is retained as diagnostics,
not required independently for PASS. Observed wrong-source use still fails. No export/configuration-read dependency
blocks the question, and the runner never silently rewrites a draft. Prefer
`-ReuseResults`; a manual per-scenario mapping is also supported:

```json
{
  "data_agent_ids": {
    "data-agent.lakehouse": "REPLACE_WITH_RETAINED_DRAFT_GUID"
  }
}
```

Add that property to the complete local configuration; the snippet is not a full
configuration. The retired `operations.native-import` scenario is not selectable;
old `-RerunFailed` reports map it to the explicitly skipped `operations.runtime`.

### Operations inactive authoring

The source cases match Data Agent: `lakehouse`, `kql`, `warehouse`, `sql`, `mirror`,
`semantic`, `sm-lakehouse`, `sm-kql`, `lakehouse-kql`, `lakehouse-warehouse`.
For example:

```powershell
.\Start-Validation.ps1 -Config .\validation.local.json -Agents operations -Configure
.\Start-Validation.ps1 -Config .\validation.local.json -Agents operations -AllowCreate -PlanOnly
.\Start-Validation.ps1 -Config .\validation.local.json -Scenarios operations.lakehouse -AllowCreate
```

Each run creates one new **unconfigured, nonrunning** Operations artifact. Every
selected case supplies its own source-specific configuration to
`POST configuration/behaviorModel`, polls that preview's unique ID, reads its
returned Markdown, and checks native `GET settings` before/after. Cases are sequential:
a confirmed terminal generation outcome is required before starting the next preview.
Distinct preview IDs and per-scenario requests/results are retained; a reused preview
ID is an error, never another scenario's result. Generated
playbooks are assessed as authoring output, not imported/exported or activated.
The native route uses workload `OA`, MWC artifact type `OperationalAgents`, and
`OAgentsService`; no ALM capability/readback gate is used.

The preview calls match the [Configuration V1 controller](https://dev.azure.com/powerbi/MWC/_git/workload-rti-ai?path=/Workloads/OAgents/Service/Microsoft.MWC.Workload.OAgents/Controllers/Configuration/V1/ConfigurationV1Controller.cs&version=GC949231d36dec2b241f109545ba31fb7d7e68bfe0),
checked on 2026-10-28. This is a source-contract check, not proof of the deployed revision.
The native base is `/webapi/capacities/{capacity}/workloads/OA/OAgentsService/automatic/v1/workspaces/{workspace}/operationalagents/{agent}/configuration`;
native calls use `api-version=2025-05-01` and the artifact-scoped MWC v2 token.

| Call | Purpose |
|---|---|
| Fabric `POST /v1/workspaces/{workspace}/operationsAgents` | Create the fresh inactive artifact |
| Metadata `POST /metadata/v201606/generatemwctokenv2` | Obtain the `OA` token for `OperationalAgents`; verify returned host/capacity |
| Native `GET /settings` | Verify nonrunning state before and after each preview |
| Native `POST /behaviorModel` | Submit the configuration; the controller sets `generatePreview: true` and returns a preview ID |
| Native `GET /behaviorModel/{previewId}/status` | Poll that preview's native `InProgress`, `Completed` or `Failed` state |
| Native `GET /behaviorModel/{previewId}` | Read the completed preview's `ontology` and `rules` Markdown |

HTTP success with native status `Failed` is a generation failure, not a failed
HTTP request. Preserve both the HTTP evidence and native error; do not infer an
incorrect route or root cause from the generic generation message alone.

| Authoring metric | Evidence / result |
|---|---|
| Native generation | `generationStatus.state` must be `Completed`; completion alone is not PASS |
| Static playbook contract | `playbookCheck`: exactly one service-rendered native rule/query, a Celsius temperature property (`TemperatureC` or `TemperatureCelsius`), `ReadingId`, `AssetId`, `PlantId`, and condition `<Celsius property> Is Above 32.5`. The condition property must also occur in the rendered query; an equivalent Celsius name is not a failure. Explicit renames from a different measurement still fail |
| Inspectability / mismatches | Missing query/condition rendering or required output properties remains PARTIAL; wrong threshold/property or explicit unexpected source labels FAIL. GQL, KQL and `kqldataquery` can PASS without independent physical-source binding or join-lineage proof |
| Nonrunning state | `stateChecks` must report `Inactive` **or** `Unconfigured` before and after generation; `inactiveVerified` denotes this check, not a requirement for the literal state `Inactive` |
| Execution boundary | `queryExecuted` and `runtimeValidated` remain false; generated queries are never executed by the runner |

**Authoring PASS requires all three:** native completion, a passing static contract,
and verified nonrunning state before/after. Static checks do not prove query
semantics, fixture-data correctness, live monitoring, trigger/rule firing,
notifications, external actions or Private Link enforcement. `operations.runtime`
always reports SKIP.

`Completed` generation returning native KQL/SQL passthrough is not a failed
generation or unsupported response. For example, a Readings-only query with the
correct 32.5 threshold does not establish Assets/Plants joins merely because
the accompanying prose mentions them. Missing join/source proof is informational.
Missing requested `AssetId`/`PlantId` output, however, remains an incomplete
playbook contract rather than a source-proof limitation.
Numeric casts such as `todouble(TemperatureC)` / `toreal(TemperatureC)` preserve the
Celsius measurement. A timestamp fallback such as `coalesce(ObservedAt, now())`
does not exclude historical rows and is not, by itself, a failure. Relative-time
predicates such as `where ObservedAt > ago(1h)` still require fixture review.
If either before/after state cannot be verified as nonrunning, a safety stop
blocks subsequent Operations previews in that run. A lost generation response,
missing/reused preview ID, timeout, failed status read or inconsistent status also
blocks later previews, even if the agent remains inactive: the prior generation
may still be running. No automatic replay, replacement artifact or cancellation
is attempted. Confirmed terminal `Failed` generations and static-contract failures
do not block later cases when nonrunning state is verified. Inspect retained evidence
before another Operations run; the runner never activates or repairs the agent.

The per-scenario resource mappings `operations_agents` and `operations_playbooks`
retain the shared artifact ID and individual generated-preview IDs.
`operations_shared` records the single creation attempt; `operations_previews`
records each attempted preview's lifecycle. Failed/ambiguous artifact creation
cannot trigger a replacement in the same run. Nothing is automatically deleted
or reused across runs. Every new authoring run needs `-AllowCreate` and creates a
fresh artifact; inspect retained IDs after ambiguous timeouts.

### Data Agent functional metrics

The query uses the ML UX Responses route with `agent=aiskill&stage=sandbox`.
Each case asks for A012's reading count and the maximum reading with asset/plant
context; combined cases use Plants/Assets from the first source and Readings from
the second. The expected values are 10 readings, 32.9 C, A012, R0120,
2026-01-01T00:45:00Z, P03, East Plant and Boston.

| Metric | Evidence / result |
|---|---|
| Query attempted | `queryAttempted`; false means setup blocked, not a failed query |
| Query completion | `queryCompletion`; API/tool errors fail, and bounded timeouts are TIMEOUT |
| Answer correctness | `answerChecks`; incorrect complete values FAIL, missing values remain UNVERIFIED |
| Source observations | `sourceEvidenceVerified` remains diagnostic, not a PASS gate. Missing independent source/workspace/lineage proof is informational; observed wrong-source use remains a failure |
| Response time | `queryDurationSeconds`, plus total scenario duration; no unagreed latency threshold |

The count result does **not** have to repeat `AssetId`. A count-only row such as
`ReadingCount = 10` is accepted when its own successful expected-source execution
proves that the returned count column is restricted to A012. The checker follows
SQL `COUNT`/`COUNT_BIG` projections through CTEs and UNION branches (including NULL
count projections for separate maximum-reading rows), and DAX
`EVALUATE ROW(..., CALCULATE(COUNTROWS(...), ...[AssetId] = "A012"))`.
Explicit A012 row labels remain valid. Contradictory asset labels are not overridden;
a proven count other than 10 fails even if another count is correct.

`countScopeEvidence` records the row-label or executed-query basis, result filename,
execution call ID, column and value. Each result table also records `countScope`
with a reason when query scope is unverified. Proof cannot cross files or sources,
come from failed executions, or rely on filenames, prose, comments or unrelated
query branches. Reused filenames and inspections before execution completion
cannot establish query-derived count scope.

The structural checker is deliberately bounded, uses only the Python standard
library and adds no setup dependencies. Unsupported SQL/DAX/KQL shapes without an
explicit A012 result label remain unverified in the source-evidence diagnostics.
That alone cannot downgrade an otherwise complete fixture-correct answer.

A completed query with a complete fixture-correct answer can PASS even when
execution/source evidence is incomplete. The sample's `ObservedAt` values are
known UTC: a timezone-less ISO timestamp is interpreted as UTC, and explicit
offsets are normalized to UTC before comparison. This fixture-specific rule does
not infer timezones for arbitrary data. Wrong instants, missing values and invalid
timestamps still fail; `timestampNormalization` records any UTC assumption.
Code alone or an incomplete answer is
still insufficient; actual incorrect results, source contradictions, service errors
and timeouts remain non-passing. Neither
successful creation nor ALM export is a functional metric. `configurationVerified`
remains false: runtime evidence is not a certification of the entire stored draft.
Private-network enforcement and controlled permission-denial tests remain separate.

## 3. Copy the report

Every run prints its output path. The directory contains:

- **`report.md`**: copyable Markdown summary with all selected/unselected scenarios,
  outcomes, limits, retained resources and untested Private Link acceptance checks.
- **`results.json`**: structured results, configuration and error classifications.
- **`resources.json`**: retained artifact/conversation/operation IDs as they are recorded.
- Per-scenario `*.result.json`, `*.http.json` and supporting evidence.

Reports are checkpointed before/after each scenario. Ordinary assertion errors,
resolver warnings, empty responses, failed agent calls and timeouts cannot abort
unrelated scenarios. Ctrl+C stops intentionally and preserves completed results;
forced process/machine termination leaves the last checkpoint. A missing shared
prerequisite such as authentication or invalid target configuration blocks execution
and writes a run-level explanation rather than pretending tests ran.

HTTP requests and polling have finite budgets. Writes are not automatically
replayed, including after ambiguous timeouts. Source data and created test items
are never automatically deleted. Inspect retained operations/items before retrying.

Statuses:

- **PASS**: the specific stated assertion passed, not overall Private Link sign-off.
- **PARTIAL**: a required answer, output or safety/acceptance check is incomplete.
  Missing independent source/lineage evidence alone never causes PARTIAL.
- **FAIL**: an observed assertion or service/response failure.
- **BLOCKED**: missing prerequisite or authorization; no success claim.
- **TIMEOUT / ERROR**: bounded timeout or unexpected test error, captured for diagnosis.
- **SKIP**: not selected, manual runtime, or a plan-only scenario with no detected static blockers;
  never counted as a pass. Missing prerequisites are **BLOCKED** even in plan mode.

Default exit **0** means the runner completed and wrote the report, **not all tests
passed**. `-Strict` returns 1 for any selected non-PASS result, but still finishes all
selected scenarios. Run-level setup failures return 2. Unknown CLI options are
rejected before execution.

```powershell
# Retry only prior partial/failed/blocked/error/timeout/unfinished cases.
# New output directory required. No prior evidence is overwritten.
.\Start-Validation.ps1 -Config .\validation.local.json `
  -RerunFailed .\runs\pl-query-01\results.json `
  -OutputDirectory .\runs\pl-query-02

# Copy the complete report on Windows.
Get-Content -Raw .\runs\pl-query-02\report.md | Set-Clipboard
```

Rerunning creation scenarios with `-AllowCreate` can create another test artifact;
the runner does not infer that a timed-out create failed or resume an apply blindly.
The single-source aliases are `lakehouse`, `kql`, `warehouse`, `sql`, `mirror`,
`semantic`; combination aliases are listed by `-ListScenarios`.

Evidence redacts tokens/authorization and omits token-exchange bodies. It can still
contain source data, generated queries and tenant/workspace IDs: review it before
sharing. Local config and run outputs must not be committed.

## What remains outside this package's sign-off

The report explicitly leaves WSPL/BPA topology, denied-principal tests, source
revocation/recovery, sentinel/caching checks, source variants, graph/sharing and
apply-race cancellation unverified. These require prepared fixtures and authorized
policy changes; the runner does not silently alter them.

The [normal-Daily investigation](../../docs/prds/Ontology-FL2/Private-Link-Validation-Results-2026-10-28.md)
records known Data Agent support/mapping gaps and MCP empty responses. The portable
runner reports these as results to review, not reasons to abandon the remaining tests.
