import copy
import io
import json
import tempfile
import unittest
from contextlib import redirect_stdout
from datetime import datetime
from pathlib import Path
from unittest.mock import Mock, patch

import requests

from create_sample import Api, sample_tables
from validate_sample import catalog, execute_scenarios, main, select_scenarios, validate_config
from validation_common import HttpFailure, InvalidResponse, ScenarioBlocked, ValidationContext, sanitize
from validation_preview import CASES, KUSTO_SCOPE, build_query, compare_fixture, preview, settings
from validation_setup import configure, prerequisites, unselected_source_reason

WORKSPACE = "11111111-1111-1111-1111-111111111111"
ONTOLOGY = "22222222-2222-2222-2222-222222222222"
SOURCE_WORKSPACE = "33333333-3333-3333-3333-333333333333"
EH = "44444444-4444-4444-4444-444444444444"
DATABASE = "55555555-5555-5555-5555-555555555555"
SOURCE_ITEM = "66666666-6666-6666-6666-666666666666"
GATEWAY = "https://ontology.z4.kusto.fabric.microsoft.com"
SOURCE_CLUSTER = "https://source.z4.kusto.fabric.microsoft.com"


def config():
    sql = {"workspace_id": SOURCE_WORKSPACE, "item_id": SOURCE_ITEM,
           "sql_endpoint": "sample.daily-datawarehouse.fabric.microsoft.com",
           "sql_database": "OntologySample_Lakehouse", "schema": "dbo"}
    return {"tenant_id": WORKSPACE, "workspace_id": WORKSPACE, "ontology_id": ONTOLOGY,
            "target_network": "tenantpl", "authoring_mode": "public",
            "preview": {"execution": {"workspace_id": WORKSPACE, "ontology_id": ONTOLOGY,
                                     "eventhouse_id": EH, "database_id": DATABASE,
                                     "cluster_uri": GATEWAY, "provenance": "ontology-child-eventhouse"},
                        "sources": {**{case: dict(sql) for case in ("lakehouse", "warehouse", "sql", "mirror")},
                                    "kql": {"workspace_id": SOURCE_WORKSPACE, "item_id": SOURCE_ITEM,
                                            "cluster_uri": SOURCE_CLUSTER, "database": "SampleKQL"},
                                    "semantic": {"workspace_id": SOURCE_WORKSPACE, "item_id": SOURCE_ITEM,
                                                 "api_host": "https://dailyapi.powerbi.com"}}}}


def frames(table):
    kinds = {"string": "string", "double": "real", "datetime": "datetime"}
    return [{"FrameType": "DataSetHeader", "IsProgressive": False},
            {"FrameType": "DataTable", "TableKind": "PrimaryResult",
             "Columns": [{"ColumnName": name, "ColumnType": kinds[kind]} for name, kind in table.columns],
             "Rows": [[value.isoformat() + "Z" if isinstance(value, datetime) else value for value in row]
                      for row in table.rows]},
            {"FrameType": "DataSetCompletion", "HasErrors": False, "Cancelled": False}]


class PreviewTests(unittest.TestCase):
    def test_registry_prerequisites_and_alm_need_no_ux_authoring_routes(self):
        names = {f"preview.{case}" for case in CASES}
        self.assertEqual(select_scenarios(catalog(), agents=["preview"]), names)
        checked = validate_config(config())
        self.assertNotIn("ux_metadata_api", checked)
        self.assertEqual(prerequisites(checked, names), {})
        checked.pop("preview")
        self.assertEqual(set(prerequisites(checked, names)), names)
        self.assertEqual(prerequisites(checked, {"ontology.definition"}), {})

    def test_unselected_source_is_skip_not_missing_config_block(self):
        value = config()
        value["source_types"] = ["Lakehouse", "Eventhouse"]
        value["preview"]["sources"] = {key: item for key, item in value["preview"]["sources"].items()
                                       if key in ("lakehouse", "kql")}
        for case in CASES:
            self.assertEqual(bool(unselected_source_reason(value, "preview." + case)),
                             case not in ("lakehouse", "kql"))
        self.assertFalse(prerequisites(value, {"preview." + case for case in CASES}))

    def test_execution_identity_and_source_substitution_are_rejected(self):
        for key, replacement in (("ontology_id", SOURCE_ITEM), ("workspace_id", SOURCE_WORKSPACE),
                                 ("provenance", "source-eventhouse"), ("database_id", ""),
                                 ("eventhouse_id", "00000000-0000-0000-0000-000000000000")):
            with self.subTest(key=key):
                value = config()
                value["preview"]["execution"][key] = replacement
                with self.assertRaises(ScenarioBlocked):
                    settings(value, "lakehouse")
        for field in ("item_id", "database"):
            value = config()
            value["preview"]["sources"]["kql"][field] = DATABASE
            with self.assertRaisesRegex(ScenarioBlocked, "Source"):
                settings(value, "kql")

    def test_hosts_paths_directives_and_unknown_settings_block_before_auth(self):
        for origin in ("http://ontology.kusto.fabric.microsoft.com", GATEWAY + "/v2/rest/query",
                       GATEWAY + "?x=1", GATEWAY + "#", GATEWAY + ":443", "https://localhost",
                       GATEWAY + "\n", GATEWAY + "?",
                       "https://user:pass@ontology.kusto.fabric.microsoft.com",
                       "https://ontology.kusto.fabric.microsoft.com.evil.example"):
            with self.subTest(origin=origin):
                value = config()
                value["preview"]["execution"]["cluster_uri"] = origin
                with self.assertRaises(ScenarioBlocked):
                    settings(value, "lakehouse")
        for field, value in (("sql_endpoint", "host;Token=secret.database.windows.net"),
                             ("sql_database", "bad\ncatalog"), ("schema", None), ("query", ".drop database"),
                             ("access_token", "never-paste")):
            current = config()
            current["preview"]["sources"]["lakehouse"][field] = value
            with self.assertRaises(ScenarioBlocked):
                settings(current, "lakehouse")
        value = config()
        value["preview"]["sources"]["semantic"]["api_host"] = "https://api.powerbi.com"
        with self.assertRaises(ScenarioBlocked):
            settings(value, "semantic")

    def test_exact_sql_payload_for_all_relational_sources(self):
        plants = sample_tables()[0]
        for case in ("lakehouse", "warehouse", "sql", "mirror"):
            source = config()["preview"]["sources"][case]
            source["schema"] = ""
            expected = (
                "evaluate sql_request(\n"
                "  'Server=\"tcp:sample.daily-datawarehouse.fabric.microsoft.com,1433\";"
                "Authentication=\"Active Directory Integrated\";Initial Catalog=\"OntologySample_Lakehouse\";',\n"
                "  'SELECT TOP (1000) [PlantId], [Name], [City] FROM [Plants]'\n)\n"
                "| project ['PlantId'] = ['PlantId'], ['Name'] = ['Name'], ['City'] = ['City']\n| take 1000")
            self.assertEqual(build_query(case, source, plants), expected)

    def test_kql_and_semantic_follow_frontend_not_direct_source_api(self):
        value = config()["preview"]["sources"]
        plants = sample_tables()[0]
        query = build_query("kql", value["kql"], plants)
        self.assertEqual(query, f"cluster('{SOURCE_CLUSTER}').database('SampleKQL').table('Plants')\n"
                         "| project ['PlantId'] = ['PlantId'], ['Name'] = ['Name'], ['City'] = ['City']\n| take 1000")
        query = build_query("semantic", value["semantic"], plants)
        self.assertTrue(query.startswith("evaluate dax_request("))
        self.assertIn(f"https://dailyapi.powerbi.com/v1.0/myorg/datasets/{SOURCE_ITEM};Impersonate", query)
        self.assertIn("EVALUATE TOPN(1000, SELECTCOLUMNS(\\'Plants\\'", query)
        self.assertIn("| project-rename ['PlantId'] = ['[PlantId]']", query)
        self.assertNotIn("Token=", query)
        self.assertNotIn("executeQueries", query)
        self.assertNotIn("/groups/", query)

    def test_connection_values_and_kql_names_cannot_inject_queries(self):
        source = config()["preview"]["sources"]["lakehouse"]
        source["schema"] = "weird]schema"
        source["sql_database"] = 'catalog";Password=x;\' | take 0 //'
        query = build_query("lakehouse", source, sample_tables()[0])
        self.assertIn('Initial Catalog="catalog"";Password=x;\\\' | take 0 //";', query)
        self.assertIn("[weird]]schema].[Plants]", query)

    def test_all_rows_schema_types_and_order_normalization(self):
        for table in sample_tables():
            response = frames(table)
            response[1]["Rows"].reverse()
            self.assertEqual(compare_fixture(response, table)["actualRows"], len(table.rows))
        table = sample_tables()[2]
        response = frames(table)
        response[1]["Rows"][0][2] = "2026-01-01T01:00:00+01:00"
        self.assertEqual(compare_fixture(response, table)["actualRows"], 120)
        response[1]["Rows"][0][2] = "2026-01-01T00:00:00"
        self.assertEqual(compare_fixture(response, table)["actualRows"], 120)

    def test_wrong_empty_extra_duplicate_or_null_rows_never_pass(self):
        table = sample_tables()[0]
        mutations = (
            lambda response: response[1].update(Rows=[]),
            lambda response: response[1]["Rows"].pop(),
            lambda response: response[1]["Rows"].append(response[1]["Rows"][0]),
            lambda response: response[1]["Rows"].__setitem__(1, response[1]["Rows"][0]),
            lambda response: response[1]["Rows"][0].__setitem__(0, None),
            lambda response: response[1]["Rows"][0].__setitem__(1, "wrong"),
            lambda response: response[1]["Columns"][0].update(ColumnName="City"),
            lambda response: response[1]["Columns"][0].update(ColumnType="long"),
            lambda response: response[1]["Columns"][0].pop("ColumnType"),
        )
        for mutation in mutations:
            response = frames(table)
            mutation(response)
            with self.assertRaises(InvalidResponse):
                compare_fixture(response, table)
        table = sample_tables()[2]
        for invalid in ("32.9", float("nan"), True, None):
            response = frames(table)
            response[1]["Rows"][0][3] = invalid
            with self.assertRaises(InvalidResponse):
                compare_fixture(response, table)

    def test_http200_errors_missing_completion_and_status_fail_closed(self):
        table = sample_tables()[0]
        mutations = (
            lambda response: response[-1].update(HasErrors=True),
            lambda response: response[0].update(IsProgressive=True),
            lambda response: response[-1].update(Cancelled=True),
            lambda response: response[-1].update(OneApiErrors=[{"error": {"code": "Forbidden"}}]),
            lambda response: response[1]["Rows"].append({"OneApiErrors": [{"error": {"message": "partial"}}]}),
            lambda response: response.pop(),
            lambda response: response.pop(0),
            lambda response: response.append(response[-1]),
            lambda response: response.insert(1, {"FrameType": "TableFragment"}),
            lambda response: response.insert(1, copy.deepcopy(response[1])),
        )
        for mutation in mutations:
            response = frames(table)
            mutation(response)
            with self.assertRaises(InvalidResponse):
                compare_fixture(response, table)
        for severity in ("Fatal", "Exception", "Error", "Warning"):
            response = frames(table)
            response.insert(2, {"FrameType": "DataTable", "TableKind": "QueryCompletionInformation",
                                "Columns": [{"ColumnName": "LevelName"}, {"ColumnName": "Payload"}],
                                "Rows": [[severity, '{"message":"result set too large"}']]})
            with self.assertRaises(InvalidResponse):
                compare_fixture(response, table)
        for response in ({}, {"Tables": [frames(table)[1]]}, {"error": {"code": "KustoSqlRequestForbiddenException"}}):
            with self.assertRaises(InvalidResponse):
                compare_fixture(response, table)

    def test_six_sources_three_tables_and_execution_context_not_source(self):
        for case in CASES:
            ctx = Mock(config=config(), credential=Mock(), timeout=30)
            ctx.request.side_effect = [frames(table) for table in sample_tables()]
            with patch("validation_preview.Api") as api:
                result = preview(ctx, case)
            self.assertEqual(result["status"], "PASS")
            api.assert_called_once_with(GATEWAY, KUSTO_SCOPE, ctx.credential, 30)
            self.assertEqual(ctx.request.call_count, 3)
            for call in ctx.request.call_args_list:
                self.assertEqual(call.args[1:3], ("POST", GATEWAY + "/v2/rest/query"))
                self.assertEqual(set(call.args[3]), {"db", "csl", "properties"})
                self.assertEqual(call.args[3]["db"], DATABASE)
                self.assertIsNone(call.args[3]["properties"])
            ctx.workload.assert_not_called()
            ctx.mutate.assert_not_called()
            api.return_value.close.assert_called_once()
            route = result["evidence"]["routing"]
            self.assertEqual(route["sourceWorkspaceId"], SOURCE_WORKSPACE)
            self.assertEqual(route["ontologyWorkspaceId"], WORKSPACE)
            self.assertFalse(route["networkEnforcementVerified"])
            self.assertFalse(route["browserUiTested"])

    def test_table_errors_continue_and_preserve_source_specific_status(self):
        ctx = Mock(config=config(), credential=Mock(), timeout=30)
        ctx.redact.side_effect = sanitize
        ctx.request.side_effect = [HttpFailure(403, "private link forbidden"), frames(sample_tables()[1]),
                                   {"error": {"code": "semantic dataset unmaterialized"}}]
        with patch("validation_preview.Api"):
            result = preview(ctx, "semantic")
        self.assertEqual(result["status"], "FAIL")
        self.assertEqual([row["status"] for row in result["evidence"]["tables"]], ["BLOCKED", "PASS", "FAIL"])
        self.assertEqual(ctx.request.call_count, 3)
        ctx.mutate.assert_not_called()

    def test_real_transport_is_bounded_no_redirect_and_scrubs_opaque_and_nested_tokens(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            token = "opaque-access-credential-123456"
            credential = Mock()
            credential.get_token.return_value.token = token
            ctx = ValidationContext(config(), credential, directory)
            ctx.begin("preview.lakehouse")
            response = requests.Response()
            response.status_code = 200
            data = frames(sample_tables()[0])
            data[-1]["OneApiErrors"] = [{"error": {"message": token + ";Token=embedded-secret"}}]
            response._content = json.dumps(data).encode()
            response._content_consumed = True
            response.headers["x-ms-activity-id"] = "server-correlation"
            api = Api(GATEWAY, KUSTO_SCOPE, credential, 30)
            api.session = Mock()
            api.session.request.return_value.__enter__ = Mock(return_value=response)
            api.session.request.return_value.__exit__ = Mock(return_value=False)
            body = {"db": DATABASE, "csl": build_query("lakehouse", config()["preview"]["sources"]["lakehouse"],
                                                      sample_tables()[0]), "properties": None}
            ctx.request(api, "POST", GATEWAY + "/v2/rest/query", body)
            args = api.session.request.call_args.kwargs
            self.assertFalse(args["allow_redirects"])
            self.assertTrue(args["stream"])
            self.assertEqual(args["headers"]["Authorization"], "Bearer " + token)
            self.assertTrue(args["headers"]["x-ms-client-request-id"].startswith("Ontology;"))
            credential.get_token.assert_called_once_with(KUSTO_SCOPE)
            saved = (Path(directory) / "preview.lakehouse.http.json").read_text()
            for secret in (token, "embedded-secret"):
                self.assertNotIn(secret, saved)
            self.assertIn("server-correlation", saved)
            self.assertIn('"request"', saved)
            self.assertIn('"utc"', saved)
            self.assertEqual(ctx.redact({"nested": [token]})["nested"], ["[REDACTED]"])
            self.assertNotIn(token, json.dumps(ctx.redact({token: [token]})))
            response.status_code = 302
            response.headers["Location"] = "https://public.kusto.windows.net"
            with self.assertRaises(HttpFailure):
                ctx.request(api, "POST", GATEWAY + "/v2/rest/query", body)
            self.assertEqual(api.session.request.call_count, 2)
            ctx.close()

    def test_sanitization_handles_nested_dax_directives_and_token_properties(self):
        for value in ("evaluate dax_request('host/dataset;Token=embedded-secret', 'EVALUATE X')",
                      'evaluate dax_request("host/dataset;Token=embedded-secret", "EVALUATE X")',
                      'Token="embedded-secret"', "Token='embedded-secret'",
                      'Token=\\"embedded-secret\\"'):
            self.assertNotIn("embedded-secret", json.dumps(sanitize({"response": [{"csl": value}]})))
        self.assertNotIn("embedded-secret", json.dumps(sanitize({"accessToken": "embedded-secret"})))

    def test_all_preview_config_blockers_need_no_auth_or_calls(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            path = Path(directory)
            current = config()
            current.pop("preview")
            (path / "config.json").write_text(json.dumps(current))
            with patch("azure.identity.AzureCliCredential") as credential, redirect_stdout(io.StringIO()):
                code = main(["--config", str(path / "config.json"), "--output", str(path / "output"),
                             "--agents", "preview", "--strict"])
            self.assertEqual(code, 1)
            credential.assert_not_called()
            result = json.loads((path / "output" / "results.json").read_text())
            self.assertEqual([row["status"] for row in result["results"] if row["selected"]], ["BLOCKED"] * 6)

    def test_preview_source_failure_does_not_stop_later_source(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            path = Path(directory)
            ctx = ValidationContext(config(), Mock(), path)
            bad = frames(sample_tables()[0])
            bad[-1].update(HasErrors=True, OneApiErrors=[{"error": {"code": "KustoSqlRequestForbiddenException",
                                                                  "message": "While private links are enabled"}}])
            ctx.request = Mock(side_effect=[bad, *[frames(table) for table in sample_tables()[1:]],
                                            *[frames(table) for table in sample_tables()]])
            names = ["preview.lakehouse", "preview.kql"]
            report = {"startedUtc": "test", "state": "running", "config": config(),
                      "results": [{"scenario": name, "selected": True, "status": "PENDING", "summary": ""}
                                  for name in names]}
            with patch("validation_preview.Api"), redirect_stdout(io.StringIO()):
                execute_scenarios(catalog(), set(names), ctx, report, path)
            self.assertEqual([row["status"] for row in report["results"]], ["FAIL", "PASS"])
            self.assertEqual(ctx.request.call_count, 6)
            self.assertIn("KustoSqlRequestForbiddenException",
                          (path / "preview.lakehouse.Plants.response.json").read_text())
            ctx.close()

    def test_report_and_selection_keep_previews_separate_and_skip_unselected_sources(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            path = Path(directory)
            value = config()
            value["source_types"] = ["Lakehouse"]
            names = ["preview.lakehouse", "preview.kql"]
            report = {"startedUtc": "test", "state": "running", "config": value,
                      "results": [{"scenario": name, "selected": True, "status": "PENDING", "summary": ""}
                                  for name in names]}
            adapter = Mock(return_value={"status": "PASS", "summary": "mocked fixture read"})
            ctx = Mock(requests=[], state={})
            execute_scenarios(dict.fromkeys(names, adapter), set(names), ctx, report, path)
            self.assertEqual([row["status"] for row in report["results"]], ["PASS", "SKIP"])
            adapter.assert_called_once_with(ctx)
            text = (path / "report.md").read_text()
            self.assertIn("UX backend data previews (separate from agent-query results)", text)
            self.assertNotIn("| preview.", text.split("## Results (definition / agent scenarios)")[1].split(
                "## Selected scenario diagnostics")[0])

    def test_preview_only_setup_never_prompts_for_ux_authoring(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            path = Path(directory) / "config.json"
            prompts = []
            values = iter([WORKSPACE, WORKSPACE, ONTOLOGY, "tenantpl", "cli", "SAVE"])

            def answer(prompt):
                prompts.append(prompt)
                return next(values)

            with redirect_stdout(io.StringIO()):
                self.assertEqual(configure(path, {"preview.lakehouse"}, input_fn=answer), 1)
            self.assertFalse(any("metadata" in prompt.lower() or "targeturihost" in prompt.lower()
                                 for prompt in prompts))
            stored = json.loads(path.read_text())
            self.assertEqual(stored["authoring_mode"], "public")
            self.assertNotIn("ux_metadata_api", stored)


if __name__ == "__main__":
    unittest.main()
