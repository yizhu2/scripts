"""Create or reuse seven Daily sample source types, then create a bound ontology in a supplied workspace."""

import argparse
import json
import logging
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
from tempfile import TemporaryDirectory
from uuid import UUID, uuid4

from create_ontology import build_definition, discover_sources, validate_inventory
from create_sample import (
    Api, COLLECTIONS, Manifest, PBI_SCOPE, SQL_SCOPE, STORAGE_SCOPE, Provisioner, arguments as source_arguments,
    check_local_dependencies, source_plan, workspace_items,
)
from replace_ontology import read_and_verify, serialize_definition
from reuse_sources import DAILY_ENDPOINTS, reuse_workspace_sources
from target_routing import TargetApi, target_fabric_api
from ux_authoring import author_and_verify, routing as ux_routing

LOG = logging.getLogger("ontology-sample")


def guid(value):
    return str(UUID(value))


def arguments(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tenant-id", type=guid)
    parser.add_argument("--capacity-id", type=guid, help="Capacity for the new source workspace")
    parser.add_argument("--workspace-id", type=guid, help="Existing target workspace for the new ontology")
    parser.add_argument("--target-network", choices=("public", "wspl", "tenantpl"), default="public",
                        help="Target routing; the PowerShell launcher prompts, this CLI defaults to public")
    parser.add_argument("--authoring-mode", choices=("public", "ux"), default="public",
                        help="public: ALM definition API (default); ux: transactional internal definition/scripts")
    parser.add_argument("--ux-metadata-api", help="Origin of the working UX's generatemwctokenv2 request")
    parser.add_argument("--ux-workload-host", help="Expected TargetUriHost from that UX request (hostname only)")
    parser.add_argument("--source-workspace-name")
    parser.add_argument("--ontology-name")
    parser.add_argument("--auth", choices=("auto", "cli", "browser"), default="auto")
    parser.add_argument("--client-id", type=guid, help="Organization-approved public client for browser auth")
    parser.add_argument("--run-directory", type=Path, help="New output directory; existing paths are refused")
    parser.add_argument("--sources-manifest", type=Path, help="Reuse successful source provisioning after inspecting a failure")
    parser.add_argument("--skip-source-creation", action="store_true", help="Prompt for an existing sample source workspace")
    parser.add_argument("--source-workspace-id", type=guid, help="Discover and verify existing sources without changing them")
    parser.add_argument("--source-item", action="append", default=[], metavar="TYPE=GUID",
                        help="Select a source item explicitly when a workspace contains multiple items of that type")
    parser.add_argument("--ontology-id", type=guid, help="Only supported with --verify-only")
    parser.add_argument("--verify-only", action="store_true", help="Read-only check of an existing ontology")
    parser.add_argument("--timeout", type=int, default=1800)
    parser.add_argument("--settle-seconds", type=int, default=120)
    parser.add_argument("--kql-request-timeout", type=int, default=300)
    parser.add_argument("--execute", action="store_true", help="Enable live calls; otherwise print an offline plan")
    args = parser.parse_args(argv)
    if args.authoring_mode == "public" and (args.ux_metadata_api or args.ux_workload_host):
        parser.error("--ux-metadata-api and --ux-workload-host require --authoring-mode ux")
    if args.authoring_mode == "ux":
        try:
            args.ux_metadata_api, args.ux_workload_host = ux_routing(
                args.target_network, args.ux_metadata_api, args.ux_workload_host)
        except ValueError as error:
            parser.error(str(error))
    args.skip_source_creation = args.skip_source_creation or bool(args.source_workspace_id)
    if args.skip_source_creation and args.sources_manifest:
        parser.error("Use either --source-workspace-id/--skip-source-creation or --sources-manifest, not both")
    if args.source_workspace_name and args.skip_source_creation:
        parser.error("--source-workspace-name is only for creating a new source workspace")
    if args.source_item and not args.skip_source_creation:
        parser.error("--source-item requires --source-workspace-id or --skip-source-creation")
    args.source_items = {}
    for selection in args.source_item:
        kind, separator, item_id = selection.partition("=")
        if not separator or kind not in COLLECTIONS or kind in args.source_items:
            parser.error("--source-item must specify a supported TYPE=GUID once per source type")
        try:
            args.source_items[kind] = guid(item_id)
        except ValueError:
            parser.error("--source-item requires a valid item GUID")
    if args.verify_only and not (
        (args.sources_manifest or args.skip_source_creation) and args.ontology_id and args.ontology_name
    ):
        parser.error("--verify-only requires existing sources, --ontology-id and --ontology-name")
    if args.ontology_id and not args.verify_only:
        parser.error("Existing ontologies are never overwritten by this launcher; use --verify-only")
    if args.timeout < 30:
        parser.error("--timeout must be at least 30 seconds")
    if not 0 <= args.settle_seconds <= 86400:
        parser.error("--settle-seconds must be between 0 and 86400")
    if not 30 <= args.kql_request_timeout <= 3600:
        parser.error("--kql-request-timeout must be between 30 and 3600 seconds")
    prompts = [("tenant_id", "Tenant ID")]
    if args.skip_source_creation:
        prompts.append(("source_workspace_id", "Existing workspace ID containing all sample sources"))
    elif not args.sources_manifest:
        prompts.append(("capacity_id", "Source capacity ID"))
    prompts.append(("workspace_id", "Target workspace ID (ontology destination)"))
    for field, label in prompts:
        if getattr(args, field) is None:
            try:
                setattr(args, field, guid(input(f"{label}: ").strip()))
            except (ValueError, EOFError):
                parser.error(f"A valid {label} is required")
    if args.source_workspace_id == args.workspace_id:
        parser.error("Source and target workspaces must be different")
    try:
        args.target_fabric_api = target_fabric_api(
            args.target_network, args.workspace_id, args.tenant_id)
    except ValueError as error:
        parser.error(str(error))
    run_id = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S") + "_" + uuid4().hex[:6]
    args.source_workspace_name = args.source_workspace_name or f"OntologySources_{run_id}"
    args.ontology_name = args.ontology_name or f"Ontology_AllSources_{run_id}"
    for name in (args.source_workspace_name, args.ontology_name):
        if not name.strip() or len(name) > 256:
            parser.error("Workspace and ontology names must contain 1-256 characters")
    args.run_directory = (args.run_directory or Path("runs") / run_id).resolve()
    args.prefix = f"OntologySample_{run_id}"
    return args


def provision_sources(args, credential, manifest):
    with closing(Provisioner(args, credential, manifest)) as provisioner:
        try:
            provisioner.run()
        except (Exception, KeyboardInterrupt) as error:
            manifest.data.update(status="failed", error=str(error))
            manifest.save()
            raise
    return manifest.data


def run(args, credential, manifest, source_args, state=None):
    fabric_api = source_args.fabric_api if source_args else DAILY_ENDPOINTS["fabric"]
    with (
        closing(TargetApi(args.target_fabric_api, PBI_SCOPE, credential, args.timeout, manifest.operation)) as api,
        closing(Api(fabric_api, PBI_SCOPE, credential, args.timeout, manifest.operation)) as source_api,
    ):
        target = f"{api.base}/workspaces/{args.workspace_id}"
        manifest.step("Checking the target workspace before any creation")
        target_metadata = api.json("GET", target)
        if not target_metadata.get("capacityId"):
            raise ValueError("The target workspace must already be assigned to a Fabric capacity")
        manifest.data["targetWorkspace"] = target_metadata
        if args.verify_only:
            item = api.json("GET", f"{target}/items/{args.ontology_id}")
            if item.get("type") != "Ontology" or item.get("displayName") != args.ontology_name:
                raise ValueError("Verification target must be an Ontology with the supplied exact name")
        elif any(item["displayName"].casefold() == args.ontology_name.casefold()
                 for item in workspace_items(api, target)):
            raise ValueError("The target workspace already contains that name; existing items are not overwritten")

        if state is None:
            if args.skip_source_creation:
                manifest.step("Reusing sources from the supplied workspace without changing source data")
                state = reuse_workspace_sources(args, credential, source_api)
            else:
                manifest.step("Creating seven source types; SemanticModel data validation is deferred")
                sources = Manifest(source_args.manifest, source_plan(source_args))
                state = provision_sources(source_args, credential, sources)
        validate_inventory(state, allow_deferred_semantic=True)
        if state["workspaceId"].lower() == args.workspace_id.lower():
            raise ValueError("Source and target workspaces must be different for this scenario")
        manifest.data["sourceWorkspaceId"] = state["workspaceId"]
        manifest.data["sourceItems"] = state["items"]
        manifest.data["verified"]["sources"] = state["verified"]
        manifest.data["deferredValidation"] = state.get("deferredValidation", {})
        manifest.save()
        expected = build_definition(state, discover_sources(source_api, state), "powerbi://dailyapi.powerbi.com")
        manifest.data["authoredDefinition"] = expected
        with TemporaryDirectory(prefix="ontology-public-") as temporary:
            folder = Path(temporary)
            if args.authoring_mode == "public":
                manifest.step("Serializing and validating every source binding")
                body = serialize_definition(expected, folder)
                manifest.data["publicRequest"] = body
            if not args.verify_only:
                manifest.step("Creating the ontology in the target workspace")
                item = api.mutate(target + "/items", {"displayName": args.ontology_name, "type": "Ontology"})
                if not item.get("id"):
                    raise RuntimeError("Creation returned no ontology ID; inspect the operation before retrying")
            manifest.data["items"]["Ontology"] = item
            manifest.save()
            if args.authoring_mode == "ux":
                author_and_verify(args, credential, target_metadata, item, expected, manifest)
            else:
                item_path = f"{target}/ontologies/{item['id']}"
                if not args.verify_only:
                    manifest.step("Writing all bindings through the Fabric public definition API")
                    api.mutate(item_path + "/updateDefinition", body, result_required=False)
                    manifest.data["writeCompleted"] = True
                    manifest.save()
                read_and_verify(api, item_path, state, expected, folder, manifest, args.workspace_id)
        manifest.data["status"] = "succeeded"
        manifest.data["workspaceUrl"] = f"https://daily.powerbi.com/groups/{args.workspace_id}/list"
        manifest.step("Sample ontology definition verified; consult source verification and deferredValidation")


def main(argv=None):
    args = arguments(argv)
    source_path = (args.sources_manifest.resolve() if args.sources_manifest
                   else args.run_directory / "sources.manifest.json")
    state = None
    if args.sources_manifest:
        state = json.loads(source_path.read_text(encoding="utf-8-sig"))
        validate_inventory(state, allow_deferred_semantic=True)
        if (state["tenantId"].lower() != args.tenant_id
                or (args.capacity_id and state["capacityId"].lower() != args.capacity_id)):
            raise ValueError("The source manifest must match the supplied tenant and source capacity")
        args.capacity_id = state["capacityId"].lower()
        if state["workspaceId"].lower() == args.workspace_id:
            raise ValueError("Source and target workspaces must be different")
        if state["endpoints"] != DAILY_ENDPOINTS:
            raise ValueError("This wrapper supports normal Daily endpoints only")
    source_args = None if args.skip_source_creation else source_arguments([
        "--tenant-id", args.tenant_id, "--capacity-id", args.capacity_id,
        "--workspace-name", args.source_workspace_name, "--prefix", args.prefix,
        "--manifest", str(source_path), "--timeout", str(args.timeout),
        "--settle-seconds", str(args.settle_seconds),
        "--kql-request-timeout", str(args.kql_request_timeout),
    ])
    plan = {
        "environment": "Daily", "tenantId": args.tenant_id, "capacityId": args.capacity_id,
        "targetWorkspaceId": args.workspace_id, "ontologyName": args.ontology_name,
        "targetNetwork": args.target_network, "targetFabricApi": args.target_fabric_api,
        "authoringMode": args.authoring_mode,
        "uxMetadataApi": args.ux_metadata_api, "uxExpectedWorkloadHost": args.ux_workload_host,
        "sourceWorkspaceName": state["workspaceName"] if state else (
            None if args.skip_source_creation else args.source_workspace_name),
        "sourceWorkspaceId": state["workspaceId"] if state else args.source_workspace_id,
        "sourceMode": "manifest" if state else ("existing-workspace" if args.skip_source_creation else "create"),
        "selectedSourceItems": args.source_items,
        "sourceManifest": str(source_path), "runDirectory": str(args.run_directory),
        "authentication": args.auth, "operation": "verify-only" if args.verify_only else "create",
        "reuseVerifiedSources": bool(state),
        "createsSourceWorkspace": not (state or args.skip_source_creation),
        "createsSourceItems": not (state or args.skip_source_creation),
        "deferredValidation": state.get("deferredValidation", {}) if state else {
            "SemanticModel": ["refresh", "sampleRows"]},
        "verificationSettleSeconds": 0 if state or args.skip_source_creation else args.settle_seconds,
        "kqlRequestTimeoutSeconds": min(args.kql_request_timeout, args.timeout),
        "expected": {"sourceItemTypes": 7, "sourceGroups": 6, "entities": 18, "relationships": 12},
    }
    print(json.dumps(plan, indent=2))
    if not args.execute:
        return
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logging.getLogger("azure").setLevel(logging.WARNING)
    if args.run_directory.exists():
        raise FileExistsError(f"Run directory already exists: {args.run_directory}; inspect it, do not replay")
    if state is None and not args.skip_source_creation:
        check_local_dependencies(source_args)
    from sample_auth import open_credential

    with open_credential(args.tenant_id, mode=args.auth, client_id=args.client_id) as credential:
        scopes = ([PBI_SCOPE] if state or args.skip_source_creation
                  else [PBI_SCOPE, STORAGE_SCOPE, SQL_SCOPE, source_args.kusto_scope])
        for scope in scopes:
            credential.get_token(scope)
        args.run_directory.mkdir(parents=True, exist_ok=False)
        manifest = Manifest(args.run_directory / "run.manifest.json", plan)
        try:
            run(args, credential, manifest, source_args, state)
        except (Exception, KeyboardInterrupt) as error:
            manifest.data.update(status="failed", error=str(error))
            manifest.save()
            LOG.exception("Stopped. No resources were deleted. Inspect %s and %s before retrying.",
                          manifest.path, source_path)
            raise
        LOG.info("Completed. Evidence: %s", manifest.path)


if __name__ == "__main__":
    main()
