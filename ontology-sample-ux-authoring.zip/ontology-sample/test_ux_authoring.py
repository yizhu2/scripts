import copy
import io
import json
import tempfile
import unittest
from contextlib import ExitStack, redirect_stdout
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from create_ontology import build_definition, build_extension_script, verify_script_result
from create_sample import Api, Manifest, PBI_SCOPE
import run_sample
import ux_authoring as ux
from test_create_ontology import GUID, inventory, metadata

TARGET = "22222222-2222-4222-8222-222222222222"
CAPACITY = "44444444-4444-4444-8444-444444444444"
ITEM = "33333333-3333-4333-8333-333333333333"
HOST = "test.pbidedicated.windows.net"
METADATA = "https://test.analysis.windows.net"
WSPL_HOST = "e60e7807b3914e4988f14223f79e5694.ze6.daily-c.fabric.microsoft.com"
EMPTY = {"model": {"namespaces": [{"name": "default"}]}}


def result_for(script):
    return {"results": [
        {"opIndex": i, "verb": "create", "target": {kind: value["name"]}}
        for i, operation in enumerate(script["sequence"]["operations"])
        for kind, value in operation["create"].items()
    ]}


class RoutingTests(unittest.TestCase):
    def test_public_default_and_explicit_private_routes(self):
        self.assertEqual(ux.routing("public"), (ux.DAILY_METADATA_API, None))
        for network in ("wspl", "tenantpl"):
            self.assertEqual(ux.routing(network, METADATA, HOST), (METADATA, HOST))
        self.assertEqual(ux.routing("wspl", METADATA, WSPL_HOST), (METADATA, WSPL_HOST))

    def test_private_modes_never_guess_or_use_default_public_metadata(self):
        for network in ("wspl", "tenantpl"):
            for origin, host in ((None, None), (METADATA, None), (None, HOST), (ux.DAILY_METADATA_API, HOST)):
                with self.subTest(network=network, origin=origin, host=host), self.assertRaises(ValueError):
                    ux.routing(network, origin, host)

    def test_endpoints_reject_credentials_paths_redirect_parameters_and_non_service_hosts(self):
        for value in (
            "http://test.analysis.windows.net", "https://evil.example",
            "https://test.analysis.windows.net.evil.example", "https://user:test@test.analysis.windows.net",
            METADATA + "/metadata", METADATA + "?token=secret", METADATA + "#secret",
            METADATA + ":443", METADATA + "\\path", METADATA + "\n",
        ):
            with self.subTest(value=value), self.assertRaises(ValueError):
                ux.trusted_origin(value)
        for host in ("https://" + HOST, HOST + "/path", HOST + ":443", "user@" + HOST, "evil.example"):
            with self.subTest(host=host), self.assertRaises(ValueError):
                ux.workload_host(host)

    def test_private_options_are_validated_before_login_or_prompting(self):
        with patch("builtins.input") as prompt, patch("sys.stderr", io.StringIO()):
            for flags in (
                ["--authoring-mode", "ux", "--target-network", "wspl"],
                ["--authoring-mode", "public", "--ux-workload-host", HOST],
                ["--authoring-mode", "ux", "--ux-metadata-api", "https://evil.example"],
            ):
                with self.assertRaises(SystemExit):
                    run_sample.arguments(flags)
        prompt.assert_not_called()

    def test_offline_plan_records_mode_and_routes_without_authentication(self):
        with patch("sample_auth.open_credential") as authenticate, redirect_stdout(io.StringIO()) as output:
            run_sample.main([
                "--tenant-id", GUID, "--workspace-id", TARGET, "--capacity-id", CAPACITY,
                "--authoring-mode", "ux", "--target-network", "wspl",
                "--ux-metadata-api", METADATA, "--ux-workload-host", HOST,
            ])
        plan = json.loads(output.getvalue())
        self.assertEqual(plan["authoringMode"], "ux")
        self.assertEqual(plan["uxMetadataApi"], METADATA)
        self.assertEqual(plan["uxExpectedWorkloadHost"], HOST)
        authenticate.assert_not_called()


class AuthenticationTests(unittest.TestCase):
    def args(self):
        return SimpleNamespace(
            target_network="wspl", ux_metadata_api=METADATA, ux_workload_host=HOST,
            workspace_id=TARGET, timeout=60,
        )

    def test_exchange_uses_target_capacity_workspace_and_item_and_pins_refresh_host(self):
        with patch("ux_authoring.Api") as metadata_api, patch("create_ontology.Api") as workload_api:
            pbi = metadata_api.return_value
            pbi.base = METADATA
            pbi.json.return_value = {"Token": "sensitive-test-token", "TargetUriHost": HOST,
                                    "CapacityObjectId": CAPACITY}
            credential = Mock()
            with ux.open_workload(self.args(), credential, {"capacityId": CAPACITY}, ITEM):
                metadata_api.assert_called_once_with(METADATA, PBI_SCOPE, credential, 60, sensitive_response=True)
                self.assertEqual(pbi.json.call_args.args, (
                    "POST", METADATA + "/metadata/v201606/generatemwctokenv2",
                    {"capacityObjectId": CAPACITY, "workspaceObjectId": TARGET, "workloadType": "DO",
                     "artifacts": [{"artifactType": "Ontology", "artifactObjectId": ITEM}]},
                ))
                call = workload_api.call_args
                self.assertEqual(call.args[0],
                                 f"https://{HOST}/webapi/capacities/{CAPACITY}/workloads/DO/DigitalOperationsService/direct")
                self.assertEqual(call.kwargs["auth_scheme"], "MwcToken")
                mwc = call.args[2]
                self.assertEqual(mwc.get_token("").token, "sensitive-test-token")
                self.assertEqual(pbi.json.call_count, 1)
                mwc.expires = 0
                pbi.json.return_value = {"token": "refreshed", "targetUriHost": HOST, "capacityObjectId": CAPACITY}
                self.assertEqual(mwc.get_token("").token, "refreshed")
                mwc.expires = 0
                pbi.json.return_value = {"Token": "new", "TargetUriHost": "other.pbidedicated.windows.net"}
                with self.assertRaisesRegex(RuntimeError, "does not match"):
                    mwc.get_token("")
            pbi.close.assert_called_once()
            workload_api.return_value.close.assert_called_once()

    def test_user_observed_wspl_host_and_direct_route_are_used_without_rewriting(self):
        args = self.args()
        args.workspace_id = "e60e7807-b391-4e49-88f1-4223f79e5694"
        args.ux_workload_host = WSPL_HOST
        capacity = "a64daa95-f756-494b-be64-ee625df39174"
        with patch("ux_authoring.Api") as metadata_api, patch("create_ontology.Api") as workload_api:
            pbi = metadata_api.return_value
            pbi.base = METADATA
            pbi.json.return_value = {"Token": "test-token", "TargetUriHost": WSPL_HOST,
                                    "CapacityObjectId": capacity}
            with ux.open_workload(args, Mock(), {"capacityId": capacity}, ITEM):
                self.assertEqual(
                    workload_api.call_args.args[0],
                    f"https://{WSPL_HOST}/webapi/capacities/{capacity}/workloads/DO/DigitalOperationsService/direct",
                )

    def test_denied_token_or_untrusted_route_never_calls_workload_or_switches_client(self):
        for response in (
            RuntimeError("HTTP 403"), {"Token": "secret", "TargetUriHost": "evil.example"},
            {"Token": "secret", "TargetUriHost": "other.pbidedicated.windows.net"},
            {"Token": "secret", "TargetUriHost": HOST, "CapacityObjectId": GUID},
            {"TargetUriHost": HOST}, {"Token": {}, "TargetUriHost": HOST},
            {"Token": "secret\ninvalid", "TargetUriHost": HOST}, [],
        ):
            with self.subTest(response=response), patch("ux_authoring.Api") as metadata_api, \
                    patch("create_ontology.Api") as workload_api:
                pbi = metadata_api.return_value
                pbi.base = METADATA
                if isinstance(response, Exception):
                    pbi.json.side_effect = response
                else:
                    pbi.json.return_value = response
                with self.assertRaises((ValueError, RuntimeError)) as error:
                    with ux.open_workload(self.args(), Mock(), {"capacityId": CAPACITY}, ITEM):
                        self.fail("Unexpected workload session")
                self.assertNotIn("secret", str(error.exception))
                workload_api.assert_not_called()
                pbi.close.assert_called_once()

    def test_token_error_body_is_not_logged_or_persisted(self):
        for status in (403, 429):
            with self.subTest(status=status), patch("requests.Session") as session, \
                    patch("create_sample.time.sleep"), ExitStack() as stack:
                logs = stack.enter_context(self.assertLogs("ontology-sample", level="WARNING")) if status == 429 else None
                session.return_value.request.return_value = SimpleNamespace(
                    status_code=status, text="SECRET-RESPONSE", headers={"Retry-After": "0"})
                credential = Mock()
                credential.get_token.return_value.token = "secret-bearer"
                api = Api(METADATA, PBI_SCOPE, credential, 60, sensitive_response=True)
                with self.assertRaises(RuntimeError) as error:
                    api.json("POST", METADATA + "/metadata/v201606/generatemwctokenv2", {})
                self.assertNotIn("SECRET", str(error.exception))
                if logs:
                    self.assertNotIn("SECRET", "\n".join(logs.output))
                kwargs = session.return_value.request.call_args.kwargs
                self.assertEqual(kwargs["headers"]["Authorization"], "Bearer secret-bearer")
                self.assertFalse(kwargs["allow_redirects"])
                api.close()


class AuthoringTests(unittest.TestCase):
    def setup_workload(self, folder, stack, verify=False):
        args = SimpleNamespace(workspace_id=TARGET, timeout=120, verify_only=verify)
        expected = build_definition(inventory(), metadata(), "powerbi://dailyapi.powerbi.com")
        script = build_extension_script(expected, EMPTY)
        workload = stack.enter_context(patch("ux_authoring.open_workload")).return_value.__enter__.return_value
        workload.base = f"https://{HOST}/workload"
        workload.json.side_effect = [expected, expected] if verify else [EMPTY, EMPTY, expected, expected]
        workload.request.return_value = SimpleNamespace(status_code=200, json=lambda: result_for(script))
        manifest = Manifest(folder / "run.json", {})
        return args, expected, script, workload, manifest

    def test_create_sequence_and_direct_readback_verify_all_six_groups(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            args, expected, script, workload, manifest = self.setup_workload(Path(temporary), stack)
            before = copy.deepcopy(expected)
            ux.author_and_verify(args, Mock(), {"capacityId": CAPACITY}, {"id": ITEM}, expected, manifest)
            self.assertEqual(expected, before)
            path = workload.base + f"/v4/workspaces/{TARGET}/ontologies/{ITEM}/definition"
            workload.request.assert_called_once_with("POST", path + "/scripts", script, request_timeout=120)
            operations = script["sequence"]["operations"]
            self.assertEqual(len(operations), 35)
            self.assertEqual([next(iter(op["create"])) for op in operations],
                             ["expression"] * 5 + ["table"] * 18 + ["relationship"] * 12)
            self.assertNotIn("ONT_RESOLVED_", json.dumps(script))
            workload.mutate.assert_not_called()
            self.assertTrue(manifest.data["writeCompleted"])
            self.assertEqual(manifest.data["verified"]["uxDefinition"],
                             {"entities": 18, "boundTables": 18, "relationships": 12, "entityRelationships": 12})
            saved = json.loads(manifest.path.read_text())
            self.assertEqual(saved["authoredScript"], script)
            self.assertEqual(saved["expandedDefinition"], expected)

    def test_verify_only_never_submits_script_or_checks_empty(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            args, expected, _, workload, manifest = self.setup_workload(Path(temporary), stack, verify=True)
            ux.author_and_verify(args, Mock(), {"capacityId": CAPACITY}, {"id": ITEM}, expected, manifest)
            workload.request.assert_not_called()
            self.assertEqual(workload.json.call_count, 2)
            self.assertNotIn("writeCompleted", manifest.data)
            self.assertNotIn("authoredScript", manifest.data)

    def test_nonempty_or_projection_unavailable_stops_before_script(self):
        for failure in ("nonempty", "no-projection"):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
                args, expected, _, workload, manifest = self.setup_workload(Path(temporary), stack)
                workload.json.side_effect = [expected] if failure == "nonempty" else [
                    EMPTY, RuntimeError("HTTP 400: expand is not enabled")]
                with self.assertRaises((ValueError, RuntimeError)):
                    ux.author_and_verify(args, Mock(), {"capacityId": CAPACITY}, {"id": ITEM}, expected, manifest)
                workload.request.assert_not_called()

    def test_failed_or_ambiguous_write_is_not_replayed_or_fallen_back(self):
        for failure in (RuntimeError("HTTP 500"), TimeoutError("timeout")):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
                args, expected, _, workload, manifest = self.setup_workload(Path(temporary), stack)
                workload.request.side_effect = failure
                with self.assertRaises(type(failure)):
                    ux.author_and_verify(args, Mock(), {"capacityId": CAPACITY}, {"id": ITEM}, expected, manifest)
                self.assertEqual(workload.request.call_count, 1)
                workload.mutate.assert_not_called()
                self.assertIn("authoredScript", json.loads(manifest.path.read_text()))
                self.assertNotIn("writeCompleted", manifest.data)

    def test_successful_write_with_invalid_result_keeps_write_evidence(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            args, expected, _, workload, manifest = self.setup_workload(Path(temporary), stack)
            workload.request.return_value = SimpleNamespace(status_code=200, json=lambda: {"results": []})
            with self.assertRaises(ValueError):
                ux.author_and_verify(args, Mock(), {"capacityId": CAPACITY}, {"id": ITEM}, expected, manifest)
            saved = json.loads(manifest.path.read_text())
            self.assertTrue(saved["writeCompleted"])
            self.assertEqual(saved["scriptResult"], {"results": []})
            self.assertNotIn("uxDefinition", saved["verified"])

    def test_missing_annotation_or_wrong_binding_fails_and_keeps_raw_evidence(self):
        for corruption in ("annotation", "source", "entity"):
            with self.subTest(corruption=corruption), tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
                args, expected, _, workload, manifest = self.setup_workload(Path(temporary), stack, verify=True)
                actual = copy.deepcopy(expected)
                partition = actual["model"]["tables"][0]["partitions"][0]
                if corruption == "annotation":
                    partition.pop("annotations")
                elif corruption == "source":
                    partition["source"]["entityName"] = "Wrong"
                else:
                    actual["model"]["entities"].pop()
                workload.json.side_effect = [actual, actual]
                with self.assertRaises(ValueError):
                    ux.author_and_verify(args, Mock(), {"capacityId": CAPACITY}, {"id": ITEM}, expected, manifest)
                self.assertEqual(json.loads(manifest.path.read_text())["expandedDefinition"], actual)
                self.assertNotIn("uxDefinition", manifest.data["verified"])

    def test_malformed_script_results_raise_clear_errors(self):
        script = build_extension_script(build_definition(inventory(), metadata(), "powerbi://dailyapi.powerbi.com"), EMPTY)
        for result in (None, [], {"results": None}, {"results": [None] * 35}):
            with self.subTest(result=result), self.assertRaises(ValueError):
                verify_script_result(script, result)


if __name__ == "__main__":
    unittest.main()
