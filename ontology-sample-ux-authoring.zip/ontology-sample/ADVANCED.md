# Advanced source scripts and troubleshooting

For the packaged, interactive cross-workspace workflow, start with [README.md](README.md)
and [Start-Sample.ps1](Start-Sample.ps1). This reference covers individual
scripts, endpoint overrides, internal authentication requirements, and failure handling.

The main launcher now also accepts `-AuthoringMode ux` (`--authoring-mode ux`
in [run_sample.py](run_sample.py)) for a create-only transactional scripting
sequence and direct UX definition verification. It reuses the same source
workflow and accepts its explicit Semantic Model data deferral. See
[UX authoring setup](README.md#optional-ux-authoring-mode) for MWC exchange
authorization, auto-projection, and the required `-UxMetadataApi` /
`-UxWorkloadHost` inputs for WSPL or tenant PL. The standalone internal companion
below retains its older authentication and source-verification requirements.
Neither switching authoring mode nor an approved browser sign-in grants access
to the internal token service.

**Creates a new workspace and seven source item types, then loads and verifies
non-semantic source data. Semantic Model refresh and row queries are deferred.**
Targets normal Daily; Private Link connectivity must
be configured and validated separately. The tool does not configure private
endpoints, workspace network policies, or DNS.
An Eventhouse is the container for the populated KQL database, not a second copy
of its data.

Entry point: [create_sample.py](create_sample.py). Dependencies:
[requirements.txt](requirements.txt). Tests: [test_create_sample.py](test_create_sample.py).

## What you get

| Item | Data loading | Verification |
|---|---|---|
| Eventhouse + KQL database | `.set` from typed KQL `datatable` literals | Query every row through KQL |
| Lakehouse | Upload typed Parquet to Files; Load Table API creates Delta tables | Query every row through SQL analytics endpoint |
| Mirrored database | Open Mirroring, no external database required | Wait for replicated rows through SQL analytics endpoint |
| Semantic model | Creates inline Power Query import partitions and two many-to-one relationships; no refresh | Row verification deferred; not recorded as verified |
| SQL database | Parameterized T-SQL inserts into new tables | Query every row |
| Warehouse | Parameterized T-SQL inserts into new tables | Query every row |

Every data-bearing item uses the **Plants (3 rows), Assets (12), Readings (120)**
sample definition. Semantic Model rows are not guaranteed to be materialized.
Relationships: `Assets.PlantId -> Plants.PlantId` and
`Readings.AssetId -> Assets.AssetId`. IDs and values are identical across sources.
Readings contain UTC timestamps starting at 2026-01-01, every five minutes, plus
temperature measurements. Source tables have stable unique keys; the script
does not add SQL key constraints. Relationships are explicit in the semantic
model and represented by matching foreign-key values in the other sources.
Parquet timestamps are explicitly UTC-adjusted to keep `ObservedAt` queryable
through the SQL analytics endpoint rather than using Delta `timestamp_ntz`.

The source script does **not** create an Ontology item. For an existing Gen2
ontology, use [replace_ontology.py](replace_ontology.py) to populate source-separated
entity groups through the public API. The [create_ontology.py](create_ontology.py)
internal-route companion is documented separately below with its remaining
limitations. Source creation alone is not proof of working Ontology bindings or
agent readiness.
Semantic models use the core Fabric Items creation API with `type: SemanticModel`.
Source manifests explicitly record the Semantic Model data deferral. The main
launcher accepts it. Replacement requires explicit `--allow-deferred-semantic`;
the internal-route tool still requires full source-data verification. See the
[Semantic Model validation TODO](README.md#todo-semantic-model-data-validation).

## Prerequisites

- Python 3.10+ and Azure CLI.
- [Microsoft ODBC Driver 18 for SQL Server](https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server).
- A **Daily** tenant and existing active Fabric capacity with all requested
  workloads enabled. The caller needs workspace-creation permission and capacity
  assignment rights. The created workspace gives the caller ownership.
- A user identity with the relevant Fabric item permissions, Power BI model
  creation permissions, OneLake writes, and SQL/KQL data access.
  This script intentionally uses a tenant-specific `AzureCliCredential`; it
  neither accepts tokens on the command line nor writes tokens to disk.
- Run from a machine on the approved VNet/VPN with the correct private DNS.
  HTTPS access is needed for Entra, Fabric, Power BI, OneLake, and KQL.
  SQL connections need **TDS**, not HTTPS, over TCP 1433 (plus any SQL routing
  requirements for your environment).

**Important:** existing tenant-level Private Link connectivity does not
automatically configure workspace-level Private Link on a new workspace.
If your policy requires workspace-specific private endpoints or associations,
have your network administrator establish that workflow first. The script does
not disable Block Public Access, add network exceptions, forge service access
headers, or fall back to public endpoints. DNS routing/private-IP enforcement
is the responsibility of the existing network setup.

## Run from PowerShell

To skip all source creation/loading and discover the shipped sample in an
existing workspace, use the main launcher:

```powershell
.\Start-Sample.ps1 -SkipSourceCreation
```

The Python equivalent is an offline plan by default; add `--execute` for live
discovery, read-only source validation, and creation of the target ontology:

```powershell
.\.venv\Scripts\python.exe .\run_sample.py `
    --tenant-id '<daily-tenant-guid>' `
    --source-workspace-id '<existing-source-workspace-guid>' `
    --workspace-id '<target-ontology-workspace-guid>' `
    --target-network wspl
```

For the target, `--target-network` accepts `wspl`, `tenantpl`, or `public`.
WSPL uses the hyphen-free target workspace ID and its first two hex characters
in `https://{wsid}.z{xy}.w.dailyapi.fabric.microsoft.com/v1`. Tenant PL uses
`https://{tenantid}-api.analysis.windows.net/v1`, retaining the tenant GUID's
hyphens. The Python CLI defaults to `public` for compatibility; the PowerShell
launcher asks when `-TargetNetwork` is omitted. Supply the mode explicitly for
unattended use. It applies to target preflight, creation, operation polling, and
definition update/read-back, including manifest reuse and verification-only.
Sources retain their separate normal Daily routing. See
[target routing](README.md#target-workspace-network-routing) for constraints.

No capacity argument or existing source manifest is required. For ambiguous
source types, repeat `--source-item TYPE=GUID`, for example
`--source-item Lakehouse=<lakehouse-guid>`. Missing or incompatible sources fail
before ontology creation. Only the shipped sample schema and exact non-semantic
sample rows are supported; source items, data, and metadata are not modified.
Semantic Model schema export is checked, while refresh/data verification remains
deferred. See [existing workspace reuse](README.md#skip-source-creation-and-use-an-existing-workspace)
for selection rules, permissions, and the new source manifest.

To create new sources using the standalone source script instead:

From this directory:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r .\requirements.txt
az login --tenant '<daily-tenant-guid>' --allow-no-subscriptions

$sampleArgs = @(
    '--tenant-id', '<daily-tenant-guid>',
    '--capacity-id', '<daily-capacity-guid>',
    '--workspace-name', "OntologySources_$(Get-Date -Format yyyyMMdd_HHmmss)",
    '--manifest', '.\daily-sample.manifest.json'
)

# Offline preview: no tokens, resource changes, or manifest writes.
.\.venv\Scripts\python.exe .\create_sample.py @sampleArgs

# Creates billable resources. Add endpoint overrides here if needed.
.\.venv\Scripts\python.exe .\create_sample.py @sampleArgs --execute
```

No sample credentials or environment-specific IDs are embedded in the script.
The CLI uses production Entra authentication and the non-`-int` Power BI token
audience for Daily. Do not use this Daily tool against production.

### Daily / Private Link endpoint overrides

Defaults follow the backend repository's
[Fabric environment registry](https://dev.azure.com/powerbi/MWC/_git/workload-digitaloperations?path=/tools/AIQuestion/aiquestion/fabric/constants.py&version=GBmaster).
The small standalone tool uses the same endpoint/auth conventions without
depending on the larger AIQuestion application or its internal helper APIs.

| Option | Default / discovery |
|---|---|
| `--fabric-api` | `https://dailyapi.fabric.microsoft.com/v1` |
| `--powerbi-api` | `https://wabi-daily-us-east2-redirect.analysis.windows.net` |
| `--onelake-url` | `https://daily-onelake.dfs.fabric.microsoft.com` |
| `--kql-endpoint` | KQL database GET `properties.queryServiceUri` |
| `--kusto-scope` | `https://kusto.kusto.windows.net/.default` |
| `--sql-endpoints` | SQL item GET connection metadata; see below |

Use the **documented connection URLs for your Daily Private Link setup**, not an
arbitrary public endpoint or guessed `privatelink` hostname. OneLake accepts an
origin template containing `{workspaceId}` when the administrator has configured
workspace-scoped routing. It still requires the new workspace's network
association to exist; the template alone does not create it.

SQLDatabase uses returned `serverFqdn` and `databaseName`. Warehouse, Lakehouse,
and MirroredDatabase use their item display name as the SQL catalog and their
returned SQL endpoint host. If Daily exposes a different catalog/host, pass the
actual SQL connection details as a JSON map; for example:

```powershell
$sql = @{
    MirroredDatabase = @{
        server = '<actual-private-sql-fqdn>'
        catalog = '<actual-sql-catalog>'
    }
} | ConvertTo-Json -Compress

.\.venv\Scripts\python.exe .\create_sample.py @sampleArgs --sql-endpoints $sql --execute
```

Endpoint override keys are `Lakehouse`, `MirroredDatabase`, `SQLDatabase`, and
`Warehouse`; each allows `server`, `catalog`, or both. The default item names are
`OntologySample_<ItemType>`; change `--prefix` if needed.

## Recommended: replace an existing Ontology through the public API

[replace_ontology.py](replace_ontology.py) uses the documented Fabric
`getDefinition` and `updateDefinition` APIs with the existing Azure CLI sign-in.
**It does not acquire an MWC token or require the Power BI PowerShell module.**
It replaces the selected ontology's entire definition without changing the seven
populated source items. This also avoids
creating another ontology and its Eventhouse/Graph child resources.

Prerequisites:

- All seven source types have passed verification in the source manifest.
- The target is an existing Gen2 ontology, and its ID and exact display name are
  supplied explicitly. The caller needs the public API's required permissions.
- Python dependencies are installed. The tool generates and reads this sample's
  TMDL directly; no AS SDK, PowerShell serializer, or internal feed is required.

```powershell
$replaceArgs = @(
    '--sources-manifest', '.\daily-sample.manifest.json',
    '--ontology-id', '<existing-ontology-id>',
    '--name', '<exact-existing-ontology-display-name>',
    '--manifest', '.\ontology-replacement.manifest.json'
)

# Offline preview: no authentication.
.\.venv\Scripts\python.exe .\replace_ontology.py @replaceArgs

# Replace the definition and independently read it back.
.\.venv\Scripts\python.exe .\replace_ontology.py @replaceArgs --execute

# Later, verify again WITHOUT another replacement, using a fresh output manifest.
.\.venv\Scripts\python.exe .\replace_ontology.py @replaceArgs `
    --manifest .\ontology-verification.manifest.json --verify-only --execute
```

The script discovers the actual source metadata, generates all six source groups,
and uses [sample_tmdl.py](sample_tmdl.py) to serialize and round-trip the
sample's Gen2 definition before sending it.
The manifest retains the old public definition, submitted parts, write completion,
and read-back evidence. Temporary serializer files are cleaned up automatically.
It does not modify the item's name or `.platform` metadata.

Verification checks 18 entities, their keys and property bindings, 18 bound tables,
and 12 table/entity relationships. Public export uses a portable ALM representation:
SQL connections can contain `ONT_ALM_SQL_*` markers instead of runtime hostnames,
and default projected entity properties/descriptions may be omitted. Verification
checks the markers against the intended workspace/item identity or relative
Warehouse name and checks all backing columns; it does not accept arbitrary
markers, missing entities, changed keys, or changed bindings.

There is no automatic rollback or mutation replay. If `writeCompleted` is true but
read-back fails, use `--verify-only` with a fresh manifest rather than replacing
again. A successful definition check is **not** a graph refresh, data-query,
Operations Agent, or Data Agent sign-off.

## Advanced: internal Ontology API workflow

This workflow requires authorization for both the semantic-model query probe
and the internal MWC token exchange, in addition to Fabric item permissions.
Probe success does not authorize token exchange. Use the public API workflow
unless the target environment and supported authentication client permit the
internal route.

Run [create_ontology.py](create_ontology.py) after **all seven** source types have
passed verification. It reads the successful source manifest, discovers actual
item connection metadata, and creates a new Gen2 Ontology in that workspace.
It does not modify, reload, or recreate any source data.

```powershell
$ontologyArgs = @(
    '--sources-manifest', '.\daily-sample.manifest.json',
    '--name', 'Ontology_AllSources_Sample',
    '--manifest', '.\ontology.manifest.json'
)

# Offline plan.
.\.venv\Scripts\python.exe .\create_ontology.py @ontologyArgs

# For Windows execution, use the official Power BI authentication launcher below.
```

Install Microsoft's Power BI Profile module once, then run the launcher from a
**normal PowerShell window** on your managed Windows device:

```powershell
Install-Module MicrosoftPowerBIMgmt.Profile -RequiredVersion 1.3.84 -Scope CurrentUser -Repository PSGallery

# Keep Azure CLI signed in as the same work account used in the Power BI prompt.
.\create_ontology.ps1 `
    -SourcesManifest .\daily-sample.manifest.json `
    -Name Ontology_AllSources_Sample `
    -Manifest .\ontology.manifest.json `
    -Execute
```

Without `-Execute`, the launcher prints an offline plan without authentication.
Use `-PythonPath` for a virtual environment outside this directory, and
`-ProfileModule` for an isolated installation of the official module. The
Windows broker needs a parent window: a headless agent terminal can fail with
`A window handle must be configured`. Run the launcher in a normal console;
do not disable the broker or switch to device-code to avoid a device policy.

The definition contains **18 entities, 18 bound tables, and 12 relationships**:

| Entity prefix | Binding |
|---|---|
| `Lakehouse_` | OneLake Delta tables, Direct Lake |
| `MirroredDatabase_` | Mirrored OneLake Delta tables in `dbo`, Direct Lake |
| `SQLDatabase_` | Discovered SQL database endpoint/catalog, DirectQuery |
| `Warehouse_` | Discovered Warehouse SQL endpoint/catalog, DirectQuery |
| `SemanticModel_` | DirectQuery to the existing Semantic Model |
| `EventhouseKQL_` | Kusto tables in the KQL database inside the Eventhouse |

Each group has `Plants`, `Assets`, and `Readings`, with many-to-one relationships
from Assets to Plants and Readings to Assets. IDs repeat across groups because
these are **copies for source-comparison testing**, not extra real-world objects.
Eventhouse and KQL are one group, not two copies. Descriptions explicitly warn
agents not to add the identical copies together.

The companion uses the deployed **internal V4 TMSL++ API** and exchanges the
user token for an MWC token in memory. This requires the Gen2 Ontology features
to be enabled in the target Daily tenant. The XMLA default is
`powerbi://dailyapi.powerbi.com`; override `--xmla-base` only with the documented
endpoint for your environment. Its endpoint may differ from the Fabric REST host.

**Authentication:** the Windows launcher uses two clients for the same user:

- Azure CLI handles Fabric item discovery and provisioning, as in the source
  script.
- Microsoft's official `MicrosoftPowerBIMgmt.Profile` client handles the
  semantic-model query probe and attempts the MWC token exchange. It signs in
  using the Windows broker and supplies delegated dataset scopes. Those scopes
  do **not** by themselves authorize the internal token-exchange endpoint.

Both identities must match the source manifest's tenant and each other's user
object ID. The Power BI token travels to Python through stdin, never a command-line
argument, token file, environment variable, or manifest. Its lifetime is checked
before requests; an expiring token stops the run instead of silently switching
credentials. The Public authentication environment is intentional: normal Daily
uses production Entra and the Power BI audience; resource calls use the Daily
endpoints recorded in the source manifest.

Binding a Semantic Model requires the backend's `executeDaxQueries` Build probe.
Ordinary `executeQueries` success is not sufficient. A client/scope rejection
before DAX evaluation does not establish that the owner lacks Build permission.
The companion requires a decoded Arrow probe result of `Result = 1` before
creating an item.

The Python-only `--auth azure-cli` and `--auth device-code` modes remain available
for environments where those flows are explicitly supported.
**If sign-in says the requesting device must be managed, stop.** A successful
browser sign-in does not mean a token was granted. Device-code authentication
does not establish device compliance; use an organization-approved managed
device and supported authentication, or ask IT to confirm the compliant setup.
Do not disable or bypass Conditional Access. This tool does not grant permissions
or bypass the Build probe. Tokens stay in memory and are not included in manifests.
The script probes access before creating or writing an ontology.

If a previous attempt created an **empty** ontology, add
`--ontology-id '<existing-id>'` with its exact `--name` and a new manifest path.
Nonempty definitions are refused by default; this is not general resume or
replace support.

To deliberately add the six source groups to a **nonempty** ontology while
preserving existing content, use the explicit append mode:

```powershell
.\create_ontology.ps1 `
    -SourcesManifest .\daily-sample.manifest.json `
    -Name '<exact-existing-ontology-name>' `
    -OntologyId '<existing-ontology-id>' `
    -ExtendExisting `
    -Manifest .\ontology-extension.manifest.json `
    -Execute
```

Append mode requires the tenant's auto-projection feature and its existing default
namespace. It saves canonical and expanded before-snapshots in the manifest, then
submits one transactional `definition/scripts` sequence: five expressions,
18 bound tables, and 12 relationships. Every operation is a strict **create**,
never replace, alter, or delete. Auto-projection supplies the 18 corresponding
entities and 12 entity relationships. Existing authored or projected name
collisions are refused; backend transaction conflicts do not overwrite objects.
Read-back checks both the added bindings and preservation of the existing content.
It ignores only the service-generated partition annotation `ONT_RESOLVED_At`,
which changes when the backend refreshes binding-resolution metadata; source
bindings, user metadata, keys, and relationships remain checked.

Inspect the recorded item and operation after failures before rerunning.
In particular, a timeout or failed read-back can occur after a committed write.
Do not replay an append blindly: inspect the saved definition first. The tool
never deletes partial child resources from failed ontology creation.

Success verifies the saved definition's source expressions, column bindings,
entity keys, and relationships, not merely collection counts. **Definition
read-back is not a query, graph-materialization, Operations Agent, or Data Agent
sign-off.** Agent creation and configuration are separate follow-up work.

Suggested later agent checks, repeated for each source prefix:

- List all three plants and their cities.
- Count assets per plant: four each.
- List readings for A012: ten rows.
- Find the maximum temperature: 32.9 C, A012, R0120,
  2026-01-01 00:45:00 UTC.
- Follow R0120 to A012 and then P03 / East Plant / Boston.

Use the explicit sample date, not "today" or "last 24 hours": the deterministic
readings are historical. These are expected answers, not evidence that an agent
has already returned them.

## Completion, failures, and cleanup

For isolated testing of the other five sources, pass `--skip-eventhouse-kql`.
The manifest explicitly records both skipped types; success then covers only
the five requested sources, not all seven. Default runs still include all seven.
To avoid creating another workspace after an early failure, `--workspace-id`
can reuse an **empty** workspace: its display name and capacity must match the
supplied arguments and its item list must be empty. This is not resume support
for a partially populated workspace. Use a new manifest path for each attempt.

For an existing non-empty sample workspace, use the
[selected-source retry mode](README.md#retry-one-source-type). Its Python entry
point is [retry_source.py](retry_source.py):

```powershell
python .\retry_source.py --sources-manifest .\sources.manifest.json `
  --source-type KQLDatabase --run-directory .\runs\retry-kql --execute
```

Omit `--execute` for a preview. Add `--verify-only` to check existing items
without creating or loading data. Setup retries retain old items and recreate
only the selected type and required dependencies, never the workspace.
Fabric, Power BI and OneLake endpoints come from the input manifest; KQL and
SQL targets are discovered from item metadata. An explicit `--kql-endpoint`
override is available for an approved query-service origin; private-network
routing is not configured automatically.

- A zero exit code **after `--execute`** means the requested source items were
  created and non-semantic data passed verification. Semantic Model refresh and
  row validation remain deferred. A preview is not a deployment.
- The manifest records workspace/item IDs as creation completes, the current
  step, accepted operation URLs, expected counts, per-source verification, and
  deferred Semantic Model validation.
  Full row comparisons also detect wrong values, duplicate keys, and missing
  rows. Floating-point measurements are compared to six decimal places.
- HTTP and polling waits are bounded; `--timeout` defaults to 1,800 seconds per
  operation/table wait, not a total run limit. `Retry-After` is honored for HTTP
  retries and Fabric operations. Missing or failed endpoints are not skipped.
- All source items are created before loading; KQL loads last, after a read-only
  readiness probe succeeds. Sample-row verification is deferred until every
  load and initial SQL metadata refresh completes, followed by `--settle-seconds`
  (default 120). Status/connectivity probes still run during provisioning.
- `--kql-request-timeout` defaults to 300 seconds per HTTP read, capped by
  `--timeout`, with a separate 30-second connection timeout. Only read-only KQL
  readiness/verification timeout exceptions are retried. An ingestion timeout
  has an unknown write outcome and is never automatically replayed.
- Lakehouse and mirrored-database verification explicitly refresh SQL endpoint
  metadata with `recreateTables: false` before the settling period, not again
  immediately before reading. While waiting for missing tables or
  replicated rows, a refresh is retried at most once a minute. Refresh failures
  are surfaced; tables are never dropped or recreated by this refresh.
- The first failure stops the run with a nonzero exit code. There is no automatic
  rollback, resume, mutation replay after ambiguous network failures, or deletion.
  If a create request was accepted but its response was lost, inspect the
  workspace/operation before starting another run.
- An existing manifest path is refused. To run a fresh independent sample, use a
  new workspace name and manifest path. Do not replay Open Mirroring's initial
  INSERT files into an existing mirrored item.
- Open Mirroring uploads metadata first, uploads the initial Parquet file with
  an ignored underscore prefix, then atomically renames it to
  `00000000000000000001.parquet`. The optional CDC marker column is omitted for
  this initial INSERT-only load.
- OneLake uploads use the SDK's create-and-upload path with an `If-None-Match: *`
  condition, so new files are created but existing files are not overwritten.
- Use `MatchConditions.IfMissing` without an explicit `etag`: the SDK supplies
  the wildcard header itself. Supplying both leaves the unused `etag` argument
  to reach `requests.Session.request`, which rejects it before sending the file
  creation request.
- Delete **only the newly created sample workspace** in the Daily portal when
  finished, after confirming its ID in the manifest. This removes its sample
  items and avoids leaving resources running. The script does not delete
  anything automatically.

For 403/network failures, check the private network path, identity permissions,
and Daily workload flags. For cross-host operation/refresh URLs, configure the
correct Daily API origin; the script deliberately refuses to forward tokens
across hosts. For mirror/lakehouse timeouts, inspect replication and SQL endpoint
provisioning before increasing the timeout. Do not treat `Running` mirroring or
uploaded files alone as proof that sample data is queryable.

## Testing and environment requirements

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s . -p 'test_*.py' -v
```

Tests cover data integrity, definitions, Parquet types, polling/failure handling,
safe publication, SQL/DAX/KQL verification, and offline preview behavior. They
do not replace a live run. **Daily Private Link feature availability and end-to-end behavior
must still be validated with your tenant, capacity, and network**.

## API references

- [Create workspace](https://learn.microsoft.com/en-us/rest/api/fabric/core/workspaces/create-workspace)
- [Create KQL database](https://learn.microsoft.com/en-us/rest/api/fabric/kqldatabase/items/create-kql-database)
- [Kusto REST response and partial failures](https://learn.microsoft.com/en-us/kusto/api/rest/response)
- [Lakehouse Load Table](https://learn.microsoft.com/en-us/rest/api/fabric/lakehouse/tables/load-table)
- [Open Mirroring definition](https://learn.microsoft.com/en-us/rest/api/fabric/articles/item-management/definitions/mirrored-database-definition)
- [Open Mirroring landing zone](https://learn.microsoft.com/en-us/fabric/mirroring/open-mirroring-landing-zone-format)
- [Open Mirroring publication guidance](https://learn.microsoft.com/en-us/fabric/mirroring/open-mirroring-best-practices)
- [Get SQL database](https://learn.microsoft.com/en-us/rest/api/fabric/sqldatabase/items/get-sql-database)
- [SQL connectivity](https://learn.microsoft.com/en-us/fabric/data-warehouse/connectivity)
- [Refresh SQL endpoint metadata](https://learn.microsoft.com/en-us/rest/api/fabric/sqlendpoint/items/refresh-sql-endpoint-metadata)
- [Semantic model definition](https://learn.microsoft.com/en-us/rest/api/fabric/articles/item-management/definitions/semantic-model-definition)
- [Dataset Execute Queries](https://learn.microsoft.com/en-us/rest/api/power-bi/datasets/execute-queries-in-group)
- [Official Power BI user sign-in](https://learn.microsoft.com/en-us/powershell/module/microsoftpowerbimgmt.profile/connect-powerbiserviceaccount)
- [Get Ontology definition](https://learn.microsoft.com/en-us/rest/api/fabric/ontology/items/get-ontology-definition)
- [Update Ontology definition](https://learn.microsoft.com/en-us/rest/api/fabric/ontology/items/update-ontology-definition)
- [Fabric Private Link](https://learn.microsoft.com/en-us/fabric/security/security-private-links-overview)
