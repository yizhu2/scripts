# Daily Fabric: seven sources and one bound ontology

Run **[Start-Sample.ps1](Start-Sample.ps1)** from this directory or an extracted ZIP. It prepares a
local Python environment and asks for:

1. **Tenant ID**.
2. **Capacity ID** for a new source workspace.
3. **Workspace ID** of the existing workspace where the ontology should be created.

**The wrapped workflow requires no Analysis Services SDK, NuGet feed access, Azure DevOps
permissions, .NET SDK, or PowerShell 7.** It writes and reads the sample's TMDL
definition directly in Python.

The source workspace and target workspace are **different**. A Lakehouse cannot
contain other Fabric item types; the seven sources are sibling items in the new
source workspace. The existing target workspace is not cleared, reassigned to
another capacity, or otherwise reused for source storage.

## Result and covered scenarios

| Scenario | This package |
|---|---|
| Create a new source workspace on your supplied capacity | Implemented |
| Create Eventhouse, KQL database, Lakehouse, Open Mirrored database, Semantic Model, SQL database, and Warehouse | Non-semantic sources are populated and row-verified; Semantic Model refresh and row queries are deferred |
| Provision first, then wait before reading sample data | All source items are created first; loads and initial SQL metadata refreshes finish before a configurable settling period and row verification |
| Create a new Gen2 ontology in your supplied target workspace | Implemented through Fabric public APIs |
| Bind every source group to that ontology | 18 entities/bound tables and 12 relationships, verified by public read-back |
| Browser sign-in when cached CLI credentials are unavailable | Interactive CLI browser login, then optional approved-client browser authentication |
| Generate and verify the ontology definition without an AS SDK | Implemented directly in Python; no package-feed calls |
| Reuse successful source provisioning after inspecting a failed ontology creation | Explicit `-SourcesManifest` option; accepts recorded Semantic Model data deferral and never replays source loads |
| Verify an existing ontology without writing | `-VerifyOnly`, with source manifest and exact ontology ID/name |
| Create a **second** ontology from the sample semantic model | Optional companion; uses the UX's native Gen2 import path and verifies 3 bound tables and 2 relationships |
| Test native semantic-model Import/Promote | Implemented: requires backend `Active`, feature level 2 and `SemanticModelImportStatus: Completed`; no client-authored definition |
| Create a Data Agent artifact | Optional companion; unpublished draft referencing the sample semantic model |
| Create an Operations Agent artifact | Optional companion; inactive, unconfigured artifact. Configured creation requires a service-accepted playbook |
| Query through the ontology, refresh its graph, or validate agent answers/actions | Separate validation; not performed by this package |

The sample defines **Plants (3 rows), Assets (12), and Readings (120)**, with stable
keys and UTC timestamps. Non-semantic sources are loaded and verified; the
Semantic Model is created with inline import partitions but is not refreshed
or row-queried. Its data is not guaranteed to be materialized. The relationships are
`Assets.PlantId -> Plants.PlantId` and `Readings.AssetId -> Assets.AssetId`.
Eventhouse is the KQL database container, so seven source types produce **six**
source groups, not seven copies of the data. Fabric can additionally create
service-managed child items; seven source types does not imply exactly seven
total workspace items.

The ontology groups are `EventhouseKQL`, `Lakehouse`, `MirroredDatabase`,
`SemanticModel`, `SQLDatabase`, and `Warehouse`, each with Plants/Assets/Readings.
Bindings retain the **source** workspace/item identities; the target workspace
is used only for the ontology. Do not sum the identical source copies together.

## Prerequisites

- Windows, **Python 3.10+**, and **Windows PowerShell 5.1 or newer**.
- [Microsoft ODBC Driver 18 for SQL Server](https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server).
- Azure CLI for the preferred authentication route. It is optional if you use
  an approved application for direct browser authentication.
- A **normal Daily** tenant/capacity with all required workloads enabled.
  The target workspace must already be assigned to a Fabric capacity; it may
  have a different capacity from the new source workspace.
- Permission to create/assign workspaces and create ontology items in the target;
  access to all source items, OneLake, SQL/KQL, and Semantic Model
  creation and any source access required by server-side ontology binding validation.
- Approved network access to Entra, Fabric, Power BI, OneLake, Kusto and SQL.
  SQL requires TDS connectivity, including TCP 1433 and applicable routing ports.
  Existing Private Link/VPN/DNS policies remain unchanged. The launcher does
  not establish workspace-specific private endpoints or bypass network policies.

This package does **not** install system prerequisites, download or bundle AS SDK
binaries, change Conditional Access, or create app registrations/admin consent.

## TODO: Semantic Model data validation

- [ ] Restore explicit Semantic Model refresh and sample-row validation after
  endpoint routing and API authorization are validated in the target environment.

The main workflow does not call the model's `/refreshes` or `/executeQueries`
endpoints. It still creates the model and includes its ontology bindings.
Both run manifests record `deferredValidation.SemanticModel` as
`["refresh", "sampleRows"]`; no Semantic Model row counts are marked verified.
Completion means ontology definition read-back and the other sources' row checks
passed, not that Semantic Model or ontology data queries work.

The replacement, internal-route and agent companions retain their full source-data
verification requirement and do not accept this deferral. The native semantic-model
import companion does not require source refresh or row verification.

## TODO: Scenario-aware endpoint configuration

- [ ] Configure and validate endpoints for each scenario:
  - Normal Daily without Private Link: standard Fabric and Power BI routing.
  - Tenant-level Private Link (TPA on), with BPA off or on: use the service's
    assigned tenant endpoint and verify DNS/network routing from the calling VM.
    A `Public` classification alone does not explain a rejection when BPA is off.
  - Workspace-level Private Link (WSPL): use the exact configured workspace FQDN
    and private endpoint association; never guess the `z<zone>` component.
  - Mixed source/destination scenarios, including a non-WSPL Semantic Model
    source and a WSPL ontology destination: configure their routing separately.
- [ ] Expose the required endpoint configuration in the launchers and companions,
  including creation, polling, and definition read-back. Do not assume Fabric
  public API paths and UX `/metadata/...` paths support interchangeable hosts.
- [ ] Add read-only preflight checks and tests for these scenarios before writes;
  validate native semantic-model import using sanitized request examples without
  collecting bearer tokens, changing network policy, or falling back to public access.

These endpoint-selection scenarios are pending implementation and live validation;
the current package is not a tenant-level or workspace-level Private Link sign-off.

## Run

Open a normal interactive PowerShell window in this directory or a writable
extraction of the entire ZIP, and run:

```powershell
.\Start-Sample.ps1
```

No virtual-environment activation is required. The launcher creates
`.venv\Scripts\python.exe` when missing, installs [requirements.txt](requirements.txt)
when dependencies are missing or the requirements change, asks for the three
IDs, and requires typing **CREATE** before executing. It may also request an
approved browser-client ID when CLI authentication is unavailable.
Follow your organization's script-signing/execution policy if execution is
blocked; this package does not disable that policy.
If Python is installed but not on PATH, provide
`-PythonExecutable 'C:\path\to\python.exe'` for initial setup.

For an offline plan without Fabric calls or resource creation:

```powershell
.\Start-Sample.ps1 -PlanOnly
```

The launcher may still install local Python dependencies for that first preview.
The underlying Python preview needs no authentication.

Optional explicit values:

```powershell
.\Start-Sample.ps1 `
    -TenantId '<tenant-guid>' `
    -CapacityId '<source-capacity-guid>' `
    -WorkspaceId '<target-workspace-guid>' `
    -OntologyName 'Ontology_AllSources_Demo'
```

Unique source workspace/item names and a unique default ontology name are
generated automatically. A matching name in the target workspace is rejected,
including matches on later item-list pages. Existing ontologies are never
overwritten by this launcher.

### Provision first, then wait and verify

Provisioning/loading is separate from sample-row verification:

1. Create all seven source types.
2. Load Lakehouse, MirroredDatabase, SQL Database and Warehouse. Defer Semantic
   Model refresh and row queries. Load KQL last, giving the newly created Eventhouse more time
   to initialize. A read-only `print Ready = 1` probe must succeed before KQL
   ingestion; probe timeouts can be retried without replaying writes.
3. Refresh Lakehouse/MirroredDatabase SQL metadata with `recreateTables: false`.
4. **Wait 120 seconds by default**, after those metadata refreshes.
5. Verify non-semantic sources' sample rows, then create and read back the bound
   ontology definition, including the Semantic Model bindings.

Status polling and SQL connectivity probes remain necessary while loading.
Sample-row reads do not happen immediately after each individual source
load. Verification does not immediately trigger another initial SQL refresh
after the settling period. Existing bounded readiness/replication retries remain
in place: waiting a fixed time is not proof of readiness.

For a longer settling period and slower Kusto responses:

```powershell
.\Start-Sample.ps1 -SettleSeconds 300 -KqlRequestTimeoutSeconds 600
```

`-SettleSeconds` accepts 0-86400 seconds; 0 removes only the settling delay, not
verification. `-KqlRequestTimeoutSeconds` accepts 30-3600 seconds and defaults to
300, capped by `-TimeoutSeconds`. It controls the HTTP **read** timeout for each
KQL request; the connection timeout is 30 seconds. Other HTTP requests keep
their existing timeouts. Python equivalents are `--settle-seconds` and
`--kql-request-timeout` in both source and wrapped workflows.

The settling delay is additional to the existing per-operation/per-table
timeout. Successfully reused sources and ontology-only verification do not wait
or reload sources. New manifests record the settings and `sourceLoadsCompleted`
after all non-semantic loads return successfully; that flag alone does **not** mean verified
or make a failed run resumable.

## Sign-in

The default `-Auth auto` tries the cached Azure CLI identity in the requested
tenant. If unavailable, it offers interactive **browser** login through the
actual Azure CLI client, without device-code login or changing global CLI
settings. Use a normal interactive terminal on the requesting machine.

If CLI is unavailable/blocked or you decline it, the launcher can use
`InteractiveBrowserCredential` with an **organization-approved public-client
application ID**. It prompts for that ID, or you can supply:

```powershell
.\Start-Sample.ps1 -Auth browser -ClientId '<approved-public-client-app-guid>'
```

The registration must have a **Mobile and desktop applications** redirect URI
of **`http://localhost:8400`**; local port **8400** must be available. It also
needs delegated permissions/consent for the required resources: Fabric/Power BI, Azure Storage,
Azure SQL and Azure Data Explorer. No Azure DevOps scope or package-feed
permission is requested. Relevant Fabric operations include workspace
creation and item read/write. The main workflow does not require client-side
dataset refresh or Execute Queries calls. Have your administrator approve the exact permissions for your
tenant. API authorization and data-plane access are separate from successful
sign-in. Do not substitute arbitrary first-party app IDs.

All required token audiences are checked before new source provisioning.
The same credential is reused throughout the workflow. Authentication fallback
occurs only before resource creation, not silently after a service rejects an
operation. Browser authentication cannot overcome missing permissions, consent,
or a managed-device requirement. `-Auth cli` restricts authentication to Azure CLI.

Tokens are not passed on command lines or written to package manifests. Direct
browser tokens are held in memory; Azure CLI manages its own normal user cache.
The public ontology route does not require a client-side MWC token exchange.

## SDK-free definition handling

[sample_tmdl.py](sample_tmdl.py) writes the database, model, tables, entities,
relationships, expressions and namespace TMDL documents needed by this sample.
The generated files are parsed back and structurally checked before submission.
After the public API write, the returned definition is independently parsed and
verified for source identity, keys, columns and relationships.

This is a deliberately limited **sample-format codec**, not a general-purpose
TMDL implementation or replacement for TOM. Unsupported syntax and malformed or
duplicate declarations fail explicitly rather than being ignored. It does not
fetch packages, load DLLs, invoke a serializer subprocess, or request an Azure
DevOps token. Fabric still performs its normal server-side authorization and
definition validation.

## Evidence, failures and safe follow-up

Outputs are written under a new `runs\<unique-run-id>` directory in your current
working directory, or the explicit `-RunDirectory`:

- `sources.manifest.json`: source workspace, seven source item IDs, stages,
  operations, non-semantic expected-data verification, and deferred Semantic Model validation.
- `run.manifest.json`: target workspace, created ontology ID, submitted/read-back
  definition, verified binding counts, deferred source validation, and success/failure status.

Existing run directories are refused. **No automatic rollback or deletion is
performed.** Source provisioning is not generally resumable: do not replay
Open Mirroring INSERT files or blindly rerun after a failed creation. Inspect
both manifests and any pending operation first.

If sources succeeded but ontology creation failed, inspect the target for
partial child resources before deliberately creating a new ontology using:

```powershell
.\Start-Sample.ps1 -SourcesManifest '.\runs\<old-run>\sources.manifest.json'
```

If `writeCompleted` is true but verification failed, **do not create again**.
Use a fresh output directory and a read-only check:

```powershell
.\Start-Sample.ps1 -VerifyOnly `
    -TenantId '<tenant-guid>' -CapacityId '<source-capacity-guid>' `
    -WorkspaceId '<target-workspace-guid>' `
    -SourcesManifest '.\runs\<old-run>\sources.manifest.json' `
    -OntologyId '<created-ontology-guid>' -OntologyName '<exact-name>'
```

If the ontology exists but its definition write failed, the launcher refuses to
overwrite it. Inspect it before using the separate explicit
[replacement utility](replace_ontology.py), which accepts `--target-workspace-id`.
See [advanced usage and troubleshooting](ADVANCED.md).

Public export may normalize SQL bindings to portable identity markers and omit
default projected entity properties. Verification checks exact source identity,
keys, columns and topology, not textual equality alone. A target-relative
Warehouse binding is rejected for a cross-workspace ontology.

### SQL login error accompanied by "Database is in transition" (952)

SQL analytics can still be transitioning after Lakehouse load and metadata
refresh report success. ODBC may wrap native SQL error **952** in SQLSTATE
`28000`, alongside `Login failed for user '<token-identified principal>'`
and error `18456`. This combination is not sufficient evidence of a permissions
problem.

The script recognizes native error 952 in bounded SQL-readiness and
asynchronous row-verification retries (including Lakehouse and Open Mirroring).
Each failure is logged; only connection/read checks are repeated, not data
loads or SQL writes. The existing timeout still applies. A genuine login error
18456 **without** a recognized transient diagnostic still fails immediately.

If verification stops, keep both manifests. Sources may contain loaded data,
but the complete dataset has not been verified. **Do not pass a failed source
manifest to the full launcher's `-SourcesManifest`, edit it to say succeeded,
or replay its loads.** Failed source provisioning is not automatically resumable.
Running the full launcher again creates a **new source workspace**, not a
continuation of the old one. Existing resources are retained and may continue
to incur charges; cleanup requires a separate deliberate step.

### Snapshot isolation / concurrent DDL error (3961)

This is a different transient failure from 952. SQL can accept the connection
and then reject a SELECT because a concurrent DDL transaction changed the
object's metadata after the query transaction began. Lakehouse metadata
synchronization can overlap verification even after load/refresh reports
success; the error alone does not identify the concurrent writer.

The script recognizes native SQL error **3961**, including when exposed as
`pyodbc.ProgrammingError` with SQLSTATE `42000`. The existing asynchronous
Lakehouse/MirroredDatabase verification closes the failed connection, waits,
then opens another connection and retries the read in a fresh transaction.
It does not request another metadata refresh merely because of 3961, replay
uploads or INSERTs, or retry SQL writes. Persistent conflicts still time out,
and ordinary syntax/permission errors are not blanket-retried.

Regression tests inject this error during query execution and result fetching,
check connection disposal before reconnecting, and cover timeout and non-replay
of writes. A successful run against settled metadata does not exercise every
cold-provisioning interleaving.

### Kusto HTTPS read timeout during ingestion or verification

`requests.exceptions.ReadTimeout` from a `*.kusto.fabric.microsoft.com` host is
an HTTP response timeout, not SQL error 952/3961. Check the original Python
stack and the manifest's current step: a failure in `seed_kql` calling the
management route is an **ingestion** failure, not a verification failure.
The PowerShell launcher's final exception is only a summary.

The KQL response timeout defaults to 300 seconds, configurable above.
The script runs a retryable read-only readiness probe
before ingestion. Read-only KQL verification queries also retry timeout
exceptions within the per-table wait budget. Authentication, permission,
malformed results and row mismatches still fail explicitly.

An ingestion timeout leaves the write outcome **unknown**: some commands or rows
may already have committed. The script logs the table name and does not replay
that write or mark it verified. Waiting only before verification cannot fix an
earlier ingestion timeout. Cold startup is one possible cause of a delayed
response, but a timeout alone does not establish its cause or rule out network
or service problems. Inspect the saved source workspace/item IDs before any
new run; existing partial resources are retained.

## Optional next-step artifacts

Native semantic-model import accepts a partial or failed source manifest containing
the existing Semantic Model; source refresh and seven-source verification are not
prerequisites. Agent companions still require a successful, fully row-verified
source manifest; they reject the main workflow's Semantic Model data deferral.
These companions do not load data again or change the all-source ontology.
Run them after the main launcher has prepared `.venv`. Pass your target workspace
explicitly: otherwise they default to the **source workspace**.

### Second ontology using native semantic-model import

```powershell
.\.venv\Scripts\python.exe .\create_semantic_ontology.py `
    --sources-manifest '.\runs\<old-run>\sources.manifest.json' `
    --workspace-id '<target-workspace-guid>' `
    --name Ontology_NativeSemanticImport_Demo `
    --manifest '.\semantic-ontology.manifest.json' --execute
```

The companion uses the **same native Gen2 semantic-model import path used by the UX**:

1. Export the source model using public `getDefinition` with `format=TMSL` and
   check the sample tables, columns, types and relationships before any creation.
2. POST to the source manifest's Power BI endpoint at
   `/metadata/workspaces/{target-workspace-id}/artifacts`, with this envelope:

   ```json
   {
     "artifactType": "Ontology",
     "displayName": "<new-ontology-name>",
     "payloadContentType": "InlineJson",
     "workloadPayload": "{\"semanticModelImportConfiguration\":{\"workspaceId\":\"<source-workspace-id>\",\"itemId\":\"<source-semantic-model-id>\"},\"featureLevel\":2}"
   }
   ```

3. Persist the returned `objectId` immediately. A native HTTP 202 contains
   artifact metadata, **not** a public API Location-based operation.
4. Poll `/metadata/artifacts/{objectId}` until the backend reports both
   `provisionState: Active` and `SemanticModelImportStatus: Completed`, with
   `FeatureLevel: 2`. Import completion alone is insufficient while child
   provisioning is still in progress.
5. Read the native-generated definition using public ontology `getDefinition`.
   Check the three original table names, column types/source columns, DirectQuery
   partitions, source workspace/item annotations, shared expression and two
   relationships. The public export's workspace-name placeholder is accepted
   only with the exact pinned source identities.

The companion does **not** submit an ontology definition, call
`updateDefinition`, or fall back to client-side construction. The backend runs
the native `PromoteAsync` pipeline. This preserves native naming and projection:
the sample read-back checker expects Plants/Assets/Readings tables and two
relationships without explicit entity declarations. The script does not invent
entity keys or add entities afterward.

This creation route is a **UX/internal artifact API**, not a documented public
Fabric creation contract. The client and tenant must authorize this route;
browser sign-in cannot bypass API permissions. The `--auth` options
are retained; no MWC-token exchange or SDK is required.

The sample precheck/read-back checker deliberately supports only the shipped
Plants/Assets/Readings model, not arbitrary models or measures/hierarchies.
**The companion does not execute ontology data queries.** Source inventory and
pre-existing ontologies are not modified. An ontology without completed native
import status fails native-status verification.

### Data Agent draft

```powershell
.\.venv\Scripts\python.exe .\create_sample_agent.py --kind data `
    --sources-manifest '.\runs\<old-run>\sources.manifest.json' `
    --workspace-id '<target-workspace-guid>' --name DataAgent_Sample_Demo `
    --manifest '.\data-agent.manifest.json' --execute
```

This creates an unpublished draft referencing the sample **Semantic Model**,
with Plants, Assets and Readings selected by name, not either ontology. Public
read-back verifies the source IDs, instructions, selections and absence of
published parts. Supported datasource types are defined by the published Data
Agent schema; this companion uses a Semantic Model, not an Ontology. No published
definition or publish-info part is submitted. Agent answers are not validated.

### Operations Agent artifact

```powershell
.\.venv\Scripts\python.exe .\create_sample_agent.py --kind operations --unconfigured `
    --sources-manifest '.\runs\<old-run>\sources.manifest.json' `
    --workspace-id '<target-workspace-guid>' --name OperationsAgent_Sample_Demo `
    --manifest '.\operations-agent.manifest.json' --execute
```

This deliberately creates an **unconfigured, inactive artifact** and checks its
reported state. It does **not** attach an ontology or author a playbook. Connect
the desired ontology and author/review the playbook in Fabric before testing.
Monitoring, notifications, publishing and external actions remain disabled.
Operations Agent requires an eligible paid capacity, tenant rollout and a user
identity; this is not a service-principal scenario.

**Empty-playbook limitation:** configured creation can return HTTP 400,
`No rule definitions available in the playbook.`, even with `shouldRun: false`.
An inactive state does not remove the service's playbook-validation requirements.

The configured request is available for environments where an empty playbook
is accepted: omit `--unconfigured`, supply
`--ontology-id`, and optionally `--ontology-workspace-id` (defaults to agent
workspace). Validate this contract in the target environment. It never silently
falls back to an unconfigured artifact or fabricates runnable rules/actions.

### Preview, sign-in and recovery

Omit `--execute` for an offline preview. All companions accept `--auth
auto|cli|browser` and `--client-id` using the same browser-capable authentication
as the main launcher. Each execution requires a **new manifest path**. Name
collisions are refused and no resources are deleted or overwritten.

After an ambiguous failure, inspect the saved operation and workspace first.
If an item exists, do not create again. Recheck with the same source/name/
workspace options, a fresh manifest path, `--execute --verify-only`, and:

- Second ontology: `--ontology-id '<existing-id>'`.
- Agent: `--item-id '<existing-id>'`; retain the original `--kind` and
  `--unconfigured` or ontology-source options.

### Remaining acceptance scenarios

- Native import checks support the supplied sample in normal Daily;
  arbitrary models, additional metadata and other environments require separate
  validation.
- Configure the Operations Agent ontology/playbook, review its behavior, then
  explicitly authorize starting monitoring or enabling notifications/actions.
- Validate Data Agent answers before publishing.
- For each ontology source group, ask which asset has the highest temperature
  and which plant owns it. Expected: **A012, 32.9 C, P03 / East Plant / Boston**,
  reading R0120 at 2026-01-01 00:45 UTC. Counts are 3 plants, 12 assets and 120
  readings **per copy**, not summed across the identical source groups.

## Testing and validation scope

Offline tests cover deterministic sample data, source provisioning and verification,
native import payloads and status checks, definition read-back, authentication
selection, timeout/retry handling, and package contents. They do not establish
tenant-policy compatibility, Private Link routing, or cold-start service readiness.
Validate those separately in the intended environment.

Source data checks and definition verification do not establish that ontology
queries, graph refresh, or agents work. Verify query results and agent behavior
before publishing or enabling actions.

Run offline regression tests after dependency setup:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s . -p 'test_*.py'
```

Public API references:
[create ontology](https://learn.microsoft.com/en-us/rest/api/fabric/ontology/items/create-ontology),
[get definition](https://learn.microsoft.com/en-us/rest/api/fabric/ontology/items/get-ontology-definition),
[update definition](https://learn.microsoft.com/en-us/rest/api/fabric/ontology/items/update-ontology-definition),
[create Data Agent](https://learn.microsoft.com/en-us/rest/api/fabric/dataagent/items/create-data-agent),
[Data Agent definition](https://learn.microsoft.com/en-us/rest/api/fabric/articles/item-management/definitions/data-agent-definition),
[Data Agent datasource schema](https://developer.microsoft.com/json-schemas/fabric/item/dataAgent/definition/dataSource/1.0.0/schema.json),
[create Operations Agent](https://learn.microsoft.com/en-us/rest/api/fabric/operationsagent/items/create-operations-agent),
[Operations Agent definition](https://learn.microsoft.com/en-us/rest/api/fabric/articles/item-management/definitions/operations-agent-definition),
[interactive browser credential](https://learn.microsoft.com/en-us/python/api/azure-identity/azure.identity.interactivebrowsercredential).

The ZIP contains an explicit file allowlist and a `PACKAGE.json` SHA-256 inventory.
To rebuild it from these sources without including local environments, tokens,
manifests, or SDK binaries:

```powershell
.\.venv\Scripts\python.exe .\build_package.py --output .\ontology-sample.zip
```
