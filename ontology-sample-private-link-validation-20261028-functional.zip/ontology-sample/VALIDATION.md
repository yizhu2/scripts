# Standalone agent validation on Daily / Private Link

Use [Start-Validation.ps1](Start-Validation.ps1) **after provisioning**, including when
[Start-Sample.ps1](Start-Sample.ps1) stopped at a resolver/readback check but retained
an ontology. This runner does not call the provisioning workflow or require its
final verification to pass. It never needs a coding assistant, Azure DevOps,
Kusto investigation access, or a local backend.

**This is a functional test runner, not automatic Private Link certification.**
It records missing network/identity acceptance checks explicitly. An answer or
HTTP 200 is not proof of actual source reads or enforced private connectivity.
**ALM import/export tests are excluded for every agent.** Existing Data Agents
are queried without `getDefinition` or a replacement configuration-read gate.
Operations runtime is explicitly SKIP, not substituted with a playbook import test.

## 1. Prepare once

Use the existing sample Python environment (Python 3.10+ and
[requirements.txt](requirements.txt)); the launcher finds `.venv\Scripts\python.exe`
next to it. Otherwise supply `-PythonExecutable`. No automatic package download,
system installation, or login fallback occurs. If packages are missing, install
them from your approved source before entering the restricted network.
`-InstallDependencies` explicitly permits pip to install the existing requirements.

Use the offline configuration wizard instead of editing JSON or running inline Python:

```powershell
# New or existing config; prompts for selected services' observed routes.
.\Start-Validation.ps1 -Config .\validation.local.json `
  -Agents ontology,mcp,data-agent,generation,operations -Configure

# Optional: explicitly reuse target IDs and DO routing from a provisioning run.
# This is a run.manifest.json, NOT sources.manifest.json.
.\Start-Validation.ps1 -Config .\validation.local.json `
  -Agents data-agent -Configure `
  -SampleManifest .\runs\YOUR_PROVISIONING_RUN\run.manifest.json
```

`-Configure` makes no network calls, authenticates nobody and creates no Fabric
items. It preserves unrelated settings/draft IDs, requires typing `SAVE`, and backs
up an existing config before replacing it. Conflicting manifest target IDs are
rejected: use a separate config for a different workspace. Importing a saved run
does not prove that run succeeded or its route still works. Only target/DO settings
are imported, never tokens, source data or guessed ML routes.

Enter the tenant, target workspace and **existing ontology** IDs, not the source
workspace IDs. Configuration contains identifiers/routes, never tokens. You can
also use [validation.example.json](validation.example.json) as a manual template.
Setup exits 0 when saved with complete static settings, 1 when saved with missing
scenario prerequisites, and 2 when cancelled/invalid. Resource creation remains
disabled until a separate execution explicitly passes `-AllowCreate`.

For private Data Agent routes, open that service in the **target
workspace**, inspect its successful `generatemwctoken` request, and supply only
the request's HTTPS origin and response `TargetUriHost`. For Data Agent, confirm
the payload identifies workload `ML`. Never copy the response's `Token`, cookies,
headers or a full HAR. Even when a service uses the same host as DO, confirm it
explicitly; the wizard never copies DO routing to another private service.

If a blank UI draft was used to observe routing, do not set it as `data_agent_id`;
validation drafts need the exact ontology attachment and entity selection. The
normal runner creates those drafts with `-AllowCreate`; no bootstrap Python is needed.

| Setting | Meaning |
|---|---|
| `target_network` | Explicit `wspl`, `tenantpl`, or `public` (normal Daily only) |
| `ux_metadata_api` | HTTPS metadata **origin** from the working DO UX's MWC-token request |
| `ux_workload_host` | Exact DO `TargetUriHost` from that request, hostname only |
| `auth` | `cli` uses the existing Azure CLI identity/cache only; `browser` uses an explicitly approved client |
| `client_id` | Required approved public-client application ID when using browser authentication |
| `timeout` | HTTP/operation/conversation budget in seconds, default 240 |
| `scenario_timeout` | Overall scenario budget, default 1800; must be at least `timeout` |
| `poll_seconds` | Poll interval, default 5 |
| `generation_lakehouse_id` | Existing Lakehouse containing Plants/Assets/Readings for generation |
| `generation_source_workspace_id` | Workspace containing that Lakehouse; this generation adapter currently requires it to equal the target workspace |
| `data_agent_metadata_api`, `data_agent_workload_host` | ML Data Agent metadata origin and expected workload host; required for private-mode Data Agent scenarios |
| `data_agent_id` | Optional existing isolated ontology-backed draft to query as-is without creating a replacement |
| `data_agent_ids` | Optional mapping of full scenario IDs to existing draft GUIDs; overrides `data_agent_id` for that scenario |
| `operations_metadata_api`, `operations_workload_host` | Legacy settings; unused because Operations runtime is not automated |

Use the **appropriate service's** routing values; do not copy DO's host into ML
settings unless it is actually the observed host for that service.
Never paste a token, authorization header, or full captured request into this file.
Missing optional agent routing blocks only its scenarios, not other agents.
Before authentication, the runner lists missing selected-scenario prerequisites
and includes them in the report. If all selected scenarios are blocked, it does
not authenticate. `-PlanOnly` performs the same offline checks, including explicit
creation authorization; it is not just a scenario list and does not verify connectivity.

```powershell
# Inspect all static prerequisites before starting a long run.
.\Start-Validation.ps1 -Config .\validation.local.json `
  -Agents ontology,mcp,data-agent,generation,operations -AllowCreate -PlanOnly

# Once configured, run all Data Agent cases using the existing ontology.
.\Start-Validation.ps1 -Config .\validation.local.json `
  -Agents data-agent -AllowCreate
```

For an MWC 403, first compare DO routing with the working provisioning/UX request.
In particular, a tenant-wide metadata origin may be wrong for a WSPL workspace
whose working request uses its workspace-specific origin. Preserve CLI/browser
identity and token version unless evidence requires a change. Do not silently
switch endpoints, clients, or private-network policies to obtain success.

If an older run created drafts and then failed `getDefinition`, those drafts
already exist. **Do not delete or recreate them.** That export failure does not
establish a query failure, and the functional runner no longer calls that API.
Reuse retained drafts immediately, without waiting for an export fix:

```powershell
.\Start-Validation.ps1 -Config .\validation.local.json `
  -Agents data-agent -ReuseResults .\runs\YOUR_FAILED_RUN\results.json -PlanOnly

.\Start-Validation.ps1 -Config .\validation.local.json `
  -Agents data-agent -ReuseResults .\runs\YOUR_FAILED_RUN\results.json
```

`-ReuseResults` checks tenant/workspace/ontology identity, imports only selected
Data Agent IDs, and leaves the config file unchanged. Imported IDs override that
scenario's configured ID for this invocation. Existing drafts are never edited;
their saved configuration is not exported or certified. The requested entities
and actual execution-source IDs determine runtime coverage. Reused IDs remain
in the new report even if the question fails.
It cannot be combined with `-AllowCreate`; missing drafts remain blocked rather
than being silently created. Use a new output directory for each invocation.
`-RerunFailed` alone selects scenarios; it does not import retained resources.
You may pair it with `-ReuseResults` pointing to the same previous results file.

Private mode refuses the normal public metadata default and checks returned MWC
hosts before using workload credentials. Requests do not follow redirects or switch
to a public route. This protects routing intent; it does not prove DNS/egress policy.
The runner does not create private endpoints or change WSPL, BPA, RBAC, or Copilot settings.

For CLI authentication, sign in **before** running, using your normal approved
tenant/application. An expired or denied login is reported; the runner never opens
another login or changes client identity automatically.

The sample fixture must already be populated: 3 Plants, 12 Assets, 120 Readings per
source group. Semantic Model refresh remains a separate setup operation. A failed
data check is not automatically attributed to Private Link or the resolver.

Generation currently covers a **same-workspace Lakehouse** fixture. Its independent
source-result check also needs **ODBC Driver 18 for SQL Server** and TDS access to the
Lakehouse SQL endpoint. Missing driver/query proof yields PARTIAL, not a fake pass
or a reason to stop the other scenarios. Other generation source types and
cross-workspace generation are not implemented by this adapter.

## 2. Choose tests

```powershell
# Offline catalog: exact selectable scenario IDs.
.\Start-Validation.ps1 -ListScenarios

# Validate configuration and write a plan/report, without authentication or live calls.
.\Start-Validation.ps1 -Config .\validation.local.json -Agents ontology,mcp -PlanOnly

# Default: definition read only. Resolver warnings are recorded, not prerequisites.
.\Start-Validation.ps1 -Config .\validation.local.json

# Run two independent queries. Failure of the first does not stop the second.
.\Start-Validation.ps1 -Config .\validation.local.json `
  -Scenarios ontology.lakehouse,mcp.lakehouse `
  -OutputDirectory .\runs\pl-query-01

# All ontology and MCP source/combo probes, without provisioning or agent activation.
.\Start-Validation.ps1 -Config .\validation.local.json -Agents ontology,mcp

# Explicitly authorize NEW test artifacts. Existing source data/ontology are preserved.
.\Start-Validation.ps1 -Config .\validation.local.json `
  -Agents generation,data-agent,operations -AllowCreate
```

Select one of `-Agents`, `-Scenarios`, or `-RerunFailed`, not multiple selectors.
`-Scenarios` also accepts quoted wildcard patterns, for example `'mcp.*'`.
No selector defaults to **ontology.definition**, not a long all-agent run.

| Family | Coverage / limits |
|---|---|
| `ontology` | Definition plus six source and four combination queries. Explicit Plan/read-only context. No source mutation. Fixture-correct answers without independent execution evidence remain PARTIAL |
| `mcp` | Initialize/list-tools/ask through the selected Fabric item endpoint. Empty HTTP 200, JSON-RPC errors, tool errors and incorrect structured answers are failures |
| `data-agent` | Ontology-backed draft and query scenarios, not the older direct-SM helper. Actual execution datasets are distinguished from final prose |
| `generation` | New disposable ontology from the selected sample Lakehouse, using the explicit Plan/Act client contract. Never applies to the original ontology |
| `operations` | `operations.runtime` is explicitly SKIP: runtime is not automated. No ALM, creation, monitoring, external actions, notification destinations or activation |

Creation is disabled unless `-AllowCreate` is present **for that invocation**.
Putting `allow_create` in JSON does not grant authorization. Missing creation
permission is a BLOCKED result, and unrelated read-only checks still run.

An existing Data Agent draft is reused as-is. The question targets the configured
ontology's fixture entities; runtime evidence must identify the expected sources
and ontology context before a full PASS. No export/configuration-read dependency
blocks the question, and the runner never silently rewrites a draft. Prefer
`-ReuseResults`; a manual per-scenario mapping is also supported:

```json
{
  "data_agent_ids": {
    "data-agent.lakehouse": "REPLACE_WITH_RETAINED_DRAFT_GUID"
  }
}
```

Add that property to the complete local configuration; the snippet is not a full
configuration. The retired `operations.native-import` scenario is not selectable;
old `-RerunFailed` reports map it to the explicitly skipped `operations.runtime`.

### Data Agent functional metrics

The query uses the ML UX Responses route with `agent=aiskill&stage=sandbox`.
Each case asks for A012's reading count and the maximum reading with asset/plant
context; combined cases use Plants/Assets from the first source and Readings from
the second. The expected values are 10 readings, 32.9 C, A012, R0120,
2026-01-01T00:45:00Z, P03, East Plant and Boston.

| Metric | Evidence / result |
|---|---|
| Query attempted | `queryAttempted`; false means setup blocked, not a failed query |
| Query completion | `queryCompletion`; API/tool errors fail, and bounded timeouts are TIMEOUT |
| Answer correctness | `answerChecks`; incorrect complete values FAIL, missing values remain UNVERIFIED |
| Source correctness | `sourceEvidenceVerified`; expected source/workspace IDs, successful datasets and ontology-context evidence are required for PASS |
| Response time | `queryDurationSeconds`, plus total scenario duration; no unagreed latency threshold |

A completed query with incomplete execution/source evidence is PARTIAL, not
BLOCKED or PASS. Generated code or plausible prose alone is insufficient. Neither
successful creation nor ALM export is a functional metric. `configurationVerified`
remains false: runtime evidence is not a certification of the entire stored draft.
Private-network enforcement and controlled permission-denial tests remain separate.

## 3. Copy the report

Every run prints its output path. The directory contains:

- **`report.md`**: copyable Markdown summary with all selected/unselected scenarios,
  outcomes, limits, retained resources and untested Private Link acceptance checks.
- **`results.json`**: structured results, configuration and error classifications.
- **`resources.json`**: retained artifact/conversation/operation IDs as they are recorded.
- Per-scenario `*.result.json`, `*.http.json` and supporting evidence.

Reports are checkpointed before/after each scenario. Ordinary assertion errors,
resolver warnings, empty responses, failed agent calls and timeouts cannot abort
unrelated scenarios. Ctrl+C stops intentionally and preserves completed results;
forced process/machine termination leaves the last checkpoint. A missing shared
prerequisite such as authentication or invalid target configuration blocks execution
and writes a run-level explanation rather than pretending tests ran.

HTTP requests and polling have finite budgets. Writes are not automatically
replayed, including after ambiguous timeouts. Source data and created test items
are never automatically deleted. Inspect retained operations/items before retrying.

Statuses:

- **PASS**: the specific stated assertion passed, not overall Private Link sign-off.
- **PARTIAL**: useful evidence, but an execution/source/acceptance requirement is unverified.
- **FAIL**: an observed assertion or service/response failure.
- **BLOCKED**: missing prerequisite or authorization; no success claim.
- **TIMEOUT / ERROR**: bounded timeout or unexpected test error, captured for diagnosis.
- **SKIP**: not selected or a plan-only scenario with no detected static blockers;
  never counted as a pass. Missing prerequisites are **BLOCKED** even in plan mode.

Default exit **0** means the runner completed and wrote the report, **not all tests
passed**. `-Strict` returns 1 for any selected non-PASS result, but still finishes all
selected scenarios. Run-level setup failures return 2. Unknown CLI options are
rejected before execution.

```powershell
# Retry only prior partial/failed/blocked/error/timeout/unfinished cases.
# New output directory required. No prior evidence is overwritten.
.\Start-Validation.ps1 -Config .\validation.local.json `
  -RerunFailed .\runs\pl-query-01\results.json `
  -OutputDirectory .\runs\pl-query-02

# Copy the complete report on Windows.
Get-Content -Raw .\runs\pl-query-02\report.md | Set-Clipboard
```

Rerunning creation scenarios with `-AllowCreate` can create another test artifact;
the runner does not infer that a timed-out create failed or resume an apply blindly.
The single-source aliases are `lakehouse`, `kql`, `warehouse`, `sql`, `mirror`,
`semantic`; combination aliases are listed by `-ListScenarios`.

Evidence redacts tokens/authorization and omits token-exchange bodies. It can still
contain source data, generated queries and tenant/workspace IDs: review it before
sharing. Local config and run outputs must not be committed.

## What remains outside this package's sign-off

The report explicitly leaves WSPL/BPA topology, denied-principal tests, source
revocation/recovery, sentinel/caching checks, source variants, graph/sharing and
apply-race cancellation unverified. These require prepared fixtures and authorized
policy changes; the runner does not silently alter them.

The [normal-Daily investigation](../../docs/prds/Ontology-FL2/Private-Link-Validation-Results-2026-10-28.md)
records known Data Agent support/mapping gaps and MCP empty responses. The portable
runner reports these as results to review, not reasons to abandon the remaining tests.
