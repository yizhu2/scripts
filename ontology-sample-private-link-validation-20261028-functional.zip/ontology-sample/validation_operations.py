"""Operations runtime is explicitly untested; no ALM substitute or activation."""

from validation_setup import MANUAL_SCENARIOS


def runtime_not_automated(ctx):
    return {"status": "SKIP", "summary": MANUAL_SCENARIOS["operations.runtime"],
            "evidence": {"runtimeValidated": False, "activated": False}}


SCENARIOS = {"operations.runtime": runtime_not_automated}
