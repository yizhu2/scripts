import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from validate_sample import catalog, main, select_scenarios
from validation_operations import SCENARIOS
from validation_setup import prerequisites


class OperationsScopeTests(unittest.TestCase):
    def test_runtime_is_not_tested_and_never_uses_context(self):
        context = Mock()
        result = SCENARIOS["operations.runtime"](context)
        self.assertEqual(result["status"], "SKIP")
        self.assertFalse(result["evidence"]["runtimeValidated"])
        self.assertFalse(result["evidence"]["activated"])
        self.assertEqual(context.mock_calls, [])
        self.assertEqual(prerequisites({}, {"operations.runtime"}), {})
        self.assertNotIn("operations.native-import", catalog())

    def test_old_report_migrates_retired_alm_case_without_running_it(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "results.json"
            path.write_text(json.dumps({"results": [
                {"scenario": "operations.native-import", "selected": True, "status": "FAIL"},
                {"scenario": "data-agent.lakehouse", "selected": True, "status": "FAIL"},
            ]}))
            self.assertEqual(select_scenarios(catalog(), previous=path),
                             {"operations.runtime", "data-agent.lakehouse"})

    def test_operations_only_run_skips_without_auth_or_creation(self):
        with tempfile.TemporaryDirectory() as temporary, \
                patch("azure.identity.AzureCliCredential") as auth, \
                patch("validate_sample.ValidationContext") as context:
            root = Path(temporary)
            path = root / "config.json"
            path.write_text(json.dumps({
                "tenant_id": "11111111-1111-1111-1111-111111111111",
                "workspace_id": "22222222-2222-2222-2222-222222222222",
                "ontology_id": "33333333-3333-3333-3333-333333333333",
                "target_network": "public",
            }))
            self.assertEqual(main(["--config", str(path), "--agents", "operations",
                                   "--allow-create", "--output", str(root / "out")]), 0)
            auth.assert_not_called()
            context.assert_not_called()
            report = json.loads((root / "out" / "results.json").read_text())
            selected = [row for row in report["results"] if row["selected"]]
            self.assertEqual(len(selected), 1)
            self.assertEqual(selected[0]["status"], "SKIP")
            self.assertEqual(report["resources"], {})


if __name__ == "__main__":
    unittest.main()
