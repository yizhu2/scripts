import copy
import io
import json
import tempfile
import unittest
from contextlib import ExitStack, redirect_stdout
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch
from urllib.parse import quote

import run_sample
from create_sample import Manifest
from test_create_ontology import GUID, inventory, metadata

TARGET = "22222222-2222-4222-8222-222222222222"
ONTOLOGY = "33333333-3333-4333-8333-333333333333"


class WrappedSampleTests(unittest.TestCase):
    def argv(self, folder):
        return ["--tenant-id", GUID, "--capacity-id", GUID, "--workspace-id", TARGET,
                "--ontology-name", "BoundSample", "--run-directory", str(folder / "run")]

    def test_prompts_for_three_ids(self):
        with patch("builtins.input", side_effect=[GUID, GUID, TARGET]) as prompt:
            args = run_sample.arguments([])
        self.assertEqual(prompt.call_count, 3)
        self.assertEqual(args.workspace_id, TARGET)
        self.assertEqual(args.capacity_id, GUID)

    def test_preview_never_loads_sdk_auth_or_creates_outputs(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            with patch("run_sample.preflight_sdk") as sdk, patch("run_sample.run") as run:
                output = io.StringIO()
                with redirect_stdout(output):
                    run_sample.main(self.argv(folder))
                plan = json.loads(output.getvalue())
                self.assertEqual(plan["expected"]["sourceItemTypes"], 7)
                self.assertEqual(plan["targetWorkspaceId"], TARGET)
                self.assertFalse((folder / "run").exists())
                sdk.assert_not_called()
                run.assert_not_called()

    def test_existing_id_requires_read_only_verification(self):
        with redirect_stdout(io.StringIO()), patch("sys.stderr", io.StringIO()):
            for flags in (["--ontology-id", ONTOLOGY], ["--verify-only"]):
                with self.assertRaises(SystemExit):
                    run_sample.arguments(flags)

    def test_missing_sdk_fails_before_subprocess(self):
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaisesRegex(ValueError, "Missing Microsoft.AnalysisServices.Core.dll"):
                run_sample.locate_sdk(Path(temporary))

    def test_sdk_autodetection_orders_numeric_versions(self):
        with tempfile.TemporaryDirectory() as temporary:
            home = Path(temporary)
            package = home / ".nuget" / "packages" / "microsoft.bi.analysisservices.objectmodels.public.retail.amd64"
            for version in ("170.95.9-ontology", "170.95.29-ontology"):
                directory = package / version / "lib" / "net8.0"
                directory.mkdir(parents=True)
                for name in ("Microsoft.AnalysisServices.Core.dll", "Microsoft.AnalysisServices.Tabular.dll"):
                    (directory / name).touch()
            with patch("pathlib.Path.home", return_value=home):
                self.assertEqual(run_sample.locate_sdk(), package / "170.95.29-ontology" / "lib" / "net8.0")

    def setup_run(self, folder, stack, verify=False):
        flags = self.argv(folder)
        if verify:
            flags += ["--verify-only", "--sources-manifest", str(folder / "sources.json"),
                      "--ontology-id", ONTOLOGY]
        args = run_sample.arguments(flags)
        source_args = run_sample.source_arguments([
            "--tenant-id", GUID, "--capacity-id", GUID, "--workspace-name", "NewSources",
            "--manifest", str(folder / "sources.json"),
        ])
        api = stack.enter_context(patch("run_sample.Api")).return_value
        api.base = source_args.fabric_api
        api.json.side_effect = [{"id": TARGET, "capacityId": GUID}, (
            {"id": ONTOLOGY, "type": "Ontology", "displayName": "BoundSample"} if verify else {"value": []}
        )]
        api.mutate.return_value = {"id": ONTOLOGY, "type": "Ontology", "displayName": "BoundSample"}
        sources = stack.enter_context(patch("run_sample.provision_sources", return_value=inventory()))
        stack.enter_context(patch("run_sample.discover_sources", return_value=metadata()))
        stack.enter_context(patch("run_sample.serialize_definition", return_value={"definition": {"parts": []}}))
        readback = stack.enter_context(patch("run_sample.read_and_verify"))
        manifest = Manifest(folder / "result.json", {})
        return args, source_args, api, sources, readback, manifest

    def test_source_workspace_creation_and_target_ontology_are_separate(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            folder = Path(temporary)
            args, source_args, api, sources, readback, manifest = self.setup_run(folder, stack)
            run_sample.run(args, MagicMock(), manifest, source_args)
            self.assertIsNone(sources.call_args.args[0].workspace_id)
            target = f"{api.base}/workspaces/{TARGET}"
            self.assertEqual(api.mutate.call_args_list[0].args, (
                target + "/items", {"displayName": "BoundSample", "type": "Ontology"}))
            self.assertEqual(api.mutate.call_args_list[1].args[0],
                             target + f"/ontologies/{ONTOLOGY}/updateDefinition")
            self.assertEqual(readback.call_args.args[-1], TARGET)
            self.assertEqual(manifest.data["sourceWorkspaceId"], GUID)
            self.assertTrue(manifest.data["writeCompleted"])
            self.assertEqual(manifest.data["status"], "succeeded")
            expression = next(entry for entry in manifest.data["authoredDefinition"]["model"]["expressions"]
                              if entry["name"] == "SemanticModel_Source")
            self.assertIn(quote(inventory()["workspaceName"], safe=""), expression["expression"])
            self.assertNotIn(TARGET, json.dumps(manifest.data["authoredDefinition"]))

    def test_verify_only_does_not_create_sources_or_update_ontology(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            args, source_args, api, sources, readback, manifest = self.setup_run(Path(temporary), stack, verify=True)
            run_sample.run(args, MagicMock(), manifest, source_args, inventory())
            sources.assert_not_called()
            api.mutate.assert_not_called()
            readback.assert_called_once()
            self.assertNotIn("writeCompleted", manifest.data)

    def test_collision_on_second_page_stops_before_creation(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            args, source_args, api, sources, _, manifest = self.setup_run(Path(temporary), stack)
            api.json.side_effect = [
                {"id": TARGET, "capacityId": GUID},
                {"value": [], "continuationToken": "page2"},
                {"value": [{"displayName": "boundsample"}]},
            ]
            with self.assertRaisesRegex(ValueError, "already contains"):
                run_sample.run(args, MagicMock(), manifest, source_args)
            sources.assert_not_called()
            api.mutate.assert_not_called()
            self.assertEqual(api.json.call_args.kwargs["params"], {"continuationToken": "page2"})

    def test_repeated_pagination_is_rejected(self):
        api = MagicMock()
        api.json.return_value = {"value": [], "continuationToken": "same"}
        with self.assertRaisesRegex(RuntimeError, "Repeated"):
            list(run_sample.workspace_items(api, "https://example.com/workspaces/123"))

    def test_capacity_required_before_any_creation(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            args, source_args, api, sources, _, manifest = self.setup_run(Path(temporary), stack)
            api.json.side_effect = [{"id": TARGET}]
            with self.assertRaisesRegex(ValueError, "Fabric capacity"):
                run_sample.run(args, MagicMock(), manifest, source_args)
            sources.assert_not_called()
            api.mutate.assert_not_called()

    def test_created_id_is_saved_before_a_failed_definition_write(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            args, source_args, api, _, _, manifest = self.setup_run(Path(temporary), stack)
            api.mutate.side_effect = [
                {"id": ONTOLOGY, "displayName": "BoundSample", "type": "Ontology"},
                RuntimeError("Definition failed"),
            ]
            with self.assertRaisesRegex(RuntimeError, "Definition failed"):
                run_sample.run(args, MagicMock(), manifest, source_args, inventory())
            persisted = json.loads(manifest.path.read_text())
            self.assertEqual(persisted["items"]["Ontology"]["id"], ONTOLOGY)
            self.assertNotIn("writeCompleted", persisted)
            self.assertEqual(api.mutate.call_count, 2)

    def test_completed_write_is_saved_before_readback_failure(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            args, source_args, api, _, readback, manifest = self.setup_run(Path(temporary), stack)
            readback.side_effect = RuntimeError("Read-back unavailable")
            with self.assertRaisesRegex(RuntimeError, "Read-back unavailable"):
                run_sample.run(args, MagicMock(), manifest, source_args, inventory())
            self.assertTrue(json.loads(manifest.path.read_text())["writeCompleted"])
            self.assertEqual(api.mutate.call_count, 2)

    def test_existing_sources_must_match_tenant_capacity_and_separate_workspace(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            for field, value in (("tenantId", TARGET), ("capacityId", TARGET), ("workspaceId", TARGET)):
                state = copy.deepcopy(inventory())
                state[field] = value
                source = folder / "sources.json"
                source.write_text(json.dumps(state), encoding="utf-8")
                with self.subTest(field=field), self.assertRaises(ValueError):
                    run_sample.main(self.argv(folder) + ["--sources-manifest", str(source)])

    def test_source_failure_manifest_is_saved(self):
        with tempfile.TemporaryDirectory() as temporary, patch("run_sample.Provisioner") as provisioner:
            manifest = Manifest(Path(temporary) / "sources.json", {})
            provisioner.return_value.run.side_effect = RuntimeError("Replication failed")
            with self.assertRaisesRegex(RuntimeError, "Replication failed"):
                run_sample.provision_sources(MagicMock(), MagicMock(), manifest)
            self.assertEqual(json.loads(manifest.path.read_text())["status"], "failed")
            provisioner.return_value.close.assert_called_once()

    def test_audience_failure_stops_before_resources_or_manifests(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            folder = Path(temporary)
            credential = MagicMock()
            credential.get_token.side_effect = [object(), RuntimeError("Storage consent required")]
            opened = MagicMock()
            opened.return_value.__enter__.return_value = credential
            stack.enter_context(patch.dict("sys.modules", {"sample_auth": SimpleNamespace(open_credential=opened)}))
            stack.enter_context(patch("run_sample.preflight_sdk"))
            stack.enter_context(patch("run_sample.check_local_dependencies"))
            run = stack.enter_context(patch("run_sample.run"))
            with redirect_stdout(io.StringIO()), self.assertRaisesRegex(RuntimeError, "Storage consent"):
                run_sample.main(self.argv(folder) + ["--execute"])
            run.assert_not_called()
            self.assertFalse((folder / "run").exists())
            opened.return_value.__exit__.assert_called_once()

    def test_run_failure_is_persisted_without_automatic_retry(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            folder = Path(temporary)
            stack.enter_context(patch.dict("sys.modules", {
                "sample_auth": SimpleNamespace(open_credential=MagicMock())
            }))
            stack.enter_context(patch("run_sample.preflight_sdk"))
            stack.enter_context(patch("run_sample.check_local_dependencies"))
            run = stack.enter_context(patch("run_sample.run", side_effect=RuntimeError("Provision failed")))
            with redirect_stdout(io.StringIO()), self.assertLogs("ontology-sample", level="ERROR"):
                with self.assertRaisesRegex(RuntimeError, "Provision failed"):
                    run_sample.main(self.argv(folder) + ["--execute"])
            result = json.loads((folder / "run" / "run.manifest.json").read_text())
            self.assertEqual(result["status"], "failed")
            self.assertEqual(result["error"], "Provision failed")
            run.assert_called_once()

    def test_existing_run_directory_stops_before_authentication(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            (folder / "run").mkdir()
            with patch("run_sample.preflight_sdk") as sdk, redirect_stdout(io.StringIO()):
                with self.assertRaises(FileExistsError):
                    run_sample.main(self.argv(folder) + ["--execute"])
                sdk.assert_not_called()


if __name__ == "__main__":
    unittest.main()
