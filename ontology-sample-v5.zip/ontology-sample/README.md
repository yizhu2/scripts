# Daily Fabric: seven sources and one bound ontology

Run **[Start-Sample.ps1](Start-Sample.ps1)** from the extracted ZIP. It prepares a
local Python environment and asks for:

1. **Tenant ID**.
2. **Capacity ID** for a new source workspace.
3. **Workspace ID** of the existing workspace where the ontology should be created.

The source workspace and target workspace are **different**. A Lakehouse cannot
contain other Fabric item types; the seven sources are sibling items in the new
source workspace. The existing target workspace is not cleared, reassigned to
another capacity, or otherwise reused for source storage.

## Result and covered scenarios

| Scenario | This package |
|---|---|
| Create a new source workspace on your supplied capacity | Implemented |
| Populate Eventhouse, KQL database, Lakehouse, Open Mirrored database, Semantic Model, SQL database, and Warehouse | Implemented, with source-row verification |
| Create a new Gen2 ontology in your supplied target workspace | Implemented through Fabric public APIs |
| Bind every source group to that ontology | 18 entities/bound tables and 12 relationships, verified by public read-back |
| Browser sign-in when cached CLI credentials are unavailable | Interactive CLI browser login, then optional approved-client browser authentication |
| Reuse successfully verified sources after inspecting a failed ontology creation | Explicit `-SourcesManifest` option; never replays source loads |
| Verify an existing ontology without writing | `-VerifyOnly`, with source manifest and exact ontology ID/name |
| Import/promote a semantic model into a **second** ontology | **Next step; not implemented** |
| Create a Data Agent artifact | **Next step; not implemented** |
| Create an Operations Agent artifact | **Next step; not implemented** |
| Query through the ontology, refresh its graph, or validate agent answers/actions | Separate validation; not performed by this package |

Each data-bearing source contains the same **Plants (3 rows), Assets (12), and
Readings (120)**, with stable keys and UTC timestamps. The relationships are
`Assets.PlantId -> Plants.PlantId` and `Readings.AssetId -> Assets.AssetId`.
Eventhouse is the KQL database container, so seven source types produce **six**
source groups, not seven copies of the data. Fabric can additionally create
service-managed child items; seven source types does not imply exactly seven
total workspace items.

The ontology groups are `EventhouseKQL`, `Lakehouse`, `MirroredDatabase`,
`SemanticModel`, `SQLDatabase`, and `Warehouse`, each with Plants/Assets/Readings.
Bindings retain the **source** workspace/item identities; the target workspace
is used only for the ontology. Do not sum the identical source copies together.

## Prerequisites

- Windows, **Python 3.10+**, and **PowerShell 7** (`pwsh` on PATH). The launcher
  itself also runs in Windows PowerShell 5.1, but the serializer requires `pwsh`.
- [Microsoft ODBC Driver 18 for SQL Server](https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server).
- An **Ontology-capable Analysis Services SDK** DLL directory, including Core,
  Tabular, and their dependencies. Tested package:
  `Microsoft.BI.AnalysisServices.ObjectModels.Public.retail.amd64`,
  version `170.95.29-Ontology`, directory `lib\net8.0`.
  The launcher detects a local restored `*-ontology` package, accepts
  `-SdkDirectory`, or prompts for the directory.
  **SDK binaries are not included in this ZIP.** Obtain them through your
  approved workload build/package feed; ordinary SDK builds without Ontology
  support are insufficient. A real serializer round-trip runs before creation.
- Azure CLI for the preferred authentication route. It is optional if you use
  an approved application for direct browser authentication.
- A **normal Daily** tenant/capacity with all required workloads enabled.
  The target workspace must already be assigned to a Fabric capacity; it may
  have a different capacity from the new source workspace.
- Permission to create/assign workspaces and create ontology items in the target;
  access to all source items, OneLake, SQL/KQL, and Semantic Model
  creation/refresh/Build. The tenant must allow the Power BI **Dataset Execute
  Queries REST API**.
- Approved network access to Entra, Fabric, Power BI, OneLake, Kusto and SQL.
  SQL requires TDS connectivity, including TCP 1433 and applicable routing ports.
  Existing Private Link/VPN/DNS policies remain unchanged. The launcher does
  not establish workspace-specific private endpoints or bypass network policies.

This package does **not** install system prerequisites, redistribute the SDK,
change Conditional Access, or create app registrations/admin consent.

## Run

Extract the entire ZIP into a writable directory, open a normal interactive
PowerShell window there, and run:

```powershell
.\Start-Sample.ps1
```

No virtual-environment activation is required. The launcher creates
`.venv\Scripts\python.exe` when missing, installs [requirements.txt](requirements.txt)
when dependencies are missing or the requirements change, asks for the three
IDs, and requires typing **CREATE** before executing. It may also request your
SDK directory or approved browser-client ID when those are unavailable.
Follow your organization's script-signing/execution policy if execution is
blocked; this package does not disable that policy.
If Python is installed but not on PATH, provide
`-PythonExecutable 'C:\path\to\python.exe'` for initial setup.

For an offline plan without Fabric calls or resource creation:

```powershell
.\Start-Sample.ps1 -PlanOnly
```

The launcher may still install local Python dependencies for that first preview.
The underlying Python preview needs no authentication or SDK execution.

Optional explicit values:

```powershell
.\Start-Sample.ps1 `
    -TenantId '<tenant-guid>' `
    -CapacityId '<source-capacity-guid>' `
    -WorkspaceId '<target-workspace-guid>' `
    -SdkDirectory 'C:\approved-sdk\lib\net8.0' `
    -OntologyName 'Ontology_AllSources_Demo'
```

Unique source workspace/item names and a unique default ontology name are
generated automatically. A matching name in the target workspace is rejected,
including matches on later item-list pages. Existing ontologies are never
overwritten by this launcher.

## Sign-in

The default `-Auth auto` tries the cached Azure CLI identity in the requested
tenant. If unavailable, it offers interactive **browser** login through the
actual Azure CLI client, without device-code login or changing global CLI
settings. Use a normal interactive terminal on the requesting machine.

If CLI is unavailable/blocked or you decline it, the launcher can use
`InteractiveBrowserCredential` with an **organization-approved public-client
application ID**. It prompts for that ID, or you can supply:

```powershell
.\Start-Sample.ps1 -Auth browser -ClientId '<approved-public-client-app-guid>'
```

The registration must have a **Mobile and desktop applications** redirect URI
of **`http://localhost:8400`**; local port **8400** must be available. It also
needs delegated permissions/consent for the required resources: Fabric/Power BI, Azure Storage,
Azure SQL and Azure Data Explorer. Relevant Fabric operations include workspace
creation and item read/write; Power BI also needs dataset refresh and query
permissions. Have your administrator approve the exact permissions for your
tenant. API authorization and data-plane access are separate from successful
sign-in. Do not substitute arbitrary first-party app IDs.

All required token audiences are checked before new source provisioning.
The same credential is reused throughout the workflow. Authentication fallback
occurs only before resource creation, not silently after a service rejects an
operation. Browser authentication cannot overcome missing permissions, consent,
or a managed-device requirement. `-Auth cli` restricts authentication to Azure CLI.

Tokens are not passed on command lines or written to package manifests. Direct
browser tokens are held in memory; Azure CLI manages its own normal user cache.
The public ontology route does not require a client-side MWC token exchange.

## Evidence, failures and safe follow-up

Outputs are written under a new `runs\<unique-run-id>` directory in your current
working directory, or the explicit `-RunDirectory`:

- `sources.manifest.json`: source workspace, seven source item IDs, stages,
  operations, and expected-data verification.
- `run.manifest.json`: target workspace, created ontology ID, submitted/read-back
  definition, verified binding counts, and success/failure status.

Existing run directories are refused. **No automatic rollback or deletion is
performed.** Source provisioning is not generally resumable: do not replay
Open Mirroring INSERT files or blindly rerun after a failed creation. Inspect
both manifests and any pending operation first.

If sources succeeded but ontology creation failed, inspect the target for
partial child resources before deliberately creating a new ontology using:

```powershell
.\Start-Sample.ps1 -SourcesManifest '.\runs\<old-run>\sources.manifest.json'
```

If `writeCompleted` is true but verification failed, **do not create again**.
Use a fresh output directory and a read-only check:

```powershell
.\Start-Sample.ps1 -VerifyOnly `
    -TenantId '<tenant-guid>' -CapacityId '<source-capacity-guid>' `
    -WorkspaceId '<target-workspace-guid>' `
    -SourcesManifest '.\runs\<old-run>\sources.manifest.json' `
    -OntologyId '<created-ontology-guid>' -OntologyName '<exact-name>' `
    -SdkDirectory 'C:\approved-sdk\lib\net8.0'
```

If the ontology exists but its definition write failed, the launcher refuses to
overwrite it. Inspect it before using the separate explicit
[replacement utility](replace_ontology.py), which accepts `--target-workspace-id`.
See [advanced instructions and historical diagnostics](ADVANCED.md).

Public export may normalize SQL bindings to portable identity markers and omit
default projected entity properties. Verification checks exact source identity,
keys, columns and topology, not textual equality alone. A target-relative
Warehouse binding is rejected for a cross-workspace ontology.

## Planned next steps and acceptance scenarios

1. **Semantic-model-only ontology:** import/promote the sample Semantic Model
   into a second ontology in the target workspace. This is a distinct scenario
   from merely having a Semantic Model source group in the first ontology.
   Verify three entities, two relationships, and queries before calling it ready.
2. **Data Agent artifact:** create/configure the artifact and its supported data
   sources, then verify grounded read-only answers. Pick a single source copy
   per question: expected counts are 3 plants, 12 assets and 120 readings.
3. **Operations Agent artifact:** create/configure its supported ontology
   connection, monitor conditions and validate recommendations. Keep any
   external notification or action disabled until explicitly authorized.
4. **Cross-source query acceptance:** for each source group, ask which asset has
   the highest temperature and which plant owns it. Expected: **A012, 32.9 C,
   P03 / East Plant / Boston**, reading R0120 at 2026-01-01 00:45 UTC.
   Identical copies must not be counted as additional real-world assets.

Agent provisioning/configuration APIs and tenant rollout availability need to
be validated in that next step; this ZIP does not create placeholder agent
items or claim those scenarios already work.

## Validation boundary

All seven source types and a same-workspace public ontology replacement were
live-verified in normal Daily during development. The new **cross-workspace,
single-launcher** workflow is covered by offline orchestration/failure tests and
real SDK serialization checks, but has **not yet completed a fresh live
cross-workspace run**. Direct approved-client browser fallback is mock-tested,
not tenant-policy sign-off. Source data checks and definition verification do
not establish that ontology queries or agents work.

Run offline regression tests after dependency setup:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s . -p 'test_*.py'
```

Public API references:
[create ontology](https://learn.microsoft.com/en-us/rest/api/fabric/ontology/items/create-ontology),
[get definition](https://learn.microsoft.com/en-us/rest/api/fabric/ontology/items/get-ontology-definition),
[update definition](https://learn.microsoft.com/en-us/rest/api/fabric/ontology/items/update-ontology-definition),
[interactive browser credential](https://learn.microsoft.com/en-us/python/api/azure-identity/azure.identity.interactivebrowsercredential).

The ZIP contains an explicit file allowlist and a `PACKAGE.json` SHA-256 inventory.
To rebuild it from these sources without including local environments, tokens,
manifests, or SDK binaries:

```powershell
.\.venv\Scripts\python.exe .\build_package.py --output .\ontology-sample-v5.zip
```
