[CmdletBinding()]
param(
    [Parameter(Mandatory)][ValidateSet('Serialize', 'Deserialize')][string]$Mode,
    [Parameter(Mandatory)][string]$SdkDirectory,
    [Parameter(Mandatory)][string]$InputPath,
    [Parameter(Mandatory)][string]$OutputPath
)

$ErrorActionPreference = 'Stop'
if (Test-Path -LiteralPath $OutputPath) {
    throw "Refusing to overwrite serializer output: $OutputPath"
}
Add-Type -Path (Join-Path $SdkDirectory 'Microsoft.AnalysisServices.Core.dll')
Add-Type -Path (Join-Path $SdkDirectory 'Microsoft.AnalysisServices.Tabular.dll')
$style = [Microsoft.AnalysisServices.Tabular.Serialization.MetadataSerializationStyle]::Tmdl
$compatibility = [Microsoft.AnalysisServices.Tabular.Serialization.MetadataCompatibilityOptionsBuilder]::new($style).
    WithTargetCompatibilityMode([Microsoft.AnalysisServices.CompatibilityMode]::Ontology).
    WithTargetCompatibilityLevel(1000000).
    GetOptions()

if ($Mode -eq 'Serialize') {
    $json = Get-Content -LiteralPath $InputPath -Raw -Encoding UTF8
    $database = [Microsoft.AnalysisServices.Tabular.JsonSerializer]::DeserializeDatabase(
        $json, $null, [Microsoft.AnalysisServices.CompatibilityMode]::Ontology)
    try {
        $options = [Microsoft.AnalysisServices.Tabular.Serialization.MetadataSerializationOptionsBuilder]::new($style).
            WithCompatibilityOptions($compatibility).GetOptions()
        [Microsoft.AnalysisServices.Tabular.TmdlSerializer]::SerializeDatabaseToFolder($database, $OutputPath, $options)
    }
    finally {
        $database.Dispose()
    }
}
else {
    $options = [Microsoft.AnalysisServices.Tabular.Serialization.MetadataDeserializationOptionsBuilder]::new($style).
        WithCompatibilityOptions($compatibility).GetOptions()
    $database = [Microsoft.AnalysisServices.Tabular.TmdlSerializer]::DeserializeDatabaseFromFolder($InputPath, $options)
    try {
        $database.CompatibilityMode = [Microsoft.AnalysisServices.CompatibilityMode]::Ontology
        $json = [Microsoft.AnalysisServices.Tabular.JsonSerializer]::SerializeDatabase($database, $null)
        [System.IO.File]::WriteAllText($OutputPath, $json, [System.Text.UTF8Encoding]::new($false))
    }
    finally {
        $database.Dispose()
    }
}
