# Daily Fabric: seven sources and one bound ontology

**Already provisioned, or provisioning stopped at a resolver check?** Use the separate
[standalone validation runner](VALIDATION.md). It selects agents/scenarios, continues
after individual failures, and writes a copyable report without an assistant or Kusto access.
It does not rerun source provisioning or require the provisioning verification to pass.
Functional agent tests do not require ALM export. Reuse existing Data Agent drafts
with `-ReuseResults`; do not delete/recreate them for a fresh test run.
Operations authoring instead creates a **fresh inactive artifact per source case**
with `-AllowCreate`, using native OA MWC v2 playbook previews. It never reuses or
activates an Operations artifact; runtime/notifications/actions remain manual SKIP.

Run **[Start-Sample.ps1](Start-Sample.ps1)** from this directory or an extracted ZIP. It prepares a
local Python environment and asks for:

1. **Tenant ID**.
2. **Capacity ID** for a new source workspace, or an **existing source workspace ID**
   when using `-SkipSourceCreation`.
3. **Workspace ID** of the existing workspace where the ontology should be created.

**The wrapped workflow requires no Analysis Services SDK, NuGet feed access, Azure DevOps
permissions, .NET SDK, or PowerShell 7.** By default it writes and reads the sample's
TMDL definition directly in Python. An opt-in UX scripting mode is described below.

The source workspace and target workspace are **different**. A Lakehouse cannot
contain other Fabric item types; the seven sources are sibling items in the new
source workspace (new by default, or existing with `-SkipSourceCreation`).
The existing target workspace is not cleared, reassigned to
another capacity, or otherwise reused for source storage.

## Result and covered scenarios

| Scenario | This package |
|---|---|
| Create a new source workspace on your supplied capacity | Implemented |
| Create Eventhouse, KQL database, Lakehouse, Open Mirrored database, Semantic Model, SQL database, and Warehouse | Non-semantic sources are populated and row-verified; Semantic Model refresh and row queries are deferred |
| Provision first, then wait before reading sample data | All source items are created first; loads and initial SQL metadata refreshes finish before a configurable settling period and row verification |
| Create a new Gen2 ontology in your supplied target workspace | Implemented through Fabric public APIs |
| Select public, workspace-PL, or tenant-PL routing for the target | Launcher prompts; target checks, creation, definition writes/read-back, and operation polling use the selected endpoint |
| Bind every source group to that ontology | 18 entities/bound tables and 12 relationships, verified by public read-back |
| Author through the UX scripting path instead of ALM | Opt-in `-AuthoringMode ux`; requires MWC token-exchange authorization, auto-projection, and explicit UX routes for private-link targets |
| Combine an ALM baseline with UX additions | Opt-in `-AuthoringMode hybrid`: ALM for Warehouse, Semantic Model and KQL; UX for Lakehouse, Mirrored Database and SQL Database; final combined UX verification |
| Browser sign-in when cached CLI credentials are unavailable | Interactive CLI browser login, then optional approved-client browser authentication |
| Generate and verify the ontology definition without an AS SDK | Implemented directly in Python; no package-feed calls |
| Reuse successful source provisioning after inspecting a failed ontology creation | Explicit `-SourcesManifest` option; accepts recorded Semantic Model data deferral and never replays source loads |
| Reuse an existing source workspace without a local manifest | `-SkipSourceCreation` prompts for its ID, discovers and read-verifies the sample sources, then creates only the target ontology |
| Verify an existing ontology without writing | `-VerifyOnly`, with source manifest and exact ontology ID/name |
| Retry setup of one source type in the existing source workspace | `-RetrySource` creates fresh selected items without touching other source types; add `-VerifyOnly` to check existing items without loading data |
| Create a **second** ontology from the sample semantic model | Optional companion; uses the UX's native Gen2 import path and verifies 3 bound tables and 2 relationships |
| Test native semantic-model Import/Promote | Implemented: requires backend `Active`, feature level 2 and `SemanticModelImportStatus: Completed`; no client-authored definition |
| Create a Data Agent artifact | Optional companion; unpublished draft referencing the sample semantic model |
| Create an Operations Agent artifact | Optional companion; inactive, unconfigured artifact. Configured creation requires a service-accepted playbook |
| Query through the ontology and validate selected agents | Separate [Start-Validation.ps1](VALIDATION.md) runner; use `-Configure` for guided routing setup, then `-PlanOnly` for offline prerequisite checks before execution |
| Generate inactive Operations playbook previews | Ten `operations.<case>` authoring scenarios; explicit `-AllowCreate` and observed OA routing required, no ALM gates or runtime execution |
| Refresh graph or activate Operations Agent actions | Not performed by the validation runner |

The sample defines **Plants (3 rows), Assets (12), and Readings (120)**, with stable
keys and UTC timestamps. Non-semantic sources are loaded and verified; the
Semantic Model is created with inline import partitions but is not refreshed
or row-queried. Its data is not guaranteed to be materialized. The relationships are
`Assets.PlantId -> Plants.PlantId` and `Readings.AssetId -> Assets.AssetId`.
Eventhouse is the KQL database container, so seven source types produce **six**
source groups, not seven copies of the data. Fabric can additionally create
service-managed child items; seven source types does not imply exactly seven
total workspace items.

The ontology groups are `EventhouseKQL`, `Lakehouse`, `MirroredDatabase`,
`SemanticModel`, `SQLDatabase`, and `Warehouse`, each with Plants/Assets/Readings.
Bindings retain the **source** workspace/item identities; the target workspace
is used only for the ontology. Do not sum the identical source copies together.

## Prerequisites

- Windows, **Python 3.10+**, and **Windows PowerShell 5.1 or newer**.
- [Microsoft ODBC Driver 18 for SQL Server](https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server).
- Azure CLI for the preferred authentication route. It is optional if you use
  an approved application for direct browser authentication.
- A **Daily** tenant/capacity with all required workloads enabled.
  Source provisioning/discovery still uses normal Daily routing; the target
  ontology workspace can use public, workspace-PL, or tenant-PL routing.
  The target workspace must already be assigned to a Fabric capacity; it may
  have a different capacity from the new source workspace.
- Permission to create/assign workspaces when provisioning new sources, and create ontology items in the target;
  access to all source items, OneLake, SQL/KQL, and Semantic Model
  creation and any source access required by server-side ontology binding validation.
- Approved network access to Entra, Fabric, Power BI, OneLake, Kusto and SQL.
  SQL requires TDS connectivity, including TCP 1433 and applicable routing ports.
  Existing Private Link/VPN/DNS policies remain unchanged. The launcher does
  not establish workspace-specific private endpoints or bypass network policies.

If Python is missing, the launcher offers to install Python 3.12 for the current
user through WinGet, **only after confirmation**. For workflows that use SQL,
it also offers to install missing ODBC Driver 18 and its required dependencies
through WinGet; that machine-wide installation may require administrator approval.
For live `auto`/`cli` authentication, it also offers to install missing Azure CLI.
If Windows finds both `az.cmd` and the extensionless `az` entry, the launcher
selects the first application in PowerShell's resolution order rather than
combining their paths. An existing installation does not need reinstalling.
It does not install other system prerequisites, download or bundle AS SDK binaries,
change Conditional Access, or create app registrations/admin consent.

## TODO: Semantic Model data validation

- [ ] Restore explicit Semantic Model refresh and sample-row validation after
  endpoint routing and API authorization are validated in the target environment.

The main workflow does not call the model's `/refreshes` or `/executeQueries`
endpoints. It still creates the model and includes its ontology bindings.
Both run manifests record `deferredValidation.SemanticModel` as
`["refresh", "sampleRows"]`; no Semantic Model row counts are marked verified.
Completion means ontology definition read-back and the other sources' row checks
passed, not that Semantic Model or ontology data queries work.

The replacement utility accepts this recorded deferral only with explicit
`--allow-deferred-semantic`; other source-data checks remain required.
Internal-route and agent companions retain their full source-data verification
requirement. The native semantic-model import companion does not require source
refresh or row verification.

## Target workspace network routing

[Start-Sample.ps1](Start-Sample.ps1) asks
`Target workspace network (wspl / tenantpl / public)` unless you supply
`-TargetNetwork`. An empty or invalid answer stops instead of assuming public access.

| Choice | Target Fabric API base |
|---|---|
| `wspl` | `https://{wsid}.z{xy}.w.dailyapi.fabric.microsoft.com/v1` |
| `tenantpl` | `https://{tenantid}-api.analysis.windows.net/v1` |
| `public` | `https://dailyapi.fabric.microsoft.com/v1` |

For WSPL, `wsid` is the target workspace GUID in lowercase **without hyphens**.
`xy` is its first two hexadecimal characters, preserving leading zeros and
letters. For tenant PL, `tenantid` is the supplied tenant GUID in lowercase
**without hyphens**. `/v1` is the REST API prefix, not part of the host.

```powershell
.\Start-Sample.ps1 -TargetNetwork wspl
.\Start-Sample.ps1 -TargetNetwork tenantpl
.\Start-Sample.ps1 -TargetNetwork public
```

These options also apply when reusing source manifests or an existing source
workspace, and with `-VerifyOnly`. They cannot be combined with `-RetrySource`,
which does not access a target ontology workspace.

The target workspace/capacity and name-collision checks happen before source
creation. Target item creation, definition update/export, and operation
polling/result reads use the selected endpoint. Canonical Daily operation links
returned by the service are mapped to that same selected endpoint; the client
does not follow them back to public routing. Other cross-host operation links
and HTTP redirects are rejected. A policy-denied response is not retried on a
different host.

Source discovery and binding metadata reads use a **separate source API client**.
This choice does not change source provisioning, KQL/SQL/OneLake access, or the
Semantic Model source address. Plans and run manifests record `targetNetwork`
and `targetFabricApi`. Authentication still uses the existing credential's
Power BI audience bearer token; no portal/subscribe token needs to be copied.

The machine must already have the approved DNS, network route, and private
endpoint associations. Selecting a hostname does not configure Private Link
or guarantee service access. Live WSPL/tenant-PL connectivity is not certified
by the mocked routing tests.

### Remaining endpoint work

- [ ] Extend source-side routing and standalone replacement/internal-route/agent
  companions separately. The target option applies to the main launcher and
  [run_sample.py](run_sample.py), not all companion scripts.
- [ ] Validate deployed tenant-PL/WSPL creation and definition read-back from the
  approved network, including mixed source/target scenarios.
- [ ] Validate native semantic-model import separately. Fabric public API and
  UX `/metadata/...` paths are not assumed to support interchangeable hosts.

## Optional UX authoring mode

The default remains `-AuthoringMode public`. To use the internal UX
`POST /v4/workspaces/{workspaceId}/ontologies/{itemId}/definition/scripts`
path instead of ALM `updateDefinition`, select:

```powershell
.\Start-Sample.ps1 -AuthoringMode ux -TargetNetwork wspl `
    -SourcesManifest .\runs\<successful-source-run>\sources.manifest.json
```

This still creates a **new ontology**; it does not repair or overwrite the
ontology from a previous run. Existing source provisioning can be reused with
`-SourcesManifest` or `-SourceWorkspaceId`. Source creation, row checks, and the
Semantic Model data-validation deferral are unchanged.

### Hybrid authoring: ALM baseline, then UX additions

Select `-AuthoringMode hybrid` (Python: `--authoring-mode hybrid`) to split the
six source groups without changing the authentication method:

1. Write **Warehouse, Semantic Model and KQL** through ALM and verify their
   public definition read-back: 9 tables/entities and 6 relationships.
2. Read the baseline through UX with `expand=true` and validate it before
   appending **Lakehouse, Mirrored Database and SQL Database**. The UX script
   contains **27 operations**: 18 creates (3 expressions, 9 tables and
   6 relationships), followed by 9 entity `alter` operations setting only
   `keyProperties` on the newly projected entities. It does not create, alter or replace any Semantic Model
   expression, table, column or relationship.
3. Verify the complete ontology through UX: **18 tables/entities and 12
   table/entity relationships**, including source identities, annotations and
   keys. Verify that the baseline content and lineage remain unchanged,
   excluding response-only `ONT_RESOLVED_*` annotations from that preservation
   comparison and checking current resolver health separately. Known ALM
   SQL identity placeholders are accepted only when they identify the expected
   source. There is **no ALM replacement or export after the UX extension**.

```powershell
.\Start-Sample.ps1 -AuthoringMode hybrid -Auth cli -TargetNetwork wspl `
    -SourcesManifest .\runs\<successful-source-run>\sources.manifest.json `
    -UxMetadataApi 'https://<metadata-host-from-working-UX>' `
    -UxWorkloadHost '<TargetUriHost-from-working-UX>'
```

The observed ALM round-trip retained Semantic Model, Warehouse and KQL source
metadata; [Bug 2365801](https://dev.azure.com/powerbi/Ontology/_workitems/edit/2365801)
affects the other three groups. The server's Semantic Model binding guard
checks added or changed bindings, so leaving those bindings untouched is
expected to avoid repeating that probe in the UX phase. This is **not a
permission bypass or an authentication fix**: all normal server authorization
still applies. Live hybrid execution remains to be validated.

Keep the current CLI sign-in with `-Auth cli`. UX API authoring does not mean
browser OAuth authentication; no new application ID or second identity is
selected. Both phases use the same credential. Private UX routes and v2 MWC
exchange are required just as in UX-only mode.

This creates a **new ontology**, while `-SourceWorkspaceId` or
`-SourcesManifest` reuses existing sources without refresh or recreation.
The two phases are **not one atomic transaction**. If the second phase fails,
the verified ALM baseline remains; a script timeout can have an unknown outcome.
There is no automatic rollback, replay, or resume. Inspect the item and manifest.
`almWriteCompleted`, `almBaselineVerified`, `uxWriteCompleted`, and
`authoringPhase` distinguish partial completion; `writeCompleted` means at
least one write completed, not that the whole workflow succeeded.
The baseline and before/after UX definitions are retained as evidence.

Use the same mode with `-VerifyOnly`, the exact `-OntologyId` and
`-OntologyName`, and the same source inputs to check a combined ontology
without writes. Hybrid verification-only uses UX read-back, never ALM export.
It reports an incomplete baseline as a verification failure rather than
finishing it automatically.

To update an existing extraction, overlay the ZIP's `ontology-sample` contents
onto that same directory. Keep `.venv` and `runs`; they are not included in the
archive. A fresh directory or new virtual environment is not required.

### Repair an existing hybrid ontology with missing entity keys

A successful source binding does not imply an entity key is configured.
Table-column `isKey: true` does **not** make auto-projection populate the
entity's `keyProperties`. Earlier packages omitted those explicit entity
patches, so the UX could show correct bindings while final verification failed
at `model.entities.Lakehouse_Plants.keyProperties`.

The corrected creation script authors entity keys in the same transaction.
For an ontology already created by the earlier hybrid package, **do not rerun
creation**. Overlay this package onto the existing folder, keep `.venv` and
`runs`, and use [repair_entity_keys.py](repair_entity_keys.py) with the original
failed hybrid run's manifest:

```powershell
# Offline preview: no login, service requests, or writes.
.\.venv\Scripts\python.exe .\repair_entity_keys.py `
    --run-manifest '.\runs\<failed-hybrid-run>\run.manifest.json'

# Repair that same ontology, after inspecting the preview's item ID and name.
.\.venv\Scripts\python.exe .\repair_entity_keys.py `
    --run-manifest '.\runs\<failed-hybrid-run>\run.manifest.json' `
    --execute
```

The helper reuses the recorded target, UX routes, token version, and
authentication mode. It requires evidence of a verified ALM baseline and
completed UX write. Before any mutation it checks the live workspace/capacity
and exact item identity, then verifies every expected binding, property, key,
annotation and relationship, allowing only absent/empty keys on the nine
Lakehouse, Mirrored Database and SQL Database entities.

It submits at most nine `alter` operations, setting only `keyProperties`.
Different nonempty keys or any unrelated mismatch stop the repair; already
correct keys are left alone. There is no source refresh, source/item creation,
ALM replacement, or Semantic Model binding change. Afterward it verifies the
full ontology and preservation of existing content, including lineage tags.
Response-only `ONT_RESOLVED_*` annotations are not persisted content; current
resolver health is checked separately, as described below.

Run this while no one else is editing the ontology. This read-check-write
helper does not use a client `If-Match` precondition.
The original manifest is never modified. New evidence is written to
`runs\entity_keys_<id>\repair.manifest.json`, or a new `--run-directory`.
Timeouts and failed result/read-back checks are not automatically replayed;
inspect the recorded `writeAttempted`, `writeCompleted`, script and definitions.
A later explicit execution reads current state again and performs no write
if all keys already match. Definition verification is not a data-query test.
Live private-link repair still requires validation in the target environment.

### Authentication and private routing

UX and hybrid modes default to **v2**, matching the observed DO browser
`/metadata/v201606/generatemwctokenv2` call. It sends `workspaceObjectId`,
`workloadType: "DO"`, and the typed `artifacts` array. Client action fields
such as `type`, `asyncId`, and `iframeId` are not API request fields.
Use `-UxTokenVersion v1` (Python: `--ux-token-version v1`) only when explicitly
testing the older contract, which uses `artifactObjectIds` instead.
The selected version is saved as `uxTokenVersion` and retained on refresh;
there is no version fallback after a denial. Standalone legacy companions
retain their existing v2 behavior.

UX and hybrid modes use the selected CLI/approved-browser sign-in to request a short-lived
**MWC token**, then sends workload calls with `Authorization: MwcToken` to
`https://{TargetUriHost}/webapi/capacities/{targetCapacityId}/workloads/DO/DigitalOperationsService/direct`.
It uses the target workspace's capacity, not the source workspace's capacity.
There is no second automatic login and no token-pasting requirement.
**Successful Fabric public API authentication does not guarantee permission
to call the internal MWC token-exchange endpoint.** The chosen application,
user permissions, Conditional Access, and network policy must permit that
exchange. A 401/403 stops the run; it never silently switches applications or
falls back to the public definition API. Tokens stay in memory and token-exchange
response bodies are excluded from error logs.

For **WSPL or tenant PL**, the launcher asks for two non-secret routing values:

1. `-UxMetadataApi`: the HTTPS **origin** of the working UX's
   `/metadata/v201606/generatemwctokenv2` request (or `generatemwctoken`
   when explicitly using v1), without that path.
2. `-UxWorkloadHost`: its response's `TargetUriHost` (**hostname only**), matching
   the host of the working UX's `/definition/scripts` call. The observed Daily
   WSPL workload host has the form `{workspaceHex}.z{firstTwoHex}.daily-c.fabric.microsoft.com`;
   use the actual value from the UX, not the public `/v1` API hostname.

Obtain them from the browser Network panel while opening the target ontology
in a working UX session. Do **not** copy the `Token`, authorization headers,
cookies, or full response. Use routes for the **target** workspace, not a source
workspace. The public Fabric `/v1` hostname is **not assumed** to also serve the
UX metadata API. This tool deliberately does not invent a private UX hostname.
In the observed Daily WSPL capture, the token endpoint was on
`https://{workspaceHex}.z{firstTwoHex}.w.dailyapi.fabric.microsoft.com`,
not the tenant-scoped `analysis.windows.net` origin. Use the actual captured
origin for your workspace rather than substituting a tenant-scoped host.

The metadata origin must be HTTPS under `analysis.windows.net`,
`pbidedicated.windows.net`, `daily-c.fabric.microsoft.com`, or a workspace `dailyapi.fabric.microsoft.com` host,
without credentials, paths, query strings, or ports. Those checks establish
allowed service hosts, not network reachability. DNS and private endpoint
configuration must already be in place. The returned workload host must
match the supplied host on initial exchange **and refresh**. Redirects and
host changes are rejected; there is no public-route retry. No policy exceptions
or service-to-service access headers are fabricated.

For a normal **public** target, metadata defaults to
`https://wabi-daily-us-east2-redirect.analysis.windows.net`; the workload host
comes from the authenticated token response. An explicit metadata origin and
expected host can also be supplied.

Python equivalent (offline plan until `--execute` is added):

```powershell
.\.venv\Scripts\python.exe .\run_sample.py `
    --tenant-id '<tenant-guid>' --workspace-id '<target-workspace-guid>' `
    --sources-manifest '.\sources.manifest.json' `
    --authoring-mode ux --target-network wspl `
    --ux-metadata-api 'https://<metadata-host-from-working-UX>' `
    --ux-workload-host '<TargetUriHost-from-working-UX>'
```

### UX-only write and verification behavior

The server must support Gen2 scripting and **auto-projection** (`expand=true`).
Before writing, the tool checks that the new ontology is empty and that expanded
reads are available. It submits one transaction containing **53 operations**:
35 creates (5 expressions, 18 bound tables, and 12 relationships), followed by
18 `alter` operations setting only the new entities' `keyProperties`.
Auto-projection supplies 18 entities and 12 entity relationships, but not entity
keys; those must be authored explicitly. No replace or delete operations are
used, and pre-existing objects are not altered. The builder retains authored `ONT_*` metadata and never
submits response-only `ONT_RESOLVED_*` annotations.

Read-back uses the matching UX `GET /definition` endpoint, including its expanded
form, **not ALM export**. It checks bindings, keys, annotations, entities, and
relationships, not just counts. `-VerifyOnly` works with `-AuthoringMode ux` and
the exact existing ontology ID/name; it performs no definition or source writes
(token acquisition still uses POST). Keep the same authoring mode when verifying.

Manifests record `authoringMode`, the non-secret routes, submitted script,
per-operation results, canonical and expanded definitions, and
`verified.uxDefinition`. A 200 script response records `writeCompleted` before
validating results. Timeouts, malformed responses, and failed read-back are not
replayed or switched to another authoring path. Inspect the saved item before
retrying; an authentication failure after item creation may leave an empty
ontology. No resources are deleted.

This is an **internal, opt-in** path, not a claim of a supported external public
API. Offline tests cover routing/auth failures, script shape, and verification.
Live WSPL/tenant-PL authentication and end-to-end execution must still be
validated from the approved network. This mode avoids the ALM round-trip
implicated in [Bug 2365801](https://dev.azure.com/powerbi/Ontology/_workitems/edit/2365801);
it does not fix that backend bug or establish query/agent readiness.

### Resolver health is separate from stored binding preservation

`ONT_RESOLVED_*` annotations are computed on each read and are never authored
by this tool. Two reads of the same stored definition can reach different
workers and return different resolver states. In the observed Daily failure,
one worker resolved all eight binding expressions, while the next expanded
read reached a worker whose circuit breaker was open and returned
`Failed / ResolutionUnavailable`. That does not establish a stored binding
change or undo the successful script.

The verifier still checks every authored identity, expression, key, relationship
and preserved lineage tag. It excludes only the response-only annotation prefix
from the preservation comparison, and independently checks the latest expanded
read for reported resolution failures. It does **not** silently accept `Failed`
or `PartiallyResolved`.

If every reported issue is `Failed / ResolutionUnavailable`, the UX and hybrid
workflows (including `-VerifyOnly` and the key-repair helper) retry **only the
canonical/expanded GETs**, at most three attempts with 30 seconds between them.
They never repeat item creation, ALM updates, or scripts. Other resolution
errors and authored-definition mismatches are not automatically retried.
Persistent unavailability fails explicitly as resolver health, not a definition
mutation. `resolutionReadAttempts` retains each expanded response and its issues.
If the service supplies no resolution status, the result records no reported
failures, not proof of resolution or query readiness.

After an earlier package stopped on `ONT_RESOLVED_State`, update the existing
extraction and run `-AuthoringMode hybrid -VerifyOnly` with the same source
manifest and the existing ontology's exact ID/name. No replacement ontology
or key-repair write is needed for that error alone.

### Diagnose a denied UX token exchange without creating another ontology

A 403 from `/metadata/v201606/generatemwctoken` or its v2 variant occurs before the workload
binding script, but **after the new ontology item may have been created**.
Do not rerun creation to diagnose it. HTTP 403 alone does not establish whether
the application, item access, or private network policy rejected the exchange.
The browser can use a different approved application than Azure CLI.

Use [check_ux_auth.py](check_ux_auth.py) with the **failed UX or hybrid run's** manifest:

```powershell
.\.venv\Scripts\python.exe .\check_ux_auth.py `
    --run-manifest '.\runs\<failed-UX-run>\run.manifest.json' `
    --token-version v2 --execute
```

Without `--execute`, it only prints an offline plan. With it, it uses the
recorded tenant, metadata origin, target workspace/capacity, and existing
ontology ID to make **only** the selected token request. It does not create items,
inspect sources, read/write a definition, or change the original manifest.
Use the same authentication mode/application as the failed run; `--auth` and
`--client-id` can explicitly select an organization-approved client when needed.
Authentication uses the usual interactive helper; no raw token input is accepted.
If the failed run recorded the wrong metadata origin, explicitly supply
`--metadata-api 'https://<captured-UX-metadata-host>'`. The origin is validated
using the same routing rules. It changes only this probe, not the saved manifest.

Output includes HTTP status, allowlisted service error codes, valid correlation
GUIDs, and credential type. Token values, raw headers, response bodies, and
exception messages are not emitted by the probe. A nonzero exit indicates failure.
Token acquisition success is not a workload authorization or binding-validation
test. If the service supplies no safe error details, use the captured request ID
with platform diagnostics instead of inferring the cause from 403.

`--token-version v2` explicitly tests the observed DO UX contract against the
existing item left by the failed run. Without the option, the probe reproduces
the recorded version; manifests from older packages that did not record a version
are treated as v2. Both the endpoint and body change together. Simply renaming
the v2 endpoint while retaining its body is incorrect. Even matching the browser's
endpoint does not guarantee that the CLI/approved client is authorized.
The probe never silently switches versions, clients, or routing.

### Refresh only the existing sample Semantic Model

[retry_semantic_data.py](retry_semantic_data.py) retries the deferred refresh and
checks all sample values (3 Plants, 12 Assets, 120 Readings). It does not create
items, rewrite the model definition, or change any ontology. The sample model
uses inline M import partitions; there are no separate backing SQL tables to
create. Existing `-RetrySource SemanticModel` instead **recreates** a model and
still defers data validation, so do not use that option for this operation.

Copy this single script beside the existing launcher; no new ZIP or dependency
installation is needed when using the UX-authoring package.

```powershell
.\.venv\Scripts\python.exe .\retry_semantic_data.py `
    --sources-manifest '.\runs\<existing-run>\sources.manifest.json'
```

This prints an offline plan. Add `--execute` to refresh and verify, or
`--verify-only --execute` to query without refreshing. A fresh output source
manifest is saved; the original manifest and item IDs are preserved. On success,
the new manifest removes the Semantic Model data deferral. On a refresh timeout
or error, inspect the saved operation and service status before requesting
another refresh.

By default, the script uses the **recorded source** Power BI API origin.
`--powerbi-api 'https://<captured-source-api-host>'` explicitly selects a new
origin for refresh and query calls, with no cross-host redirects or fallback.
Supply an origin only, not a `/metadata/...` or `/v1` path. A workspace-scoped
host must belong to the source workspace; the ontology workspace's host is
rejected. Source schema reads continue to use the recorded Fabric endpoint.
An accepted origin is not proof that its refresh/query routes are reachable.

Authentication is unchanged by endpoint selection. The observed Azure CLI
token was rejected by the Semantic Model XMLA authentication layer for missing
dataset-related scopes. An organization-approved app with the required consent
can be selected using `--auth browser --client-id '<approved-app-id>'`; merely
opening an Azure CLI browser login or refreshing rows does not grant those scopes.
This helper surfaces failures instead of skipping permission checks.

## Run

Open a normal interactive PowerShell window in this directory or a writable
extraction of the entire ZIP, and run:

```powershell
.\Start-Sample.ps1
```

No virtual-environment activation is required. The launcher creates
`.venv\Scripts\python.exe` when missing, installs [requirements.txt](requirements.txt)
when dependencies are missing or the requirements change, asks for the three
IDs and target network mode, and requires typing **CREATE** before executing. It may also request an
approved browser-client ID when CLI authentication is unavailable.
Follow your organization's script-signing/execution policy if execution is
blocked; this package does not disable that policy.
If Python is installed but not on PATH, provide
`-PythonExecutable 'C:\path\to\python.exe'` for initial setup.

### First run on a new machine

The launcher checks for a working Python 3.10+, not just the Windows Microsoft
Store `python` shortcut. If none is found and WinGet is available, answer `y`
to the Python installation prompt. It installs Python 3.12 for the current user,
detects the default installation without requiring a new PowerShell window, and
continues with virtual-environment setup. No Fabric resources are created during
this bootstrap step. Existing working Python installations are not upgraded.

If WinGet is unavailable, installation fails, or you decline, the launcher stops
with manual setup instructions. Install Python from
[python.org](https://www.python.org/downloads/windows/) or your approved software
source, select **Add Python to PATH**, and open a new PowerShell window. You can
also supply the installed executable directly:

```powershell
.\Start-Sample.ps1 `
    -PythonExecutable "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe" `
    -SettleSeconds 300 `
    -KqlRequestTimeoutSeconds 600
```

Use the actual installation path if different. An invalid explicit
`-PythonExecutable` stops with an error instead of installing another Python.
The download security warning is separate: follow your organization's script
trust policy; the launcher does not unblock files or change execution policy.

For SQL workflows, the launcher next checks ODBC drivers using the sample's
Python environment. If **ODBC Driver 18 for SQL Server** is missing, answer `y`
to install it and any required dependencies through WinGet. It verifies the
driver again before continuing. The legacy `SQL Server` driver and the Python
`pyodbc` package do not replace ODBC Driver 18.

This check runs for new source provisioning, existing-workspace source discovery,
and retries/verification of Lakehouse, MirroredDatabase, SQLDatabase, or Warehouse.
It does not run for `-PlanOnly`, successful source-manifest reuse, or
Eventhouse/KQLDatabase/SemanticModel-only retries. Existing Driver 18 installations
are left unchanged. If installation is declined, unavailable, fails, or still
leaves the driver invisible to Python, the launcher stops with manual instructions
before contacting Fabric. Follow any installer permission or restart requirements;
the launcher does not elevate or restart itself.

For live runs using `-Auth auto` (the default) or `-Auth cli`, the launcher also
checks Azure CLI. It searches PATH and the standard Windows installation locations,
then offers a confirmed WinGet installation if missing. Administrator approval
may be required. It verifies `az version` and adds the detected directory to the
**current process PATH**, inherited by Python, so standard installations do not
require a new shell. It does not manually change the persistent PATH, Azure CLI
configuration, or cached account. Existing CLI installations are not upgraded.

`-PlanOnly` and `-Auth browser` do not check or install Azure CLI. If installation
is declined or WinGet is unavailable, `-Auth cli` stops with manual instructions;
`-Auth auto` warns and retains the existing explicit offer to use an
organization-approved browser application. That fallback still requires an
approved application ID and does not install Azure CLI. Installer failures,
undetected installations, and broken CLI executables stop the launcher instead
of changing authentication routes. Sign-in remains in the normal authentication
workflow; installing CLI alone does not sign you in.

### Preview and explicit values

For an offline plan without Fabric calls or resource creation:

```powershell
.\Start-Sample.ps1 -PlanOnly
```

The launcher may still offer Python installation and install local Python
dependencies for that first preview.
The underlying Python preview needs no authentication.

Optional explicit values:

```powershell
.\Start-Sample.ps1 `
    -TenantId '<tenant-guid>' `
    -CapacityId '<source-capacity-guid>' `
    -WorkspaceId '<target-workspace-guid>' `
    -OntologyName 'Ontology_AllSources_Demo'
```

Unique source workspace/item names and a unique default ontology name are
generated automatically. A matching name in the target workspace is rejected,
including matches on later item-list pages. Existing ontologies are never
overwritten by this launcher.

### Skip source creation and use an existing workspace

If the sample sources already exist, no local source manifest is required:

```powershell
.\Start-Sample.ps1 -SkipSourceCreation
```

The launcher asks for the tenant ID, the **existing source workspace ID**, and
the **target workspace ID** where a new ontology will be created. It does not
ask for a source capacity: it reads the existing workspace's capacity and name.
Source and target workspaces must remain different.

You can supply the IDs instead of answering prompts:

```powershell
.\Start-Sample.ps1 `
    -TenantId '<tenant-guid>' `
    -SourceWorkspaceId '<existing-source-workspace-guid>' `
    -WorkspaceId '<target-ontology-workspace-guid>'
```

Supplying `-SourceWorkspaceId` implies `-SkipSourceCreation`. Add `-PlanOnly`
for an offline plan; discovery and validation run only when executing.

This mode:

- Requires all seven source item types with the shipped **Plants, Assets, and
  Readings** fixture. It is not a general-purpose ontology generator for arbitrary
  schemas or data.
- Reads the workspace's paginated item inventory and resolves live item metadata.
  The Eventhouse is the parent of the selected KQL database, not an arbitrary
  Eventhouse in the workspace.
- Checks exact non-semantic sample rows through read-only KQL and SQL queries.
  It checks the Semantic Model schema using `getDefinition`; Semantic Model
  refresh and row queries remain deferred.
- Does **not** create/assign a source workspace, create source items, upload or
  reload data, refresh SQL metadata, start mirroring, or refresh the Semantic Model.
  The settling delay is not used. SQL/KQL connectivity and ODBC Driver 18 are still
  required for verification.
- Saves a fresh `sources.manifest.json` in the run directory, including discovered
  identities and verification results. Only after validation succeeds does it
  create and populate the target ontology. Failure leaves existing sources untouched.

If more than one candidate exists for a source type, it stops and lists the
candidates instead of guessing. Select the intended items explicitly:

```powershell
.\Start-Sample.ps1 `
    -SourceWorkspaceId '<existing-source-workspace-guid>' `
    -SourceItemIds @{
        Lakehouse = '<lakehouse-item-guid>'
        SemanticModel = '<semantic-model-item-guid>'
    }
```

Specify only the ambiguous types. This also handles automatic Semantic Models
or retained items from source retries. Missing types, incompatible sample data,
or a mismatched Eventhouse/KQL parent relationship stop the run before ontology
creation; the tool does not fill in missing sources.

Do not combine workspace discovery with `-SourcesManifest`, `-SourceWorkspaceName`,
or `-RetrySource`. Manifest reuse remains available and does not need a capacity
argument; if a capacity is supplied, it must match the manifest.
For read-only ontology verification, either reuse method can be combined with
`-VerifyOnly`, `-OntologyId`, and the exact `-OntologyName`.

### Provision first, then wait and verify

Provisioning/loading is separate from sample-row verification:

1. Create all seven source types.
2. Load Lakehouse, MirroredDatabase, SQL Database and Warehouse. Defer Semantic
   Model refresh and row queries. Load KQL last, giving the newly created Eventhouse more time
   to initialize. A read-only `print Ready = 1` probe must succeed before KQL
   ingestion; probe timeouts can be retried without replaying writes.
3. Refresh Lakehouse/MirroredDatabase SQL metadata with `recreateTables: false`.
4. **Wait 120 seconds by default**, after those metadata refreshes.
5. Verify non-semantic sources' sample rows, then create and read back the bound
   ontology definition, including the Semantic Model bindings.

Status polling and SQL connectivity probes remain necessary while loading.
Sample-row reads do not happen immediately after each individual source
load. Verification does not immediately trigger another initial SQL refresh
after the settling period. Existing bounded readiness/replication retries remain
in place: waiting a fixed time is not proof of readiness.

For a longer settling period and slower Kusto responses:

```powershell
.\Start-Sample.ps1 -SettleSeconds 300 -KqlRequestTimeoutSeconds 600
```

`-SettleSeconds` accepts 0-86400 seconds; 0 removes only the settling delay, not
verification. `-KqlRequestTimeoutSeconds` accepts 30-3600 seconds and defaults to
300, capped by `-TimeoutSeconds`. It controls the HTTP **read** timeout for each
KQL request; the connection timeout is 30 seconds. Other HTTP requests keep
their existing timeouts. Python equivalents are `--settle-seconds` and
`--kql-request-timeout` in both source and wrapped workflows.

The settling delay is additional to the existing per-operation/per-table
timeout. Successfully reused sources and ontology-only verification do not wait
or reload sources. New manifests record the settings and `sourceLoadsCompleted`
after all non-semantic loads return successfully; that flag alone does **not** mean verified
or make a failed run resumable.

## Sign-in

The default `-Auth auto` tries the cached Azure CLI identity in the requested
tenant. If unavailable, it offers interactive **browser** login through the
actual Azure CLI client, without device-code login or changing global CLI
settings. Use a normal interactive terminal on the requesting machine.

If CLI is unavailable/blocked or you decline it, the launcher can use
`InteractiveBrowserCredential` with an **organization-approved public-client
application ID**. It prompts for that ID, or you can supply:

```powershell
.\Start-Sample.ps1 -Auth browser -ClientId '<approved-public-client-app-guid>'
```

The registration must have a **Mobile and desktop applications** redirect URI
of **`http://localhost:8400`**; local port **8400** must be available. It also
needs delegated permissions/consent for the required resources: Fabric/Power BI, Azure Storage,
Azure SQL and Azure Data Explorer. No Azure DevOps scope or package-feed
permission is requested. Relevant Fabric operations include workspace
creation and item read/write. The main workflow does not require client-side
dataset refresh or Execute Queries calls. Have your administrator approve the exact permissions for your
tenant. API authorization and data-plane access are separate from successful
sign-in. Do not substitute arbitrary first-party app IDs.

All required token audiences are checked before new source provisioning.
The same credential is reused throughout the workflow. Authentication fallback
occurs only before resource creation, not silently after a service rejects an
operation. Browser authentication cannot overcome missing permissions, consent,
or a managed-device requirement. `-Auth cli` restricts authentication to Azure CLI.

Tokens are not passed on command lines or written to package manifests. Direct
browser tokens are held in memory; Azure CLI manages its own normal user cache.
The public ontology route does not require a client-side MWC token exchange.

## SDK-free definition handling

[sample_tmdl.py](sample_tmdl.py) writes the database, model, tables, entities,
relationships, expressions and namespace TMDL documents needed by this sample.
The generated files are parsed back and structurally checked before submission.
After the public API write, the returned definition is independently parsed and
verified for source identity, keys, columns and relationships.

Every generated partition includes authored `ONT_*` annotations for its source
workspace, item ID, item kind and display names. SQL-based bindings also pin the
known endpoint and database. Semantic Models use the UX's `Dataset` item-kind
spelling. Read-back requires these identities to survive unchanged; response-only
`ONT_RESOLVED_*` annotations are never fabricated or written by the script.

These annotations support UX source recognition; they do not establish source
access or query success. Daily-specific connector parsing, feature switches and
network routing still require UX validation in the target environment. Previously
created ontologies are not changed by updating the scripts.

To regenerate an existing sample ontology's bindings, the replacement utility
backs up its current public definition before writing. **This replaces the entire
ontology definition, including user edits**; do not use it on an edited ontology
without reviewing the backup/overwrite implications.

```powershell
.\.venv\Scripts\python.exe .\replace_ontology.py `
    --sources-manifest '.\runs\<latest-source-run>\sources.manifest.json' `
    --target-workspace-id '<ontology-workspace-guid>' `
    --ontology-id '<existing-ontology-guid>' --name '<exact-ontology-name>' `
    --manifest '.\binding-replacement.manifest.json' --allow-deferred-semantic
```

This prints a plan only. Add `--execute` only after approving replacement.
It uses Azure CLI authentication, requires a successful source inventory, and
does not recreate or reload source items. Use `--verify-only` with a new manifest
to recheck a completed write instead of replaying it.

This is a deliberately limited **sample-format codec**, not a general-purpose
TMDL implementation or replacement for TOM. Unsupported syntax and malformed or
duplicate declarations fail explicitly rather than being ignored. It does not
fetch packages, load DLLs, invoke a serializer subprocess, or request an Azure
DevOps token. Fabric still performs its normal server-side authorization and
definition validation.

## Evidence, failures and safe follow-up

Outputs are written under a new `runs\<unique-run-id>` directory in your current
working directory, or the explicit `-RunDirectory`:

- `sources.manifest.json`: source workspace, seven source item IDs, stages,
  operations, non-semantic expected-data verification, and deferred Semantic Model validation.
- `run.manifest.json`: target workspace, created ontology ID, submitted/read-back
  definition, verified binding counts, deferred source validation, and success/failure status.

Existing run directories are refused. **No automatic rollback or deletion is
performed.** Source provisioning is not generally resumable: do not replay
Open Mirroring INSERT files or blindly rerun after a failed creation. Inspect
both manifests and any pending operation first.

### Retry one source type

Use the source manifest from a successful, failed, or partial run. This mode
does not create another workspace or create/update an ontology.

```powershell
.\Start-Sample.ps1 -RetrySource KQLDatabase `
    -SourcesManifest '.\runs\<previous-run>\sources.manifest.json' `
    -RunDirectory '.\runs\retry-kql'
```

Supported values: `Eventhouse`, `KQLDatabase`, `Lakehouse`, `MirroredDatabase`,
`SemanticModel`, `SQLDatabase`, and `Warehouse`. Identity and endpoints come from
the source manifest; do not supply tenant, capacity, target-workspace or ontology
options in this mode. Authentication and timeout settings remain available.
Use `-PlanOnly` to preview without Fabric calls.

**Setup retries create fresh selected items with unique names.** Old items are
retained, not cleared or reloaded. This avoids replaying an uncertain KQL write,
SQL insert, or Open Mirroring batch. The resulting manifest points to the new
items for the selected type and preserves all unrelated item IDs and verification
results. Existing ontology bindings are not redirected.

- `KQLDatabase` reuses the recorded Eventhouse. If no Eventhouse is recorded,
  it creates that dependency too.
- `Eventhouse` creates a fresh Eventhouse and its KQL database.
- Other selections recreate only that item type.
- Semantic Model setup still defers refresh and row queries; retry checks its
  sample schema instead.

To verify already-populated items without creating or loading anything:

```powershell
.\Start-Sample.ps1 -RetrySource Lakehouse -VerifyOnly `
    -SourcesManifest '.\runs\<previous-run>\sources.manifest.json' `
    -RunDirectory '.\runs\verify-lakehouse'
```

Verification-only mode does not refresh SQL metadata. It checks existing rows,
or the Semantic Model schema, and fails if data is missing. For KQL it verifies
the sample tables; it is not just the `print Ready = 1` readiness probe.

Each attempt requires a new output directory and writes its own
`sources.manifest.json`; the input manifest is unchanged. Chain subsequent
retries from the **latest output manifest** to retain earlier repairs.
`retryStatus: succeeded` means the selected type completed. Overall `status`
remains `partial` with `remainingSources` until every required source has passed
verification (with the explicit Semantic Model data deferral allowed).
For sources already loaded but not yet verified, use `-RetrySource <type>
-VerifyOnly` rather than recreate them.

Only once the latest source manifest has `status: succeeded` can it be passed
to the normal launcher with `-SourcesManifest` to create the ontology.
No automatic retry of failed writes, deletion, or cleanup is performed.

If sources succeeded but ontology creation failed, inspect the target for
partial child resources before deliberately creating a new ontology using:

```powershell
.\Start-Sample.ps1 -SourcesManifest '.\runs\<old-run>\sources.manifest.json'
```

If `writeCompleted` is true but verification failed, **do not create again**.
Use a fresh output directory and a read-only check:

```powershell
.\Start-Sample.ps1 -VerifyOnly `
    -TenantId '<tenant-guid>' -CapacityId '<source-capacity-guid>' `
    -WorkspaceId '<target-workspace-guid>' `
    -SourcesManifest '.\runs\<old-run>\sources.manifest.json' `
    -OntologyId '<created-ontology-guid>' -OntologyName '<exact-name>'
```

If the ontology exists but its definition write failed, the launcher refuses to
overwrite it. Inspect it before using the separate explicit
[replacement utility](replace_ontology.py), which accepts `--target-workspace-id`.
See [advanced usage and troubleshooting](ADVANCED.md).

Public export may normalize SQL bindings to portable identity markers and omit
default projected entity properties. Verification checks exact source identity,
keys, columns and topology, not textual equality alone. A target-relative
Warehouse binding is rejected for a cross-workspace ontology.

### SQL login error accompanied by "Database is in transition" (952)

SQL analytics can still be transitioning after Lakehouse load and metadata
refresh report success. ODBC may wrap native SQL error **952** in SQLSTATE
`28000`, alongside `Login failed for user '<token-identified principal>'`
and error `18456`. This combination is not sufficient evidence of a permissions
problem.

The script recognizes native error 952 in bounded SQL-readiness and
asynchronous row-verification retries (including Lakehouse and Open Mirroring).
Each failure is logged; only connection/read checks are repeated, not data
loads or SQL writes. The existing timeout still applies. A genuine login error
18456 **without** a recognized transient diagnostic still fails immediately.

If verification stops, keep both manifests. Sources may contain loaded data,
but the complete dataset has not been verified. **Do not pass a failed source
manifest to the full launcher's `-SourcesManifest`, edit it to say succeeded,
or replay its loads.** Failed source provisioning is not automatically resumable.
Running the full launcher again creates a **new source workspace**, not a
continuation of the old one. Existing resources are retained and may continue
to incur charges; cleanup requires a separate deliberate step.

### Snapshot isolation / concurrent DDL error (3961)

This is a different transient failure from 952. SQL can accept the connection
and then reject a SELECT because a concurrent DDL transaction changed the
object's metadata after the query transaction began. Lakehouse metadata
synchronization can overlap verification even after load/refresh reports
success; the error alone does not identify the concurrent writer.

The script recognizes native SQL error **3961**, including when exposed as
`pyodbc.ProgrammingError` with SQLSTATE `42000`. The existing asynchronous
Lakehouse/MirroredDatabase verification closes the failed connection, waits,
then opens another connection and retries the read in a fresh transaction.
It does not request another metadata refresh merely because of 3961, replay
uploads or INSERTs, or retry SQL writes. Persistent conflicts still time out,
and ordinary syntax/permission errors are not blanket-retried.

Regression tests inject this error during query execution and result fetching,
check connection disposal before reconnecting, and cover timeout and non-replay
of writes. A successful run against settled metadata does not exercise every
cold-provisioning interleaving.

### Kusto HTTPS read timeout during ingestion or verification

`requests.exceptions.ReadTimeout` from a `*.kusto.fabric.microsoft.com` host is
an HTTP response timeout, not SQL error 952/3961. Check the original Python
stack and the manifest's current step: a failure in `seed_kql` calling the
management route is an **ingestion** failure, not a verification failure.
The PowerShell launcher's final exception is only a summary.

The KQL response timeout defaults to 300 seconds, configurable above.
The script runs a retryable read-only readiness probe
before ingestion. Read-only KQL verification queries also retry timeout
exceptions within the per-table wait budget. Authentication, permission,
malformed results and row mismatches still fail explicitly.

An ingestion timeout leaves the write outcome **unknown**: some commands or rows
may already have committed. The script logs the table name and does not replay
that write or mark it verified. Waiting only before verification cannot fix an
earlier ingestion timeout. Cold startup is one possible cause of a delayed
response, but a timeout alone does not establish its cause or rule out network
or service problems. Inspect the saved source workspace/item IDs before any
new run; existing partial resources are retained.

## Optional next-step artifacts

Native semantic-model import accepts a partial or failed source manifest containing
the existing Semantic Model; source refresh and seven-source verification are not
prerequisites. Agent companions still require a successful, fully row-verified
source manifest; they reject the main workflow's Semantic Model data deferral.
These companions do not load data again or change the all-source ontology.
Run them after the main launcher has prepared `.venv`. Pass your target workspace
explicitly: otherwise they default to the **source workspace**.

### Second ontology using native semantic-model import

```powershell
.\.venv\Scripts\python.exe .\create_semantic_ontology.py `
    --sources-manifest '.\runs\<old-run>\sources.manifest.json' `
    --workspace-id '<target-workspace-guid>' `
    --name Ontology_NativeSemanticImport_Demo `
    --manifest '.\semantic-ontology.manifest.json' --execute
```

The companion uses the **same native Gen2 semantic-model import path used by the UX**:

1. Export the source model using public `getDefinition` with `format=TMSL` and
   check the sample tables, columns, types and relationships before any creation.
2. POST to the source manifest's Power BI endpoint at
   `/metadata/workspaces/{target-workspace-id}/artifacts`, with this envelope:

   ```json
   {
     "artifactType": "Ontology",
     "displayName": "<new-ontology-name>",
     "payloadContentType": "InlineJson",
     "workloadPayload": "{\"semanticModelImportConfiguration\":{\"workspaceId\":\"<source-workspace-id>\",\"itemId\":\"<source-semantic-model-id>\"},\"featureLevel\":2}"
   }
   ```

3. Persist the returned `objectId` immediately. A native HTTP 202 contains
   artifact metadata, **not** a public API Location-based operation.
4. Poll `/metadata/artifacts/{objectId}` until the backend reports both
   `provisionState: Active` and `SemanticModelImportStatus: Completed`, with
   `FeatureLevel: 2`. Import completion alone is insufficient while child
   provisioning is still in progress.
5. Read the native-generated definition using public ontology `getDefinition`.
   Check the three original table names, column types/source columns, DirectQuery
   partitions, source workspace/item annotations, shared expression and two
   relationships. The public export's workspace-name placeholder is accepted
   only with the exact pinned source identities.

The companion does **not** submit an ontology definition, call
`updateDefinition`, or fall back to client-side construction. The backend runs
the native `PromoteAsync` pipeline. This preserves native naming and projection:
the sample read-back checker expects Plants/Assets/Readings tables and two
relationships without explicit entity declarations. The script does not invent
entity keys or add entities afterward.

This creation route is a **UX/internal artifact API**, not a documented public
Fabric creation contract. The client and tenant must authorize this route;
browser sign-in cannot bypass API permissions. The `--auth` options
are retained; no MWC-token exchange or SDK is required.

The sample precheck/read-back checker deliberately supports only the shipped
Plants/Assets/Readings model, not arbitrary models or measures/hierarchies.
**The companion does not execute ontology data queries.** Source inventory and
pre-existing ontologies are not modified. An ontology without completed native
import status fails native-status verification.

### Data Agent draft

```powershell
.\.venv\Scripts\python.exe .\create_sample_agent.py --kind data `
    --sources-manifest '.\runs\<old-run>\sources.manifest.json' `
    --workspace-id '<target-workspace-guid>' --name DataAgent_Sample_Demo `
    --manifest '.\data-agent.manifest.json' --execute
```

This creates an unpublished draft referencing the sample **Semantic Model**,
with Plants, Assets and Readings selected by name, not either ontology. Public
read-back verifies the source IDs, instructions, selections and absence of
published parts. Supported datasource types are defined by the published Data
Agent schema; this companion uses a Semantic Model, not an Ontology. No published
definition or publish-info part is submitted. Agent answers are not validated.

### Operations Agent artifact

```powershell
.\.venv\Scripts\python.exe .\create_sample_agent.py --kind operations --unconfigured `
    --sources-manifest '.\runs\<old-run>\sources.manifest.json' `
    --workspace-id '<target-workspace-guid>' --name OperationsAgent_Sample_Demo `
    --manifest '.\operations-agent.manifest.json' --execute
```

This deliberately creates an **unconfigured, inactive artifact** and checks its
reported state. It does **not** attach an ontology or author a playbook. Connect
the desired ontology and author/review the playbook in Fabric before testing.
Monitoring, notifications, publishing and external actions remain disabled.
Operations Agent requires an eligible paid capacity, tenant rollout and a user
identity; this is not a service-principal scenario.

For automated inactive **authoring** checks, use the separate validation runner:

The validation runner reuses the configured workspace metadata origin and expected
host for all agents, including Operations; it does not ask for separate ML/OA
endpoints. Existing paired service overrides remain supported. Artifact-scoped
tokens and returned-host checks are still enforced; no public fallback is used.
`-Agents operations -AllowCreate` selects ten native preview scenarios plus a
manual runtime SKIP. Each creates its own artifact rather than reusing this
companion. PASS requires native `Completed`, a service-rendered static playbook
contract check, and reported `Inactive` or `Unconfigured` before/after. Generated
queries are not executed; data correctness and runtime behavior are not certified.
See [Operations authoring metrics and boundaries](VALIDATION.md#operations-inactive-authoring).

**Empty-playbook limitation:** configured creation can return HTTP 400,
`No rule definitions available in the playbook.`, even with `shouldRun: false`.
An inactive state does not remove the service's playbook-validation requirements.

The configured request is available for environments where an empty playbook
is accepted: omit `--unconfigured`, supply
`--ontology-id`, and optionally `--ontology-workspace-id` (defaults to agent
workspace). Validate this contract in the target environment. It never silently
falls back to an unconfigured artifact or fabricates runnable rules/actions.

### Preview, sign-in and recovery

Omit `--execute` for an offline preview. All companions accept `--auth
auto|cli|browser` and `--client-id` using the same browser-capable authentication
as the main launcher. Each execution requires a **new manifest path**. Name
collisions are refused and no resources are deleted or overwritten.

After an ambiguous failure, inspect the saved operation and workspace first.
If an item exists, do not create again. Recheck with the same source/name/
workspace options, a fresh manifest path, `--execute --verify-only`, and:

- Second ontology: `--ontology-id '<existing-id>'`.
- Agent: `--item-id '<existing-id>'`; retain the original `--kind` and
  `--unconfigured` or ontology-source options.

### Remaining acceptance scenarios

- Native import checks support the supplied sample in normal Daily;
  arbitrary models, additional metadata and other environments require separate
  validation.
- Review Operations playbook previews and runtime behavior separately, then
  explicitly authorize starting monitoring or enabling notifications/actions.
- Validate Data Agent answers before publishing.
- For each ontology source group, ask which asset has the highest temperature
  and which plant owns it. Expected: **A012, 32.9 C, P03 / East Plant / Boston**,
  reading R0120 at 2026-01-01 00:45 UTC. Counts are 3 plants, 12 assets and 120
  readings **per copy**, not summed across the identical source groups.

## Testing and validation scope

Offline tests cover deterministic sample data, source provisioning and verification,
native import payloads and status checks, definition read-back, authentication
selection, timeout/retry handling, and package contents. They do not establish
tenant-policy compatibility, Private Link routing, or cold-start service readiness.
Validate those separately in the intended environment.

For Data Agent functional checks, count-only results can establish A012's reading
count through their own successful SQL/DAX execution; repeating `AssetId` in the
result row is not required. See [functional metrics and proof boundaries](VALIDATION.md#data-agent-functional-metrics).
These checks do not use ALM export as a prerequisite.

Source data checks and definition verification do not establish that ontology
queries, graph refresh, or agents work. Verify query results and agent behavior
before publishing or enabling actions.

Run offline regression tests after dependency setup:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s . -p 'test_*.py'
```

Public API references:
[create ontology](https://learn.microsoft.com/en-us/rest/api/fabric/ontology/items/create-ontology),
[get definition](https://learn.microsoft.com/en-us/rest/api/fabric/ontology/items/get-ontology-definition),
[update definition](https://learn.microsoft.com/en-us/rest/api/fabric/ontology/items/update-ontology-definition),
[create Data Agent](https://learn.microsoft.com/en-us/rest/api/fabric/dataagent/items/create-data-agent),
[Data Agent definition](https://learn.microsoft.com/en-us/rest/api/fabric/articles/item-management/definitions/data-agent-definition),
[Data Agent datasource schema](https://developer.microsoft.com/json-schemas/fabric/item/dataAgent/definition/dataSource/1.0.0/schema.json),
[create Operations Agent](https://learn.microsoft.com/en-us/rest/api/fabric/operationsagent/items/create-operations-agent),
[Operations Agent definition](https://learn.microsoft.com/en-us/rest/api/fabric/articles/item-management/definitions/operations-agent-definition),
[interactive browser credential](https://learn.microsoft.com/en-us/python/api/azure-identity/azure.identity.interactivebrowsercredential).

The ZIP contains an explicit file allowlist and a `PACKAGE.json` SHA-256 inventory.
To rebuild it from these sources without including local environments, tokens,
manifests, or SDK binaries:

```powershell
.\.venv\Scripts\python.exe .\build_package.py --output .\ontology-sample.zip
```
