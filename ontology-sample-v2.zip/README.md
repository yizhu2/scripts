# Daily Fabric ontology source samples

**Creates a new workspace and seven source item types, then loads and verifies
related synthetic data.** Existing Private Link connectivity is required; this
tool does not configure private endpoints, workspace network policies, or DNS.
An Eventhouse is the container for the populated KQL database, not a second copy
of its data.

Entry point: [create_sample.py](create_sample.py). Dependencies:
[requirements.txt](requirements.txt). Tests: [test_create_sample.py](test_create_sample.py).

## What you get

| Item | Data loading | Verification |
|---|---|---|
| Eventhouse + KQL database | `.set` from typed KQL `datatable` literals | Query every row through KQL |
| Lakehouse | Upload typed Parquet to Files; Load Table API creates Delta tables | Query every row through SQL analytics endpoint |
| Mirrored database | Open Mirroring, no external database required | Wait for replicated rows through SQL analytics endpoint |
| Semantic model | Inline Power Query import partitions, two many-to-one relationships | Refresh this specific model; DAX-query every row |
| SQL database | Parameterized T-SQL inserts into new tables | Query every row |
| Warehouse | Parameterized T-SQL inserts into new tables | Query every row |

Every data-bearing item has **Plants (3 rows), Assets (12), Readings (120)**.
Relationships: `Assets.PlantId -> Plants.PlantId` and
`Readings.AssetId -> Assets.AssetId`. IDs and values are identical across sources.
Readings contain UTC timestamps starting at 2026-01-01, every five minutes, plus
temperature measurements. Source tables have stable unique keys; the script
does not add SQL key constraints. Relationships are explicit in the semantic
model and represented by matching foreign-key values in the other sources.

This does **not** create an Ontology item, entity types, bindings, or a graph.
Source creation is not a claim that every source is bindable by the current
Daily Ontology UI or engine.

## Prerequisites

- Python 3.10+ and Azure CLI.
- [Microsoft ODBC Driver 18 for SQL Server](https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server).
- A **Daily** tenant and existing active Fabric capacity with all requested
  workloads enabled. The caller needs workspace-creation permission and capacity
  assignment rights. The created workspace gives the caller ownership.
- A user identity with the relevant Fabric item permissions, Power BI model
  creation/refresh/Build permissions, OneLake writes, and SQL/KQL data access.
  The tenant must allow the Power BI **Dataset Execute Queries REST API**.
  This script intentionally uses a tenant-specific `AzureCliCredential`; it
  neither accepts tokens on the command line nor writes tokens to disk.
- Run from a machine on the approved VNet/VPN with the correct private DNS.
  HTTPS access is needed for Entra, Fabric, Power BI, OneLake, and KQL.
  SQL connections need **TDS**, not HTTPS, over TCP 1433 (plus any SQL routing
  requirements for your environment).

**Important:** existing tenant-level Private Link connectivity does not
automatically configure workspace-level Private Link on a new workspace.
If your policy requires workspace-specific private endpoints or associations,
have your network administrator establish that workflow first. The script does
not disable Block Public Access, add network exceptions, forge service access
headers, or fall back to public endpoints. DNS routing/private-IP enforcement
is the responsibility of the existing network setup.

## Run from PowerShell

From this directory:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r .\requirements.txt
az login --tenant '<daily-tenant-guid>' --allow-no-subscriptions

$sampleArgs = @(
    '--tenant-id', '<daily-tenant-guid>',
    '--capacity-id', '<daily-capacity-guid>',
    '--workspace-name', "OntologySources_$(Get-Date -Format yyyyMMdd_HHmmss)",
    '--manifest', '.\daily-sample.manifest.json'
)

# Offline preview: no tokens, resource changes, or manifest writes.
.\.venv\Scripts\python.exe .\create_sample.py @sampleArgs

# Creates billable resources. Add endpoint overrides here if needed.
.\.venv\Scripts\python.exe .\create_sample.py @sampleArgs --execute
```

No sample credentials or environment-specific IDs are embedded in the script.
The CLI uses production Entra authentication and the non-`-int` Power BI token
audience for Daily. Do not use this Daily tool against production.

### Daily / Private Link endpoint overrides

Defaults follow the backend repository's
[Fabric environment registry](https://dev.azure.com/powerbi/MWC/_git/workload-digitaloperations?path=/tools/AIQuestion/aiquestion/fabric/constants.py&version=GBmaster).
The small standalone tool uses the same endpoint/auth conventions without
depending on the larger AIQuestion application or its internal helper APIs.

| Option | Default / discovery |
|---|---|
| `--fabric-api` | `https://dailyapi.fabric.microsoft.com/v1` |
| `--powerbi-api` | `https://wabi-daily-us-east2-redirect.analysis.windows.net` |
| `--onelake-url` | `https://daily-onelake.dfs.fabric.microsoft.com` |
| `--kql-endpoint` | KQL database GET `properties.queryServiceUri` |
| `--kusto-scope` | `https://kusto.kusto.windows.net/.default` |
| `--sql-endpoints` | SQL item GET connection metadata; see below |

Use the **documented connection URLs for your Daily Private Link setup**, not an
arbitrary public endpoint or guessed `privatelink` hostname. OneLake accepts an
origin template containing `{workspaceId}` when the administrator has configured
workspace-scoped routing. It still requires the new workspace's network
association to exist; the template alone does not create it.

SQLDatabase uses returned `serverFqdn` and `databaseName`. Warehouse, Lakehouse,
and MirroredDatabase use their item display name as the SQL catalog and their
returned SQL endpoint host. If Daily exposes a different catalog/host, pass the
actual SQL connection details as a JSON map; for example:

```powershell
$sql = @{
    MirroredDatabase = @{
        server = '<actual-private-sql-fqdn>'
        catalog = '<actual-sql-catalog>'
    }
} | ConvertTo-Json -Compress

.\.venv\Scripts\python.exe .\create_sample.py @sampleArgs --sql-endpoints $sql --execute
```

Endpoint override keys are `Lakehouse`, `MirroredDatabase`, `SQLDatabase`, and
`Warehouse`; each allows `server`, `catalog`, or both. The default item names are
`OntologySample_<ItemType>`; change `--prefix` if needed.

## Completion, failures, and cleanup

- A zero exit code **after `--execute`** means all seven source types passed
  verification. A preview is not a deployment.
- The manifest records workspace/item IDs as creation completes, the current
  step, accepted operation URLs, expected counts, and per-source verification.
  Full row comparisons also detect wrong values, duplicate keys, and missing
  rows. Floating-point measurements are compared to six decimal places.
- HTTP and polling waits are bounded; `--timeout` defaults to 1,800 seconds per
  operation/table wait, not a total run limit. `Retry-After` is honored for HTTP
  retries and Fabric operations. Missing or failed endpoints are not skipped.
- The first failure stops the run with a nonzero exit code. There is no automatic
  rollback, resume, mutation replay after ambiguous network failures, or deletion.
  If a create request was accepted but its response was lost, inspect the
  workspace/operation before starting another run.
- An existing manifest path is refused. To run a fresh independent sample, use a
  new workspace name and manifest path. Do not replay Open Mirroring's initial
  INSERT files into an existing mirrored item.
- Open Mirroring uploads metadata first, uploads the initial Parquet file with
  an ignored underscore prefix, then atomically renames it to
  `00000000000000000001.parquet`. The optional CDC marker column is omitted for
  this initial INSERT-only load.
- OneLake uploads use the SDK's create-and-upload path with an `If-None-Match: *`
  condition, so new files are created but existing files are not overwritten.
  Earlier script versions used `overwrite=False`, which skipped file creation
  in the ADLS SDK and could fail with `PathNotFound` on the first append.
  If affected, replace the script with this version and use a new workspace
  name and manifest for a fresh run. Retain the old manifest to identify the
  partially created workspace; this update does not add resume support.
- Delete **only the newly created sample workspace** in the Daily portal when
  finished, after confirming its ID in the manifest. This removes its sample
  items and avoids leaving resources running. The script does not delete
  anything automatically.

For 403/network failures, check the private network path, identity permissions,
and Daily workload flags. For cross-host operation/refresh URLs, configure the
correct Daily API origin; the script deliberately refuses to forward tokens
across hosts. For mirror/lakehouse timeouts, inspect replication and SQL endpoint
provisioning before increasing the timeout. Do not treat `Running` mirroring or
uploaded files alone as proof that sample data is queryable.

## Local validation and environment limitation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s . -p 'test_*.py' -v
```

Tests cover data integrity, definitions, Parquet types, polling/failure handling,
safe publication, SQL/DAX/KQL verification, and offline preview behavior. They
do not replace a live run. Public API contracts were checked against Microsoft
documentation; **Daily Private Link feature availability and end-to-end behavior
must still be validated with your tenant, capacity, and network**.

## API references

- [Create workspace](https://learn.microsoft.com/en-us/rest/api/fabric/core/workspaces/create-workspace)
- [Create KQL database](https://learn.microsoft.com/en-us/rest/api/fabric/kqldatabase/items/create-kql-database)
- [Kusto REST response and partial failures](https://learn.microsoft.com/en-us/kusto/api/rest/response)
- [Lakehouse Load Table](https://learn.microsoft.com/en-us/rest/api/fabric/lakehouse/tables/load-table)
- [Open Mirroring definition](https://learn.microsoft.com/en-us/rest/api/fabric/articles/item-management/definitions/mirrored-database-definition)
- [Open Mirroring landing zone](https://learn.microsoft.com/en-us/fabric/mirroring/open-mirroring-landing-zone-format)
- [Open Mirroring publication guidance](https://learn.microsoft.com/en-us/fabric/mirroring/open-mirroring-best-practices)
- [Get SQL database](https://learn.microsoft.com/en-us/rest/api/fabric/sqldatabase/items/get-sql-database)
- [SQL connectivity](https://learn.microsoft.com/en-us/fabric/data-warehouse/connectivity)
- [Semantic model definition](https://learn.microsoft.com/en-us/rest/api/fabric/articles/item-management/definitions/semantic-model-definition)
- [Dataset Execute Queries](https://learn.microsoft.com/en-us/rest/api/power-bi/datasets/execute-queries-in-group)
- [Fabric Private Link](https://learn.microsoft.com/en-us/fabric/security/security-private-links-overview)
