"""Build a portable source-only ZIP from an explicit allowlist, never local credentials or run output."""

import argparse
import hashlib
import io
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

FILES = (
    "Start-Sample.ps1", "run_sample.py", "sample_auth.py", "create_sample.py",
    "create_ontology.py", "create_ontology.ps1", "replace_ontology.py",
    "requirements.txt", "README.md", "ADVANCED.md", ".gitignore", "build_package.py",
    "test_create_sample.py", "test_create_ontology.py", "test_replace_ontology.py",
    "test_run_sample.py", "test_sample_auth.py", "test_build_package.py",
    "sample_tmdl.py", "test_sample_tmdl.py",
    "create_semantic_ontology.py", "test_create_semantic_ontology.py",
    "create_sample_agent.py", "test_create_sample_agent.py",
)


def build(output, source=None):
    source = source or Path(__file__).resolve().parent
    contents = {name: (source / name).read_bytes() for name in FILES}
    manifest = {
        "packageVersion": 13,
        "entryPoint": "Start-Sample.ps1",
        "sdkBinariesIncluded": False,
        "sdkRequired": False,
        "internalFeedAccessRequired": False,
        "files": {name: hashlib.sha256(data).hexdigest() for name, data in contents.items()},
    }
    buffer = io.BytesIO()
    with ZipFile(buffer, "w", compression=ZIP_DEFLATED) as archive:
        for name, data in contents.items():
            archive.writestr("ontology-sample/" + name, data)
        archive.writestr("ontology-sample/PACKAGE.json", json.dumps(manifest, indent=2))
    with output.open("xb") as stream:
        stream.write(buffer.getvalue())
    return hashlib.sha256(buffer.getvalue()).hexdigest()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    digest = build(args.output)
    print(f"ZIP: {args.output.resolve()}\nSHA256: {digest}")
