import builtins
import copy
import io
import json
import shutil
import unittest
from contextlib import contextmanager, redirect_stderr, redirect_stdout
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
from uuid import uuid4

import discover_validation as discovery
from create_ontology import build_definition
from create_sample import PBI_SCOPE, sample_tables
from target_routing import target_fabric_api
from validate_sample import catalog, validate_config
from validation_setup import prerequisites

TENANT = "10000000-0000-0000-0000-000000000001"
WORKSPACE = "20000000-0000-0000-0000-000000000002"
CAPACITY = "30000000-0000-0000-0000-000000000003"
ONTOLOGY = "40000000-0000-0000-0000-000000000004"
LAKEHOUSE = "50000000-0000-0000-0000-000000000005"
SOURCE_EH = "60000000-0000-0000-0000-000000000006"
SOURCE_DB = "70000000-0000-0000-0000-000000000007"
CHILD_EH = "80000000-0000-0000-0000-000000000008"
CHILD_DB = "90000000-0000-0000-0000-000000000009"
SQL_ID = "a0000000-0000-0000-0000-00000000000a"
CLIENT_ID = "b0000000-0000-0000-0000-00000000000b"
ROUTE = target_fabric_api("wspl", WORKSPACE, TENANT)
ORIGIN = ROUTE.removesuffix("/v1")
HOST = discovery.expected_host(WORKSPACE)
WORKLOAD = f"https://{HOST}/webapi/capacities/{CAPACITY}/workloads/DO/DigitalOperationsService/direct"
SOURCE_CLUSTER = "https://source.kusto.fabric.microsoft.com"
CHILD_CLUSTER = "https://child.kusto.fabric.microsoft.com"
SERVER = "sample.daily-datawarehouse.fabric.microsoft.com"
SECRET = "opaque-sensitive-test-value"


def fixtures(network="wspl", ux_origin=None, ux_host=None):
    route = target_fabric_api(network, WORKSPACE, TENANT)
    origin = ux_origin or route.removesuffix("/v1")
    host = ux_host or (HOST if network == "wspl" else "observed-daily-cluster.pbidedicated.windows.net")
    workload = f"https://{host}/webapi/capacities/{CAPACITY}/workloads/DO/DigitalOperationsService/direct"
    items = {"Lakehouse": {"id": LAKEHOUSE, "displayName": "Sample_Lakehouse"},
             "Eventhouse": {"id": SOURCE_EH, "displayName": "Sample_Eventhouse"},
             "KQLDatabase": {"id": SOURCE_DB, "displayName": "Sample_KQLDatabase"}}
    sources = {"status": "succeeded", "tenantId": TENANT, "capacityId": CAPACITY,
               "workspaceId": WORKSPACE, "existingWorkspaceId": WORKSPACE, "workspaceName": "SampleWorkspace",
               "sameWorkspace": True, "targetNetwork": network, "sourceTypes": list(discovery.SOURCE_TYPES),
               "items": items, "verified": {kind: {t.name: len(t.rows) for t in sample_tables()}
                                          for kind in ("Lakehouse", "KQLDatabase")},
               "endpoints": {"fabric": route, "powerbi": "https://dailyapi.powerbi.com/v1.0/myorg",
                             "onelake": "https://example.daily-dfs.fabric.microsoft.com"}}
    properties = {
        "Lakehouse": {"oneLakeTablesPath": "https://example.daily-dfs.fabric.microsoft.com/sample/Tables",
                      "sqlEndpointProperties": {"connectionString": SERVER, "id": SQL_ID,
                                                "provisioningStatus": "Success"}},
        "KQLDatabase": {"queryServiceUri": SOURCE_CLUSTER, "parentEventhouseItemId": SOURCE_EH},
    }
    definition = build_definition(sources, properties, "https://dailyapi.powerbi.com")
    for table in definition["model"]["tables"]:
        if table["name"].startswith("Lakehouse_"):
            table["partitions"][0]["source"]["schemaName"] = "dbo"
    run = {"status": "succeeded", "environment": "Daily", "authoringMode": "public",
           "tenantId": TENANT, "capacityId": CAPACITY, "targetWorkspaceId": WORKSPACE,
           "targetNetwork": network, "sameWorkspace": True, "targetFabricApi": route,
           "sourceFabricApi": route, "sourceWorkspaceId": WORKSPACE,
           "sourceTypes": list(discovery.SOURCE_TYPES), "sourceItems": copy.deepcopy(items),
           "authoredDefinition": definition, "items": {"Ontology": {"id": ONTOLOGY}},
           "authentication": "cli", "uxMetadataApi": origin, "uxExpectedWorkloadHost": host}
    documents = {
        route + "/workspaces/" + WORKSPACE: {"id": WORKSPACE, "capacityId": CAPACITY},
        origin + "/metadata/v201606/generatemwctokenv2":
            {"TargetUriHost": host, "Token": SECRET, "CapacityObjectId": CAPACITY},
        workload + f"/v4/workspaces/{WORKSPACE}/ontologies/{ONTOLOGY}/definition": definition,
        origin + "/metadata/artifacts/" + ONTOLOGY:
            {"objectId": ONTOLOGY, "artifactType": "Ontology", "workspaceObjectId": WORKSPACE,
             "extendedProperties": {"ChildItems": json.dumps({"OntologyEventhouse": CHILD_EH})}},
        origin + "/metadata/artifacts/" + CHILD_EH:
            {"objectId": CHILD_EH, "artifactType": "KustoEventHouse", "parentArtifactObjectId": ONTOLOGY,
             "extendedProperties": {"QueryServiceUri": CHILD_CLUSTER},
             "artifactRelations": [{"settings": 1, "dependentArtifactObjectId": CHILD_DB}]},
    }
    for kind, identity, name, collection, props in (
        ("Ontology", ONTOLOGY, "Ontology", None, {}),
        ("Eventhouse", SOURCE_EH, items["Eventhouse"]["displayName"], None, {}),
        ("Lakehouse", LAKEHOUSE, items["Lakehouse"]["displayName"], "lakehouses", properties["Lakehouse"]),
        ("KQLDatabase", SOURCE_DB, items["KQLDatabase"]["displayName"], "kqlDatabases", properties["KQLDatabase"]),
        ("Eventhouse", CHILD_EH, "ChildEventhouse", None, {}),
        ("KQLDatabase", CHILD_DB, "ActualChildDatabase", "kqlDatabases",
         {"parentEventhouseItemId": CHILD_EH, "queryServiceUri": CHILD_CLUSTER}),
    ):
        item = {"id": identity, "type": kind, "displayName": name, "workspaceId": WORKSPACE, "properties": props}
        documents[route + f"/workspaces/{WORKSPACE}/items/{identity}"] = copy.deepcopy(item)
        if collection:
            documents[route + f"/workspaces/{WORKSPACE}/{collection}/{identity}"] = copy.deepcopy(item)
    return run, sources, documents


class DiscoveryTests(unittest.TestCase):
    def setUp(self):
        # Keep test files in this repository, not the machine's shared temporary directory.
        self.directory = Path(__file__).parent / (".test-discovery-" + uuid4().hex)
        self.directory.mkdir()
        self.addCleanup(shutil.rmtree, self.directory)
        self.run_path = self.directory / "run.manifest.json"
        self.sources_path = self.directory / "sources.manifest.json"
        self.output = self.directory / "validation.json"
        self.run, self.sources, self.documents = fixtures()
        self.calls = []
        self.instances = []
        self.save_inputs()

    def save_inputs(self):
        self.run_path.write_text(json.dumps(self.run), encoding="utf-8")
        self.sources_path.write_text(json.dumps(self.sources), encoding="utf-8")

    def inputs(self, **kwargs):
        self.save_inputs()
        return discovery.load_inputs(self.run_path, self.sources_path, **kwargs)

    def api_factory(self, base, scope, credential, timeout, **kwargs):
        outer = self

        class FakeApi:
            def __init__(self):
                self.base = base
                self.closed = False

            def json(self, method, path, body=None):
                credential.get_token(scope)
                outer.calls.append((method, path, body))
                value = outer.documents[path]
                if isinstance(value, Exception):
                    raise value
                return copy.deepcopy(value)

            def close(self):
                self.closed = True

        self.assertTrue(kwargs["sensitive_response"])
        instance = FakeApi()
        self.instances.append(instance)
        return instance

    @contextmanager
    def identity(self, config):
        yield Mock()

    def discover(self):
        run, sources, config, route, origin = self.inputs()
        with patch.object(discovery, "DiscoveryApi", side_effect=self.api_factory):
            return discovery.discover(config, run, sources, route, origin, Mock())

    def main(self, execute=True, extra=()):
        args = ["--run-manifest", str(self.run_path), "--output-config", str(self.output), *extra]
        if execute:
            args.append("--execute")
        output = io.StringIO()
        with redirect_stdout(output), redirect_stderr(output):
            code = discovery.main(args)
        return code, output.getvalue()

    def execute(self):
        with patch.object(discovery, "DiscoveryApi", side_effect=self.api_factory), \
                patch.object(discovery, "open_identity", side_effect=self.identity):
            return self.main()

    def test_plan_is_offline_and_does_not_create_config(self):
        with patch.object(discovery, "open_identity") as auth, patch.object(discovery, "DiscoveryApi") as api:
            code, output = self.main(execute=False)
        self.assertEqual(code, 0)
        self.assertIn("PLAN ONLY", output)
        self.assertIn(ORIGIN, output)
        auth.assert_not_called()
        api.assert_not_called()
        self.assertFalse(self.output.exists())

    def test_success_validates_all_19_positive_scenarios_and_preserves_no_secrets(self):
        code, output = self.execute()
        self.assertEqual(code, 0, output)
        saved = json.loads(self.output.read_text(encoding="utf-8"))
        self.assertEqual(len(discovery.POSITIVE_SCENARIOS), 19)
        self.assertTrue(set(discovery.POSITIVE_SCENARIOS) <= catalog().keys())
        self.assertEqual(prerequisites(validate_config(copy.deepcopy(saved)),
                                       discovery.POSITIVE_SCENARIOS, check_creation=False), {})
        self.assertEqual(saved["ux_metadata_api"], ORIGIN)
        self.assertEqual(saved["ux_workload_host"], HOST)
        self.assertEqual(saved["authoring_mode"], "ux")
        self.assertEqual(saved["preview"]["execution"]["eventhouse_id"], CHILD_EH)
        self.assertEqual(saved["preview"]["execution"]["database_id"], CHILD_DB)
        self.assertEqual(saved["preview"]["sources"]["kql"]["database"], SOURCE_DB)
        self.assertEqual(saved["preview"]["sources"]["lakehouse"]["schema"], "dbo")
        self.assertEqual(saved["discovery"]["source_sql_catalog_provenance"], "live-fabric-item-metadata")
        self.assertEqual(saved["discovery"]["source_sql_schema_provenance"],
                         "selected-run-authored-definition-not-live-verified")
        self.assertFalse(saved["discovery"]["source_sql_schema_live_verified"])
        self.assertEqual(saved["generation_lakehouse_id"], LAKEHOUSE)
        self.assertEqual(saved["generation_source_workspace_id"], WORKSPACE)
        self.assertEqual(saved["p0_access"], {"context": "authorized"})
        self.assertNotIn("allow_create", saved)
        self.assertNotIn(SECRET, self.output.read_text(encoding="utf-8") + output)
        self.assertTrue(all(instance.closed for instance in self.instances))
        posts = [call for call in self.calls if call[0] != "GET"]
        self.assertEqual(posts, [("POST", ORIGIN + "/metadata/v201606/generatemwctokenv2",
                                 {"workspaceObjectId": WORKSPACE, "workloadType": "DO",
                                  "artifacts": [{"artifactType": "Ontology", "artifactObjectId": ONTOLOGY}]})])

    def test_existing_config_blocks_before_authentication(self):
        self.output.write_text("KEEP", encoding="utf-8")
        with patch.object(discovery, "open_identity") as auth:
            code, _ = self.main()
        self.assertEqual(code, 2)
        auth.assert_not_called()
        self.assertEqual(self.output.read_text(encoding="utf-8"), "KEEP")

    def test_explicit_sources_manifest_is_used_not_another_run(self):
        other = self.directory / "selected-sources.json"
        self.sources_path.rename(other)
        code, _ = self.main(execute=False, extra=("--sources-manifest", str(other)))
        self.assertEqual(code, 0)
        code, _ = self.main(execute=False)
        self.assertEqual(code, 2)

    def test_manifest_identity_and_route_mismatches_are_rejected_offline(self):
        cases = [
            ("tenantId", "not-a-guid"), ("capacityId", WORKSPACE),
            ("targetNetwork", "public"), ("sameWorkspace", False),
            ("sourceWorkspaceId", TENANT), ("targetFabricApi", "https://dailyapi.fabric.microsoft.com/v1"),
            ("sourceFabricApi", "https://dailyapi.fabric.microsoft.com/v1"),
            ("sourceTypes", ["Lakehouse"]), ("sourceTypes", ["Lakehouse", "Eventhouse", "Warehouse"]),
            ("environment", "Prod"), ("status", "failed"),
            ("uxMetadataApi", "https://wabi-daily-us-east2-redirect.analysis.windows.net"),
            ("uxExpectedWorkloadHost", "other.zff.daily-c.fabric.microsoft.com"),
        ]
        for field, value in cases:
            with self.subTest(field=field, value=value):
                self.run, self.sources, self.documents = fixtures()
                self.run[field] = value
                self.save_inputs()
                with patch.object(discovery, "open_identity") as auth:
                    code, _ = self.main()
                self.assertEqual(code, 2)
                auth.assert_not_called()
                self.assertFalse(self.output.exists())

    def test_sources_manifest_conflicts_and_invalid_inventory_are_rejected(self):
        for mutate in (
            lambda s: s.update(sameWorkspace=False),
            lambda s: s.update(workspaceId=TENANT),
            lambda s: s.update(tenantId=WORKSPACE),
            lambda s: s["items"]["Lakehouse"].update(id=CHILD_EH),
            lambda s: s["items"]["Lakehouse"].update(displayName="Renamed"),
            lambda s: s["verified"].update(Lakehouse={}),
            lambda s: s["endpoints"].update(fabric="https://dailyapi.fabric.microsoft.com/v1"),
        ):
            self.run, self.sources, self.documents = fixtures()
            mutate(self.sources)
            with self.assertRaises((discovery.DiscoveryError, ValueError)):
                self.inputs()

    def test_authored_identity_missing_duplicates_and_mixed_tables_are_rejected(self):
        for field in ("ONT_WorkspaceId", "ONT_ItemId", "ONT_ItemKind"):
            self.run, self.sources, self.documents = fixtures()
            partition = self.run["authoredDefinition"]["model"]["tables"][0]["partitions"][0]
            annotation = next(entry for entry in partition["annotations"] if entry["name"] == field)
            annotation["value"] = CHILD_EH
            with self.subTest(field=field), self.assertRaises(discovery.DiscoveryError):
                self.inputs()
        self.run, self.sources, self.documents = fixtures()
        self.run["authoredDefinition"]["model"]["tables"].pop()
        with self.assertRaises(discovery.DiscoveryError):
            self.inputs()

    def test_browser_requires_explicit_client_and_cli_never_accepts_client(self):
        self.run["authentication"] = "browser"
        config = self.inputs()[2]
        with self.assertRaises(discovery.DiscoveryError):
            discovery.complete_initial(config, ROUTE, discovery.MissingFields(non_interactive=True))
        config = self.inputs(client_id=CLIENT_ID)[2]
        self.assertEqual(config["auth"], "browser")
        self.assertEqual(config["client_id"], CLIENT_ID)
        config = self.inputs(auth="cli")[2]
        self.assertEqual(config["auth"], "cli")
        with self.assertRaises(discovery.DiscoveryError):
            self.inputs(auth="cli", client_id=CLIENT_ID)
        self.run["authentication"] = "auto"
        self.assertEqual(self.inputs(auth="cli")[2]["auth"], "cli")
        self.assertIsNone(self.inputs()[2]["auth"])

    def test_mwc_rejects_other_workspace_public_host_and_url_forms_before_workload_call(self):
        key = ORIGIN + "/metadata/v201606/generatemwctokenv2"
        for host in ("other.zff.daily-c.fabric.microsoft.com", "wabi-daily-us-east2.analysis.windows.net",
                     "dailyapi.fabric.microsoft.com", "https://" + HOST, HOST + ":443", HOST + "/",
                     HOST + ".evil.example", HOST + "\n", discovery.expected_host(TENANT)):
            self.run, self.sources, self.documents = fixtures()
            self.calls.clear()
            self.documents[key]["TargetUriHost"] = host
            with self.subTest(host=host), self.assertRaises((discovery.DiscoveryError, ValueError)):
                self.discover()
            self.assertFalse(any("/workloads/" in path for _, path, _ in self.calls))

    def test_mwc_capacity_mismatch_or_missing_token_blocks(self):
        key = ORIGIN + "/metadata/v201606/generatemwctokenv2"
        for field, value in (("CapacityObjectId", TENANT), ("Token", ""), ("Token", 1), ("TargetUriHost", None)):
            self.run, self.sources, self.documents = fixtures()
            self.documents[key][field] = value
            with self.subTest(field=field), self.assertRaises(discovery.DiscoveryError):
                self.discover()

    def test_missing_child_and_bad_childitems_never_substitute_source_eventhouse(self):
        key = ORIGIN + "/metadata/artifacts/" + ONTOLOGY
        for child_items in (None, {}, "not JSON", "{}", json.dumps({"OntologyEventhouse": SOURCE_EH}),
                            json.dumps({"OntologyEventhouse": ONTOLOGY})):
            self.run, self.sources, self.documents = fixtures()
            self.documents[key]["extendedProperties"]["ChildItems"] = child_items
            with self.subTest(child_items=child_items), self.assertRaises(discovery.DiscoveryError):
                self.discover()

    def test_child_relation_requires_one_exact_cascade_delete_edge(self):
        key = ORIGIN + "/metadata/artifacts/" + CHILD_EH
        for relations in (None, [], [{"settings": 0, "dependentArtifactObjectId": CHILD_DB}],
                          [{"settings": True, "dependentArtifactObjectId": CHILD_DB}],
                          [{"settings": "1", "dependentArtifactObjectId": CHILD_DB}],
                          [{"settings": 1, "dependentArtifactObjectId": SOURCE_DB}],
                          [{"settings": 1, "dependentArtifactObjectId": "ontology_kustodb"}],
                          [{"settings": 1, "dependentArtifactObjectId": CHILD_DB}] * 2):
            self.run, self.sources, self.documents = fixtures()
            self.documents[key]["artifactRelations"] = relations
            with self.subTest(relations=relations), self.assertRaises(discovery.DiscoveryError):
                self.discover()

    def test_noncascade_relations_do_not_choose_first_item(self):
        key = ORIGIN + "/metadata/artifacts/" + CHILD_EH
        self.documents[key]["artifactRelations"].insert(0, {"settings": 0, "dependentArtifactObjectId": SOURCE_DB})
        self.assertEqual(self.discover()["preview"]["execution"]["database_id"], CHILD_DB)

    def test_raw_metadata_symbolic_cascade_delete_enum_is_supported(self):
        key = ORIGIN + "/metadata/artifacts/" + CHILD_EH
        self.documents[key]["artifactRelations"] = [
            {"settings": "Datasource", "settingsList": "None", "dependentArtifactObjectId": SOURCE_DB},
            {"settings": "CascadeDelete", "settingsList": "CascadeDelete", "dependentArtifactObjectId": CHILD_DB},
        ]
        self.assertEqual(self.discover()["preview"]["execution"]["database_id"], CHILD_DB)

    def test_child_parent_workspace_and_cluster_mismatches_block(self):
        cases = [
            (ORIGIN + "/metadata/artifacts/" + CHILD_EH, "parentArtifactObjectId", SOURCE_EH),
            (ORIGIN + "/metadata/artifacts/" + ONTOLOGY, "workspaceObjectId", TENANT),
            (ROUTE + f"/workspaces/{WORKSPACE}/items/{CHILD_EH}", "workspaceId", TENANT),
            (ROUTE + f"/workspaces/{WORKSPACE}/items/{CHILD_DB}", "type", "Eventhouse"),
        ]
        for key, field, value in cases:
            self.run, self.sources, self.documents = fixtures()
            self.documents[key][field] = value
            with self.subTest(field=field), self.assertRaises(discovery.DiscoveryError):
                self.discover()
        key = ROUTE + f"/workspaces/{WORKSPACE}/kqlDatabases/{CHILD_DB}"
        for field, value in (("parentEventhouseItemId", SOURCE_EH), ("queryServiceUri", SOURCE_CLUSTER)):
            self.run, self.sources, self.documents = fixtures()
            self.documents[key]["properties"][field] = value
            with self.assertRaises(discovery.DiscoveryError):
                self.discover()

    def test_workload_payload_endpoint_representation_is_supported_but_not_guessed(self):
        key = ORIGIN + "/metadata/artifacts/" + CHILD_EH
        self.documents[key]["extendedProperties"] = {}
        self.documents[key]["workloadPayload"] = json.dumps({"content": json.dumps({"queryUri": CHILD_CLUSTER})})
        self.assertEqual(self.discover()["preview"]["execution"]["cluster_uri"], CHILD_CLUSTER)
        self.documents[key]["workloadPayload"] = "{invalid"
        with self.assertRaises(discovery.DiscoveryError):
            self.discover()

    def test_source_metadata_identity_parent_endpoint_and_schema_are_checked(self):
        key = ROUTE + f"/workspaces/{WORKSPACE}/kqlDatabases/{SOURCE_DB}"
        self.documents[key]["properties"]["parentEventhouseItemId"] = CHILD_EH
        with self.assertRaises(discovery.DiscoveryError):
            self.discover()
        self.run, self.sources, self.documents = fixtures()
        key = ROUTE + f"/workspaces/{WORKSPACE}/lakehouses/{LAKEHOUSE}"
        self.documents[key]["properties"]["sqlEndpointProperties"]["connectionString"] = "evil.example"
        with self.assertRaises(ValueError):
            self.discover()
        self.run, self.sources, self.documents = fixtures()
        self.documents[key]["properties"]["sqlEndpointProperties"]["provisioningStatus"] = "InProgress"
        with self.assertRaises(discovery.DiscoveryError):
            self.discover()

    def test_live_definition_source_drift_blocks_publication(self):
        key = WORKLOAD + f"/v4/workspaces/{WORKSPACE}/ontologies/{ONTOLOGY}/definition"
        self.documents[key] = {"model": {"tables": []}}
        code, output = self.execute()
        self.assertEqual(code, 2, output)
        self.assertFalse(self.output.exists())

    def test_metadata_403_does_not_fallback_or_write_a_config(self):
        key = ORIGIN + "/metadata/v201606/generatemwctokenv2"
        self.documents[key] = discovery.DiscoveryError("Read-only discovery request failed. HTTP 403. No fallback.")
        code, output = self.execute()
        self.assertEqual(code, 2)
        self.assertIn("403", output)
        self.assertFalse(self.output.exists())
        self.assertFalse(any("wabi" in path for _, path, _ in self.calls))
        self.assertEqual(sum(method == "POST" for method, _, _ in self.calls), 1)

    def test_unknown_network_error_body_and_tokens_are_never_printed(self):
        key = ORIGIN + "/metadata/artifacts/" + ONTOLOGY
        self.documents[key] = RuntimeError("Authorization: Bearer " + SECRET)
        code, output = self.execute()
        self.assertEqual(code, 2)
        self.assertNotIn(SECRET, output)
        self.assertFalse(self.output.exists())

    def test_cli_auth_failure_does_not_invoke_browser(self):
        self.save_inputs()
        with patch("azure.identity.AzureCliCredential") as cli, \
                patch("azure.identity.InteractiveBrowserCredential") as browser:
            cli.return_value.get_token.side_effect = RuntimeError(SECRET)
            code, output = self.main()
        self.assertEqual(code, 2)
        self.assertNotIn(SECRET, output)
        browser.assert_not_called()
        cli.return_value.close.assert_called_once()
        self.assertFalse(self.output.exists())

    def test_browser_auth_is_only_explicit_approved_client(self):
        config = self.inputs(auth="browser", client_id=CLIENT_ID)[2]
        with patch("azure.identity.AzureCliCredential") as cli, \
                patch("azure.identity.InteractiveBrowserCredential") as browser:
            with discovery.open_identity(config) as credential:
                self.assertIs(credential, browser.return_value)
        cli.assert_not_called()
        browser.assert_called_once_with(tenant_id=TENANT, client_id=CLIENT_ID,
                                        redirect_uri="http://localhost:8400", disable_automatic_authentication=True)
        browser.return_value.authenticate.assert_called_once_with(scopes=[PBI_SCOPE])
        browser.return_value.close.assert_called_once()

    def test_atomic_output_race_preserves_competing_file_and_cleans_stage(self):
        def race(source, destination):
            destination.write_text("COMPETITOR", encoding="utf-8")
            raise FileExistsError()

        with patch.object(discovery.os, "link", side_effect=race), self.assertRaises(discovery.DiscoveryError):
            discovery.write_exclusive(self.output, {"safe": True})
        self.assertEqual(self.output.read_text(encoding="utf-8"), "COMPETITOR")
        self.assertEqual(list(self.directory.glob("*.staging")), [])

    def test_atomic_publication_failure_does_not_leave_partial_config(self):
        with patch.object(discovery.os, "link", side_effect=OSError()), self.assertRaises(discovery.DiscoveryError):
            discovery.write_exclusive(self.output, {"safe": True})
        self.assertFalse(self.output.exists())
        self.assertEqual(list(self.directory.glob("*.staging")), [])

    def test_invalid_json_diagnostic_does_not_echo_input(self):
        self.run_path.write_text('{"token": "' + SECRET, encoding="utf-8")
        code, output = self.main()
        self.assertEqual(code, 2)
        self.assertNotIn(SECRET, output)
        self.assertFalse(self.output.exists())

    def test_missing_output_directory_is_offline_failure(self):
        self.output = self.directory / "missing" / "config.json"
        with patch.object(discovery, "open_identity") as auth:
            code, _ = self.main()
        self.assertEqual(code, 2)
        auth.assert_not_called()

    def test_missing_routes_prompt_only_two_fields_before_auth_or_requests(self):
        self.run.pop("uxMetadataApi")
        self.run.pop("uxExpectedWorkloadHost")
        self.save_inputs()
        fields = []

        def ask(label):
            self.assertFalse(self.calls)
            fields.append(label)
            return ORIGIN if "ux_metadata_api" in label else HOST

        with patch("builtins.input", side_effect=ask):
            code, output = self.execute()
        self.assertEqual(code, 0, output)
        self.assertEqual(len(fields), 2)
        saved = json.loads(self.output.read_text(encoding="utf-8"))
        self.assertEqual(saved["discovery"]["configured_fields"], ["ux_metadata_api", "ux_workload_host"])
        self.assertEqual(saved["discovery"]["ux_route_verification"], "mwc-v2-host-and-workload-definition")

    def test_non_interactive_missing_routes_blocks_before_auth_and_plan_never_prompts(self):
        self.run.pop("uxMetadataApi")
        self.run.pop("uxExpectedWorkloadHost")
        self.save_inputs()
        with patch("builtins.input") as ask, patch.object(discovery, "open_identity") as auth:
            code, output = self.main(extra=("--non-interactive",))
            self.assertEqual(code, 2)
            self.assertIn("ux_metadata_api, ux_workload_host", output)
            code, output = self.main(execute=False)
            self.assertEqual(code, 0)
            self.assertIn("Missing initial settings", output)
        ask.assert_not_called()
        auth.assert_not_called()
        self.assertFalse(self.output.exists())

    def test_observed_route_validation_rejects_global_or_other_workspace_before_auth(self):
        self.run.pop("uxMetadataApi")
        self.save_inputs()
        with patch("builtins.input", return_value="https://wabi-daily-us-east2-redirect.analysis.windows.net"), \
                patch.object(discovery, "open_identity") as auth:
            code, output = self.main()
        self.assertEqual(code, 2)
        auth.assert_not_called()
        self.assertNotIn(SECRET, output)

    def test_missing_ontology_child_prompts_only_child_eh_and_marks_unverified_association(self):
        self.documents[ORIGIN + "/metadata/artifacts/" + ONTOLOGY]["extendedProperties"] = {}
        with patch("builtins.input", return_value=CHILD_EH) as ask:
            code, output = self.execute()
        self.assertEqual(code, 0, output)
        ask.assert_called_once()
        self.assertIn("eventhouse_id", ask.call_args.args[0])
        saved = json.loads(self.output.read_text(encoding="utf-8"))
        self.assertEqual(saved["discovery"]["execution_provenance"],
                         "operator-configured-not-independently-verified")
        self.assertFalse(saved["discovery"]["ontology_child_relation_verified"])
        self.assertTrue(saved["discovery"]["eventhouse_database_relation_verified"])
        self.assertTrue(saved["discovery"]["child_workspace_verified"])
        self.assertEqual(prerequisites(validate_config(copy.deepcopy(saved)), discovery.POSITIVE_SCENARIOS,
                                       check_creation=False), {})

    def test_missing_database_and_endpoint_prompt_only_unknown_child_fields(self):
        eventhouse = self.documents[ORIGIN + "/metadata/artifacts/" + CHILD_EH]
        eventhouse["artifactRelations"] = []
        eventhouse["extendedProperties"] = {}
        database = self.documents[ROUTE + f"/workspaces/{WORKSPACE}/kqlDatabases/{CHILD_DB}"]
        database["properties"].pop("queryServiceUri")
        with patch("builtins.input", side_effect=[CHILD_DB, CHILD_CLUSTER]) as ask:
            code, output = self.execute()
        self.assertEqual(code, 0, output)
        self.assertEqual(ask.call_count, 2)
        saved = json.loads(self.output.read_text(encoding="utf-8"))
        self.assertEqual(saved["discovery"]["configured_fields"],
                         ["preview.execution.database_id", "preview.execution.cluster_uri"])
        self.assertFalse(saved["discovery"]["child_cluster_verified"])

    def test_operator_cannot_substitute_source_eventhouse_or_skip_http_refusal(self):
        self.documents[ORIGIN + "/metadata/artifacts/" + ONTOLOGY]["extendedProperties"] = {}
        with patch("builtins.input", return_value=SOURCE_EH):
            code, _ = self.execute()
        self.assertEqual(code, 2)
        self.assertFalse(self.output.exists())
        self.documents[ORIGIN + "/metadata/artifacts/" + ONTOLOGY] = discovery.DiscoveryError("HTTP 403")
        with patch("builtins.input") as ask:
            code, output = self.execute()
        self.assertEqual(code, 2)
        self.assertIn("403", output)
        ask.assert_not_called()
        self.assertFalse(self.output.exists())

    def test_non_interactive_missing_child_is_clear_no_config_and_no_prompt(self):
        self.documents[ORIGIN + "/metadata/artifacts/" + ONTOLOGY]["extendedProperties"] = {}
        with patch.object(discovery, "DiscoveryApi", side_effect=self.api_factory), \
                patch.object(discovery, "open_identity", side_effect=self.identity), patch("builtins.input") as ask:
            code, output = self.main(extra=("--non-interactive",))
        self.assertEqual(code, 2)
        self.assertIn("preview.execution.eventhouse_id", output)
        ask.assert_not_called()
        self.assertFalse(self.output.exists())

    def test_source_endpoint_prompts_do_not_replace_known_catalog_or_source_ids(self):
        self.documents[ROUTE + f"/workspaces/{WORKSPACE}/kqlDatabases/{SOURCE_DB}"]["properties"].pop("queryServiceUri")
        self.documents[ROUTE + f"/workspaces/{WORKSPACE}/lakehouses/{LAKEHOUSE}"]["properties"].pop("sqlEndpointProperties")
        with patch("builtins.input", side_effect=[SOURCE_CLUSTER, SERVER]) as ask:
            code, output = self.execute()
        self.assertEqual(code, 0, output)
        self.assertEqual(ask.call_count, 2)
        saved = json.loads(self.output.read_text(encoding="utf-8"))
        self.assertEqual(saved["preview"]["sources"]["lakehouse"]["sql_database"], "Sample_Lakehouse")
        self.assertEqual(saved["generation_lakehouse_id"], LAKEHOUSE)

    def test_cancelled_prompt_writes_nothing(self):
        self.run.pop("uxMetadataApi")
        self.save_inputs()
        with patch("builtins.input", side_effect=EOFError), patch.object(discovery, "open_identity") as auth:
            code, _ = self.main()
        self.assertEqual(code, 2)
        auth.assert_not_called()
        self.assertFalse(self.output.exists())

    def lakehouse_partitions(self):
        return [table["partitions"][0] for table in self.run["authoredDefinition"]["model"]["tables"]
                if table["name"].startswith("Lakehouse_")]

    def test_missing_schema_prompts_only_schema_and_records_operator_provenance(self):
        for partition in self.lakehouse_partitions():
            partition["source"].pop("schemaName")
        self.save_inputs()
        with patch("builtins.input", return_value="dbo") as ask:
            code, output = self.execute()
        self.assertEqual(code, 0, output)
        ask.assert_called_once()
        self.assertIn("preview.sources.lakehouse.schema", ask.call_args.args[0])
        saved = json.loads(self.output.read_text(encoding="utf-8"))
        self.assertEqual(saved["discovery"]["source_sql_schema_provenance"],
                         "operator-configured-not-independently-verified")
        self.assertFalse(saved["discovery"]["source_sql_schema_live_verified"])
        self.assertEqual(saved["discovery"]["configured_fields"], ["preview.sources.lakehouse.schema"])
        self.assertEqual(prerequisites(validate_config(copy.deepcopy(saved)), discovery.POSITIVE_SCENARIOS,
                                       check_creation=False), {})

    def test_non_interactive_missing_schema_blocks_without_sql_or_metadata_request(self):
        self.lakehouse_partitions()[0]["source"].pop("schemaName")
        self.save_inputs()
        with patch.object(discovery, "DiscoveryApi", side_effect=self.api_factory), \
                patch.object(discovery, "open_identity", side_effect=self.identity), patch("builtins.input") as ask:
            code, output = self.main(extra=("--non-interactive",))
        self.assertEqual(code, 2)
        self.assertIn("preview.sources.lakehouse.schema", output)
        ask.assert_not_called()
        self.assertFalse(self.calls)
        self.assertFalse(self.output.exists())

    def test_unambiguous_schema_requires_every_identity_checked_entity_partition(self):
        for change in (
            lambda p: p[0]["source"].pop("schemaName"),
            lambda p: p[1]["source"].update(schemaName="other"),
            lambda p: p[1]["source"].update(entityName="OtherTable"),
            lambda p: p[1]["source"].update(type="m", expression="Schema = dbo"),
            lambda p: p[1]["source"].update(schemaName=None),
        ):
            self.run, self.sources, self.documents = fixtures()
            change(self.lakehouse_partitions())
            self.assertIsNone(discovery.saved_lakehouse_schema(self.run, self.sources, WORKSPACE))
            ask = Mock(return_value="dbo")
            schema, provenance = discovery.lakehouse_schema(
                self.run, self.sources, WORKSPACE, discovery.MissingFields(input_fn=ask))
            self.assertEqual(schema, "dbo")
            self.assertEqual(provenance, "operator-configured-not-independently-verified")
            ask.assert_called_once()

    def test_schema_annotations_cannot_claim_another_source_item_or_workspace(self):
        for field in ("ONT_ItemId", "ONT_WorkspaceId", "ONT_ItemKind"):
            self.run, self.sources, self.documents = fixtures()
            partition = self.lakehouse_partitions()[0]
            annotation = next(entry for entry in partition["annotations"] if entry["name"] == field)
            annotation["value"] = SOURCE_DB
            with self.subTest(field=field), self.assertRaises(discovery.DiscoveryError):
                discovery.saved_lakehouse_schema(self.run, self.sources, WORKSPACE)

    def test_uniform_unsupported_saved_schema_and_invalid_operator_schema_do_not_guess_dbo(self):
        for partition in self.lakehouse_partitions():
            partition["source"]["schemaName"] = "other"
        ask = Mock()
        with self.assertRaises(discovery.DiscoveryError):
            discovery.lakehouse_schema(self.run, self.sources, WORKSPACE, discovery.MissingFields(input_fn=ask))
        ask.assert_not_called()
        for partition in self.lakehouse_partitions():
            partition["source"].pop("schemaName")
        with self.assertRaises(discovery.DiscoveryError):
            discovery.lakehouse_schema(self.run, self.sources, WORKSPACE,
                                      discovery.MissingFields(input_fn=Mock(return_value="other")))

    def test_plan_missing_schema_is_offline_and_never_prompts(self):
        for partition in self.lakehouse_partitions():
            partition["source"].pop("schemaName")
        self.save_inputs()
        with patch("builtins.input") as ask, patch.object(discovery, "open_identity") as auth:
            code, output = self.main(execute=False, extra=("--non-interactive",))
        self.assertEqual(code, 0, output)
        ask.assert_not_called()
        auth.assert_not_called()
        self.assertFalse(self.output.exists())

    def test_no_sql_import_driver_connection_or_token_regardless_of_driver_installation(self):
        original_import = builtins.__import__

        def guarded_import(name, *args, **kwargs):
            self.assertNotEqual(name, "pyodbc", "Config construction must not even import the SQL driver")
            return original_import(name, *args, **kwargs)

        for network, installed in (("wspl", True), ("wspl", False), ("tenantpl", True), ("tenantpl", False)):
            with self.subTest(network=network, installed=installed):
                self.run, self.sources, self.documents = fixtures(network)
                self.save_inputs()
                driver = Mock()
                driver.drivers.return_value = ["ODBC Driver 18 for SQL Server"] if installed else []
                with patch.dict("sys.modules", {"pyodbc": driver if installed else None}), \
                        patch("builtins.__import__", side_effect=guarded_import), \
                        patch("azure.identity.AzureCliCredential") as cli, \
                        patch.object(discovery, "DiscoveryApi", side_effect=self.api_factory), \
                        patch("builtins.input") as ask:
                    cli.return_value.get_token.return_value.token = SECRET
                    code, output = self.main(extra=("--non-interactive",))
                self.assertEqual(code, 0, output)
                self.assertTrue(cli.return_value.get_token.called)
                self.assertTrue(all(call.args == (PBI_SCOPE,) for call in cli.return_value.get_token.call_args_list))
                driver.drivers.assert_not_called()
                driver.connect.assert_not_called()
                ask.assert_not_called()
                self.output.unlink()

    def test_failed_child_metadata_404_or_403_never_prompts_fallback(self):
        for status in (404, 403):
            self.documents[ORIGIN + "/metadata/artifacts/" + ONTOLOGY] = discovery.DiscoveryError(f"HTTP {status}")
            with patch("builtins.input") as ask:
                code, output = self.execute()
            self.assertEqual(code, 2)
            self.assertIn(str(status), output)
            ask.assert_not_called()
            self.assertFalse(self.output.exists())

    def test_both_private_networks_preserve_exact_routes_and_all_19_prerequisites(self):
        for network in ("wspl", "tenantpl"):
            with self.subTest(network=network):
                self.run, self.sources, self.documents = fixtures(network)
                self.save_inputs()
                self.calls.clear()
                route = target_fabric_api(network, WORKSPACE, TENANT)
                origin, host = self.run["uxMetadataApi"], self.run["uxExpectedWorkloadHost"]
                with patch.object(discovery, "DiscoveryApi", side_effect=self.api_factory), \
                        patch.object(discovery, "open_identity", side_effect=self.identity), patch("builtins.input") as ask:
                    code, output = self.main(extra=("--non-interactive", "--sources-manifest", str(self.sources_path),
                                                    "--auth", "cli", "--timeout", "120"))
                self.assertEqual(code, 0, output)
                saved = json.loads(self.output.read_text(encoding="utf-8"))
                self.assertEqual(saved["target_network"], network)
                self.assertEqual(saved["ux_metadata_api"], origin)
                self.assertEqual(saved["ux_workload_host"], host)
                self.assertEqual(saved["timeout"], 120)
                self.assertEqual(prerequisites(validate_config(copy.deepcopy(saved)), discovery.POSITIVE_SCENARIOS,
                                               check_creation=False), {})
                self.assertEqual(saved["p0_access"]["context"], "authorized")
                get_paths = {path for method, path, _ in self.calls if method == "GET"}
                self.assertIn(route + f"/workspaces/{WORKSPACE}/lakehouses/{LAKEHOUSE}", get_paths)
                self.assertIn(route + f"/workspaces/{WORKSPACE}/kqlDatabases/{SOURCE_DB}", get_paths)
                self.assertIn(route + f"/workspaces/{WORKSPACE}/kqlDatabases/{CHILD_DB}", get_paths)
                self.assertIn(route + f"/workspaces/{WORKSPACE}/items/{CHILD_EH}", get_paths)
                self.assertIn(origin + f"/metadata/artifacts/{ONTOLOGY}", get_paths)
                self.assertIn(origin + f"/metadata/artifacts/{CHILD_EH}", get_paths)
                self.assertTrue(all(path.startswith(route + "/workspaces/") for path in get_paths
                                    if "/workspaces/" in path and "/workloads/" not in path))
                self.assertEqual([(method, path) for method, path, _ in self.calls if method != "GET"],
                                 [("POST", origin + "/metadata/v201606/generatemwctokenv2")])
                ask.assert_not_called()
                self.output.unlink()

    def test_both_network_plans_are_offline_even_when_ux_routes_missing(self):
        for network in ("wspl", "tenantpl"):
            self.run, self.sources, self.documents = fixtures(network)
            self.run.pop("uxMetadataApi")
            self.run.pop("uxExpectedWorkloadHost")
            self.save_inputs()
            with patch("builtins.input") as ask, patch.object(discovery, "open_identity") as auth, \
                    patch.object(discovery, "DiscoveryApi") as api:
                code, output = self.main(execute=False, extra=("--non-interactive",))
            self.assertEqual(code, 0, output)
            self.assertIn(f"Same-workspace {network} target", output)
            self.assertIn("ux_metadata_api, ux_workload_host", output)
            ask.assert_not_called()
            auth.assert_not_called()
            api.assert_not_called()
            self.assertFalse(self.output.exists())

    def test_tenantpl_prompts_observed_routes_before_auth_never_invents_ws_host(self):
        origin = "https://observed-daily-metadata.analysis.windows.net"
        host = "observed-daily-workload.pbidedicated.windows.net"
        self.run, self.sources, self.documents = fixtures("tenantpl", ux_origin=origin, ux_host=host)
        self.run.pop("uxMetadataApi")
        self.run.pop("uxExpectedWorkloadHost")
        self.save_inputs()
        observed = iter((origin, host))

        def ask(label):
            self.assertFalse(self.calls)
            return next(observed)

        with patch("builtins.input", side_effect=ask) as prompt:
            code, output = self.execute()
        self.assertEqual(code, 0, output)
        self.assertEqual(prompt.call_count, 2)
        saved = json.loads(self.output.read_text(encoding="utf-8"))
        self.assertEqual(saved["target_network"], "tenantpl")
        self.assertEqual(saved["ux_metadata_api"], origin)
        self.assertEqual(saved["ux_workload_host"], host)
        self.assertFalse(any(".daily-c.fabric.microsoft.com" in path for _, path, _ in self.calls))

    def test_tenantpl_missing_expected_host_noninteractive_never_uses_manifest_fabric_origin_as_guess(self):
        self.run, self.sources, self.documents = fixtures("tenantpl")
        self.run.pop("uxExpectedWorkloadHost")
        self.save_inputs()
        with patch.object(discovery, "open_identity") as auth, patch("builtins.input") as ask:
            code, output = self.main(extra=("--non-interactive",))
        self.assertEqual(code, 2)
        self.assertIn("ux_workload_host", output)
        auth.assert_not_called()
        ask.assert_not_called()

    def test_tenantpl_mwc_response_must_match_exact_recorded_host_not_merely_allowlist(self):
        for returned in ("other-daily-cluster.pbidedicated.windows.net",
                         target_fabric_api("tenantpl", WORKSPACE, TENANT).removesuffix("/v1").removeprefix("https://"),
                         HOST, "dailyapi.fabric.microsoft.com"):
            self.run, self.sources, self.documents = fixtures("tenantpl")
            self.save_inputs()
            self.calls.clear()
            self.documents[self.run["uxMetadataApi"] + "/metadata/v201606/generatemwctokenv2"]["TargetUriHost"] = returned
            with patch("builtins.input") as ask:
                code, _ = self.execute()
            self.assertEqual(code, 2)
            self.assertFalse(any("/workloads/" in path for _, path, _ in self.calls))
            self.assertFalse(self.output.exists())
            ask.assert_not_called()

    def test_tenantpl_rejects_mismatched_manifests_and_public_routes_offline(self):
        for change in (
            lambda r, s: s.update(targetNetwork="wspl"),
            lambda r, s: s.update(tenantId=WORKSPACE),
            lambda r, s: s.update(workspaceId=TENANT),
            lambda r, s: s.update(existingWorkspaceId=TENANT),
            lambda r, s: s.update(capacityId=TENANT),
            lambda r, s: s.update(sameWorkspace=False),
            lambda r, s: s["endpoints"].update(fabric=ROUTE),
            lambda r, s: r.update(sourceFabricApi=ROUTE),
            lambda r, s: r.update(targetFabricApi="https://dailyapi.fabric.microsoft.com/v1"),
            lambda r, s: r.update(targetNetwork="public"),
            lambda r, s: r.update(sourceTypes=["Lakehouse"]),
            lambda r, s: r.update(uxMetadataApi="https://wabi-daily-us-east2-redirect.analysis.windows.net"),
            lambda r, s: r.update(uxExpectedWorkloadHost=HOST),
            lambda r, s: r.update(uxMetadataApi=target_fabric_api("tenantpl", WORKSPACE, WORKSPACE).removesuffix("/v1")),
        ):
            self.run, self.sources, self.documents = fixtures("tenantpl")
            change(self.run, self.sources)
            self.save_inputs()
            with patch.object(discovery, "open_identity") as auth, patch("builtins.input") as ask:
                code, _ = self.main(extra=("--non-interactive",))
            self.assertEqual(code, 2)
            auth.assert_not_called()
            ask.assert_not_called()
            self.assertFalse(self.output.exists())

    def test_tenantpl_403_404_no_fallback_and_operator_child_never_substitutes_source(self):
        for status in (403, 404):
            self.run, self.sources, self.documents = fixtures("tenantpl")
            self.save_inputs()
            self.documents[self.run["uxMetadataApi"] + f"/metadata/artifacts/{ONTOLOGY}"] = discovery.DiscoveryError(
                f"HTTP {status}")
            with patch("builtins.input") as ask:
                code, output = self.execute()
            self.assertEqual(code, 2)
            self.assertIn(str(status), output)
            ask.assert_not_called()
            self.assertFalse(self.output.exists())
        self.run, self.sources, self.documents = fixtures("tenantpl")
        self.documents[self.run["uxMetadataApi"] + f"/metadata/artifacts/{ONTOLOGY}"]["extendedProperties"] = {}
        self.save_inputs()
        with patch("builtins.input", return_value=SOURCE_EH):
            code, _ = self.execute()
        self.assertEqual(code, 2)
        self.assertFalse(self.output.exists())
        with patch("builtins.input", return_value=CHILD_EH):
            code, output = self.execute()
        self.assertEqual(code, 0, output)
        saved = json.loads(self.output.read_text(encoding="utf-8"))
        self.assertEqual(saved["target_network"], "tenantpl")
        self.assertEqual(saved["discovery"]["execution_provenance"],
                         "operator-configured-not-independently-verified")


class HttpTests(unittest.TestCase):
    def test_http_errors_show_only_status_not_response_or_token(self):
        credential = Mock()
        credential.get_token.return_value.token = SECRET
        api = discovery.DiscoveryApi(ORIGIN, PBI_SCOPE, credential, 30, sensitive_response=True)
        self.addCleanup(api.close)
        api.session = Mock()
        api.session.request.return_value = SimpleNamespace(status_code=403, text=SECRET, headers={})
        with self.assertRaises(discovery.DiscoveryError) as error:
            api.request("POST", ORIGIN + "/metadata/v201606/generatemwctokenv2", {})
        self.assertIn("HTTP 403", str(error.exception))
        self.assertNotIn(SECRET, str(error.exception))
        api.session.request.assert_called_once()

    def test_read_only_api_blocks_mutations_and_redirects(self):
        credential = Mock()
        credential.get_token.return_value.token = SECRET
        api = discovery.DiscoveryApi(ORIGIN, PBI_SCOPE, credential, 30, sensitive_response=True)
        self.addCleanup(api.close)
        api.session = Mock()
        with self.assertRaises(discovery.DiscoveryError):
            api.request("POST", ORIGIN + "/metadata/artifacts", {})
        api.session.request.assert_not_called()
        api.session.request.return_value = SimpleNamespace(status_code=302, text=SECRET, headers={})
        with self.assertRaises(discovery.DiscoveryError) as error:
            api.request("GET", ORIGIN + "/metadata/artifacts/" + ONTOLOGY)
        self.assertIn("HTTP 302", str(error.exception))
        self.assertNotIn(SECRET, str(error.exception))
        self.assertFalse(api.session.request.call_args.kwargs["allow_redirects"])


if __name__ == "__main__":
    unittest.main()
