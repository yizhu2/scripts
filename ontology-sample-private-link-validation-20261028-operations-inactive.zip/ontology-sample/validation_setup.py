"""Offline configuration and prerequisite checks; never acquire tokens or infer service routes."""

import json
import shutil
import tempfile
from pathlib import Path
from uuid import UUID, uuid4

from ux_authoring import routing
from validation_common import console

MANUAL_SCENARIOS = {
    "operations.runtime": "This runtime entry performs no calls; activation, monitoring, actions and "
                          "notifications are not tested. Separate authoring entries may create inactive artifacts.",
}


def prerequisites(config, selected, check_creation=True):
    problems = {}
    for name in sorted(selected):
        if name in MANUAL_SCENARIOS:
            continue
        family = name.split(".")[0]
        errors = []
        if config.get("auth") == "browser":
            try:
                UUID(str(config.get("client_id", "")))
            except ValueError:
                errors.append("Browser auth requires an organization-approved client_id GUID")
        prefix = {"data-agent": "data_agent", "operations": "operations"}.get(family)
        if prefix:
            origin, host = config.get(prefix + "_metadata_api"), config.get(prefix + "_workload_host")
            try:
                routing(config["target_network"], origin or (
                    config.get("ux_metadata_api") if config["target_network"] == "public" else None),
                    host or (config.get("ux_workload_host") if config["target_network"] == "public" else None))
            except ValueError:
                errors.append(f"Supply valid {prefix}_metadata_api and {prefix}_workload_host from that "
                              "service's successful MWC request; do not infer another service's route")
        if family == "operations":
            if config.get("ux_token_version", "v2") != "v2":
                errors.append("Operations Agent requires OA MWC v2 (ux_token_version v2); no v1 fallback")
            if check_creation and not config.get("allow_create"):
                errors.append("Every Operations authoring case creates a fresh inactive artifact; "
                              "explicit -AllowCreate is required (no reuse)")
            if config.get("scenario_timeout", 1800) <= config.get("operations_generation_timeout", 900):
                errors.append("scenario_timeout must exceed operations_generation_timeout for Operations authoring")
        if family == "data-agent":
            if config.get("ux_token_version", "v2") != "v2":
                errors.append("Data Agent requires ux_token_version v2")
            ids = config.get("data_agent_ids") or {}
            if not isinstance(ids, dict):
                errors.append("data_agent_ids must be an object mapping scenario names to draft GUIDs")
                agent = None
            else:
                agent = ids.get(name) or config.get("data_agent_id")
            if agent:
                try:
                    UUID(str(agent))
                except ValueError:
                    errors.append("Configured Data Agent draft ID must be a GUID")
            elif check_creation and not config.get("allow_create"):
                errors.append("No existing draft configured; run with -AllowCreate to authorize a new test draft")
        if family == "generation":
            try:
                UUID(str(config.get("generation_lakehouse_id", "")))
            except ValueError:
                errors.append("Supply generation_lakehouse_id for the populated sample Lakehouse")
            try:
                source = UUID(str(config.get("generation_source_workspace_id") or config["workspace_id"]))
                if source != UUID(config["workspace_id"]):
                    errors.append("Generation currently requires a Lakehouse in the target workspace")
            except ValueError:
                errors.append("generation_source_workspace_id must be a GUID")
        if family == "generation" and check_creation and not config.get("allow_create"):
            errors.append("This scenario creates a new test item; explicit -AllowCreate is required")
        if errors:
            problems[name] = errors
    return problems


def import_sample_settings(config, manifest_path):
    saved = json.loads(Path(manifest_path).read_text(encoding="utf-8-sig"))
    if saved.get("environment") != "Daily" or saved.get("authoringMode") not in ("ux", "hybrid"):
        raise ValueError("Use a Daily UX/hybrid run.manifest.json, not a source manifest")
    values = {
        "tenant_id": saved.get("tenantId"),
        "workspace_id": saved.get("targetWorkspaceId"),
        "ontology_id": saved.get("items", {}).get("Ontology", {}).get("id"),
    }
    for key, value in values.items():
        values[key] = str(UUID(str(value)))
        if config.get(key) and str(UUID(str(config[key]))) != values[key]:
            raise ValueError(f"Sample manifest conflicts with {key}; use a separate config file")
    values.update(
        target_network=saved.get("targetNetwork"),
        ux_metadata_api=saved.get("uxMetadataApi"),
        ux_workload_host=saved.get("uxExpectedWorkloadHost"),
        ux_token_version=saved.get("uxTokenVersion") or "v2",
    )
    if saved.get("authentication") in ("cli", "browser"):
        values["auth"] = saved["authentication"]
    config.update(values)
    console("Imported target/DO settings only. A saved manifest does not prove its route still works.")
    console("ML and Operations routes must be confirmed separately; no sources or credentials were imported.")


def reuse_data_agents(config, results_path, selected):
    saved = json.loads(Path(results_path).read_text(encoding="utf-8-sig"))
    if not isinstance(saved, dict) or not isinstance(saved.get("config"), dict):
        raise ValueError("Reuse requires results.json with target configuration, not resources.json")
    for key in ("tenant_id", "workspace_id", "ontology_id"):
        if str(UUID(str(saved["config"].get(key)))) != str(UUID(str(config[key]))):
            raise ValueError(f"Prior results conflict with {key}; retained drafts were not imported")
    resources = saved.get("resources")
    drafts = resources.get("data_agents") if isinstance(resources, dict) else None
    if not isinstance(drafts, dict):
        raise ValueError("Prior results do not contain a retained data_agents mapping")
    imported = {name: str(UUID(str(agent))) for name, agent in drafts.items()
                if name in selected and name.startswith("data-agent.")}
    if not imported:
        raise ValueError("Prior results contain no retained drafts for the selected Data Agent scenarios")
    existing = config.get("data_agent_ids") or {}
    if not isinstance(existing, dict):
        raise ValueError("data_agent_ids must be an object mapping scenario names to draft GUIDs")
    config["data_agent_ids"] = {**existing, **imported}
    console(f"Reusing {len(imported)} retained Data Agent drafts; no export or configuration edits. "
            "Runtime source evidence determines functional coverage.")


def configure(path, selected, sample_manifest=None, input_fn=None):
    from validate_sample import validate_config

    ask = input_fn or input
    path = Path(path)
    original = path.read_bytes() if path.exists() else None
    value = json.loads(original.decode("utf-8-sig")) if original is not None else {}
    if not isinstance(value, dict):
        raise ValueError("Configuration must be a JSON object")
    if sample_manifest:
        import_sample_settings(value, sample_manifest)
    console("Offline configuration only: no login, network calls, provisioning or agent creation.")
    console("Use identifiers and observed service origins/hosts only; never paste tokens, headers or full responses.")

    def prompt(key, label, default=""):
        current = value.get(key) or default
        entered = ask(f"{label} [{current or 'blank = unconfigured'}]: ").strip()
        value[key] = entered or current

    for key, label in (("tenant_id", "Tenant ID"), ("workspace_id", "Target workspace ID"),
                       ("ontology_id", "Existing ontology ID")):
        prompt(key, label)
    prompt("target_network", "Network: wspl / tenantpl / public")
    prompt("auth", "Authentication: cli / browser", "cli")
    if value["auth"] == "browser":
        prompt("client_id", "Organization-approved public client application ID")
        UUID(str(value["client_id"]))
    prompt("ux_token_version", "DO token version: v1 / v2", "v2")
    console("DO: use the working provisioning/UX MWC route. A tenant-wide origin is not automatically "
            "the correct route for a WSPL workspace.")
    prompt("ux_metadata_api", "DO metadata HTTPS origin (no path)")
    prompt("ux_workload_host", "DO TargetUriHost (hostname only)")
    families = {name.split(".")[0] for name in selected if name not in MANUAL_SCENARIOS}
    if "operations.runtime" in selected:
        console(MANUAL_SCENARIOS["operations.runtime"])
    for family, prefix, label in (("data-agent", "data_agent", "ML / Data Agent"),
                                  ("operations", "operations", "OA / Operations Agent")):
        if family not in families:
            continue
        console(f"{label}: use that service's successful generatemwctoken request in the target workspace.")
        console("Copy only the request origin and response TargetUriHost. Even if they equal DO, confirm them.")
        if family == "operations":
            console("OA requires generatemwctokenv2. Every case creates a fresh inactive artifact; "
                    "no reuse, activation, monitoring, actions or notifications.")
        prompt(prefix + "_metadata_api", f"{label} metadata HTTPS origin (no path)")
        prompt(prefix + "_workload_host", f"{label} TargetUriHost (hostname only)")
    if "generation" in families:
        console("Generation supports only a populated sample Lakehouse in the target workspace.")
        prompt("generation_lakehouse_id", "Generation Lakehouse item ID")
        prompt("generation_source_workspace_id", "Generation source workspace ID", value["workspace_id"])
    # Validate without persisting runtime-only creation authorization or derived defaults.
    checked = validate_config(dict(value))
    value.pop("allow_create", None)
    issues = prerequisites(checked, selected, check_creation=False)
    for name, errors in issues.items():
        console(f"{name}: SETUP REQUIRED - {'; '.join(errors)}")
    if ask("Type SAVE to persist this configuration (does not run tests): ").strip() != "SAVE":
        raise ValueError("Configuration cancelled; no file changes")
    current = path.read_bytes() if path.exists() else None
    if current != original:
        raise ValueError("Configuration changed during setup; not overwritten")
    path.parent.mkdir(parents=True, exist_ok=True)
    if original is not None:
        backup = path.with_name(path.name + "." + uuid4().hex[:12] + ".bak")
        shutil.copy2(path, backup)
        console(f"Backup: {backup.resolve()}")
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(value, stream, indent=2)
            stream.write("\n")
        temporary.replace(path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    console(f"Configuration saved: {path.resolve()}")
    console("Next: run -PlanOnly with the same selectors and intended -AllowCreate to check prerequisites offline.")
    return int(bool(issues))
