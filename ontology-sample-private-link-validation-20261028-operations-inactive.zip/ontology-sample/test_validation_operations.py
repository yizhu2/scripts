import json
import tempfile
import time
import unittest
from contextlib import nullcontext
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

import validation_operations as adapter
from validate_sample import catalog, main, select_scenarios
from validation_common import HttpFailure, InvalidResponse, ScenarioBlocked
from validation_operations import SCENARIOS
from validation_setup import prerequisites


WORKSPACE = "10000000-0000-0000-0000-000000000001"
ONTOLOGY = "10000000-0000-0000-0000-000000000002"
AGENT = "10000000-0000-0000-0000-000000000003"
CAPACITY = "10000000-0000-0000-0000-000000000004"
PLAYBOOK = "10000000-0000-0000-0000-000000000005"
HOST = "test-daily.pbidedicated.windows.net"


def playbook(case="lakehouse"):
    dimensions, readings = adapter.GROUPS[case]
    return {
        "ontology": f"### Entity: `{readings}_Readings`\n#### Properties\n- TemperatureC",
        "rules": f"""<details>
  <summary><strong>Hot readings</strong>: Historical temperature check</summary>

  ```gql
  MATCH (r:{readings}_Readings), (a:{dimensions}_Assets), (p:{dimensions}_Plants)
  WHERE r.AssetId = a.AssetId AND a.PlantId = p.PlantId
  RETURN r.ReadingId, r.TemperatureC, a.AssetId, p.PlantId
  ```

  | Property | Condition | Value |
  |----------|-----------|-------|
  | TemperatureC | Is Above | 32.5 |
</details>
""",
    }


class FakeContext:
    def __init__(self, case="lakehouse"):
        self.config = {"workspace_id": WORKSPACE, "ontology_id": ONTOLOGY,
                       "target_network": "public", "allow_create": True, "poll_seconds": 1}
        self.fabric = SimpleNamespace(base="https://api.fabric.microsoft.com/v1")
        self.api = SimpleNamespace(base="https://" + HOST)
        self.scenario = "operations." + case
        self.state = {}
        self.deadline = time.monotonic() + 1800
        self.calls = []
        self.saved = {}
        self.statuses = [{"state": "Completed"}]
        self.agent_states = ["Unconfigured", "Inactive"]
        self.preview = playbook(case)
        self.generate_result = {"id": PLAYBOOK}
        self.creation_error = None
        self.generation_error = None
        self.status_error = None
        self.state_error = None

    def save_evidence(self, label, value):
        self.saved[label] = json.loads(json.dumps(value))

    def mutate(self, api, path, body):
        self.calls.append(("CREATE", path, body, self.deadline))
        if self.creation_error:
            raise self.creation_error
        return {"id": AGENT}

    def request(self, api, method, path, body=None, params=None):
        self.calls.append((method, path, body, self.deadline))
        if path.endswith("/workspaces/" + WORKSPACE):
            return {"capacityId": CAPACITY}
        if path.endswith("/items/" + ONTOLOGY):
            return {"id": ONTOLOGY, "type": "Ontology", "displayName": "Sample ontology"}
        if path.endswith("/settings"):
            if self.state_error and len(self.agent_states) == 1:
                raise self.state_error
            return {"agentState": self.agent_states.pop(0)}
        if path.endswith("/behaviorModel") and method == "POST":
            if self.generation_error:
                raise self.generation_error
            return self.generate_result
        if path.endswith("/status"):
            if self.status_error:
                raise self.status_error
            return self.statuses.pop(0)
        if path.endswith("/" + PLAYBOOK):
            return self.preview
        raise AssertionError(f"Unexpected request: {method} {path}")


def run_case(ctx, case="lakehouse"):
    with patch.object(adapter, "operations_context", return_value=nullcontext(ctx.api)):
        return adapter.authoring(ctx, case)


class OperationsScopeTests(unittest.TestCase):
    def test_runtime_is_not_tested_and_never_uses_context(self):
        context = Mock()
        result = SCENARIOS["operations.runtime"](context)
        self.assertEqual(result["status"], "SKIP")
        self.assertFalse(result["evidence"]["runtimeValidated"])
        self.assertFalse(result["evidence"]["activated"])
        self.assertEqual(context.mock_calls, [])
        self.assertEqual(prerequisites({}, {"operations.runtime"}), {})
        self.assertNotIn("operations.native-import", catalog())

    def test_old_report_migrates_retired_alm_case_without_running_it(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "results.json"
            path.write_text(json.dumps({"results": [
                {"scenario": "operations.native-import", "selected": True, "status": "FAIL"},
                {"scenario": "data-agent.lakehouse", "selected": True, "status": "FAIL"},
            ]}))
            self.assertEqual(select_scenarios(catalog(), previous=path),
                             {"operations.runtime", "data-agent.lakehouse"})

    def test_runtime_only_run_skips_without_auth_or_creation(self):
        with tempfile.TemporaryDirectory() as temporary, \
                patch("azure.identity.AzureCliCredential") as auth, \
                patch("validate_sample.ValidationContext") as context:
            root = Path(temporary)
            path = root / "config.json"
            path.write_text(json.dumps({
                "tenant_id": "11111111-1111-1111-1111-111111111111",
                "workspace_id": "22222222-2222-2222-2222-222222222222",
                "ontology_id": "33333333-3333-3333-3333-333333333333",
                "target_network": "public",
            }))
            self.assertEqual(main(["--config", str(path), "--scenarios", "operations.runtime",
                                   "--allow-create", "--output", str(root / "out")]), 0)
            auth.assert_not_called()
            context.assert_not_called()
            report = json.loads((root / "out" / "results.json").read_text())
            selected = [row for row in report["results"] if row["selected"]]
            self.assertEqual(len(selected), 1)
            self.assertEqual(selected[0]["status"], "SKIP")
            self.assertEqual(report["resources"], {})

    def test_authoring_suite_contains_ten_cases_and_separate_runtime(self):
        self.assertEqual(set(SCENARIOS), {f"operations.{case}" for case in adapter.GROUPS}
                         | {"operations.runtime"})


class PlaybookTests(unittest.TestCase):
    def test_all_ten_source_selections_have_static_contract_coverage(self):
        for case in adapter.GROUPS:
            with self.subTest(case=case):
                result = adapter.assess_playbook(playbook(case), case)
                self.assertEqual(result["status"], "PASS")
                self.assertFalse(result["queryExecuted"])

    def test_prose_without_inspectable_query_is_not_a_pass(self):
        result = adapter.assess_playbook({"ontology": "concepts", "rules": "- Hot asset: TemperatureC > 32.5"}, "lakehouse")
        self.assertEqual(result["status"], "UNVERIFIED")

    def test_empty_or_malformed_payload_is_explicit_error(self):
        for payload in (None, {}, {"ontology": [], "rules": "x"}, {"ontology": "x", "rules": None}):
            with self.subTest(payload=payload), self.assertRaises(InvalidResponse):
                adapter.assess_playbook(payload, "lakehouse")

    def test_wrong_threshold_or_non_strict_condition_fails(self):
        for old, new in (("32.5", "30"), ("Is Above", "Is Above Or Equal"), ("TemperatureC |", "AssetId |")):
            value = playbook()
            value["rules"] = value["rules"].replace(old, new)
            self.assertEqual(adapter.assess_playbook(value, "lakehouse")["status"], "FAIL")

    def test_equivalent_numeric_threshold_is_accepted(self):
        for number in ("32.500", "3.25E1"):
            value = playbook()
            value["rules"] = value["rules"].replace("32.5", number)
            self.assertEqual(adapter.assess_playbook(value, "lakehouse")["status"], "PASS")

    def test_wrong_source_group_fails(self):
        value = playbook()
        value["rules"] = value["rules"].replace("Lakehouse_Readings", "Warehouse_Readings")
        self.assertEqual(adapter.assess_playbook(value, "lakehouse")["status"], "FAIL")

    def test_entity_mentions_in_comments_or_literals_cannot_supply_scope(self):
        for replacement in ("Unknown /* (r:Lakehouse_Readings) */",
                            "Unknown // (r:Lakehouse_Readings)\n",
                            "Unknown {text: '(r:Lakehouse_Readings)'}"):
            value = playbook()
            value["rules"] = value["rules"].replace("Lakehouse_Readings", replacement)
            self.assertNotEqual(adapter.assess_playbook(value, "lakehouse")["status"], "PASS")

    def test_missing_properties_empty_concepts_or_query_are_not_passes(self):
        for old, new in (("r.TemperatureC", "r.OtherValue"), ("```gql", "```text"),
                         ("RETURN", "YIELD"), ("Lakehouse_Plants", "")):
            value = playbook()
            value["rules"] = value["rules"].replace(old, new)
            self.assertNotEqual(adapter.assess_playbook(value, "lakehouse")["status"], "PASS")
        value = playbook()
        value["ontology"] = ""
        self.assertEqual(adapter.assess_playbook(value, "lakehouse")["status"], "UNVERIFIED")

    def test_more_than_one_rule_fails(self):
        value = playbook()
        value["rules"] *= 2
        self.assertEqual(adapter.assess_playbook(value, "lakehouse")["status"], "FAIL")

    def test_native_kql_is_retained_without_claiming_unproven_source_bindings(self):
        for language in ("kql", "kqldataquery"):
            value = playbook()
            value["rules"] = value["rules"].replace("```gql", "```" + language)
            result = adapter.assess_playbook(value, "lakehouse")
            self.assertEqual(result["status"], "UNVERIFIED")
            self.assertEqual(result["queryLanguage"], language)
            self.assertIn("query", result)

    def test_mutation_query_is_not_accepted(self):
        value = playbook()
        value["rules"] = value["rules"].replace("RETURN", "DELETE r RETURN")
        self.assertEqual(adapter.assess_playbook(value, "lakehouse")["status"], "FAIL")


class AuthoringTests(unittest.TestCase):
    def test_all_cases_create_fresh_preview_once_and_never_activate(self):
        for case in adapter.GROUPS:
            with self.subTest(case=case):
                ctx = FakeContext(case)
                original_deadline = ctx.deadline
                result = run_case(ctx, case)
                self.assertEqual(result["status"], "PASS")
                self.assertTrue(result["evidence"]["inactiveVerified"])
                self.assertFalse(result["evidence"]["queryExecuted"])
                self.assertFalse(result["evidence"]["runtimeValidated"])
                self.assertEqual(ctx.state["operations_agents"][ctx.scenario], AGENT)
                self.assertEqual(ctx.state["operations_playbooks"][ctx.scenario], PLAYBOOK)
                writes = [call for call in ctx.calls if call[0] != "GET"]
                self.assertEqual([call[0] for call in writes], ["CREATE", "POST"])
                self.assertTrue(writes[0][1].endswith("/operationsAgents"))
                self.assertTrue(writes[1][1].endswith("/configuration/behaviorModel"))
                self.assertEqual(writes[1][2]["actions"], {})
                self.assertEqual(writes[1][2]["dataSources"]["businessOntology"]["id"], ONTOLOGY)
                self.assertEqual(writes[1][2]["dataSources"]["businessOntology"]["displayName"], "Sample ontology")
                self.assertEqual(writes[1][2]["dataSources"]["businessOntology"]["connection"], {"tableName": ""})
                self.assertNotIn("definition", writes[0][2])
                self.assertLess(writes[1][3], original_deadline)
                self.assertEqual(ctx.deadline, original_deadline)
                self.assertEqual(ctx.calls[-1][3], original_deadline)

    def test_creation_requires_flag_even_if_existing_id_is_supplied(self):
        ctx = FakeContext()
        ctx.config.update(allow_create=False, operations_agent_id=AGENT)
        result = run_case(ctx)
        self.assertEqual(result["status"], "BLOCKED")
        self.assertEqual(ctx.calls, [])

    def test_private_route_missing_is_blocked_before_creation(self):
        ctx = FakeContext()
        ctx.config["target_network"] = "wspl"
        self.assertEqual(run_case(ctx)["status"], "BLOCKED")
        self.assertEqual(ctx.calls, [])

    def test_creation_timeout_retains_attempt_name_without_retry(self):
        ctx = FakeContext()
        ctx.creation_error = TimeoutError("ambiguous create")
        self.assertEqual(run_case(ctx)["status"], "TIMEOUT")
        self.assertIn(ctx.scenario, ctx.state["operations_creation_attempts"])
        self.assertNotIn("operations_agents", ctx.state)
        self.assertEqual(sum(call[0] == "CREATE" for call in ctx.calls), 1)

    def test_active_or_unknown_initial_state_blocks_generation(self):
        for state in ("Active", "Starting", None, 0):
            with self.subTest(state=state):
                ctx = FakeContext()
                ctx.agent_states[0] = state
                self.assertEqual(run_case(ctx)["status"], "ERROR")
                self.assertFalse(any(call[0] == "POST" for call in ctx.calls))

    def test_polling_in_progress_is_read_only(self):
        ctx = FakeContext()
        ctx.statuses.insert(0, {"state": "InProgress"})
        with patch.object(adapter.time, "sleep") as sleep:
            result = run_case(ctx)
        self.assertEqual(result["status"], "PASS")
        sleep.assert_called_once()
        self.assertEqual(sum(call[0] == "POST" for call in ctx.calls), 1)

    def test_server_generation_failure_preserves_error_and_checks_state(self):
        ctx = FakeContext()
        ctx.statuses = [{"state": "Failed", "error": "Source policy denied"}]
        result = run_case(ctx)
        self.assertEqual(result["status"], "FAIL")
        self.assertEqual(result["evidence"]["generationStatus"]["error"], "Source policy denied")
        self.assertTrue(result["evidence"]["inactiveVerified"])
        self.assertTrue(ctx.calls[-1][1].endswith("/settings"))

    def test_ambiguous_generation_post_is_not_replayed(self):
        ctx = FakeContext()
        ctx.generation_error = TimeoutError("generation response lost")
        result = run_case(ctx)
        self.assertEqual(result["status"], "TIMEOUT")
        self.assertEqual(sum(call[0] == "POST" for call in ctx.calls), 1)
        self.assertTrue(result["evidence"]["generationPostAttempted"])
        self.assertTrue(result["evidence"]["inactiveVerified"])

    def test_generation_timeout_keeps_model_and_agent(self):
        ctx = FakeContext()
        ctx.status_error = TimeoutError("status timed out")
        result = run_case(ctx)
        self.assertEqual(result["status"], "TIMEOUT")
        self.assertEqual(result["evidence"]["playbookId"], PLAYBOOK)
        self.assertTrue(result["evidence"]["inactiveVerified"])

    def test_generation_poll_deadline_expires_without_replay(self):
        ctx = FakeContext()
        ctx.statuses = [{"state": "InProgress"}]
        with patch.object(adapter.time, "monotonic", side_effect=[100, 100, 101, 1001, 1002]), \
                patch.object(adapter.time, "sleep"):
            result = run_case(ctx)
        self.assertEqual(result["status"], "TIMEOUT")
        self.assertEqual(result["evidence"]["playbookId"], PLAYBOOK)
        self.assertTrue(result["evidence"]["inactiveVerified"])
        self.assertEqual(sum(call[0] == "POST" for call in ctx.calls), 1)

    def test_unknown_status_or_missing_model_id_is_not_success(self):
        for value in (None, {"state": "Succeeded"}, {"state": 0}):
            ctx = FakeContext()
            ctx.statuses = [value]
            self.assertEqual(run_case(ctx)["status"], "ERROR")
        ctx = FakeContext()
        ctx.generate_result = {"id": "../../settings"}
        self.assertEqual(run_case(ctx)["status"], "ERROR")
        self.assertEqual(sum(call[0] == "POST" for call in ctx.calls), 1)

    def test_completed_with_error_is_not_pass(self):
        ctx = FakeContext()
        ctx.statuses = [{"state": "Completed", "error": "Contradictory status"}]
        self.assertEqual(run_case(ctx)["status"], "ERROR")

    def test_failed_after_state_check_never_yields_pass(self):
        ctx = FakeContext()
        ctx.agent_states[-1] = "Active"
        result = run_case(ctx)
        self.assertEqual(result["status"], "ERROR")
        self.assertFalse(result["evidence"]["inactiveVerified"])
        self.assertIn("safetyError", result["evidence"])
        calls = len(ctx.calls)
        self.assertEqual(run_case(ctx)["status"], "BLOCKED")
        self.assertEqual(len(ctx.calls), calls)

    def test_primary_error_not_masked_by_failed_after_check(self):
        ctx = FakeContext()
        ctx.status_error = TimeoutError("primary timeout")
        ctx.state_error = HttpFailure(403, "after-state denied")
        result = run_case(ctx)
        self.assertEqual(result["status"], "TIMEOUT")
        self.assertIn("primary timeout", result["summary"])
        self.assertIn("after-state denied", result["evidence"]["safetyError"]["message"])

    def test_generation_denial_is_failure_not_setup_block(self):
        ctx = FakeContext()
        ctx.generation_error = HttpFailure(403, "generation denied")
        self.assertEqual(run_case(ctx)["status"], "FAIL")


class RoutingTests(unittest.TestCase):
    def context(self):
        ctx = SimpleNamespace(
            config={"workspace_id": WORKSPACE, "target_network": "wspl",
                    "operations_metadata_api": "https://private-route.analysis.windows.net",
                    "operations_workload_host": HOST},
            credential=Mock(), timeout=30,
            request=Mock(return_value={"Token": "synthetic-token", "TargetUriHost": HOST,
                                       "CapacityObjectId": CAPACITY}))
        return ctx

    def test_oa_contract_and_token_scheme(self):
        ctx = self.context()
        with adapter.operations_context(ctx, AGENT, CAPACITY) as api:
            self.assertIn("/workloads/OA/OAgentsService/automatic", api.base)
            self.assertEqual(api.auth_scheme, "MwcToken")
        call = ctx.request.call_args
        self.assertEqual(call.args[1], "POST")
        self.assertTrue(call.args[2].endswith("/metadata/v201606/generatemwctokenv2"))
        self.assertEqual(call.args[3]["workloadType"], "OA")
        self.assertEqual(call.args[3]["artifacts"], [{"artifactType": "OperationalAgents", "artifactObjectId": AGENT}])
        ctx.credential.get_token.assert_not_called()

    def test_wrong_returned_host_or_capacity_blocks_workload_call(self):
        for key, value in (("TargetUriHost", "public.pbidedicated.windows.net"),
                           ("CapacityObjectId", ONTOLOGY)):
            ctx = self.context()
            ctx.request.return_value[key] = value
            with self.assertRaises(ScenarioBlocked):
                with adapter.operations_context(ctx, AGENT, CAPACITY):
                    self.fail("Host/capacity mismatch must not yield an API")
            self.assertEqual(ctx.request.call_count, 1)

    def test_missing_token_or_invalid_host_never_yields_api(self):
        for key, value in (("Token", ""), ("TargetUriHost", "example.com")):
            ctx = self.context()
            ctx.request.return_value[key] = value
            with self.assertRaises((InvalidResponse, ValueError)):
                with adapter.operations_context(ctx, AGENT, CAPACITY):
                    self.fail("Invalid MWC response must not yield an API")

    def test_v1_not_allowed(self):
        ctx = self.context()
        ctx.config["ux_token_version"] = "v1"
        with self.assertRaises(ScenarioBlocked):
            adapter.operations_routing(ctx.config)


if __name__ == "__main__":
    unittest.main()
