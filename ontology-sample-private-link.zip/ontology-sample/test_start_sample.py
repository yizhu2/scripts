import base64
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


def run_powershell(script):
    with tempfile.TemporaryDirectory() as temporary:
        path = Path(temporary) / "test-launcher.ps1"
        path.write_text(script, encoding="utf-8-sig")
        return subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-File", str(path)],
            capture_output=True, text=True, timeout=30,
        )


@unittest.skipUnless(shutil.which("powershell.exe"), "Windows PowerShell is required for bootstrap tests")
class PythonBootstrapTests(unittest.TestCase):
    def invoke(self, **scenario):
        text = Path(__file__).with_name("Start-Sample.ps1").read_text(encoding="utf-8-sig")
        bootstrap = text[:text.index("$requirements = Join-Path")]
        bootstrap = bootstrap.replace(
            "$ErrorActionPreference = 'Stop'",
            "$PSScriptRoot = 'C:\\Sample Package'\n$ErrorActionPreference = 'Stop'", 1,
        )
        source = base64.b64encode(bootstrap.encode("utf-8")).decode()
        config = base64.b64encode(json.dumps(scenario).encode("utf-8")).decode()
        script = r"""
$ErrorActionPreference = 'Stop'
$global:scenario = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('CONFIG')) | ConvertFrom-Json
$global:events = [Collections.Generic.List[string]]::new()
$global:installed = $false
$env:LOCALAPPDATA = 'C:\Test User'
function Write-Host {}
function Get-Command {
    param($Name, $CommandType, $ErrorAction)
    switch ($Name) {
        'py' { if ($scenario.py) { return [pscustomobject]@{ Source = 'Invoke-Py' } } }
        'python' { if ($scenario.python) { return [pscustomobject]@{ Source = 'Invoke-Python' } } }
        'winget' { if ($scenario.winget) { return [pscustomobject]@{ Source = 'Invoke-Winget' } } }
        'C:\Custom Python\python.exe' { return [pscustomobject]@{ Source = 'Invoke-CustomPython' } }
    }
}
function Join-Path {
    param($Path, $ChildPath)
    if ($ChildPath -eq 'Programs\Python\Python312\python.exe') { return 'Invoke-InstalledPython' }
    return Microsoft.PowerShell.Management\Join-Path $Path $ChildPath
}
function Test-Path {
    param($LiteralPath)
    if ($LiteralPath -eq 'Invoke-InstalledPython') {
        return ($scenario.installed -or ($global:installed -and -not $scenario.undetectable))
    }
    if ($LiteralPath -like '*\.venv\Scripts\python.exe') { return [bool]$scenario.venv }
    throw "Unexpected path: $LiteralPath"
}
function Read-Host {
    param($Prompt)
    $global:events.Add('prompt')
    if ($Prompt -notlike 'Install Python 3.12*') { throw "Unexpected prompt: $Prompt" }
    return $scenario.answer
}
function Invoke-Probe {
    param($Kind, $Code, $Arguments)
    $global:events.Add("$Kind $($Arguments -join ' ')")
    $global:LASTEXITCODE = $Code
    if ($Arguments -contains 'venv') { $global:LASTEXITCODE = [int]$scenario.venvExit }
}
function Invoke-Py { Invoke-Probe 'py' ([int]$scenario.pyExit) $args }
function Invoke-Python { Invoke-Probe 'python' ([int]$scenario.pythonExit) $args }
function Invoke-CustomPython { Invoke-Probe 'custom' ([int]$scenario.customExit) $args }
function Invoke-InstalledPython { Invoke-Probe 'installed' ([int]$scenario.installedExit) $args }
function Invoke-Winget {
    $global:events.Add("winget $($args -join ' ')")
    $global:installed = $true
    $global:LASTEXITCODE = [int]$scenario.wingetExit
}
$errorMessage = $null
try {
    $source = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('SOURCE'))
    $parameters = @{}
    if ($scenario.explicit) { $parameters.PythonExecutable = $scenario.explicit }
    & ([scriptblock]::Create($source)) @parameters
} catch { $errorMessage = $_.Exception.Message }
@{ events = @($global:events); error = $errorMessage } | ConvertTo-Json -Compress
""".replace("SOURCE", source).replace("CONFIG", config)
        result = run_powershell(script)
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def test_existing_virtual_environment_needs_no_probe_or_install(self):
        result = self.invoke(venv=True)
        self.assertIsNone(result["error"])
        self.assertEqual(result["events"], [])

    def test_working_launcher_creates_virtual_environment_without_installing(self):
        result = self.invoke(py=True, winget=True)
        self.assertIsNone(result["error"])
        self.assertTrue(result["events"][0].startswith("py -3 -c "))
        self.assertEqual(result["events"][-1], r"py -3 -m venv C:\Sample Package\.venv")
        self.assertFalse(any(event.startswith(("winget", "prompt")) for event in result["events"]))

    def test_unusable_launcher_falls_back_to_working_python(self):
        result = self.invoke(py=True, pyExit=1, python=True)
        self.assertIsNone(result["error"])
        self.assertTrue(result["events"][-1].startswith("python -m venv "))

    def test_store_shortcut_prompts_then_detects_install_without_path_refresh(self):
        result = self.invoke(python=True, pythonExit=9009, winget=True, answer="y")
        self.assertIsNone(result["error"])
        self.assertIn("prompt", result["events"])
        self.assertIn(
            "winget install --exact --id Python.Python.3.12 --source winget --scope user",
            result["events"],
        )
        self.assertTrue(result["events"][-1].startswith("installed -m venv "))

    def test_existing_default_installation_is_found_without_path_entry(self):
        result = self.invoke(installed=True)
        self.assertIsNone(result["error"])
        self.assertTrue(result["events"][-1].startswith("installed -m venv "))
        self.assertNotIn("prompt", result["events"])

    def test_decline_and_missing_winget_stop_with_manual_instructions(self):
        for scenario in ({}, {"winget": True, "answer": "n"}, {"winget": True, "answer": ""}):
            with self.subTest(scenario=scenario):
                result = self.invoke(**scenario)
                self.assertIn("https://www.python.org/downloads/windows/", result["error"])
                self.assertIn("-PythonExecutable", result["error"])
                self.assertFalse(any("winget install" in event or "venv" in event for event in result["events"]))

    def test_failed_install_or_failed_detection_never_creates_virtual_environment(self):
        for scenario, message in (
            ({"wingetExit": 5}, "WinGet exit code 5"),
            ({"undetectable": True}, "could not be located"),
            ({"installedExit": 1}, "could not be located"),
        ):
            with self.subTest(scenario=scenario):
                result = self.invoke(winget=True, answer="yes", **scenario)
                self.assertIn(message, result["error"])
                self.assertFalse(any("venv" in event for event in result["events"]))

    def test_explicit_executable_is_respected_and_never_triggers_install(self):
        for exit_code in (0, 1):
            with self.subTest(exit_code=exit_code):
                result = self.invoke(
                    explicit=r"C:\Custom Python\python.exe", customExit=exit_code, winget=True,
                )
                self.assertNotIn("prompt", result["events"])
                if exit_code:
                    self.assertIn("specified Python executable", result["error"])
                else:
                    self.assertIsNone(result["error"])
                    self.assertTrue(result["events"][-1].startswith("custom -m venv "))
        result = self.invoke(explicit=r"C:\Missing\python.exe", winget=True)
        self.assertIn("specified Python executable", result["error"])
        self.assertEqual(result["events"], [])

    def test_virtual_environment_failure_stops_setup(self):
        result = self.invoke(py=True, venvExit=1)
        self.assertIn("virtual environment creation failed", result["error"])


@unittest.skipUnless(shutil.which("powershell.exe"), "Windows PowerShell is required for bootstrap tests")
class OdbcBootstrapTests(unittest.TestCase):
    def invoke(self, **scenario):
        text = Path(__file__).with_name("Start-Sample.ps1").read_text(encoding="utf-8-sig")
        functions = text[text.index("function Get-SampleOdbcDrivers"):text.index("$python = Join-Path")]
        gating = text[text.index("$needsSql ="):text.index("if (-not $RetrySource) {")]
        source = base64.b64encode((functions + gating).encode("utf-8")).decode()
        config = base64.b64encode(json.dumps(scenario).encode("utf-8")).decode()
        script = r"""
$ErrorActionPreference = 'Stop'
$global:scenario = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('CONFIG')) | ConvertFrom-Json
$global:events = [Collections.Generic.List[string]]::new()
$global:installed = $false
$python = 'Invoke-TestPython'
$PlanOnly = [bool]$scenario.planOnly
$VerifyOnly = [bool]$scenario.verifyOnly
$reuseWorkspace = [bool]$scenario.reuseWorkspace
$SourcesManifest = $scenario.sourcesManifest
$RetrySource = $scenario.retrySource
function Write-Host {}
function Get-Command {
    param($Name, $CommandType, $ErrorAction)
    if ($Name -ne 'winget') { throw "Unexpected command: $Name" }
    if ($scenario.winget) { return [pscustomobject]@{ Source = 'Invoke-Winget' } }
}
function Read-Host {
    param($Prompt)
    if ($Prompt -notlike 'Install ODBC Driver 18*Administrator approval*') { throw "Unexpected prompt: $Prompt" }
    $global:events.Add('prompt')
    return $scenario.answer
}
function Invoke-TestPython {
    if ($args.Count -ne 2 -or $args[0] -ne '-c' -or $args[1] -notlike '*pyodbc.drivers()*') {
        throw "Unexpected Python call: $args"
    }
    $global:events.Add('probe')
    $global:LASTEXITCODE = [int]$scenario.probeExit
    if ($scenario.driverPresent -or ($global:installed -and -not $scenario.notVisible)) {
        ConvertTo-Json -InputObject @('SQL Server', 'ODBC Driver 18 for SQL Server') -Compress
    }
    elseif ($scenario.noDrivers) { '[]' }
    else { ConvertTo-Json -InputObject @('SQL Server') -Compress }
}
function Invoke-Winget {
    $global:events.Add("winget $($args -join ' ')")
    $global:installed = $true
    $global:LASTEXITCODE = [int]$scenario.wingetExit
}
$errorMessage = $null
try {
    $source = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('SOURCE'))
    & ([scriptblock]::Create($source))
} catch { $errorMessage = $_.Exception.Message }
@{ events = @($global:events); error = $errorMessage } | ConvertTo-Json -Compress
""".replace("SOURCE", source).replace("CONFIG", config)
        result = run_powershell(script)
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def test_existing_driver_is_not_reinstalled(self):
        result = self.invoke(driverPresent=True, winget=True)
        self.assertIsNone(result["error"])
        self.assertEqual(result["events"], ["probe"])

    def test_install_requires_consent_and_is_rechecked_in_sample_python(self):
        for no_drivers in (False, True):
            with self.subTest(no_drivers=no_drivers):
                result = self.invoke(winget=True, answer="y", noDrivers=no_drivers)
                self.assertIsNone(result["error"])
                self.assertEqual(result["events"], [
                    "probe", "prompt",
                    "winget install --exact --id Microsoft.msodbcsql.18 --source winget --scope machine",
                    "probe",
                ])

    def test_missing_winget_and_declined_install_show_manual_instructions(self):
        for scenario in ({}, {"winget": True, "answer": ""}, {"winget": True, "answer": "n"}):
            with self.subTest(scenario=scenario):
                result = self.invoke(**scenario)
                self.assertIn("https://learn.microsoft.com/en-us/sql/connect/odbc/", result["error"])
                self.assertFalse(any(event.startswith("winget ") for event in result["events"]))

    def test_installer_failure_or_driver_still_missing_stops_setup(self):
        for scenario, expected in (
            ({"wingetExit": 5}, "WinGet exit code 5"),
            ({"wingetExit": 3010}, "restart requirement"),
            ({"notVisible": True}, "still unavailable"),
        ):
            with self.subTest(scenario=scenario):
                result = self.invoke(winget=True, answer="yes", **scenario)
                self.assertIn(expected, result["error"])
                self.assertIn("ODBC Driver 18", result["error"])

    def test_failed_probe_never_attempts_install(self):
        result = self.invoke(probeExit=1, winget=True, answer="yes")
        self.assertIn("Could not check ODBC drivers", result["error"])
        self.assertEqual(result["events"], ["probe"])

    def test_non_sql_and_plan_flows_do_not_probe_or_install(self):
        for scenario in (
            {"planOnly": True},
            {"planOnly": True, "reuseWorkspace": True},
            {"planOnly": True, "retrySource": "Warehouse"},
            {"sourcesManifest": "sources.json"},
            {"sourcesManifest": "sources.json", "verifyOnly": True},
            *({"retrySource": kind, "verifyOnly": verify} for kind in (
                "Eventhouse", "KQLDatabase", "SemanticModel") for verify in (False, True)),
        ):
            with self.subTest(scenario=scenario):
                result = self.invoke(**scenario)
                self.assertIsNone(result["error"])
                self.assertEqual(result["events"], [])

    def test_source_reuse_and_sql_retries_require_driver_including_verify_only(self):
        for scenario in (
            {"reuseWorkspace": True},
            {"reuseWorkspace": True, "verifyOnly": True},
            *({"retrySource": kind, "verifyOnly": verify, "sourcesManifest": "sources.json"} for kind in (
                "Lakehouse", "MirroredDatabase", "SQLDatabase", "Warehouse") for verify in (False, True)),
        ):
            with self.subTest(scenario=scenario):
                result = self.invoke(driverPresent=True, **scenario)
                self.assertIsNone(result["error"])
                self.assertEqual(result["events"], ["probe"])


@unittest.skipUnless(shutil.which("powershell.exe"), "Windows PowerShell is required for bootstrap tests")
class AzureCliBootstrapTests(unittest.TestCase):
    def invoke(self, **scenario):
        text = Path(__file__).with_name("Start-Sample.ps1").read_text(encoding="utf-8-sig")
        functions = text[text.index("function Find-SampleAzureCli"):text.index("function Get-SampleOdbcDrivers")]
        gating = text[text.index("$needsAzureCli ="):text.index("$needsSql =")]
        source = base64.b64encode((functions + gating).encode("utf-8")).decode()
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            probe = root / "version-probe.txt"
            for directory in ("Program Files", "Program Files (x86)"):
                executable = root / directory / "Microsoft SDKs" / "Azure" / "CLI2" / "wbin" / "az.cmd"
                executable.parent.mkdir(parents=True)
                executable.write_text(
                    '@echo off\nif not "%~1"=="version" exit /b 17\n'
                    'if not "%~2"=="--output" exit /b 18\n'
                    'if not "%~3"=="json" exit /b 19\n'
                    f'echo version>>"{probe}"\nexit /b {scenario.get("versionExit", 0)}\n',
                    encoding="ascii",
                )
            scenario.update(root=str(root), python=sys.executable, probe=str(probe))
            config = base64.b64encode(json.dumps(scenario).encode("utf-8")).decode()
            script = r"""
$ErrorActionPreference = 'Stop'
$global:scenario = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('CONFIG')) | ConvertFrom-Json
$global:events = [Collections.Generic.List[string]]::new()
$global:installed = $false
$env:ProgramFiles = Join-Path $scenario.root 'Program Files'
${env:ProgramFiles(x86)} = Join-Path $scenario.root 'Program Files (x86)'
$cliDirectory = Join-Path $env:ProgramFiles 'Microsoft SDKs\Azure\CLI2\wbin'
if ($scenario.x86) { $cliDirectory = Join-Path ${env:ProgramFiles(x86)} 'Microsoft SDKs\Azure\CLI2\wbin' }
$script:executable = Join-Path $cliDirectory 'az.cmd'
if ($scenario.onPath) { $env:PATH = "$cliDirectory;$env:PATH" }
$originalPath = $env:PATH
$PlanOnly = [bool]$scenario.planOnly
$Auth = if ($scenario.auth) { $scenario.auth } else { 'auto' }
function Write-Host {}
function Write-Warning { param($Message); $global:events.Add("warning: $Message") }
function Get-Command {
    param($Name, $CommandType, $ErrorAction)
    if ($Name -eq 'az' -and $scenario.onPath) { return [pscustomobject]@{ Source = $script:executable } }
    if ($Name -eq 'winget' -and $scenario.winget) { return [pscustomobject]@{ Source = 'Invoke-Winget' } }
}
function Test-Path {
    param($LiteralPath, $PathType)
    return $LiteralPath -eq $script:executable -and (
        $scenario.standardInstall -or ($global:installed -and -not $scenario.undetectable))
}
function Read-Host {
    param($Prompt)
    if ($Prompt -notlike 'Install Azure CLI*Administrator approval*') { throw "Unexpected prompt: $Prompt" }
    $global:events.Add('prompt')
    return $scenario.answer
}
function Invoke-Winget {
    $global:events.Add("winget $($args -join ' ')")
    $global:installed = $true
    $global:LASTEXITCODE = [int]$scenario.wingetExit
}
$errorMessage = $null
$pythonFound = $null
try {
    $source = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('SOURCE'))
    & ([scriptblock]::Create($source))
    if (Microsoft.PowerShell.Management\Test-Path -LiteralPath $scenario.probe) {
        $pythonFound = & $scenario.python -c 'import shutil, sys; print(shutil.which(sys.argv[1]))' az
        if ($LASTEXITCODE -ne 0) { throw 'Python CLI lookup failed' }
    }
} catch { $errorMessage = $_.Exception.Message }
@{
    events = @($global:events); error = $errorMessage; pythonFound = $pythonFound
    pathUnchanged = $env:PATH -eq $originalPath
    preservesOriginalPath = $env:PATH.EndsWith($originalPath)
} | ConvertTo-Json -Compress
""".replace("SOURCE", source).replace("CONFIG", config)
            result = run_powershell(script)
            self.assertEqual(result.returncode, 0, result.stderr)
            found = json.loads(result.stdout)
            found["versionProbes"] = probe.read_text().splitlines() if probe.exists() else []
            found["expectedExecutable"] = str(root / (
                "Program Files (x86)" if scenario.get("x86") else "Program Files"
            ) / "Microsoft SDKs" / "Azure" / "CLI2" / "wbin" / "az.cmd")
            return found

    def assert_available(self, result):
        self.assertIsNone(result["error"])
        self.assertEqual(result["versionProbes"], ["version"])
        self.assertEqual(Path(result["pythonFound"]), Path(result["expectedExecutable"]))
        self.assertTrue(result["preservesOriginalPath"])

    def test_existing_cli_on_path_is_checked_without_reinstalling(self):
        result = self.invoke(onPath=True, winget=True)
        self.assert_available(result)
        self.assertEqual(result["events"], [])
        self.assertTrue(result["pathUnchanged"])

    def test_standard_install_is_found_and_visible_to_python_without_new_shell(self):
        for x86 in (False, True):
            with self.subTest(x86=x86):
                result = self.invoke(standardInstall=True, x86=x86)
                self.assert_available(result)
                self.assertEqual(result["events"], [])
                self.assertFalse(result["pathUnchanged"])

    def test_confirmed_install_is_verified_and_exposed_to_python(self):
        result = self.invoke(winget=True, answer="yes", auth="cli")
        self.assert_available(result)
        self.assertEqual(result["events"], [
            "prompt", "winget install --exact --id Microsoft.AzureCLI --source winget --scope machine",
        ])

    def test_browser_and_preview_modes_do_not_check_or_install_cli(self):
        for scenario in ({"auth": "browser"}, {"planOnly": True}, {"planOnly": True, "auth": "cli"}):
            with self.subTest(scenario=scenario):
                result = self.invoke(**scenario)
                self.assertIsNone(result["error"])
                self.assertEqual(result["events"], [])
                self.assertEqual(result["versionProbes"], [])
                self.assertTrue(result["pathUnchanged"])

    def test_cli_mode_decline_or_missing_winget_stops_with_manual_guidance(self):
        for scenario in ({}, {"winget": True, "answer": "n"}, {"winget": True, "answer": ""}):
            with self.subTest(scenario=scenario):
                result = self.invoke(auth="cli", **scenario)
                self.assertIn("https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-windows", result["error"])
                self.assertEqual(result["versionProbes"], [])
                self.assertTrue(result["pathUnchanged"])

    def test_auto_mode_retains_explicit_browser_fallback_when_install_not_selected(self):
        for scenario in ({}, {"winget": True, "answer": "n"}):
            with self.subTest(scenario=scenario):
                result = self.invoke(**scenario)
                self.assertIsNone(result["error"])
                self.assertIn("approved application ID is required", result["events"][-1])
                self.assertEqual(result["versionProbes"], [])
                self.assertTrue(result["pathUnchanged"])

    def test_install_or_detection_failure_does_not_fall_back_to_another_auth_route(self):
        for scenario, message in (
            ({"wingetExit": 5}, "WinGet exit code 5"),
            ({"undetectable": True}, "could not be located"),
        ):
            with self.subTest(scenario=scenario):
                result = self.invoke(winget=True, answer="y", **scenario)
                self.assertIn(message, result["error"])
                self.assertFalse(any(event.startswith("warning:") for event in result["events"]))
                self.assertTrue(result["pathUnchanged"])

    def test_broken_cli_stops_before_path_changes_or_sign_in(self):
        result = self.invoke(standardInstall=True, versionExit=1, winget=True)
        self.assertIn("version check failed", result["error"])
        self.assertEqual(result["events"], [])
        self.assertEqual(result["versionProbes"], ["version"])
        self.assertTrue(result["pathUnchanged"])


if __name__ == "__main__":
    unittest.main()
