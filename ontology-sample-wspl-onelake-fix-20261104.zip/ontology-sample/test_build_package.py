import ast
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile

from build_package import FILES, build


class PackageTests(unittest.TestCase):
    def test_example_config_exposes_operations_route_and_bounded_generation_without_reuse(self):
        config = json.loads(Path(__file__).with_name("validation.example.json").read_text())
        self.assertEqual(config["operations_generation_timeout"], 900)
        self.assertGreater(config["scenario_timeout"], config["operations_generation_timeout"])
        self.assertEqual(config["ux_token_version"], "v2")
        self.assertEqual(config["operations_metadata_api"], "")
        self.assertEqual(config["operations_workload_host"], "")
        self.assertNotIn("operations_id", config)
        self.assertNotIn("operations_ids", config)
        self.assertNotIn("allow_create", config)

    def test_validation_adapters_are_portable_and_complete(self):
        import importlib
        from validate_sample import MODULE_SCENARIOS, catalog
        folder = Path(__file__).resolve().parent
        self.assertIn("Start-Validation.ps1", FILES)
        self.assertIn("validation.example.json", FILES)
        self.assertIn("VALIDATION.md", FILES)
        self.assertIn("validation_setup.py", FILES)
        self.assertIn("test_validation_setup.py", FILES)
        self.assertIn("validation_count_scope.py", FILES)
        self.assertIn("test_validation_count_scope.py", FILES)
        self.assertEqual(len(catalog()), 43)
        for module, scenarios in MODULE_SCENARIOS.items():
            self.assertIn(module + ".py", FILES)
            self.assertEqual(set(importlib.import_module(module).SCENARIOS), set(scenarios))
            text = (folder / (module + ".py")).read_text(encoding="utf-8")
            for entry in ast.parse(text).body:
                definition_probe = module == "validation_queries" and getattr(entry, "name", "") == "definition"
                for node in ast.walk(entry):
                    if isinstance(node, ast.Constant) and isinstance(node.value, str):
                        for endpoint in ("/getDefinition", "/updateDefinition", "/exportDefinition", "/importDefinition"):
                            if definition_probe and endpoint == "/getDefinition":
                                continue
                            self.assertNotIn(endpoint, node.value, f"{module} must not gate functional tests on ALM")
            for local_dependency in ("C:\\Users\\", "C:/Users/", ".copilot", "sys.path.insert"):
                self.assertNotIn(local_dependency, text)

    def test_runtime_has_no_sdk_download_or_serializer_dependency(self):
        folder = Path(__file__).resolve().parent
        for name in FILES:
            if name.startswith("test_") or not name.endswith((".py", ".ps1")):
                continue
            text = (folder / name).read_text(encoding="utf-8-sig")
            for dependency in ("pkgs.dev.azure.com", "499b84ac-1321-427f-aa17-267ca6975798",
                               "Microsoft.AnalysisServices.Core.dll", "ontology_tmdl.ps1",
                               "sdk_bootstrap", "--sdk-directory", "SdkDirectory"):
                with self.subTest(file=name, dependency=dependency):
                    self.assertNotIn(dependency, text)

    def test_archive_contains_only_allowlisted_files_and_matching_hashes(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            for name in FILES:
                (folder / name).write_text(name, encoding="utf-8")
            (folder / "secret.token").write_text("not included", encoding="utf-8")
            (folder / "sources.manifest.json").write_text("not included", encoding="utf-8")
            (folder / "sdk.dll").write_bytes(b"not included")
            output = folder / "package.zip"
            digest = build(output, folder)
            self.assertEqual(digest, hashlib.sha256(output.read_bytes()).hexdigest())
            with ZipFile(output) as archive:
                names = set(archive.namelist())
                self.assertEqual(names, {"ontology-sample/" + name for name in (*FILES, "PACKAGE.json")})
                manifest = json.loads(archive.read("ontology-sample/PACKAGE.json"))
                for name, expected_hash in manifest["files"].items():
                    self.assertEqual(hashlib.sha256(archive.read("ontology-sample/" + name)).hexdigest(),
                                     expected_hash)
                self.assertFalse(manifest["sdkBinariesIncluded"])
                self.assertFalse(manifest["sdkRequired"])
                self.assertFalse(manifest["internalFeedAccessRequired"])
                self.assertEqual(set(manifest), {
                    "entryPoint", "sdkBinariesIncluded", "sdkRequired", "internalFeedAccessRequired", "files",
                })
                self.assertNotIn("ontology-sample/sdk_bootstrap.py", names)
                self.assertNotIn("ontology-sample/ontology_tmdl.ps1", names)
            with self.assertRaises(FileExistsError):
                build(output, folder)

    def test_missing_input_does_not_leave_a_partial_zip(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            output = folder / "package.zip"
            with self.assertRaises(FileNotFoundError):
                build(output, folder)
            self.assertFalse(output.exists())


if __name__ == "__main__":
    unittest.main()
