"""Run independent, selectable Fabric agent scenarios and persist a copyable report."""

import argparse
import fnmatch
import importlib
import json
import sys
import time
from collections import Counter
from contextlib import ExitStack
from functools import partial
from pathlib import Path
from uuid import UUID, uuid4

from validation_common import HttpFailure, InvalidResponse, ScenarioBlocked, ValidationContext, console, sanitize, utc_now, write_json
from validation_setup import MANUAL_SCENARIOS, prerequisites, unselected_source_reason

MODULES = ("validation_queries", "validation_data_agent", "validation_generation", "validation_operations")
SOURCE_CASES = ("lakehouse", "kql", "warehouse", "sql", "mirror", "semantic",
                "sm-lakehouse", "sm-kql", "lakehouse-kql", "lakehouse-warehouse")
MODULE_SCENARIOS = {
    "validation_queries": ("ontology.definition",) + tuple(
        f"{family}.{case}" for family in ("ontology", "mcp") for case in SOURCE_CASES),
    "validation_data_agent": tuple(f"data-agent.{case}" for case in SOURCE_CASES),
    "validation_generation": ("generation.lifecycle",),
    "validation_operations": tuple(f"operations.{case}" for case in SOURCE_CASES) + ("operations.runtime",),
}
STATUSES = ("PASS", "PARTIAL", "FAIL", "BLOCKED", "ERROR", "TIMEOUT", "SKIP", "PENDING", "RUNNING")
MANUAL_CHECKS = (
    "WSPL/BPA enforced on workspace A; semantic model in separate workspace B with BPA Off",
    "Private DNS/routes verified from the intended client; no public-egress access",
    "Unauthorized principal/source-permission denial and recovery",
    "Source connectivity revocation and recovery",
    "Fresh sentinel read to rule out cached answers",
    "Copilot-disabled tenant setting enforcement",
    "Operations Agent runtime/actions/notifications (never enabled by this runner)",
    "Cancellation racing an active generation apply",
    "Source variants: DirectQuery/Direct Lake, views, shortcuts, materialized views/functions",
    "Graph, sharing, deployment remapping and MCP Tasks",
)


def invoke_adapter(ctx, module_name, scenario):
    # Import inside the scenario boundary: an unavailable optional adapter cannot block other agents.
    module = importlib.import_module(module_name)
    return module.SCENARIOS[scenario](ctx)


def catalog():
    return {scenario: partial(invoke_adapter, module_name=module_name, scenario=scenario)
            for module_name in MODULES for scenario in MODULE_SCENARIOS[module_name]}


def select_scenarios(available, agents=None, scenarios=None, previous=None):
    if previous:
        saved = json.loads(Path(previous).read_text(encoding="utf-8-sig"))
        selected = {row["scenario"] for row in saved["results"]
                    if row["selected"] and row["status"] in
                    ("PARTIAL", "FAIL", "BLOCKED", "ERROR", "TIMEOUT", "PENDING", "RUNNING")}
        if "operations.native-import" in selected:
            selected.remove("operations.native-import")
            selected.add("operations.runtime")
            console("Retired operations.native-import: Operations runtime will be reported SKIP, not an ALM test.")
        unknown = selected - available.keys()
        if unknown:
            raise ValueError(f"Prior report contains unavailable scenarios: {sorted(unknown)}")
        return selected
    if scenarios:
        selected = set()
        for pattern in scenarios:
            matches = {name for name in available if fnmatch.fnmatchcase(name, pattern)}
            if not matches:
                raise ValueError(f"No scenario matches {pattern!r}; use --list")
            selected.update(matches)
        return selected
    if agents:
        return {name for name in available if name.split(".")[0] in agents}
    # Safe default: read-only definition probe, not a long agent or creation run.
    return {"ontology.definition"}


def load_config(path):
    if not path:
        raise ValueError("--config is required (except --list)")
    value = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    return validate_config(value)


def validate_config(value):
    if not isinstance(value, dict):
        raise ValueError("Configuration must be a JSON object")
    for name in ("tenant_id", "workspace_id", "ontology_id"):
        try:
            value[name] = str(UUID(value.get(name, "")))
        except (ValueError, TypeError, AttributeError):
            raise ValueError(f"{name} must be a valid GUID in the configuration") from None
    if value.get("target_network") not in ("public", "wspl", "tenantpl"):
        raise ValueError("Set target_network explicitly: public, wspl or tenantpl")
    for name, default, minimum, maximum in (
        ("timeout", 240, 30, 1800), ("scenario_timeout", 1800, 30, 7200), ("poll_seconds", 5, 1, 60),
        ("operations_generation_timeout", 900, 30, 3600),
    ):
        setting = value.get(name, default)
        if type(setting) is not int or not minimum <= setting <= maximum:
            raise ValueError(f"{name} must be an integer from {minimum} to {maximum}")
        value[name] = setting
    if value["scenario_timeout"] < value["timeout"]:
        raise ValueError("scenario_timeout must be at least timeout")
    if value.get("auth", "cli") not in ("cli", "browser"):
        raise ValueError("auth must be cli or browser; automatic identity fallback is disabled")
    value["auth"] = value.get("auth", "cli")
    if value.get("data_agent_mode", "shared") not in ("shared", "isolated"):
        raise ValueError("data_agent_mode must be shared or isolated")
    value["data_agent_mode"] = value.get("data_agent_mode", "shared")
    if "allow_create" in value and type(value["allow_create"]) is not bool:
        raise ValueError("allow_create must be a JSON boolean")
    # Only the command line can authorize creation for this invocation.
    value["allow_create"] = False
    from ux_authoring import routing
    from source_selection import normalize_source_types
    if "source_types" in value:
        value["source_types"] = list(normalize_source_types(value["source_types"]))
    if value.get("authoring_mode", "ux") not in ("public", "ux", "hybrid"):
        raise ValueError("authoring_mode must be public, ux or hybrid")
    if (value.get("authoring_mode") != "public"
            or value.get("ux_metadata_api") or value.get("ux_workload_host")):
        value["ux_metadata_api"], value["ux_workload_host"] = routing(
            value["target_network"], value.get("ux_metadata_api"), value.get("ux_workload_host"))
    if value.get("ux_token_version", "v2") not in ("v1", "v2"):
        raise ValueError("ux_token_version must be v1 or v2")
    return value


def cell(value):
    return str(sanitize(value)).replace("|", "\\|").replace("\r", " ").replace("\n", "<br>")


def persist(directory, report):
    report["assessmentPolicy"] = {"sourceEvidenceRequired": False,
                                  "sampleNaiveTimestampsAssumedUtc": True,
                                  "scope": "Functional answers/playbooks; not Private Link certification"}
    write_json(directory / "results.json", report)
    counts = Counter(row["status"] for row in report["results"] if row["selected"])
    lines = [
        "# Fabric ontology/agent validation report", "",
        "**Not a Private Link certification.** Functional results below do not prove network or identity enforcement.",
        "", f"- Started (UTC): {report['startedUtc']}",
        f"- Updated (UTC): {utc_now()}", f"- Run state: {report['state']}",
        f"- Network route: {cell(report.get('config', {}).get('target_network', 'not configured'))}",
        f"- Workspace: {cell(report.get('config', {}).get('workspace_id', 'not configured'))}",
        f"- Ontology: {cell(report.get('config', {}).get('ontology_id', 'not configured'))}",
        f"- Selected result counts: {cell(dict(counts))}",
        "- Writes: only explicit --allow-create permits new test artifacts; no source writes or Operations Agent activation.",
        "- Resolver warnings do not prevent independent agent/query scenarios.",
        "- Functional agent tests do not export/import definitions.",
        f"- Data Agent mode: {cell(report.get('config', {}).get('data_agent_mode', 'shared'))}. "
        "Shared mode creates one fresh draft per run unless reuse is explicitly configured; "
        "all ontology entities are selected and each question is independent.",
        "- Independent source/lineage proof is informational, not a PASS/PARTIAL requirement. "
        "Wrong or incomplete answers, observed source mismatches, errors and safety failures remain non-passing.",
        "- Sample ObservedAt values are known UTC: an omitted timezone suffix is normalized to UTC. "
        "Different, missing or invalid timestamps still fail.",
        "- Operations authoring: one fresh inactive artifact per run, separate sequential native playbook previews "
        "and static checks only; "
        "no independent query execution. Operations runtime remains SKIP (no monitoring/actions/notifications).",
        "- Operations authoring PASS requires native Completed, one inspectable native rule/query with required properties and "
        "TemperatureC or TemperatureCelsius Is Above 32.5, and reported Inactive/Unconfigured before and after; "
        "not data-correctness or trigger validation.",
        "- Operations artifacts/playbooks remain in operations_agents/operations_playbooks; "
        "no automatic deletion or cross-run reuse. operations_shared/operations_previews record creation and "
        "preview lifecycle; an uncertain generation outcome or nonrunning state blocks later Operations previews.",
        "- PASS is scoped to the check stated. PARTIAL is not an acceptance pass. SKIP means not tested.",
        "",
    ]
    if report.get("error"):
        lines += [f"**Run-level error:** {cell(report['error'])}", ""]
    if report.get("preflight"):
        lines += ["## Configuration preflight", "",
                  "Offline checks only. Blocked scenarios are skipped; independently ready scenarios still run.",
                  "Use `Start-Validation.ps1 -Configure` with the same selectors to supply missing settings.", ""]
        for name, errors in report["preflight"].items():
            lines.append(f"- **{cell(name)}:** {cell('; '.join(errors))}")
        lines.append("")
    lines += ["## Results", "", "| Scenario | Selected | Status | Detail | Evidence |",
              "|---|---|---|---|---|"]
    for row in report["results"]:
        evidence = f"[JSON]({row['scenario']}.result.json)" if row.get("finishedUtc") else "-"
        lines.append(f"| {cell(row['scenario'])} | {'yes' if row['selected'] else 'no'} | "
                     f"{row['status']} | {cell(row['summary'])} | {evidence} |")
    lines += ["", "## Selected scenario diagnostics", ""]
    for row in report["results"]:
        if not row["selected"] or not row.get("finishedUtc"):
            continue
        lines += [f"### {row['scenario']}", "",
                  f"- Result: **{row['status']}** - {cell(row['summary'])}",
                  f"- Duration: {row.get('durationSeconds', '?')} seconds"]
        if row.get("errorType"):
            lines.append(f"- Error type: {cell(row['errorType'])}")
        details = row.get("evidence", {})
        if isinstance(details, dict):
            # Keep correlation/assertion summaries copyable without duplicating whole definitions/messages.
            compact = {key: value for key, value in details.items()
                       if len(json.dumps(value, default=str)) <= 2000}
            if compact:
                lines += ["", "```json", json.dumps(sanitize(compact), indent=2, ensure_ascii=True), "```"]
        if row.get("requestSummary"):
            lines += ["", "Last mutation/error requests and final response (full ledger in adjacent HTTP JSON):",
                      "", "```json", json.dumps(sanitize(row["requestSummary"]), indent=2, ensure_ascii=True), "```"]
        lines.append("")
    lines += ["", "## Private Link acceptance checks not automated by this runner", ""]
    lines += [f"- NOT RUN: {check}" for check in MANUAL_CHECKS]
    lines += ["", "## Retained resources", "", "```json",
              json.dumps(sanitize(report.get("resources", {})), indent=2, ensure_ascii=True), "```", "",
              "## Evidence and reruns", "",
              "Copy this whole report into your test record. Keep the adjacent results.json and sanitized per-scenario",
              "HTTP/result evidence for diagnostics. Review before sharing: responses may contain source data.",
              "No token files are written. No automatic public fallback, alternate login, or write retry is performed.",
              "Rerun explicitly with --scenarios or --rerun-failed results.json and a NEW output directory.",
              "Creation retries can create another test artifact; inspect retained IDs/operations first.", ""]
    temporary = directory / "report.md.tmp"
    temporary.write_text("\n".join(lines), encoding="utf-8")
    temporary.replace(directory / "report.md")


def execute_scenarios(available, selected, ctx, report, directory, plan=False):
    for row in report["results"]:
        if not row["selected"]:
            continue
        skip = (MANUAL_SCENARIOS.get(row["scenario"])
                or unselected_source_reason(report.get("config", {}), row["scenario"]))
        if skip:
            row.update(status="SKIP", summary=skip,
                       finishedUtc=utc_now(), durationSeconds=0)
            write_json(directory / f"{row['scenario']}.result.json", row)
            persist(directory, report)
            console(f"{row['scenario']}: SKIP - {row['summary']}")
            continue
        errors = report.get("preflight", {}).get(row["scenario"])
        if errors:
            row.update(status="BLOCKED", summary="Configuration preflight: " + "; ".join(errors),
                       errorType="ScenarioBlocked", finishedUtc=utc_now(), durationSeconds=0)
            write_json(directory / f"{row['scenario']}.result.json", row)
            persist(directory, report)
            console(f"{row['scenario']}: BLOCKED - {row['summary']}")
            continue
        if plan:
            row.update(status="SKIP", summary="Plan only; no authentication or live calls")
            continue
        row.update(status="RUNNING", startedUtc=utc_now(), summary="Running; evidence checkpointed")
        persist(directory, report)
        ctx.begin(row["scenario"])
        console(f"Running {row['scenario']} (independent result; failures will not stop later scenarios)")
        started = time.monotonic()
        try:
            result = available[row["scenario"]](ctx)
            if not isinstance(result, dict) or result.get("status") not in STATUSES[:7]:
                raise ValueError("Scenario returned an invalid result contract")
            if not isinstance(result.get("summary"), str):
                raise ValueError("Scenario result must contain summary text")
            row.update(result)
        except ScenarioBlocked as error:
            row.update(status="BLOCKED", summary=str(error), errorType=type(error).__name__)
        except HttpFailure as error:
            row.update(status="BLOCKED" if error.status in (401, 403) else "FAIL",
                       summary=str(error), errorType=type(error).__name__)
        except InvalidResponse as error:
            row.update(status="FAIL", summary=str(error), errorType=type(error).__name__)
        except TimeoutError as error:
            row.update(status="TIMEOUT", summary=str(error), errorType=type(error).__name__)
        except KeyboardInterrupt:
            row.update(status="ERROR", summary="Interrupted; resources retained; no automatic cleanup")
            raise
        except Exception as error:
            # Isolation boundary: record a visible error, never a success-shaped fallback.
            row.update(status="ERROR", summary=str(error), errorType=type(error).__name__)
        finally:
            row.update(finishedUtc=utc_now(), durationSeconds=round(time.monotonic() - started, 3))
            requests = ctx.requests if isinstance(ctx.requests, list) else []
            selected_requests = [entry for entry in requests
                                 if entry.get("method") != "GET" or entry.get("error")]
            if requests and (not selected_requests or selected_requests[-1] is not requests[-1]):
                selected_requests.append(requests[-1])
            row["requestSummary"] = [
                {key: entry[key] for key in ("utc", "method", "url", "httpStatus", "durationSeconds",
                                            "clientRequestId", "headers", "responseByteLength", "error")
                 if key in entry}
                for entry in selected_requests[-8:]]
            report["resources"] = ctx.state
            write_json(directory / f"{row['scenario']}.result.json", row)
            persist(directory, report)
        console(f"{row['scenario']}: {row['status']} - {row['summary']}")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path)
    selection = parser.add_mutually_exclusive_group()
    selection.add_argument("--agents", nargs="+", choices=("ontology", "mcp", "data-agent", "generation", "operations"))
    selection.add_argument("--scenarios", nargs="+", help="Exact names or quoted wildcard patterns from --list")
    selection.add_argument("--rerun-failed", type=Path, help="Prior results.json; includes partial/unfinished tests")
    parser.add_argument("--list", action="store_true", help="List scenario IDs without auth/config")
    parser.add_argument("--plan", action="store_true", help="Write selected plan/report without live calls")
    parser.add_argument("--configure", action="store_true", help="Interactively save configuration offline, then exit")
    parser.add_argument("--sample-manifest", type=Path, help="Import target/DO settings during --configure only")
    parser.add_argument("--reuse-results", type=Path, help="Reuse selected Data Agent drafts from prior results.json")
    parser.add_argument("--allow-create", action="store_true",
                        help="Permit NEW test Data Agents, inactive Operations authoring artifacts and generated ontology")
    parser.add_argument("--output", type=Path, help="New directory; existing directories are never overwritten")
    parser.add_argument("--strict", action="store_true", help="Return exit 1 if any selected result is not PASS")
    args = parser.parse_args(argv)
    if args.sample_manifest and not args.configure:
        parser.error("--sample-manifest requires --configure")
    if args.reuse_results and (args.configure or args.list or args.allow_create):
        parser.error("--reuse-results cannot be combined with --configure, --list or --allow-create")
    if args.configure and (args.list or args.plan or args.allow_create):
        parser.error("--configure is setup only; do not combine it with --list, --plan or --allow-create")
    available = catalog()
    if args.list:
        console("\n".join(available))
        return 0
    if args.configure:
        try:
            if not args.config:
                raise ValueError("--config is required for --configure")
            selected = select_scenarios(available, args.agents, args.scenarios, args.rerun_failed)
            from validation_setup import configure
            return configure(args.config, selected, args.sample_manifest)
        except (ValueError, OSError, EOFError, KeyboardInterrupt) as error:
            console(f"Configuration stopped: {error}", file=sys.stderr)
            return 2
    directory = (args.output or Path("runs") / ("validation_" + uuid4().hex[:12])).resolve()
    directory.mkdir(parents=True, exist_ok=False)
    report = {"startedUtc": utc_now(), "state": "starting", "results": [], "resources": {}}
    persist(directory, report)
    try:
        selected = select_scenarios(available, args.agents, args.scenarios, args.rerun_failed)
        report["results"] = [{"scenario": name, "selected": name in selected,
                              "status": "PENDING" if name in selected else "SKIP",
                              "summary": "Awaiting execution" if name in selected else "Not selected"}
                             for name in available]
        config = load_config(args.config)
        config["allow_create"] = args.allow_create
        if args.reuse_results:
            from validation_setup import reuse_data_agents
            reuse_data_agents(config, args.reuse_results, selected)
        report.update(config=sanitize(config), state="running" if not args.plan else "plan")
        report["preflight"] = prerequisites(config, selected)
        for name, errors in report["preflight"].items():
            console(f"Preflight {name}: {'; '.join(errors)}")
        persist(directory, report)
        with ExitStack() as stack:
            ready = {name for name in selected - report["preflight"].keys() - MANUAL_SCENARIOS.keys()
                     if not unselected_source_reason(config, name)}
            if args.plan or not ready:
                ctx = None
            else:
                if config["auth"] == "browser":
                    from sample_auth import open_credential
                    ctx_credential = stack.enter_context(open_credential(
                        config["tenant_id"], mode="browser", client_id=config.get("client_id")))
                else:
                    from azure.identity import AzureCliCredential
                    ctx_credential = AzureCliCredential(tenant_id=config["tenant_id"], process_timeout=30)
                    stack.callback(ctx_credential.close)
                    # A failed cached login is reported; never launch another login behind the user's back.
                    from create_sample import PBI_SCOPE
                    ctx_credential.get_token(PBI_SCOPE)
                ctx = ValidationContext(config, ctx_credential, directory)
                stack.callback(ctx.close)
            execute_scenarios(available, selected, ctx, report, directory, plan=args.plan)
        report["state"] = "plan" if args.plan else "completed"
    except (Exception, KeyboardInterrupt) as error:
        report.update(state="interrupted" if isinstance(error, KeyboardInterrupt) else "blocked",
                      error={"type": type(error).__name__, "message": sanitize(str(error))})
        for row in report["results"]:
            if row["selected"] and row["status"] == "PENDING":
                row.update(status="BLOCKED", summary="Run-level prerequisite/interrupt; see run error")
        persist(directory, report)
        console(f"Stopped: {error}", file=sys.stderr)
        console(f"Report: {directory / 'report.md'}")
        return 2
    persist(directory, report)
    counts = Counter(row["status"] for row in report["results"] if row["selected"])
    console(f"Report: {directory / 'report.md'}\nResults: {dict(counts)}")
    # Default means the runner completed, NOT that all scenarios passed.
    return int(args.strict and any(row["selected"] and row["status"] != "PASS" for row in report["results"]))


if __name__ == "__main__":
    sys.exit(main())
