import copy
import json
import unittest
from contextlib import contextmanager
from types import SimpleNamespace
from unittest.mock import patch

import validation_operations as operations
from target_routing import target_fabric_api
from validation_common import HttpFailure

TENANT = "11111111-1111-1111-1111-111111111111"
WORKSPACE = "22222222-2222-2222-2222-222222222222"
ONTOLOGY = "33333333-3333-3333-3333-333333333333"
ITEM = "44444444-4444-4444-4444-444444444444"
RULE = "55555555-5555-5555-5555-555555555555"
CAPACITY = "66666666-6666-6666-6666-666666666666"
PRIVATE_METADATA = "https://tenant.private.analysis.windows.net"
DO_HOST = "do-private.pbidedicated.windows.net"
OA_HOST = "oa-private.pbidedicated.windows.net"


def fixture():
    return {"model": {"entities": [{
        "name": operations.ENTITY, "keyProperties": [operations.KEY],
        "properties": [{"name": operations.KEY, "dataType": "string"},
                       {"name": operations.METRIC, "dataType": "double"}],
    }]}}


class FakeContext:
    def __init__(self, network="public"):
        self.config = {"tenant_id": TENANT, "workspace_id": WORKSPACE, "ontology_id": ONTOLOGY,
                       "target_network": network, "allow_create": True, "ux_token_version": "v2"}
        if network != "public":
            self.config.update(ux_metadata_api=PRIVATE_METADATA, ux_workload_host=DO_HOST,
                               operations_metadata_api=PRIVATE_METADATA, operations_workload_host=OA_HOST)
        self.fabric = SimpleNamespace(base=target_fabric_api(network, WORKSPACE, TENANT))
        self.timeout, self.credential = 30, object()
        self.state, self.saved, self.calls = {}, [], []
        self.source = fixture()
        self.expanded_source = None
        self.source_reads = 0
        self.change_source = False
        self.change_export = None
        self.change_item = None
        self.failure = None
        self.create_result = {"id": ITEM}
        self.token_result = {"TargetUriHost": OA_HOST, "Token": "opaque-in-memory-value",
                             "CapacityObjectId": CAPACITY}
        self.document = None

    def save_evidence(self, label, data):
        self.saved.append((label, copy.deepcopy(data), copy.deepcopy(self.state)))
        return "evidence/" + label

    @contextmanager
    def workload(self, ontology_id=None):
        self.calls.append(("workload", ontology_id))
        yield SimpleNamespace(base="https://" + DO_HOST + "/workloads/DO/DigitalOperationsService/direct")

    def request(self, api, method, url, body=None, params=None):
        self.calls.append(("request", method, url, copy.deepcopy(body), copy.deepcopy(params)))
        if "generatemwctoken" in url:
            if not api.sensitive_response:
                raise AssertionError("Token exchange response must be marked sensitive")
            return self.token_result
        if url.endswith("/definition"):
            if params == {"expand": "true"}:
                return copy.deepcopy(self.source if self.expanded_source is None else self.expanded_source)
            self.source_reads += 1
            result = copy.deepcopy(self.source)
            if self.source_reads > 1 and self.change_source:
                result["model"]["description"] = "concurrent change"
            return result
        if "/operationsAgents/" in url:
            if self.failure == "readback":
                raise HttpFailure(403, "readback denied")
            saved_ids = [entry[2]["operations_agents"][0]["id"] for entry in self.saved
                         if entry[0] == "created"]
            if saved_ids != [ITEM]:
                raise AssertionError("Resource id must be persisted before readback")
            item = {"id": ITEM, "displayName": self.name, "type": "OperationsAgent",
                    "properties": {"state": "Inactive"}}
            if self.change_item:
                self.change_item(item)
            return item
        if "/items/" in url:
            return {"id": ONTOLOGY, "type": "Ontology"}
        return {"capacityId": CAPACITY}

    def mutate(self, api, path, body):
        self.calls.append(("mutate", path, copy.deepcopy(body)))
        if path.endswith("/getDefinition"):
            if self.failure == "definition":
                raise HttpFailure(500, "definition failed")
            exported = operations.envelope(self.document)
            if self.change_export:
                self.change_export(exported)
            return exported
        if not path.endswith("/operationsAgents"):
            raise AssertionError("Unexpected write endpoint")
        if self.failure == "create":
            raise HttpFailure(400, "create rejected")
        if self.failure == "timeout":
            raise TimeoutError("Create outcome is unknown")
        self.name = body["displayName"]
        self.document = operations.decode_definition(body)
        return self.create_result


class FakeMetadataApi:
    def __init__(self, base, scope, credential, timeout, sensitive_response):
        self.base, self.scope = base, scope
        self.credential, self.timeout = credential, timeout
        self.sensitive_response = sensitive_response

    def close(self):
        pass


class OperationsContractTests(unittest.TestCase):
    def test_registered_scenario(self):
        self.assertIs(operations.SCENARIOS["operations.native-import"], operations.native_import)

    def test_required_members_and_no_actions(self):
        definition = operations.build_definition(WORKSPACE, ONTOLOGY, RULE)
        self.assertIs(definition["shouldRun"], False)
        config = definition["configuration"]
        self.assertEqual(config["actions"], {})
        self.assertNotIn("messageDestination", config)
        self.assertEqual(config["dataSources"],
                         {ONTOLOGY: {"id": ONTOLOGY, "type": "Ontology", "workspaceId": WORKSPACE}})
        playbook = definition["playbook"]
        self.assertEqual(len(playbook["OntologyDefinitions"]), 3)
        for value in playbook["OntologyDefinitions"].values():
            self.assertIn("DocumentId", value)
            self.assertIsInstance(value["DocumentId"], str)
            self.assertTrue(value["Description"])
        self.assertEqual(list(playbook["RuleDefinitions"]), [RULE])
        rule = playbook["RuleDefinitions"][RULE]
        self.assertEqual(rule["Id"], RULE)
        self.assertIsNone(rule["ActionBinding"])
        self.assertEqual(rule["RuleCondition"]["Threshold"], 1000)
        self.assertIn("Lakehouse_Readings", json.loads(rule["ClassExpression"]["Expression"])["EntitySelector"]["Query"])
        self.assertEqual(operations.decode_definition(operations.envelope(definition)), definition)

    def test_binding_and_rule_identifiers_are_not_sample_constants(self):
        other_workspace, other_ontology = CAPACITY, ITEM
        document = operations.build_definition(other_workspace, other_ontology, TENANT)
        self.assertEqual(list(document["configuration"]["dataSources"]), [other_ontology])
        self.assertEqual(document["configuration"]["dataSources"][other_ontology]["workspaceId"], other_workspace)
        self.assertEqual(list(document["playbook"]["RuleDefinitions"]), [TENANT])
        with self.assertRaises(ValueError):
            operations.build_definition("not-a-guid", ONTOLOGY, RULE)

    def test_definition_decoder_rejects_missing_duplicate_unknown_and_invalid_parts(self):
        valid = operations.envelope(operations.build_definition(WORKSPACE, ONTOLOGY, RULE))
        variants = [
            {}, {"definition": {"parts": []}},
            {"definition": {"parts": valid["definition"]["parts"] * 2}},
            {"definition": {"parts": [{"path": "unexpected", "payloadType": "InlineBase64", "payload": ""}]}},
            {"definition": {"parts": [{"path": "Configurations.json", "payloadType": "Url", "payload": "x"}]}},
            {"definition": {"parts": [{"path": "Configurations.json", "payloadType": "InlineBase64", "payload": "?"}]}},
        ]
        for exported in variants:
            with self.subTest(exported=exported), self.assertRaises((ValueError, KeyError)):
                operations.decode_definition(exported)

    def test_platform_part_is_ignored_but_duplicate_platform_is_not(self):
        exported = operations.envelope(operations.build_definition(WORKSPACE, ONTOLOGY, RULE))
        exported["definition"]["parts"].append({"path": ".platform"})
        self.assertIsInstance(operations.decode_definition(exported), dict)
        exported["definition"]["parts"].append({"path": ".PLATFORM"})
        with self.assertRaises(ValueError):
            operations.decode_definition(exported)

    def test_preservation_ignores_only_valid_resolver_timestamps_not_source_types_or_bindings(self):
        baseline = fixture()
        baseline["model"]["tables"] = [{"name": "Lakehouse_Readings", "partitions": [{
            "annotations": [
                {"name": "ONT_RESOLVED_At", "value": "2026-10-28T06:53:13.0996037Z"},
                {"name": "ONT_RESOLVED_State", "value": "Resolved"},
                {"name": "ONT_RESOLVED_ItemId", "value": ONTOLOGY},
            ],
        }]}]
        original = copy.deepcopy(baseline)
        changed = copy.deepcopy(baseline)
        annotations = changed["model"]["tables"][0]["partitions"][0]["annotations"]
        annotations[0]["value"] = "2026-10-28T06:52:57.4327360Z"
        self.assertEqual(operations.preservation_snapshot(baseline), operations.preservation_snapshot(changed))
        self.assertEqual(baseline, original)
        for index, value in ((0, "not-a-timestamp"), (1, "Failed"), (2, ITEM)):
            with self.subTest(index=index):
                invalid = copy.deepcopy(changed)
                invalid["model"]["tables"][0]["partitions"][0]["annotations"][index]["value"] = value
                self.assertNotEqual(operations.preservation_snapshot(baseline),
                                    operations.preservation_snapshot(invalid))
        changed["model"]["entities"][0]["properties"][1]["dataType"] = "string"
        self.assertNotEqual(operations.preservation_snapshot(baseline), operations.preservation_snapshot(changed))


class OperationsScenarioTests(unittest.TestCase):
    def test_create_permission_must_be_boolean_true_and_blocks_before_network(self):
        for allowed in (None, False, "true", 1):
            with self.subTest(allowed=allowed):
                ctx = FakeContext()
                ctx.config["allow_create"] = allowed
                result = operations.native_import(ctx)
                self.assertEqual(result["status"], "BLOCKED")
                self.assertEqual(ctx.calls, [])
                self.assertNotIn("operations_agents", ctx.state)

    def test_success_is_import_only_and_preserves_source(self):
        ctx = FakeContext()
        result = operations.native_import(ctx)
        self.assertEqual(result["status"], "PASS")
        self.assertFalse(result["evidence"]["runtimeValidated"])
        self.assertFalse(result["evidence"]["networkEnforcementVerified"])
        self.assertFalse(result["evidence"]["activated"])
        self.assertTrue(all(result["evidence"]["checks"].values()))
        self.assertEqual(ctx.state["operations_agents"][0]["id"], ITEM)
        self.assertEqual(ctx.state["operations_agents"][0]["phase"], "verified-inactive")
        mutations = [call for call in ctx.calls if call[0] == "mutate"]
        self.assertEqual(len(mutations), 2)
        self.assertTrue(mutations[0][1].endswith("/operationsAgents"))
        self.assertTrue(mutations[1][1].endswith(f"/{ITEM}/getDefinition"))
        self.assertIsNone(mutations[1][2])
        self.assertEqual(ctx.source_reads, 2)
        self.assertEqual([call for call in ctx.calls if call[0] == "workload"],
                         [("workload", ONTOLOGY), ("workload", ONTOLOGY)])
        self.assertTrue(all(call[1] == "GET" for call in ctx.calls if call[0] == "request"))

    def test_source_fixture_preflight_blocks_before_any_create(self):
        for change in ("missing", "key", "metric"):
            with self.subTest(change=change):
                ctx = FakeContext()
                entity = ctx.source["model"]["entities"][0]
                if change == "missing":
                    entity["name"] = "DifferentEntity"
                elif change == "key":
                    entity["keyProperties"] = []
                else:
                    entity["properties"][1]["dataType"] = "string"
                self.assertEqual(operations.native_import(ctx)["status"], "BLOCKED")
                self.assertFalse(any(call[0] == "mutate" for call in ctx.calls))

    def test_persisted_tom_omits_projected_metric_but_expanded_type_is_verified(self):
        ctx = FakeContext()
        # Retained Daily response: persisted entity lists ReadingId only, while its
        # backing table also contains the projected TemperatureC double column.
        ctx.source = {"model": {
            "entities": [{
                "name": "Lakehouse_Readings", "backingTable": "Lakehouse_Readings",
                "overriddenMetadataFields": [], "keyProperties": ["ReadingId"],
                "additionalBackingTables": [],
                "properties": [{
                    "name": "ReadingId", "dataType": "string",
                    "backingConfiguration": {"type": "default", "valueColumn": {
                        "table": "Lakehouse_Readings", "column": "ReadingId"}},
                    "overriddenMetadataFields": [], "synonyms": [], "annotations": [],
                }],
                "synonyms": [], "annotations": [], "resourceLinks": [],
            }],
            "tables": [{"name": "Lakehouse_Readings", "columns": [
                {"name": "ReadingId", "dataType": "string", "sourceColumn": "ReadingId",
                 "isKey": True, "isNullable": False},
                {"name": "AssetId", "dataType": "string", "sourceColumn": "AssetId"},
                {"name": "ObservedAt", "dataType": "dateTime", "sourceColumn": "ObservedAt"},
                {"name": "TemperatureC", "dataType": "double", "sourceColumn": "TemperatureC"},
            ]}],
        }}
        ctx.expanded_source = fixture()
        baseline = copy.deepcopy(ctx.source)
        result = operations.native_import(ctx)
        self.assertEqual(result["status"], "PASS")
        self.assertTrue(result["evidence"]["checks"]["sourceUnchanged"])
        self.assertEqual(ctx.source, baseline)
        expanded_reads = [call for call in ctx.calls if call[0] == "request" and call[4] == {"expand": "true"}]
        self.assertEqual(len(expanded_reads), 1)
        self.assertNotIn("?", expanded_reads[0][2])
        self.assertEqual(ctx.source_reads, 2)

    def test_expanded_property_type_must_be_explicit_and_correct(self):
        for field, invalid_type in ((operations.KEY, "int64"), (operations.KEY, None),
                                    (operations.METRIC, "string"), (operations.METRIC, None)):
            with self.subTest(field=field, invalid_type=invalid_type):
                ctx = FakeContext()
                ctx.expanded_source = fixture()
                prop = next(p for p in ctx.expanded_source["model"]["entities"][0]["properties"]
                            if p["name"] == field)
                if invalid_type is None:
                    prop.pop("dataType")
                else:
                    prop["dataType"] = invalid_type
                self.assertEqual(operations.native_import(ctx)["status"], "BLOCKED")
                self.assertFalse(any(call[0] == "mutate" for call in ctx.calls))

    def test_create_errors_are_explicit_no_replay_and_keep_intent(self):
        for failure in ("create", "timeout"):
            with self.subTest(failure=failure):
                ctx = FakeContext()
                ctx.failure = failure
                result = operations.native_import(ctx)
                self.assertEqual(result["status"], "FAIL")
                self.assertEqual(result["evidence"]["error"]["phase"], "create")
                self.assertEqual(len([call for call in ctx.calls if call[0] == "mutate"]), 1)
                self.assertEqual(ctx.state["operations_agents"][0]["phase"], "failed-create")
                self.assertIsNone(ctx.state["operations_agents"][0]["id"])

    def test_missing_create_id_is_not_a_pass_and_does_not_readback(self):
        ctx = FakeContext()
        ctx.create_result = {"operation": "unknown"}
        result = operations.native_import(ctx)
        self.assertEqual(result["status"], "FAIL")
        self.assertIn("no item id", result["evidence"]["error"]["reason"])
        self.assertFalse(any(call[0] == "request" and "/operationsAgents/" in call[2] for call in ctx.calls))

    def test_ids_persist_before_readback_failures_and_resources_remain(self):
        for failure, status in (("readback", "BLOCKED"), ("definition", "FAIL")):
            with self.subTest(failure=failure):
                ctx = FakeContext()
                ctx.failure = failure
                result = operations.native_import(ctx)
                self.assertEqual(result["status"], status)
                self.assertEqual(ctx.state["operations_agents"][0]["id"], ITEM)
                self.assertEqual(result["evidence"]["error"]["phase"], "readback")
                self.assertFalse(any("delete" in str(call).lower() for call in ctx.calls))

    def test_readback_mutations_fail_instead_of_returning_partial_or_pass(self):
        for change in ("running", "action", "destination", "binding", "rule", "required-member", "rule-action"):
            with self.subTest(change=change):
                ctx = FakeContext()

                def corrupt(exported):
                    document = operations.decode_definition(exported)
                    if change == "running":
                        document["shouldRun"] = True
                    elif change == "action":
                        document["configuration"]["actions"]["unexpected"] = {}
                    elif change == "destination":
                        document["configuration"]["messageDestination"] = {"kind": "Recipient"}
                    elif change == "binding":
                        document["configuration"]["dataSources"][ONTOLOGY]["id"] = "00000000-0000-0000-0000-000000000000"
                    elif change == "rule":
                        document["playbook"]["RuleDefinitions"] = {}
                    elif change == "rule-action":
                        next(iter(document["playbook"]["RuleDefinitions"].values()))["ActionBinding"] = {}
                    else:
                        document["playbook"]["OntologyDefinitions"][operations.KEY].pop("DocumentId")
                    exported.update(operations.envelope(document))

                ctx.change_export = corrupt
                result = operations.native_import(ctx)
                self.assertEqual(result["status"], "FAIL")
                self.assertFalse(all(result["evidence"]["checks"].values()))
                self.assertEqual(ctx.state["operations_agents"][0]["id"], ITEM)

    def test_optional_null_action_binding_may_be_omitted_from_export(self):
        ctx = FakeContext()

        def omit_null(exported):
            document = operations.decode_definition(exported)
            for rule in document["playbook"]["RuleDefinitions"].values():
                rule.pop("ActionBinding")
            document["playbook"].pop("Status")
            exported.update(operations.envelope(document))

        ctx.change_export = omit_null
        result = operations.native_import(ctx)
        self.assertEqual(result["status"], "PASS")
        self.assertTrue(result["evidence"]["checks"]["ruleDefinitionsPreserved"])
        self.assertFalse(result["evidence"]["runtimeValidated"])

    def test_active_or_wrong_item_readback_fails_without_attempting_stop(self):
        for change in ("active", "identity"):
            with self.subTest(change=change):
                ctx = FakeContext()
                ctx.change_item = (lambda item: item["properties"].update(state="Active")) if change == "active" \
                    else (lambda item: item.update(id=ONTOLOGY))
                self.assertEqual(operations.native_import(ctx)["status"], "FAIL")
                self.assertEqual(len([call for call in ctx.calls if call[0] == "mutate"]), 2)

    def test_source_change_is_reported_not_overwritten(self):
        ctx = FakeContext()
        ctx.change_source = True
        result = operations.native_import(ctx)
        self.assertEqual(result["status"], "FAIL")
        self.assertFalse(result["evidence"]["checks"]["sourceUnchanged"])
        self.assertNotEqual(result["evidence"]["sourceBeforeSha256"], result["evidence"]["sourceAfterSha256"])
        self.assertEqual(len([call for call in ctx.calls if call[0] == "mutate"]), 2)


class OperationsRoutingTests(unittest.TestCase):
    def test_private_modes_require_operations_pins_before_network(self):
        for network in ("wspl", "tenantpl"):
            for missing in ("operations_metadata_api", "operations_workload_host"):
                with self.subTest(network=network, missing=missing):
                    ctx = FakeContext(network)
                    ctx.config.pop(missing)
                    self.assertEqual(operations.native_import(ctx)["status"], "BLOCKED")
                    self.assertEqual(ctx.calls, [])

    def test_wrong_fabric_route_cannot_fall_back_to_public(self):
        ctx = FakeContext("wspl")
        ctx.fabric.base = target_fabric_api("public", WORKSPACE, TENANT)
        self.assertEqual(operations.native_import(ctx)["status"], "BLOCKED")
        self.assertEqual(ctx.calls, [])

    def test_private_metadata_and_host_reject_public_default_or_untrusted_origins(self):
        for key, value in (
            ("operations_metadata_api", "https://wabi-daily-us-east2-redirect.analysis.windows.net"),
            ("operations_metadata_api", "https://evil.example"),
            ("operations_metadata_api", PRIVATE_METADATA + "/path"),
            ("operations_workload_host", "https://" + OA_HOST),
            ("ux_metadata_api", None),
        ):
            with self.subTest(key=key, value=value):
                ctx = FakeContext("wspl")
                ctx.config[key] = value
                self.assertEqual(operations.native_import(ctx)["status"], "BLOCKED")
                self.assertEqual(ctx.calls, [])

    def test_oa_route_is_independent_of_do_and_tokens_never_enter_saved_evidence(self):
        for network in ("wspl", "tenantpl"):
            with self.subTest(network=network), patch.object(operations, "Api", FakeMetadataApi):
                ctx = FakeContext(network)
                result = operations.native_import(ctx)
                self.assertEqual(result["status"], "PASS")
                self.assertEqual(result["evidence"]["operationsRoute"]["serviceReturnedHost"], OA_HOST)
                token_calls = [call for call in ctx.calls if call[0] == "request" and "generatemwctoken" in call[2]]
                self.assertEqual(len(token_calls), 1)
                self.assertEqual(token_calls[0][2], PRIVATE_METADATA + "/metadata/v201606/generatemwctokenv2")
                self.assertEqual(token_calls[0][3],
                                 {"workspaceObjectId": WORKSPACE, "workloadType": "OA",
                                  "artifacts": [{"artifactType": "OperationsAgent", "artifactObjectId": ITEM}]})
                self.assertNotIn("opaque-in-memory-value", json.dumps(ctx.saved))
                self.assertFalse(result["evidence"]["operationsRoute"]["tokenForwarded"])

    def test_wrong_service_host_or_capacity_blocks_without_forwarding_or_retry(self):
        for field, value in (("TargetUriHost", DO_HOST), ("CapacityObjectId", TENANT)):
            with self.subTest(field=field), patch.object(operations, "Api", FakeMetadataApi):
                ctx = FakeContext("wspl")
                ctx.token_result[field] = value
                result = operations.native_import(ctx)
                self.assertEqual(result["status"], "BLOCKED")
                self.assertEqual(result["evidence"]["error"]["phase"], "operations-route")
                self.assertEqual(ctx.state["operations_agents"][0]["id"], ITEM)
                self.assertFalse(any(call[0] == "request" and "/workloads/OA/" in call[2] for call in ctx.calls))
                self.assertEqual(len([call for call in ctx.calls if call[0] == "request" and "generatemwctoken" in call[2]]), 1)

    def test_invalid_token_version_blocks_before_network(self):
        ctx = FakeContext()
        ctx.config["ux_token_version"] = "unknown"
        self.assertEqual(operations.native_import(ctx)["status"], "BLOCKED")
        self.assertEqual(ctx.calls, [])

    def test_v1_uses_dynamic_capacity_and_item_ids(self):
        with patch.object(operations, "Api", FakeMetadataApi):
            ctx = FakeContext("wspl")
            ctx.config["ux_token_version"] = "v1"
            self.assertEqual(operations.native_import(ctx)["status"], "PASS")
            call = next(call for call in ctx.calls if call[0] == "request" and "generatemwctoken" in call[2])
            self.assertTrue(call[2].endswith("/generatemwctoken"))
            self.assertEqual(call[3], {"workspaceObjectId": WORKSPACE, "workloadType": "OA",
                                       "capacityObjectId": CAPACITY, "artifactObjectIds": [ITEM]})


if __name__ == "__main__":
    unittest.main()
