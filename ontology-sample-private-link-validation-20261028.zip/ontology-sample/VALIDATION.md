# Standalone agent validation on Daily / Private Link

Use [Start-Validation.ps1](Start-Validation.ps1) **after provisioning**, including when
[Start-Sample.ps1](Start-Sample.ps1) stopped at a resolver/readback check but retained
an ontology. This runner does not call the provisioning workflow or require its
final verification to pass. It never needs a coding assistant, Azure DevOps,
Kusto investigation access, or a local backend.

**This is a functional test runner, not automatic Private Link certification.**
It records missing network/identity acceptance checks explicitly. An answer or
HTTP 200 is not proof of actual source reads or enforced private connectivity.

## 1. Prepare once

Use the existing sample Python environment (Python 3.10+ and
[requirements.txt](requirements.txt)); the launcher finds `.venv\Scripts\python.exe`
next to it. Otherwise supply `-PythonExecutable`. No automatic package download,
system installation, or login fallback occurs. If packages are missing, install
them from your approved source before entering the restricted network.
`-InstallDependencies` explicitly permits pip to install the existing requirements.

Copy [validation.example.json](validation.example.json) to `validation.local.json`.
Fill in the tenant, target workspace, and **existing ontology** IDs. These are not
the source workspace IDs. Configuration contains identifiers/routes, never tokens.

| Setting | Meaning |
|---|---|
| `target_network` | Explicit `wspl`, `tenantpl`, or `public` (normal Daily only) |
| `ux_metadata_api` | HTTPS metadata **origin** from the working DO UX's MWC-token request |
| `ux_workload_host` | Exact DO `TargetUriHost` from that request, hostname only |
| `auth` | `cli` uses the existing Azure CLI identity/cache only; `browser` uses an explicitly approved client |
| `client_id` | Required approved public-client application ID when using browser authentication |
| `timeout` | HTTP/operation/conversation budget in seconds, default 240 |
| `scenario_timeout` | Overall scenario budget, default 1800; must be at least `timeout` |
| `poll_seconds` | Poll interval, default 5 |
| `generation_lakehouse_id` | Existing Lakehouse containing Plants/Assets/Readings for generation |
| `generation_source_workspace_id` | Workspace containing that Lakehouse; this generation adapter currently requires it to equal the target workspace |
| `data_agent_metadata_api`, `data_agent_workload_host` | ML Data Agent metadata origin and expected workload host; required for private-mode Data Agent scenarios |
| `data_agent_id` | Optional existing isolated ontology-backed draft to verify and query without creating a replacement |
| `data_agent_ids` | Optional mapping of full scenario IDs to existing draft GUIDs; overrides `data_agent_id` for that scenario |
| `operations_metadata_api`, `operations_workload_host` | Operations Agent metadata origin and expected workload host; required for private-mode Operations scenarios |

Use the **appropriate service's** routing values; do not copy DO's host into ML or
Operations settings unless it is actually the observed host for that service.
Never paste a token, authorization header, or full captured request into this file.
Missing optional agent routing blocks only its scenarios, not other agents.

Private mode refuses the normal public metadata default and checks returned MWC
hosts before using workload credentials. Requests do not follow redirects or switch
to a public route. This protects routing intent; it does not prove DNS/egress policy.
The runner does not create private endpoints or change WSPL, BPA, RBAC, or Copilot settings.

For CLI authentication, sign in **before** running, using your normal approved
tenant/application. An expired or denied login is reported; the runner never opens
another login or changes client identity automatically.

The sample fixture must already be populated: 3 Plants, 12 Assets, 120 Readings per
source group. Semantic Model refresh remains a separate setup operation. A failed
data check is not automatically attributed to Private Link or the resolver.

Generation currently covers a **same-workspace Lakehouse** fixture. Its independent
source-result check also needs **ODBC Driver 18 for SQL Server** and TDS access to the
Lakehouse SQL endpoint. Missing driver/query proof yields PARTIAL, not a fake pass
or a reason to stop the other scenarios. Other generation source types and
cross-workspace generation are not implemented by this adapter.

## 2. Choose tests

```powershell
# Offline catalog: exact selectable scenario IDs.
.\Start-Validation.ps1 -ListScenarios

# Validate configuration and write a plan/report, without authentication or live calls.
.\Start-Validation.ps1 -Config .\validation.local.json -Agents ontology,mcp -PlanOnly

# Default: definition read only. Resolver warnings are recorded, not prerequisites.
.\Start-Validation.ps1 -Config .\validation.local.json

# Run two independent queries. Failure of the first does not stop the second.
.\Start-Validation.ps1 -Config .\validation.local.json `
  -Scenarios ontology.lakehouse,mcp.lakehouse `
  -OutputDirectory .\runs\pl-query-01

# All ontology and MCP source/combo probes, without provisioning or agent activation.
.\Start-Validation.ps1 -Config .\validation.local.json -Agents ontology,mcp

# Explicitly authorize NEW test artifacts. Existing source data/ontology are preserved.
.\Start-Validation.ps1 -Config .\validation.local.json `
  -Agents generation,data-agent,operations -AllowCreate
```

Select one of `-Agents`, `-Scenarios`, or `-RerunFailed`, not multiple selectors.
`-Scenarios` also accepts quoted wildcard patterns, for example `'mcp.*'`.
No selector defaults to **ontology.definition**, not a long all-agent run.

| Family | Coverage / limits |
|---|---|
| `ontology` | Definition plus six source and four combination queries. Explicit Plan/read-only context. No source mutation. Fixture-correct answers without independent execution evidence remain PARTIAL |
| `mcp` | Initialize/list-tools/ask through the selected Fabric item endpoint. Empty HTTP 200, JSON-RPC errors, tool errors and incorrect structured answers are failures |
| `data-agent` | Ontology-backed draft and query scenarios, not the older direct-SM helper. Actual execution datasets are distinguished from final prose |
| `generation` | New disposable ontology from the selected sample Lakehouse, using the explicit Plan/Act client contract. Never applies to the original ontology |
| `operations` | Corrected native-playbook creation and stopped-configuration readback only. No monitoring, external actions, notification destinations or activation |

Creation is disabled unless `-AllowCreate` is present **for that invocation**.
Putting `allow_create` in JSON does not grant authorization. Missing creation
permission is a BLOCKED result, and unrelated read-only checks still run.

An existing Data Agent draft is checked for its ontology association and selected
entities before reuse; an incompatible draft is not silently rewritten. For reruns,
use IDs from the earlier run's retained resources, for example:

```json
{
  "data_agent_ids": {
    "data-agent.lakehouse": "REPLACE_WITH_RETAINED_DRAFT_GUID"
  }
}
```

Add that property to the complete local configuration; the snippet is not a full
configuration. Operations import requires `Lakehouse_Readings` with `ReadingId`
and `TemperatureC` in the existing ontology.

## 3. Copy the report

Every run prints its output path. The directory contains:

- **`report.md`**: copyable Markdown summary with all selected/unselected scenarios,
  outcomes, limits, retained resources and untested Private Link acceptance checks.
- **`results.json`**: structured results, configuration and error classifications.
- **`resources.json`**: retained artifact/conversation/operation IDs as they are recorded.
- Per-scenario `*.result.json`, `*.http.json` and supporting evidence.

Reports are checkpointed before/after each scenario. Ordinary assertion errors,
resolver warnings, empty responses, failed agent calls and timeouts cannot abort
unrelated scenarios. Ctrl+C stops intentionally and preserves completed results;
forced process/machine termination leaves the last checkpoint. A missing shared
prerequisite such as authentication or invalid target configuration blocks execution
and writes a run-level explanation rather than pretending tests ran.

HTTP requests and polling have finite budgets. Writes are not automatically
replayed, including after ambiguous timeouts. Source data and created test items
are never automatically deleted. Inspect retained operations/items before retrying.

Statuses:

- **PASS**: the specific stated assertion passed, not overall Private Link sign-off.
- **PARTIAL**: useful evidence, but an execution/source/acceptance requirement is unverified.
- **FAIL**: an observed assertion or service/response failure.
- **BLOCKED**: missing prerequisite or authorization; no success claim.
- **TIMEOUT / ERROR**: bounded timeout or unexpected test error, captured for diagnosis.
- **SKIP**: not selected or plan-only; never counted as a pass.

Default exit **0** means the runner completed and wrote the report, **not all tests
passed**. `-Strict` returns 1 for any selected non-PASS result, but still finishes all
selected scenarios. Run-level setup failures return 2. Unknown CLI options are
rejected before execution.

```powershell
# Retry only prior partial/failed/blocked/error/timeout/unfinished cases.
# New output directory required. No prior evidence is overwritten.
.\Start-Validation.ps1 -Config .\validation.local.json `
  -RerunFailed .\runs\pl-query-01\results.json `
  -OutputDirectory .\runs\pl-query-02

# Copy the complete report on Windows.
Get-Content -Raw .\runs\pl-query-02\report.md | Set-Clipboard
```

Rerunning creation scenarios with `-AllowCreate` can create another test artifact;
the runner does not infer that a timed-out create failed or resume an apply blindly.
The single-source aliases are `lakehouse`, `kql`, `warehouse`, `sql`, `mirror`,
`semantic`; combination aliases are listed by `-ListScenarios`.

Evidence redacts tokens/authorization and omits token-exchange bodies. It can still
contain source data, generated queries and tenant/workspace IDs: review it before
sharing. Local config and run outputs must not be committed.

## What remains outside this package's sign-off

The report explicitly leaves WSPL/BPA topology, denied-principal tests, source
revocation/recovery, sentinel/caching checks, source variants, graph/sharing and
apply-race cancellation unverified. These require prepared fixtures and authorized
policy changes; the runner does not silently alter them.

The [normal-Daily investigation](../../docs/prds/Ontology-FL2/Private-Link-Validation-Results-2026-10-28.md)
records known Data Agent support/mapping gaps and MCP empty responses. The portable
runner reports these as results to review, not reasons to abandon the remaining tests.
