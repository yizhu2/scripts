"""Ontology-backed, unpublished Data Agent scenarios for the standalone validator.

Private targets require data_agent_metadata_api and data_agent_workload_host.
Optional data_agent_ids maps scenario names to existing isolated drafts; the scalar
data_agent_id is also supported. Existing drafts are never edited. Creation requires
allow_create. All HTTP (including finite SSE reads) goes through ValidationContext.
"""

import base64
import json
import re
from contextlib import closing, contextmanager
from functools import partial
from types import SimpleNamespace
from uuid import UUID, uuid4

from create_sample import Api, PBI_SCOPE
from ux_authoring import routing, workload_host
from validation_common import ScenarioBlocked, sanitize


GROUPS = {
    "lakehouse": "Lakehouse", "kql": "EventhouseKQL", "warehouse": "Warehouse",
    "sql": "SQLDatabase", "mirror": "MirroredDatabase", "semantic": "SemanticModel",
}
CASES = {key: (value, value) for key, value in GROUPS.items()}
CASES.update({
    "sm-lakehouse": ("SemanticModel", "Lakehouse"),
    "sm-kql": ("SemanticModel", "EventhouseKQL"),
    "lakehouse-kql": ("Lakehouse", "EventhouseKQL"),
    "lakehouse-warehouse": ("Lakehouse", "Warehouse"),
})
SCHEMA = "https://developer.microsoft.com/json-schemas/fabric/item/dataAgent/definition/"
EXECUTION_TOOLS = {"askPBI.tool.execute", "analyze.database.execute"}


def ml_routing(config):
    if config.get("ux_token_version", "v2") != "v2":
        raise ScenarioBlocked("Data Agent requires ML MWC v2; no v1 fallback")
    network = config["target_network"]
    metadata = config.get("data_agent_metadata_api")
    host = config.get("data_agent_workload_host")
    if network != "public" and (not metadata or not host):
        raise ScenarioBlocked(
            "Private Data Agent validation requires explicit data_agent_metadata_api "
            "and data_agent_workload_host from the working ML UX route")
    return routing(network, metadata or config.get("ux_metadata_api"),
                   host or config.get("ux_workload_host"))


@contextmanager
def ml_context(ctx, agent_id, capacity_id):
    origin, expected_host = ml_routing(ctx.config)
    workspace = str(UUID(ctx.config["workspace_id"]))
    agent_id, capacity_id = str(UUID(agent_id)), str(UUID(capacity_id))
    with closing(Api(origin, PBI_SCOPE, ctx.credential, ctx.timeout,
                     sensitive_response=True)) as metadata:
        result = ctx.request(metadata, "POST", origin + "/metadata/v201606/generatemwctokenv2", {
            "workspaceObjectId": workspace, "workloadType": "ML",
            "artifacts": [{"artifactType": "DataAgent", "artifactObjectId": agent_id}],
        })
    host = workload_host(result["TargetUriHost"])
    if expected_host and host != expected_host:
        raise ScenarioBlocked("ML routing host mismatch; no workload call or public fallback attempted")
    token = result.get("Token")
    if not isinstance(token, str) or not token:
        raise ScenarioBlocked("ML MWC response did not contain a workload token")
    credential = SimpleNamespace(get_token=lambda *_args, **_kwargs: SimpleNamespace(token=token))
    base = f"https://{host}/webapi/capacities/{capacity_id}/workloads/ML"
    with closing(Api(base, PBI_SCOPE, credential, ctx.timeout, auth_scheme="MwcToken")) as api:
        api.session.headers.update({
            "Accept": "application/json", "ActivityId": str(uuid4()),
            "x-ms-workload-resource-moniker": str(uuid4()),
            "x-ms-ai-assistant-scenario": "aiskill", "x-ms-ai-aiskill-stage": "sandbox",
            "X-Taxonomy-TrafficType": "Production", "x-llm-service-tier": "default",
        })
        yield api


def decode_definition(export):
    documents = {}
    for part in export.get("definition", {}).get("parts", []):
        if part.get("payloadType") != "InlineBase64":
            raise ScenarioBlocked("Draft export contains an unsupported payload type")
        documents[part["path"]] = json.loads(base64.b64decode(part["payload"], validate=True))
    return documents


def verify_draft(documents, workspace, ontology, selected):
    if any("/published/" in key.lower() or "/datasources/" in key.lower()
           or key.lower().endswith("/datasource.json")
           for key in documents):
        raise ScenarioBlocked("Expected an unpublished ontology-only draft; direct sources do not count")
    contexts = [v for k, v in documents.items() if k.endswith("/ontology.json")]
    if (len(contexts) != 1
            or contexts[0].get("artifactId", "").lower() != ontology.lower()
            or contexts[0].get("workspaceId", "").lower() != workspace.lower()):
        raise ScenarioBlocked("Existing draft does not exclusively reference the configured ontology/workspace")
    actual = {e["id"] for e in contexts[0].get("elements", []) if e.get("is_selected") is True}
    return actual == set(selected)


def fixture_bindings(definition, selected, evidence):
    model = definition.get("model", {})
    entities = {e["name"] for e in model.get("entities", [])}
    if not set(selected) <= entities:
        raise ScenarioBlocked("Ontology is missing selected fixture entities: " +
                              ", ".join(sorted(set(selected) - entities)))
    tables = {t["name"]: t for t in model.get("tables", [])}
    identities = {}
    for name in selected:
        found = set()
        for partition in tables.get(name, {}).get("partitions", []):
            annotations = {a["name"]: a.get("value") for a in partition.get("annotations", [])}
            state = annotations.get("ONT_RESOLVED_State")
            if state and state != "Resolved":
                evidence["warnings"].append(f"{name}: resolver state {state}; still attempting independent query")
            item = annotations.get("ONT_RESOLVED_ItemId") or annotations.get("ONT_ItemId")
            workspace = annotations.get("ONT_RESOLVED_WorkspaceId") or annotations.get("ONT_WorkspaceId")
            if item and workspace:
                found.add((str(UUID(item)), str(UUID(workspace))))
        if len(found) == 1:
            identities[name] = next(iter(found))
        else:
            evidence["warnings"].append(f"{name}: source identity missing/ambiguous; full PASS cannot be proven")
    return entities, identities


def definition_parts(entities, selected, workspace, ontology, display_name):
    if not display_name or any(c in display_name for c in "/\\") or display_name in (".", ".."):
        raise ScenarioBlocked("Ontology display name is not a safe definition path component")
    documents = {
        "Files/Config/data_agent.json": {"$schema": SCHEMA + "dataAgent/2.1.0/schema.json"},
        "Files/Config/draft/stage_config.json": {
            "$schema": SCHEMA + "stageConfiguration/1.0.0/schema.json",
            "aiInstructions": "Use only selected ontology entities. Execute read-only queries and show actual "
                              "datasets; never infer fixture answers. Do not modify data, publish, refresh, "
                              "activate monitoring or invoke external actions.",
        },
        f"Files/Config/draft/ontologies/{display_name}/ontology.json": {
            "$schema": SCHEMA + "ontology/1.0.0/schema.json",
            "artifactId": ontology, "workspaceId": workspace, "displayName": display_name,
            "elements": [{"id": name, "display_name": name, "type": "ontology.entity",
                          "is_selected": name in selected, "children": []} for name in sorted(entities)],
        },
    }
    return [{"path": path, "payloadType": "InlineBase64",
             "payload": base64.b64encode(json.dumps(value).encode()).decode()}
            for path, value in documents.items()]


def get_draft(ctx, case, selected, entities, evidence):
    config = ctx.config
    workspace, ontology = config["workspace_id"], config["ontology_id"]
    root = f"{ctx.fabric.base}/workspaces/{workspace}/dataAgents"
    name = "data-agent." + case
    owned = ctx.state.setdefault("data_agents", {})
    agent = owned.get(name) or (config.get("data_agent_ids") or {}).get(name) or config.get("data_agent_id")
    if agent:
        agent = str(UUID(agent))
        documents = decode_definition(ctx.mutate(ctx.fabric, root + f"/{agent}/getDefinition", None))
        if verify_draft(documents, workspace, ontology, selected):
            evidence.update(agentId=agent, definitionVerified=True, created=False)
            return agent
        if not config.get("allow_create"):
            raise ScenarioBlocked("Existing draft selection differs; provide an isolated draft or allow_create")
        evidence["warnings"].append("Existing draft selection differs; preserving it and creating an isolated draft")
    elif not config.get("allow_create"):
        raise ScenarioBlocked("No ontology-backed draft configured; creation requires allow_create")
    item = ctx.request(ctx.fabric, "GET", f"{ctx.fabric.base}/workspaces/{workspace}/items/{ontology}")
    parts = definition_parts(entities, selected, workspace, ontology, item["displayName"])
    created = ctx.mutate(ctx.fabric, root, {
        "displayName": f"OntologyValidation_{case}_{uuid4().hex[:12]}",
        "description": "Unpublished isolated ontology validation. Read-only questions; no external actions.",
        "definition": {"parts": parts},
    })
    agent = str(UUID(created["id"]))
    owned[name] = agent
    evidence.update(agentId=agent, created=True)
    ctx.save_evidence("data-agent-resource", {"scenario": name, "agentId": agent, "published": False})
    documents = decode_definition(ctx.mutate(ctx.fabric, root + f"/{agent}/getDefinition", None))
    if not verify_draft(documents, workspace, ontology, selected):
        raise ScenarioBlocked("New draft selection readback mismatch; retained without editing/recreating")
    evidence["definitionVerified"] = True
    return agent


def terminal_response(response):
    """Accept JSON Responses output or terminal SSE; never infer success from HTTP 200."""
    text = response.text
    if not text.strip():
        raise ValueError("Empty Responses body is not an execution result")
    if text.lstrip().startswith("{"):
        terminal = json.loads(text)
    else:
        terminal = None
        for frame in re.split(r"\r?\n\r?\n", text):
            data = "\n".join(line[5:].lstrip() for line in frame.splitlines() if line.startswith("data:"))
            if not data or data == "[DONE]":
                continue
            event = json.loads(data)
            if event.get("type") in ("response.completed", "response.failed", "response.incomplete"):
                terminal = event.get("response")
        if terminal is None:
            raise ValueError("SSE ended without a terminal response; no completed query proven")
    return {**{k: terminal.get(k) for k in ("id", "status", "error")},
            "output": [o for o in terminal.get("output", []) if o.get("type") != "reasoning"]}


def _json(value):
    return json.loads(value) if isinstance(value, str) else value


def _key(value):
    return re.sub(r"[^a-z0-9]", "", value.lower())


def _rows(text):
    header = None
    for line in text.splitlines():
        if not line.strip().startswith("|"):
            header = None
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if all(re.fullmatch(r"[: -]+", c or "-") for c in cells):
            continue
        if header is None:
            header = [_key(c) for c in cells]
        elif len(cells) == len(header):
            yield dict(zip(header, cells))


def _value(row, *names):
    return next((row[_key(n)] for n in names if _key(n) in row), "")


def _expected(rows, reading_source, context_source):
    readings = [r for source, r in rows if source == reading_source]
    context = [r for source, r in rows if source == context_source]
    count = any(
        _value(r, "ReadingCount", "A012ReadingCount", "ReadingsForA012") in ("10", "10.0")
        and ("a012readingcount" in r or "readingsfora012" in r or _value(r, "AssetId") == "A012"
             or "a012" in _value(r, "Metric", "ResultType").lower())
        for r in readings)
    maximum = any(
        _value(r, "TemperatureC", "MaxTemperatureC") == "32.9"
        and _value(r, "AssetId") == "A012" and _value(r, "ReadingId") == "R0120"
        and _value(r, "ObservedAtUtc", "ObservedAt", "Timestamp").removesuffix("Z")
        .removesuffix("+00:00") == "2026-01-01T00:45:00"
        for r in readings)
    asset = any(_value(r, "AssetId") == "A012" and _value(r, "PlantId") == "P03" for r in context)
    plant = any(_value(r, "PlantId") == "P03" and _value(r, "PlantName", "Name") == "East Plant"
                and _value(r, "City") == "Boston" for r in context)
    return count and maximum and asset and plant


def assess(terminal, identities, selected, evidence):
    output = terminal["output"]
    calls = {o["call_id"]: o for o in output if o.get("type") == "function_call"}
    results = {o["call_id"]: o for o in output if o.get("type") == "function_call_output"}
    files, rows, attached = {}, [], set()
    evidence.update(executions=[], resultTables=[], ontologyRuntime=[])
    for call_id, call in calls.items():
        result = results.get(call_id, {})
        text = result.get("output", "")
        if call["name"].startswith("ontology."):
            evidence["ontologyRuntime"].append({"tool": call["name"], "output": text})
            if call["name"] == "ontology.context.datasources_attached":
                attached.update(x["id"].lower() for x in _json(text).get("attached", []))
        if call["name"] not in EXECUTION_TOOLS:
            continue
        arguments = _json(call.get("arguments", "{}"))
        diagnostics = _json(result.get("metadata", {}).get("diagnostic_details", "{}"))
        failed = result.get("status") != "completed" or any(
            query.get("is_error") is True for query in diagnostics.get("queries_ran", []))
        match = re.search(r"file ['\"]([^'\"]+)['\"].*?dataset contains (\d+) rows", text, re.I | re.S)
        filename = match[1] if match else arguments.get("result_file_name")
        if filename:
            files.pop(filename, None)
        source = (str(arguments.get("datasource_artifact_id", "")).lower(),
                  str(arguments.get("datasource_workspace_id", "")).lower())
        evidence["executions"].append({"tool": call["name"], "arguments": arguments, "output": text,
                                       "diagnostics": diagnostics, "failed": failed})
        if match and not failed and arguments.get("code") and source in set(identities.values()):
            files[match[1]] = source
        else:
            evidence["warnings"].append(f"{call['name']} did not prove a successful expected-source dataset")
    for call_id, call in calls.items():
        if call["name"] != "generate_files_data_insights.execute":
            continue
        result = results.get(call_id, {})
        if result.get("status") != "completed":
            continue
        for section in re.split(r"(?m)^File:\s*", result.get("output", ""))[1:]:
            filename, _, table = section.partition("\n")
            if filename.strip() in files:
                table = table.split("## Instructions")[0]
                evidence["resultTables"].append({"file": filename.strip(), "table": table})
                rows.extend((files[filename.strip()], row) for row in _rows(table))
    proven = (len(identities) == len(selected)
              and {item for item, _ in identities.values()} <= attached
              and _expected(rows, identities.get(selected[2]), identities.get(selected[0])))
    if terminal.get("status") != "completed":
        return "FAIL", "Responses did not complete successfully; retain tool failures and correlation IDs"
    if proven:
        return "PASS", "Ontology-backed execution datasets verify A012=10 and global 32.9°C with asset/plant/time"
    if files:
        return "PARTIAL", "Some expected-source data executed, but required readings/joined result proof is incomplete"
    return "BLOCKED", "No successful expected-source execution dataset; final answer/code alone is not a pass"


def run_scenario(ctx, case):
    group, readings = CASES[case]
    selected = [group + "_Assets", group + "_Plants", readings + "_Readings"]
    evidence = {"scenario": "data-agent." + case, "selectedEntities": selected,
                "warnings": [], "published": False, "independentBackendTelemetryVerified": False}
    try:
        ml_routing(ctx.config)  # Fail private routing closed before any resource creation.
        workspace, ontology = str(UUID(ctx.config["workspace_id"])), str(UUID(ctx.config["ontology_id"]))
        with ctx.workload() as api:
            definition = ctx.request(api, "GET",
                                     f"{api.base}/v4/workspaces/{workspace}/ontologies/{ontology}/definition",
                                     params={"expand": "true"})
        entities, identities = fixture_bindings(definition, selected, evidence)
        evidence["sourceIdentities"] = identities
        agent = get_draft(ctx, case, selected, entities, evidence)
        metadata = ctx.request(ctx.fabric, "GET", f"{ctx.fabric.base}/workspaces/{workspace}")
        with ml_context(ctx, agent, metadata["capacityId"]) as api:
            context_url = (api.base + f"/DataAgent/Automatic/v1/workspaces/{workspace}/dataagents/{agent}"
                           f"/staging/ontologies/{ontology}/ontologydatasources")
            try:
                evidence["derivedSources"] = ctx.request(api, "GET", context_url,
                                                         params={"responseSource": "live"})
            except Exception as error:
                if getattr(error, "status", None) in (401, 403):
                    raise
                evidence["warnings"].append("Derived-source discovery failed; independent runtime still attempted: "
                                            + sanitize(str(error)))
            response = ctx.exchange(
                api, "POST", api.base + f"/AISkill/Automatic/v1/workspaces/{workspace}/artifacts/{agent}/responses",
                {"model": "gpt-5.1", "input": (
                    f"Use only {', '.join(selected)} in the attached ontology, not duplicate source groups. "
                    "Execute read-only queries: count readings for AssetId A012; separately find the global "
                    "maximum Celsius temperature across ALL assets and its asset/plant/location/reading/time. "
                    "Return actual dataset rows using columns ReadingCount, TemperatureC, AssetId, PlantId, "
                    "PlantName, City, ReadingId, ObservedAtUtc. Show execution evidence and inspect result files. "
                    "Do not merely generate code, guess, modify sources, refresh or invoke external actions. "
                    "If tools or bindings are unavailable, report the exact failure.")},
                params={"api-version": "2024-05-01-preview", "client": "sdk"})
        terminal = terminal_response(response)
        evidence["response"] = terminal
        evidence["correlations"] = {k: v for k, v in response.headers.items()
                                    if k.lower() in ("requestid", "x-ms-request-id", "x-ms-root-activity-id")}
        status, summary = assess(terminal, identities, selected, evidence)
        if status == "BLOCKED" and (group in ("Warehouse", "SQLDatabase", "MirroredDatabase")
                                    or readings == "Warehouse"):
            evidence["warnings"].append(
                "Known capability limit: Gen4 ontology-to-DataAgent mapping omits explicit Warehouse/SQLDatabase/"
                "MirroredDatabase kinds. Do not relabel or bypass source-kind validation.")
        if status != "PASS" and readings == "EventhouseKQL":
            evidence["warnings"].append(
                "Known KQL mapping risk: M-partition physical table names may differ from TOM entity aliases. "
                "Discovery success alone does not establish executable tools.")
    except Exception as error:
        status = "BLOCKED" if isinstance(error, ScenarioBlocked) or getattr(error, "status", None) in (401, 403) else "FAIL"
        summary = sanitize(str(error))
        evidence["error"] = {"type": type(error).__name__, "message": summary}
    result = {"status": status, "summary": summary, "evidence": sanitize(evidence)}
    ctx.save_evidence("data-agent-result", result)
    return result


SCENARIOS = {"data-agent." + case: partial(run_scenario, case=case) for case in CASES}
