"""Offline tests: no Azure credential acquisition, network calls or live writes."""

import base64
import copy
import json
import unittest
from contextlib import nullcontext
from types import SimpleNamespace
from unittest.mock import Mock

import requests

import validation_data_agent as adapter
from validation_common import HttpFailure, ScenarioBlocked


WORKSPACE = "10000000-0000-0000-0000-000000000001"
ONTOLOGY = "10000000-0000-0000-0000-000000000002"
AGENT = "10000000-0000-0000-0000-000000000003"
CAPACITY = "10000000-0000-0000-0000-000000000004"
LAKEHOUSE = "20000000-0000-0000-0000-000000000001"
SEMANTIC = "20000000-0000-0000-0000-000000000002"
KQL = "20000000-0000-0000-0000-000000000003"
HOST = "test-daily.pbidedicated.windows.net"
PRIVATE_METADATA = "https://private-route.analysis.windows.net"
SOURCE_IDS = {"Lakehouse": LAKEHOUSE, "SemanticModel": SEMANTIC, "EventhouseKQL": KQL,
              "Warehouse": "20000000-0000-0000-0000-000000000004",
              "SQLDatabase": "20000000-0000-0000-0000-000000000005",
              "MirroredDatabase": "20000000-0000-0000-0000-000000000006"}
FULL_TABLE = """
File: result.json
Total rows: 1
| A012ReadingCount | TemperatureC | AssetId | PlantId | PlantName | City | ReadingId | ObservedAt |
|:---|:---|:---|:---|:---|:---|:---|:---|
| 10 | 32.9 | A012 | P03 | East Plant | Boston | R0120 | 2026-01-01T00:45:00Z |
"""


def pair(name, arguments, result, call_id, diagnostics=None, status="completed"):
    return [
        {"type": "function_call", "name": name, "call_id": call_id,
         "arguments": json.dumps(arguments), "status": "completed"},
        {"type": "function_call_output", "call_id": call_id, "status": status, "output": result,
         "metadata": {"diagnostic_details": json.dumps(diagnostics or {})}},
    ]


def execution(source, filename="result.json", call_id="execute", workspace=WORKSPACE, failed=False):
    return pair("askPBI.tool.execute" if source == SEMANTIC else "analyze.database.execute",
                {"datasource_artifact_id": source, "datasource_workspace_id": workspace,
                 "code": "SELECT * FROM Readings", "result_file_name": filename},
                f"The resulting dataset can be found in the file '{filename}'. The dataset contains 1 rows.",
                call_id, {"queries_ran": [{"is_error": failed}]})


def terminal(source=LAKEHOUSE, table=FULL_TABLE):
    output = pair("ontology.context.datasources_attached", {}, json.dumps({
        "attached": [{"id": source, "type": "LakehouseTables"}]}), "context")
    output += execution(source)
    output += pair("generate_files_data_insights.execute", {"file_names": ["result.json"]}, table, "insight")
    return {"id": "response-test", "status": "completed", "output": output}


def response(value, sse=True):
    result = requests.Response()
    result.status_code = 200
    result.headers["x-ms-root-activity-id"] = "test-root-activity"
    result.encoding = "utf-8"
    text = ("event: response.completed\ndata: " +
            json.dumps({"type": "response.completed", "response": value}) + "\n\n") if sse else json.dumps(value)
    result._content = text.encode()
    return result


def fixture():
    names = [f"{group}_{entity}" for group in SOURCE_IDS for entity in ("Assets", "Plants", "Readings")]
    return {"model": {
        "entities": [{"name": name} for name in names],
        "tables": [{"name": name, "partitions": [{"annotations": [
            {"name": "ONT_RESOLVED_State", "value": "Resolved"},
            {"name": "ONT_RESOLVED_ItemId", "value": SOURCE_IDS[name.rsplit("_", 1)[0]]},
            {"name": "ONT_RESOLVED_WorkspaceId", "value": WORKSPACE},
        ]}]} for name in names],
    }}


class FakeContext:
    def __init__(self):
        self.config = {"workspace_id": WORKSPACE, "ontology_id": ONTOLOGY,
                       "tenant_id": WORKSPACE, "target_network": "public", "allow_create": True}
        self.credential = Mock()
        self.timeout = 20
        self.state = {}
        self.fabric = SimpleNamespace(base="https://dailyapi.fabric.microsoft.com/v1")
        self.do = SimpleNamespace(base="https://test-daily.pbidedicated.windows.net/direct")
        self.workload = Mock(side_effect=lambda: nullcontext(self.do))
        self.definition = fixture()
        self.export = None
        self.discovery_error = None
        self.runtime = response(terminal())
        self.route_host = HOST
        self.events = []
        self.save_evidence = Mock(side_effect=lambda label, value: self.events.append(("save", label, copy.deepcopy(value))))
        self.request = Mock(side_effect=self._request)
        self.exchange = Mock(side_effect=self._exchange)
        self.mutate = Mock(side_effect=self._mutate)

    def _request(self, api, method, url, body=None, params=None):
        self.events.append((method, url, body))
        if "generatemwctokenv2" in url:
            return {"Token": "fake-mwc-credential", "TargetUriHost": self.route_host}
        if url.endswith("/definition"):
            return self.definition
        if url.endswith("/items/" + ONTOLOGY):
            return {"id": ONTOLOGY, "displayName": "TestOntology"}
        if url.endswith("/workspaces/" + WORKSPACE):
            return {"capacityId": CAPACITY}
        if url.endswith("/ontologydatasources"):
            if self.discovery_error:
                raise self.discovery_error
            return {"value": [{"id": LAKEHOUSE, "type": "Lakehouse"}]}
        raise AssertionError("Unexpected HTTP: " + url)

    def _mutate(self, api, path, body):
        self.events.append(("mutate", path, copy.deepcopy(body)))
        if path.endswith("/getDefinition"):
            return self.export
        if path.endswith("/dataAgents"):
            self.export = {"definition": body["definition"]}
            return {"id": AGENT}
        raise AssertionError("Unexpected mutation: " + path)

    def _exchange(self, api, method, url, body=None, params=None):
        self.events.append(("runtime", url, body))
        if isinstance(self.runtime, Exception):
            raise self.runtime
        self.runtime_api = api
        return self.runtime

    def existing(self, group="Lakehouse"):
        self.config["allow_create"] = False
        self.config["data_agent_id"] = AGENT
        selected = [group + "_" + suffix for suffix in ("Assets", "Plants", "Readings")]
        self.export = {"definition": {"parts": adapter.definition_parts(
            [e["name"] for e in self.definition["model"]["entities"]], selected,
            WORKSPACE, ONTOLOGY, "TestOntology")}}


class RoutingTests(unittest.TestCase):
    def test_private_requires_explicit_ml_route_before_any_http(self):
        for network in ("wspl", "tenantpl"):
            ctx = FakeContext()
            ctx.config.update(target_network=network, ux_metadata_api=PRIVATE_METADATA, ux_workload_host=HOST)
            result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
            self.assertEqual("BLOCKED", result["status"])
            ctx.request.assert_not_called()
            ctx.mutate.assert_not_called()

    def test_private_rejects_public_metadata_default_and_unsafe_hosts(self):
        for metadata, host in [
            (adapter.routing("public")[0], HOST),
            ("https://attacker.example", HOST),
            (PRIVATE_METADATA, "test.pbidedicated.windows.net/evil"),
        ]:
            with self.subTest(metadata=metadata, host=host):
                with self.assertRaises((ValueError, ScenarioBlocked)):
                    adapter.ml_routing({"target_network": "wspl", "data_agent_metadata_api": metadata,
                                        "data_agent_workload_host": host})

    def test_private_mismatch_never_calls_workload(self):
        ctx = FakeContext()
        ctx.existing()
        ctx.config.update(target_network="tenantpl", data_agent_metadata_api=PRIVATE_METADATA,
                          data_agent_workload_host="expected.pbidedicated.windows.net")
        result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
        self.assertEqual("BLOCKED", result["status"])
        ctx.exchange.assert_not_called()
        self.assertFalse(any("/ontologydatasources" in call.args[2] for call in ctx.request.call_args_list))

    def test_private_explicit_route_uses_same_identity_and_sandbox(self):
        ctx = FakeContext()
        ctx.config.update(target_network="wspl", data_agent_metadata_api=PRIVATE_METADATA,
                          data_agent_workload_host=HOST)
        result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
        self.assertEqual("PASS", result["status"])
        mint = next(c for c in ctx.request.call_args_list if "generatemwctokenv2" in c.args[2])
        self.assertIs(ctx.credential, mint.args[0].credential)
        self.assertTrue(mint.args[2].startswith(PRIVATE_METADATA))
        self.assertTrue(mint.args[0].sensitive_response)
        self.assertEqual("ML", mint.args[3]["workloadType"])
        self.assertEqual("MwcToken", ctx.runtime_api.auth_scheme)
        self.assertEqual("sandbox", ctx.runtime_api.session.headers["x-ms-ai-aiskill-stage"])
        self.assertNotIn("fake-mwc-credential", json.dumps(result))

    def test_no_v1_fallback(self):
        ctx = FakeContext()
        ctx.config["ux_token_version"] = "v1"
        self.assertEqual("BLOCKED", adapter.SCENARIOS["data-agent.lakehouse"](ctx)["status"])
        ctx.request.assert_not_called()


class LifecycleTests(unittest.TestCase):
    def test_registry(self):
        self.assertEqual({"data-agent." + n for n in (
            "lakehouse", "kql", "warehouse", "sql", "mirror", "semantic", "sm-lakehouse",
            "sm-kql", "lakehouse-kql", "lakehouse-warehouse")}, set(adapter.SCENARIOS))

    def test_no_creation_without_consent(self):
        ctx = FakeContext()
        ctx.config["allow_create"] = False
        self.assertEqual("BLOCKED", adapter.SCENARIOS["data-agent.lakehouse"](ctx)["status"])
        ctx.mutate.assert_not_called()

    def test_created_id_saved_before_readback_failure(self):
        ctx = FakeContext()
        normal = ctx._mutate

        def mutate(api, path, body):
            if path.endswith("/getDefinition"):
                raise RuntimeError("readback unavailable")
            return normal(api, path, body)

        ctx.mutate.side_effect = mutate
        result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
        self.assertEqual("FAIL", result["status"])
        self.assertEqual(AGENT, ctx.state["data_agents"]["data-agent.lakehouse"])
        self.assertTrue(any(e[:2] == ("save", "data-agent-resource") for e in ctx.events))
        self.assertEqual(1, sum(c.args[1].endswith("/dataAgents") for c in ctx.mutate.call_args_list))

    def test_matching_existing_draft_is_read_only(self):
        ctx = FakeContext()
        ctx.existing()
        self.assertEqual("PASS", adapter.SCENARIOS["data-agent.lakehouse"](ctx)["status"])
        self.assertTrue(all(c.args[1].endswith("/getDefinition") for c in ctx.mutate.call_args_list))

    def test_wrong_ontology_or_direct_sources_are_blocked_even_with_create(self):
        for change in ("ontology", "source", "published"):
            ctx = FakeContext()
            ctx.existing()
            ctx.config["allow_create"] = True
            docs = adapter.decode_definition(ctx.export)
            if change == "ontology":
                next(v for k, v in docs.items() if k.endswith("/ontology.json"))["artifactId"] = AGENT
            else:
                docs["Files/Config/" + ("draft/datasources/test/datasource.json"
                                       if change == "source" else "published/stage_config.json")] = {}
            ctx.export = {"definition": {"parts": [
                {"path": k, "payloadType": "InlineBase64",
                 "payload": base64.b64encode(json.dumps(v).encode()).decode()} for k, v in docs.items()
            ]}}
            result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
            self.assertEqual("BLOCKED", result["status"])
            self.assertTrue(all(c.args[1].endswith("/getDefinition") for c in ctx.mutate.call_args_list))

    def test_wrong_selection_preserved_without_consent(self):
        ctx = FakeContext()
        ctx.existing("SemanticModel")
        self.assertEqual("BLOCKED", adapter.SCENARIOS["data-agent.lakehouse"](ctx)["status"])
        self.assertEqual(1, ctx.mutate.call_count)

    def test_wrong_selection_can_create_isolated_draft_without_edit(self):
        ctx = FakeContext()
        ctx.existing("SemanticModel")
        ctx.config["allow_create"] = True
        self.assertEqual("PASS", adapter.SCENARIOS["data-agent.lakehouse"](ctx)["status"])
        self.assertFalse(any("/updateDefinition" in c.args[1] for c in ctx.mutate.call_args_list))

    def test_discovery_timeout_and_resolver_warnings_do_not_skip_runtime(self):
        ctx = FakeContext()
        ctx.discovery_error = HttpFailure(504, "Kusto dependency timeout")
        ctx.definition["model"]["tables"][0]["partitions"][0]["annotations"][0]["value"] = "Failed"
        result = adapter.SCENARIOS["data-agent.lakehouse"](ctx)
        self.assertEqual("PASS", result["status"])
        self.assertGreaterEqual(len(result["evidence"]["warnings"]), 2)
        ctx.exchange.assert_called_once()

    def test_discovery_auth_denial_stops_without_alternate_path(self):
        ctx = FakeContext()
        ctx.discovery_error = HttpFailure(403, "denied")
        self.assertEqual("BLOCKED", adapter.SCENARIOS["data-agent.lakehouse"](ctx)["status"])
        ctx.exchange.assert_not_called()

    def test_runtime_timeout_not_replayed_and_next_scenario_runs(self):
        ctx = FakeContext()
        ctx.runtime = TimeoutError("SSE total budget exhausted")
        self.assertEqual("FAIL", adapter.SCENARIOS["data-agent.lakehouse"](ctx)["status"])
        self.assertEqual(1, ctx.exchange.call_count)
        ctx.runtime = response(terminal())
        self.assertEqual("PASS", adapter.SCENARIOS["data-agent.lakehouse"](ctx)["status"])
        self.assertEqual(2, ctx.exchange.call_count)

    def test_missing_entity_blocks_before_creation(self):
        ctx = FakeContext()
        ctx.definition["model"]["entities"] = []
        self.assertEqual("BLOCKED", adapter.SCENARIOS["data-agent.lakehouse"](ctx)["status"])
        ctx.mutate.assert_not_called()


class EvidenceTests(unittest.TestCase):
    def assess(self, value, group="Lakehouse", readings=None):
        readings = readings or group
        selected = [group + "_Assets", group + "_Plants", readings + "_Readings"]
        identities = {n: (SOURCE_IDS[n.rsplit("_", 1)[0]], WORKSPACE) for n in selected}
        evidence = {"warnings": []}
        return adapter.assess(value, identities, selected, evidence), evidence

    def test_actual_lakehouse_and_semantic_datasets_pass(self):
        for group in ("Lakehouse", "SemanticModel"):
            self.assertEqual("PASS", self.assess(terminal(SOURCE_IDS[group]), group)[0][0])

    def test_correct_final_answer_or_generated_code_is_not_execution(self):
        for output in ([], [{"type": "message", "content": [{"text": FULL_TABLE}]}],
                       pair("generate_files_data_insights.execute", {}, FULL_TABLE, "insight")):
            value = {"status": "completed", "output": output}
            self.assertEqual("BLOCKED", self.assess(value)[0][0])

    def test_failed_execution_cannot_be_rescued_by_correct_table(self):
        value = terminal()
        result = next(o for o in value["output"] if o.get("call_id") == "execute"
                      and o["type"] == "function_call_output")
        result["metadata"]["diagnostic_details"] = '{"queries_ran":[{"is_error":true}]}'
        self.assertEqual("BLOCKED", self.assess(value)[0][0])

    def test_wrong_source_workspace_and_missing_code_do_not_pass(self):
        for field, value in (("datasource_artifact_id", KQL), ("datasource_workspace_id", AGENT), ("code", "")):
            doc = terminal()
            call = next(o for o in doc["output"] if o["type"] == "function_call" and o["call_id"] == "execute")
            args = json.loads(call["arguments"])
            args[field] = value
            call["arguments"] = json.dumps(args)
            self.assertEqual("BLOCKED", self.assess(doc)[0][0])

    def test_overwritten_file_cannot_reuse_old_execution_provenance(self):
        doc = terminal()
        doc["output"] += execution(KQL, "result.json", "overwrite")
        self.assertEqual("BLOCKED", self.assess(doc)[0][0])

    def test_partial_or_wrong_fixture_data_not_pass(self):
        for table in (FULL_TABLE.replace("| 10 |", "| 110 |"),
                      FULL_TABLE.replace("R0120", "R0001"), FULL_TABLE.replace("Boston", "Paris")):
            self.assertEqual("PARTIAL", self.assess(terminal(table=table))[0][0])

    def test_generic_count_must_be_for_a012(self):
        table = """
File: result.json
Total rows: 2
| ReadingCount | TemperatureC | AssetId | PlantId | PlantName | City | ReadingId | ObservedAt |
|:---|:---|:---|:---|:---|:---|:---|:---|
| 10 | {} | A013 | {} | {} | {} | {} | {} |
| {} | 32.9 | A012 | P03 | East Plant | Boston | R0120 | 2026-01-01T00:45:00Z |
"""
        self.assertEqual("PARTIAL", self.assess(terminal(table=table))[0][0])

    def test_unrelated_result_file_cannot_supply_missing_values(self):
        doc = terminal(table=FULL_TABLE.replace("result.json", "unexecuted.json"))
        self.assertEqual("PARTIAL", self.assess(doc)[0][0])

    def test_missing_ontology_runtime_provenance_not_pass(self):
        doc = terminal()
        doc["output"] = [o for o in doc["output"] if o["call_id"] != "context"]
        self.assertEqual("PARTIAL", self.assess(doc)[0][0])

    def test_cross_source_cannot_pass_by_reading_duplicate_single_source(self):
        self.assertEqual("PARTIAL", self.assess(terminal(), "SemanticModel", "Lakehouse")[0][0])

    def test_cross_source_joined_datasets_pass(self):
        doc = terminal()
        doc["output"][1]["output"] = json.dumps({"attached": [{"id": LAKEHOUSE}, {"id": SEMANTIC}]})
        doc["output"] += execution(SEMANTIC, "context.json", "context-execution")
        doc["output"] += pair("generate_files_data_insights.execute", {}, """
File: context.json
Total rows: 1
| AssetId | PlantId | PlantName | City |
|:---|:---|:---|:---|
| A012 | P03 | East Plant | Boston |
""", "context-insights")
        self.assertEqual("PASS", self.assess(doc, "SemanticModel", "Lakehouse")[0][0])

    def test_incomplete_terminal_never_passes(self):
        doc = terminal()
        doc["status"] = "incomplete"
        self.assertEqual("FAIL", self.assess(doc)[0][0])

    def test_json_and_sse_parse_without_reasoning(self):
        doc = terminal()
        doc["output"].append({"type": "reasoning", "content": "not retained"})
        for sse in (True, False):
            parsed = adapter.terminal_response(response(doc, sse))
            self.assertEqual("completed", parsed["status"])
            self.assertFalse(any(o["type"] == "reasoning" for o in parsed["output"]))

    def test_empty_missing_terminal_and_malformed_sse_fail(self):
        for text in ("", "data: {\"type\":\"response.created\"}\n\n", "data: nonsense\n\n"):
            result = response({})
            result._content = text.encode()
            with self.assertRaises(ValueError):
                adapter.terminal_response(result)

    def test_kql_and_unsupported_sources_are_attempted_not_assumed_pass(self):
        for case in ("kql", "warehouse", "sql", "mirror"):
            ctx = FakeContext()
            ctx.runtime = response({"status": "completed", "output": []})
            result = adapter.SCENARIOS["data-agent." + case](ctx)
            self.assertEqual("BLOCKED", result["status"])
            ctx.exchange.assert_called_once()
            self.assertTrue(result["evidence"]["warnings"])


if __name__ == "__main__":
    unittest.main()
