import json
import io
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from validation_common import ScenarioBlocked, ValidationContext, console, sanitize
from validation_queries import EXPECTED, answer_check, context, definition, mcp, ontology
from validate_sample import catalog, execute_scenarios, load_config, main, persist, select_scenarios


CONFIG = {"tenant_id": "11111111-1111-1111-1111-111111111111",
          "workspace_id": "22222222-2222-2222-2222-222222222222",
          "ontology_id": "33333333-3333-3333-3333-333333333333", "target_network": "public"}


class RunnerTests(unittest.TestCase):
    def test_console_output_cannot_abort_on_windows_encoding(self):
        output = io.BytesIO()
        stream = io.TextIOWrapper(output, encoding="cp1252")
        console("Unexpected server text \u2705 | Bearer opaque-secret", file=stream)
        stream.flush()
        self.assertIn(b"\\u2705", output.getvalue())
        self.assertNotIn(b"opaque-secret", output.getvalue())

    def test_listing_does_not_import_optional_adapters(self):
        with patch("validate_sample.importlib.import_module", side_effect=ImportError("optional adapter")) as importer:
            scenarios = catalog()
            self.assertIn("generation.lifecycle", scenarios)
            importer.assert_not_called()
            with self.assertRaises(ImportError):
                scenarios["generation.lifecycle"](Mock())

    def test_select_names_groups_and_unknown(self):
        names = {"ontology.definition": None, "ontology.lakehouse": None, "mcp.lakehouse": None}
        self.assertEqual(select_scenarios(names), {"ontology.definition"})
        self.assertEqual(select_scenarios(names, agents=["mcp"]), {"mcp.lakehouse"})
        self.assertEqual(select_scenarios(names, scenarios=["*.lakehouse"]),
                         {"ontology.lakehouse", "mcp.lakehouse"})
        with self.assertRaises(ValueError):
            select_scenarios(names, scenarios=["typo"])

    def test_failure_isolation_and_incremental_report(self):
        def fail(_):
            raise ValueError("unexpected test error | does not stop following checks")

        def blocked(_):
            raise ScenarioBlocked("Missing optional service route")

        def timeout(_):
            raise TimeoutError("Finite budget")

        scenarios = {"a": fail, "b": blocked, "c": timeout,
                     "d": lambda _: {"status": "PASS", "summary": "Last scenario executed"}}
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary)
            report = {"startedUtc": "test", "state": "running", "results": [
                {"scenario": name, "selected": True, "status": "PENDING", "summary": ""}
                for name in scenarios]}
            ctx = Mock(state={"retained": "item"})
            execute_scenarios(scenarios, set(scenarios), ctx, report, path)
            self.assertEqual([row["status"] for row in report["results"]],
                             ["ERROR", "BLOCKED", "TIMEOUT", "PASS"])
            self.assertIn("Last scenario executed", (path / "report.md").read_text())
            self.assertEqual(len(list(path.glob("*.result.json"))), 4)
            self.assertIn("retained", (path / "results.json").read_text())

    def test_interrupt_persists_current_result(self):
        def interrupt(_):
            raise KeyboardInterrupt()
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary)
            report = {"startedUtc": "test", "state": "running", "results": [
                {"scenario": "a", "selected": True, "status": "PENDING", "summary": ""}]}
            with self.assertRaises(KeyboardInterrupt):
                execute_scenarios({"a": interrupt}, {"a"}, Mock(state={}), report, path)
            self.assertEqual(json.loads((path / "a.result.json").read_text())["status"], "ERROR")

    def test_config_error_still_writes_report(self):
        with tempfile.TemporaryDirectory() as temporary, patch("validate_sample.catalog", return_value={"a": None}):
            path = Path(temporary)
            config = path / "bad.json"
            config.write_text("{}")
            output = path / "output"
            self.assertEqual(main(["--config", str(config), "--output", str(output), "--scenarios", "a"]), 2)
            self.assertTrue((output / "report.md").is_file())
            self.assertEqual(json.loads((output / "results.json").read_text())["results"][0]["status"], "BLOCKED")

    def test_plan_never_authenticates(self):
        with tempfile.TemporaryDirectory() as temporary, patch("validate_sample.catalog", return_value={"a": Mock()}) as cat:
            path = Path(temporary)
            config = path / "config.json"
            config.write_text(json.dumps(CONFIG))
            self.assertEqual(main(["--config", str(config), "--output", str(path / "out"),
                                   "--scenarios", "a", "--plan"]), 0)
            cat.return_value["a"].assert_not_called()

    def test_strict_changes_only_exit_code_not_failure_isolation(self):
        scenarios = {"a": lambda _: {"status": "FAIL", "summary": "Service failed"},
                     "b": lambda _: {"status": "PASS", "summary": "Still ran"}}
        for strict in (False, True):
            with self.subTest(strict=strict), tempfile.TemporaryDirectory() as temporary, \
                    patch("validate_sample.catalog", return_value=scenarios), \
                    patch("azure.identity.AzureCliCredential"), \
                    patch("validate_sample.ValidationContext") as context_type:
                context_type.return_value.state = {}
                context_type.return_value.requests = []
                path = Path(temporary)
                config = path / "config.json"
                config.write_text(json.dumps(CONFIG))
                argv = ["--config", str(config), "--output", str(path / "out"), "--scenarios", "a", "b"]
                result = main(argv + (["--strict"] if strict else []))
                self.assertEqual(result, int(strict))
                results = json.loads((path / "out" / "results.json").read_text())["results"]
                self.assertEqual([row["status"] for row in results], ["FAIL", "PASS"])

    def test_private_mode_requires_pinned_hosts_and_never_uses_public_default(self):
        with tempfile.TemporaryDirectory() as temporary:
            config = Path(temporary) / "config.json"
            for value in ({**CONFIG, "target_network": "wspl"},
                          {**CONFIG, "target_network": "tenantpl", "ux_metadata_api":
                           "https://wabi-daily-us-east2-redirect.analysis.windows.net",
                           "ux_workload_host": "test.pbidedicated.windows.net"}):
                config.write_text(json.dumps(value))
                with self.assertRaises(ValueError):
                    load_config(config)
            config.write_text(json.dumps({**CONFIG, "allow_create": True}))
            self.assertFalse(load_config(config)["allow_create"])

    def test_retry_selection_includes_partial_and_unfinished(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "results.json"
            path.write_text(json.dumps({"results": [
                {"scenario": name, "status": status, "selected": True}
                for name, status in (("a", "PARTIAL"), ("b", "PASS"), ("c", "RUNNING"))]}))
            self.assertEqual(select_scenarios({"a": None, "b": None, "c": None}, previous=path), {"a", "c"})

    def test_report_and_json_redact_tokens_and_escape_table_cells(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary)
            report = {"startedUtc": "test", "state": "completed", "resources": {"accessToken": "opaque-secret"},
                      "results": [{"scenario": "a", "selected": True, "status": "ERROR",
                                   "summary": "Bearer opaque-secret | another\nline"}]}
            persist(path, report)
            for name in ("report.md", "results.json"):
                self.assertNotIn("opaque-secret", (path / name).read_text())
            self.assertIn("\\|", (path / "report.md").read_text())
        self.assertNotIn("abc", sanitize("https://x/?sig=abc"))


class QueryTests(unittest.TestCase):
    def test_fixture_answer_requires_all_fields(self):
        self.assertEqual(answer_check(json.dumps(EXPECTED))["status"], "PASS")
        self.assertEqual(answer_check(json.dumps({**EXPECTED, "TemperatureC": 99}))["status"], "FAIL")
        self.assertEqual(answer_check("A012 32.9 East Plant")["status"], "UNVERIFIED")
        self.assertEqual(answer_check(json.dumps({**EXPECTED, "ObservedAt": "2026-01-01T00:45:00+00:00"}))["status"], "PASS")

    def test_plan_context_is_json_string(self):
        actual = json.loads(context(CONFIG)["fabricOntology.context"])
        self.assertEqual(actual["MutationMode"], 0)
        self.assertTrue(actual["MutationModeExplicit"])
        self.assertEqual(actual["OntologyId"], CONFIG["ontology_id"])

    def test_resolver_failure_is_an_observation_not_an_exception(self):
        ctx = Mock(config=CONFIG)
        ctx.workload.return_value.__enter__ = Mock(return_value=Mock(base="https://test.pbidedicated.windows.net"))
        ctx.workload.return_value.__exit__ = Mock(return_value=False)
        ctx.request.return_value = {"model": {"tables": [{"name": "Lakehouse_Plants", "partitions": [
            {"name": "Plants", "annotations": [{"name": "ONT_RESOLVED_State", "value": "Failed"},
                                              {"name": "ONT_RESOLVED_Error", "value": "ResolutionUnavailable"}]}]}]}}
        result = definition(ctx)
        self.assertEqual(result["status"], "PARTIAL")
        self.assertEqual(result["evidence"]["resolverIssues"][0]["errors"], ["ResolutionUnavailable"])

    def test_correct_prose_does_not_claim_source_execution(self):
        api = Mock(base="https://test.pbidedicated.windows.net")
        ctx = Mock(config=CONFIG, state={})
        ctx.workload.return_value.__enter__ = Mock(return_value=api)
        ctx.workload.return_value.__exit__ = Mock(return_value=False)
        ctx.request.side_effect = [{"id": "test"}, [
            {"role": "assistant", "contents": [{"$type": "text", "text": json.dumps(EXPECTED)}]}]]
        ctx.poll_conversation.return_value = {"status": "completed"}
        result = ontology(ctx, "lakehouse")
        body = ctx.request.call_args_list[0].args[3]
        self.assertIn("additionalContext", body)
        self.assertNotIn("additionalContext", body["initialMessage"])
        self.assertEqual(result["status"], "PARTIAL")
        self.assertEqual(result["evidence"]["answerCheck"]["status"], "PASS")
        self.assertFalse(result["evidence"]["executionVerified"])

    def test_mcp_error_empty_and_wrong_rpc_id_fail(self):
        for reply in ({"jsonrpc": "2.0", "id": 9, "result": {}},
                      {"jsonrpc": "2.0", "id": 1, "error": {"code": 500}}):
            ctx = Mock(config=CONFIG)
            ctx.fabric.base = "https://dailyapi.fabric.microsoft.com/v1"
            ctx.request.return_value = reply
            with self.assertRaises(RuntimeError):
                mcp(ctx, "lakehouse")


class TransportTests(unittest.TestCase):
    def test_sensitive_response_never_written_to_disk(self):
        from requests import Response
        with tempfile.TemporaryDirectory() as temporary:
            response = Response()
            response.status_code = 200
            response._content = b'{"Token":"opaque-topsecret"}'
            response._content_consumed = True
            ctx = ValidationContext(CONFIG, Mock(), temporary)
            ctx.fabric.sensitive_response = True
            ctx.fabric.session = Mock()
            ctx.fabric.session.request.return_value.__enter__ = Mock(return_value=response)
            ctx.fabric.session.request.return_value.__exit__ = Mock(return_value=False)
            try:
                ctx.begin("test")
                result = ctx.request(ctx.fabric, "POST", ctx.fabric.base + "/generatemwctokenv2", {})
                self.assertEqual(result["Token"], "opaque-topsecret")
                self.assertNotIn("opaque-topsecret", (Path(temporary) / "test.http.json").read_text())
            finally:
                ctx.close()

    def test_socket_timeout_is_bounded_and_recorded(self):
        import requests
        with tempfile.TemporaryDirectory() as temporary:
            ctx = ValidationContext(CONFIG, Mock(), temporary)
            ctx.fabric.session = Mock()
            ctx.fabric.session.request.side_effect = requests.exceptions.ReadTimeout("socket expired")
            try:
                ctx.begin("test")
                with self.assertRaises(TimeoutError):
                    ctx.exchange(ctx.fabric, "POST", ctx.fabric.base + "/query", {})
                self.assertEqual(ctx.fabric.session.request.call_count, 1)
                ledger = json.loads((Path(temporary) / "test.http.json").read_text())
                self.assertEqual(ledger[0]["error"]["type"], "ReadTimeout")
            finally:
                ctx.close()

    def test_cross_origin_prevented_before_token_or_http(self):
        with tempfile.TemporaryDirectory() as temporary:
            credential = Mock()
            ctx = ValidationContext(CONFIG, credential, temporary)
            try:
                ctx.begin("test")
                with self.assertRaises(RuntimeError):
                    ctx.exchange(ctx.fabric, "GET", "https://unrelated.example/v1")
                credential.get_token.assert_not_called()
            finally:
                ctx.close()

    def test_empty_http_success_not_json_success_and_no_write_retry(self):
        from requests import Response
        for status in (200, 403, 503):
            with self.subTest(status=status), tempfile.TemporaryDirectory() as temporary:
                response = Response()
                response.status_code = status
                response._content = b""
                response._content_consumed = True
                ctx = ValidationContext(CONFIG, Mock(), temporary)
                ctx.fabric.session = Mock()
                ctx.fabric.session.request.return_value.__enter__ = Mock(return_value=response)
                ctx.fabric.session.request.return_value.__exit__ = Mock(return_value=False)
                try:
                    ctx.begin("test")
                    with self.assertRaises(RuntimeError):
                        ctx.request(ctx.fabric, "POST", ctx.fabric.base + "/test", {})
                    self.assertEqual(ctx.fabric.session.request.call_count, 1)
                    kwargs = ctx.fabric.session.request.call_args.kwargs
                    self.assertFalse(kwargs["allow_redirects"])
                    self.assertTrue((Path(temporary) / "test.http.json").exists())
                finally:
                    ctx.close()


if __name__ == "__main__":
    unittest.main()
