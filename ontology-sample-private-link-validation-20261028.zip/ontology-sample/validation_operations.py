"""Stopped native-playbook import, not runtime/monitoring validation.

Contract: workload-rti-ai commit 298b397ab89709409d1ac685c815e640ad76935f,
ClassDefinition.cs, DataPropertyDefinition.cs, IClassExpression.cs and
AlmTranslatorTestsOnOntologyAgent.yaml. Required DocumentId/Description members
were confirmed by a successful Daily import and definition readback.
Public envelope: https://learn.microsoft.com/rest/api/fabric/articles/item-management/definitions/operations-agent-definition
"""

import base64
import copy
import hashlib
import json
from contextlib import closing
from datetime import datetime
from uuid import UUID, uuid4

from create_sample import Api, PBI_SCOPE
from target_routing import target_fabric_api
from ux_authoring import routing, workload_host
from validation_common import ScenarioBlocked

ENTITY = "Lakehouse_Readings"
KEY = "ReadingId"
METRIC = "TemperatureC"


def build_definition(workspace_id, ontology_id, rule_id):
    """Build the proven native contract with caller-specific resource identifiers."""
    workspace_id, ontology_id, rule_id = (
        str(UUID(str(value))) for value in (workspace_id, ontology_id, rule_id)
    )
    query = {"EntitySelector": {
        "queryType": "GQL",
        "Query": f"MATCH (r:`{ENTITY}`) RETURN r.`{KEY}` AS `{KEY}`, r.`{METRIC}` AS `{METRIC}`",
    }}
    return {
        "configuration": {
            "instructions": (
                "Configuration-only validation against synthetic Lakehouse_Readings. Remain stopped. "
                "Do not send notifications or execute actions. Use only this source group, not duplicate groups. "
                "The harmless threshold of 1000 Celsius is intentionally above the synthetic fixture maximum."
            ),
            # The deployed import/export contract uses the dictionary key as the inline source id.
            "dataSources": {ontology_id: {"id": ontology_id, "type": "Ontology", "workspaceId": workspace_id}},
            "actions": {},
        },
        "playbook": {
            "Status": {"State": "Completed", "Error": None, "StartTime": None},
            "Id": None,
            "OntologyDefinitions": {
                ENTITY: {"$type": "class", "IRI": ENTITY, "DocumentId": "", "Name": ENTITY,
                         "Description": "Synthetic Lakehouse readings; stopped validation only."},
                KEY: {"$type": "data", "IRI": KEY, "DocumentId": "", "Name": KEY,
                      "Description": "Synthetic reading identifier.", "DomainClassIRI": ENTITY,
                      "RangeDataType": "string", "Kind": 0},
                METRIC: {"$type": "data", "IRI": METRIC, "DocumentId": "", "Name": METRIC,
                         "Description": "Synthetic temperature in Celsius.", "DomainClassIRI": ENTITY,
                         "RangeDataType": "decimal", "Kind": 1},
            },
            "RuleDefinitions": {rule_id: {
                "Id": rule_id, "Name": "Synthetic no-action temperature rule",
                "Description": "Stopped validation; no action binding or notification destination.",
                "ClassExpression": {"$type": "ontologyqueryexpression", "Expression": json.dumps(query),
                                    "Description": "Read synthetic Lakehouse_Readings only."},
                "RuleCondition": {"$type": "propertywhenisabove", "DataPropertyName": METRIC, "Threshold": 1000},
                "ActionBinding": None,
            }},
            "AlmDefinitions": None, "ConfigurationHash": None,
        },
        "shouldRun": False,
    }


def envelope(document):
    return {"definition": {"parts": [{
        "path": "Configurations.json", "payloadType": "InlineBase64",
        "payload": base64.b64encode(json.dumps(document).encode("utf-8")).decode("ascii"),
    }]}}


def decode_definition(exported):
    parts = exported.get("definition", {}).get("parts")
    if not isinstance(parts, list):
        raise ValueError("Definition response omitted parts")
    seen, document = set(), None
    for part in parts:
        path = part.get("path")
        if not isinstance(path, str) or path.casefold() in seen:
            raise ValueError("Definition contains invalid or duplicate part paths")
        seen.add(path.casefold())
        if path not in ("Configurations.json", ".platform"):
            raise ValueError("Unexpected OperationsAgent definition part")
        if path == ".platform":
            continue
        if part.get("payloadType") != "InlineBase64":
            raise ValueError("OperationsAgent definition must use InlineBase64")
        document = json.loads(base64.b64decode(part["payload"], validate=True))
    if not isinstance(document, dict):
        raise ValueError("Configurations.json is missing or not an object")
    return document


def verify_definition(expected, exported, item, item_id, name):
    document = decode_definition(exported)
    configuration = document.get("configuration") or {}
    playbook = document.get("playbook") or {}
    actual_rules = copy.deepcopy(playbook.get("RuleDefinitions"))
    if isinstance(actual_rules, dict):
        for rule in actual_rules.values():
            if isinstance(rule, dict):
                # Export may omit optional null ActionBinding. A present non-null binding
                # must still differ from the no-action contract and fail verification.
                rule.setdefault("ActionBinding", None)
    checks = {
        "itemIdentity": item.get("id") == item_id and item.get("type") == "OperationsAgent"
                        and item.get("displayName") == name,
        "inactive": item.get("properties", {}).get("state") == "Inactive",
        "shouldRunFalse": document.get("shouldRun") is False,
        "instructionsPreserved": configuration.get("instructions") == expected["configuration"]["instructions"],
        "sourceBindingsPreserved": configuration.get("dataSources") == expected["configuration"]["dataSources"],
        "actionsEmpty": configuration.get("actions") == {},
        "noNotificationDestination": configuration.get("messageDestination") is None
                                     and configuration.get("recipient") in (None, ""),
        "ontologyDefinitionsPreserved": playbook.get("OntologyDefinitions") == expected["playbook"]["OntologyDefinitions"],
        "ruleDefinitionsPreserved": actual_rules == expected["playbook"]["RuleDefinitions"],
    }
    return checks, document


def _route_plan(ctx):
    config = ctx.config
    network = config["target_network"]
    expected_api = target_fabric_api(network, config["workspace_id"], config["tenant_id"])
    if ctx.fabric.base.rstrip("/") != expected_api:
        raise ScenarioBlocked("Fabric API does not match the selected network/workspace/tenant; no fallback allowed")
    try:
        routing(network, config.get("ux_metadata_api"), config.get("ux_workload_host"))
        origin, host = config.get("operations_metadata_api"), config.get("operations_workload_host")
        if network != "public" or origin or host:
            if not origin or not host:
                raise ScenarioBlocked(
                    "Operations routing requires operations_metadata_api and operations_workload_host "
                    "from the working Operations Agent UX; DO routing is not an Operations route substitute")
            return routing(network, origin, host)
    except ValueError as error:
        raise ScenarioBlocked(str(error)) from error
    return None


def _require_fixture(definition):
    model = definition.get("model")
    if not isinstance(model, dict):
        raise ScenarioBlocked("Ontology definition did not contain a model")
    entities = model.get("entities") or []
    entity = next((value for value in entities if value.get("name") == ENTITY), None)
    if not entity or entity.get("keyProperties") != [KEY]:
        raise ScenarioBlocked(f"Native import requires the existing {ENTITY} fixture with key {KEY}; no source is changed")
    properties = {value.get("name"): value for value in entity.get("properties", [])}
    if properties.get(KEY, {}).get("dataType") != "string" or properties.get(METRIC, {}).get("dataType") not in (
        "double", "decimal", "int64",
    ):
        raise ScenarioBlocked(f"Native import requires existing string {KEY} and numeric {METRIC}")


def _fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def preservation_snapshot(definition):
    """Ignore only the resolver's read timestamp, retaining bindings and all other metadata."""
    snapshot = copy.deepcopy(definition)
    for table in snapshot.get("model", {}).get("tables", []):
        for partition in table.get("partitions", []):
            for annotation in partition.get("annotations", []):
                if annotation.get("name") != "ONT_RESOLVED_At" or not isinstance(annotation.get("value"), str):
                    continue
                try:
                    timestamp = datetime.fromisoformat(annotation["value"].replace("Z", "+00:00"))
                except ValueError:
                    continue
                if timestamp.tzinfo is not None:
                    annotation["value"] = "<resolver-read-timestamp>"
    return snapshot


def _validate_operations_route(ctx, plan, item_id, capacity_id):
    """Validate OA's own service-returned host; never reuse the DO token or host."""
    if plan is None:
        return {"status": "NOT_REQUESTED", "scope": "Fabric public API import/readback only"}
    origin, expected_host = plan
    version = ctx.config.get("ux_token_version", "v2")
    if version not in ("v1", "v2"):
        raise ScenarioBlocked("MWC token version must be v1 or v2")
    body = {"workspaceObjectId": ctx.config["workspace_id"], "workloadType": "OA"}
    if version == "v2":
        body["artifacts"] = [{"artifactType": "OperationsAgent", "artifactObjectId": item_id}]
    else:
        body.update(capacityObjectId=capacity_id, artifactObjectIds=[item_id])
    with closing(Api(origin, PBI_SCOPE, ctx.credential, ctx.timeout, sensitive_response=True)) as metadata:
        token_response = ctx.request(
            metadata, "POST", origin + "/metadata/v201606/generatemwctoken" + ("v2" if version == "v2" else ""), body)
    host = token_response.get("TargetUriHost") or token_response.get("targetUriHost")
    token = token_response.get("Token") or token_response.get("token")
    actual_capacity = token_response.get("CapacityObjectId") or token_response.get("capacityObjectId")
    if not isinstance(token, str) or not token or any(char.isspace() for char in token):
        raise ValueError("Operations workload-token response missing a valid token")
    if not isinstance(host, str) or workload_host(host) != expected_host:
        raise ScenarioBlocked("Operations service-returned host differs from pinned host; token not forwarded")
    if actual_capacity and str(actual_capacity).lower() != capacity_id.lower():
        raise ScenarioBlocked("Operations token capacity differs from workspace; token not forwarded")
    # Route discovery is not proof of rule execution or private-network enforcement.
    return {"status": "MATCHED", "metadataOrigin": origin, "expectedHost": expected_host,
            "serviceReturnedHost": workload_host(host), "tokenForwarded": False,
            "scope": "OA metadata route discovery only; no runtime/monitoring call"}


def native_import(ctx):
    evidence = {"scope": "Stopped native-playbook import and preservation only", "runtimeValidated": False,
                "networkEnforcementVerified": False, "activated": False,
                "limitation": "No rule execution or preview is performed. Active monitoring is not permitted."}
    record = None
    phase = "preflight"
    try:
        if ctx.config.get("allow_create") is not True:
            raise ScenarioBlocked("operations.native-import requires explicit allow_create=true")
        workspace, ontology = (str(UUID(ctx.config[key])) for key in ("workspace_id", "ontology_id"))
        route = _route_plan(ctx)
        if ctx.config.get("ux_token_version", "v2") not in ("v1", "v2"):
            raise ScenarioBlocked("MWC token version must be v1 or v2")
        target = f"{ctx.fabric.base}/workspaces/{workspace}"
        workspace_item = ctx.request(ctx.fabric, "GET", target)
        capacity = str(UUID(workspace_item["capacityId"]))
        source = ctx.request(ctx.fabric, "GET", f"{target}/items/{ontology}")
        if source.get("type") != "Ontology" or source.get("id") != ontology:
            raise ScenarioBlocked("Configured ontology source identity/type did not match")
        with ctx.workload(ontology_id=ontology) as api:
            definition_path = f"{api.base}/v4/workspaces/{workspace}/ontologies/{ontology}/definition"
            baseline = ctx.request(api, "GET", definition_path)
            # Persisted TOM omits auto-projected properties. Validate actual projected types,
            # while retaining the unexpanded document for the source-preservation comparison.
            expanded = ctx.request(api, "GET", definition_path, params={"expand": "true"})
        ctx.save_evidence("source-preflight-expanded", expanded)
        _require_fixture(expanded)
        evidence["sourceBeforeSha256"] = _fingerprint(baseline)
        ctx.save_evidence("source-before", baseline)
        document = build_definition(workspace, ontology, str(uuid4()))
        name = "OperationsAgent_NoAction_" + uuid4().hex
        record = {"displayName": name, "workspaceId": workspace, "ontologyId": ontology,
                  "phase": "create-intent", "id": None, "activationAllowed": False}
        ctx.state.setdefault("operations_agents", []).append(record)
        evidence["resource"] = record
        ctx.save_evidence("create-intent", {"resource": record, "authoredDefinition": document})
        phase = "create"
        result = ctx.mutate(ctx.fabric, target + "/operationsAgents", {
            "displayName": name, "description": "Owned stopped validation; no actions or notifications; do not activate.",
            **envelope(document),
        })
        if isinstance(result, dict):
            record["id"] = result.get("id")
        record["phase"] = "create-returned"
        ctx.save_evidence("created", {"resource": record, "response": result})
        if not record["id"]:
            raise ValueError("Create returned no item id; inspect retained operation/name before any retry")
        item_id = str(UUID(record["id"]))
        record["id"] = item_id
        phase = "readback"
        item_path = f"{target}/operationsAgents/{item_id}"
        item = ctx.request(ctx.fabric, "GET", item_path)
        exported = ctx.mutate(ctx.fabric, item_path + "/getDefinition", None)
        ctx.save_evidence("definition-readback", {"item": item, "definition": exported})
        checks, stored = verify_definition(document, exported, item, item_id, name)
        evidence["checks"] = checks
        ctx.save_evidence("decoded-definition", stored)
        if not all(checks.values()):
            raise ValueError("Imported definition or inactive/no-action safety checks failed")
        phase = "source-preservation"
        with ctx.workload(ontology_id=ontology) as api:
            after = ctx.request(
                api, "GET", f"{api.base}/v4/workspaces/{workspace}/ontologies/{ontology}/definition")
        ctx.save_evidence("source-after", after)
        evidence["sourceAfterSha256"] = _fingerprint(after)
        evidence["sourcePreservationIgnoredFields"] = [
            "model.tables[].partitions[].annotations[name=ONT_RESOLVED_At].value: resolver read timestamp only",
        ]
        checks["sourceUnchanged"] = preservation_snapshot(baseline) == preservation_snapshot(after)
        if not checks["sourceUnchanged"]:
            raise ValueError("Source definition changed during validation; preservation not verified")
        phase = "operations-route"
        evidence["operationsRoute"] = _validate_operations_route(ctx, route, item_id, capacity)
        phase = "final-state"
        final_item = ctx.request(ctx.fabric, "GET", item_path)
        checks["finalInactive"] = final_item.get("properties", {}).get("state") == "Inactive"
        ctx.save_evidence("final-item", final_item)
        if not checks["finalInactive"]:
            raise ValueError("Retained Operations Agent no longer reports Inactive")
        record["phase"] = "verified-inactive"
        status, summary = "PASS", "Native playbook imported/read back inactive; source preserved. Runtime is NOT tested."
    except Exception as error:
        if record is not None:
            record["phase"] = "failed-" + phase
        http_status = getattr(error, "status", None)
        status = "BLOCKED" if isinstance(error, ScenarioBlocked) or http_status in (401, 403) else "FAIL"
        summary = f"Stopped native import {status.lower()} during {phase}; inspect evidence; no write replay or cleanup."
        evidence["error"] = {"type": type(error).__name__, "phase": phase, "httpStatus": http_status}
        if isinstance(error, (ScenarioBlocked, ValueError)):
            evidence["error"]["reason"] = str(error)
    evidence["status"] = status
    ctx.save_evidence("native-import", evidence)
    return {"status": status, "summary": summary, "evidence": copy.deepcopy(evidence)}


SCENARIOS = {"operations.native-import": native_import}
