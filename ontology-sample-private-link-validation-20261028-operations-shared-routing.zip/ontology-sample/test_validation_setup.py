import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from validate_sample import main, validate_config
from validation_setup import configure, import_sample_settings, prerequisites, reuse_data_agents


TENANT = "11111111-1111-1111-1111-111111111111"
WORKSPACE = "22222222-2222-2222-2222-222222222222"
ONTOLOGY = "33333333-3333-3333-3333-333333333333"
AGENT = "44444444-4444-4444-4444-444444444444"
ORIGIN = "https://22222222222222222222222222222222.z22.w.dailyapi.fabric.microsoft.com"
HOST = "22222222222222222222222222222222.z22.daily-c.fabric.microsoft.com"
CONFIG = {
    "tenant_id": TENANT, "workspace_id": WORKSPACE, "ontology_id": ONTOLOGY,
    "target_network": "wspl", "auth": "cli", "ux_token_version": "v2",
    "ux_metadata_api": ORIGIN, "ux_workload_host": HOST,
}


def answers(question):
    if question.startswith(("ML / Data Agent metadata", "OA / Operations Agent metadata")):
        return ORIGIN
    if question.startswith(("ML / Data Agent TargetUriHost", "OA / Operations Agent TargetUriHost")):
        return HOST
    return "SAVE" if question.startswith("Type SAVE") else ""


class PrerequisiteTests(unittest.TestCase):
    def test_workspace_route_is_shared_without_separate_service_settings(self):
        issues = prerequisites({**CONFIG, "allow_create": True},
                               {"data-agent.lakehouse", "operations.lakehouse",
                                "ontology.lakehouse", "mcp.lakehouse"})
        self.assertEqual(issues, {})

    def test_explicitly_confirmed_shared_route_and_existing_draft(self):
        config = {**CONFIG, "data_agent_metadata_api": ORIGIN, "data_agent_workload_host": HOST,
                  "data_agent_ids": {"data-agent.lakehouse": AGENT}}
        self.assertEqual(prerequisites(config, {"data-agent.lakehouse"}), {})
        self.assertIn("AllowCreate", prerequisites(config, {"data-agent.kql"})["data-agent.kql"][0])

    def test_invalid_optional_route_and_token_contract(self):
        for origin, host in ((ORIGIN + "/metadata/request", HOST), (ORIGIN, "https://" + HOST),
                             ("https://unrelated.example", HOST)):
            config = {**CONFIG, "allow_create": True, "data_agent_metadata_api": origin,
                      "data_agent_workload_host": host, "ux_token_version": "v1"}
            errors = prerequisites(config, {"data-agent.lakehouse"})["data-agent.lakehouse"]
            self.assertEqual(len(errors), 2)

    def test_generation_checks_fixture_workspace_and_creation(self):
        errors = prerequisites(CONFIG, {"generation.lifecycle"})["generation.lifecycle"]
        self.assertEqual(len(errors), 2)
        config = {**CONFIG, "allow_create": True, "generation_lakehouse_id": AGENT,
                  "generation_source_workspace_id": TENANT}
        self.assertIn("target workspace", prerequisites(config, {"generation.lifecycle"})[
            "generation.lifecycle"][0])
        config["generation_source_workspace_id"] = WORKSPACE
        self.assertEqual(prerequisites(config, {"generation.lifecycle"}), {})

    def test_operations_runtime_has_no_alm_or_creation_prerequisites(self):
        self.assertEqual(prerequisites(CONFIG, {"operations.runtime"}), {})

    def test_invalid_or_partial_operations_override_is_not_silently_ignored(self):
        for network in ("wspl", "tenantpl"):
            for origin, host in ((ORIGIN, None), (None, HOST),
                                 (ORIGIN + "/metadata/request", HOST), (ORIGIN, "https://" + HOST)):
                config = {**CONFIG, "target_network": network, "allow_create": True,
                          "data_agent_metadata_api": ORIGIN, "data_agent_workload_host": HOST,
                          "operations_metadata_api": origin, "operations_workload_host": host}
                issues = prerequisites(config, {"operations.lakehouse", "operations.runtime",
                                                "ontology.definition", "data-agent.lakehouse"})
                self.assertEqual(set(issues), {"operations.lakehouse"})
                self.assertIn("operations_metadata_api", issues["operations.lakehouse"][0])

    def test_operations_requires_creation_and_v2_even_with_retained_resources(self):
        config = {**CONFIG, "operations_metadata_api": ORIGIN, "operations_workload_host": HOST,
                  "ux_token_version": "v1", "data_agent_id": AGENT}
        errors = prerequisites(config, {"operations.lakehouse"})["operations.lakehouse"]
        self.assertEqual(len(errors), 2)
        self.assertTrue(any("OA MWC v2" in error for error in errors))
        self.assertTrue(any("AllowCreate" in error and "no reuse" in error for error in errors))
        config.update(ux_token_version="v2", allow_create=True)
        self.assertEqual(prerequisites(config, {"operations.lakehouse", "operations.runtime"}), {})
        self.assertNotIn("operations.lakehouse", prerequisites({**config, "allow_create": False},
                                                              {"operations.lakehouse"}, check_creation=False))

    def test_operations_public_route_fallback_and_selected_timeout_preflight(self):
        config = validate_config({**CONFIG, "target_network": "public", "scenario_timeout": 900})
        config["allow_create"] = True
        self.assertEqual(prerequisites(config, {"ontology.definition", "operations.runtime"}), {})
        errors = prerequisites(config, {"operations.kql"})["operations.kql"]
        self.assertEqual(errors, ["scenario_timeout must exceed operations_generation_timeout for Operations authoring"])
        config["scenario_timeout"] = 901
        self.assertEqual(prerequisites(config, {"operations.kql"}), {})
        config["operations_metadata_api"] = "https://unrelated.example"
        self.assertIn("operations_metadata_api", prerequisites(config, {"operations.kql"})["operations.kql"][0])

    def test_bad_draft_map_and_browser_identity_are_explicit(self):
        for ids in (["bad"], {"data-agent.lakehouse": "not-a-guid"}):
            errors = prerequisites({**CONFIG, "auth": "browser", "data_agent_ids": ids},
                                   {"data-agent.lakehouse"})["data-agent.lakehouse"]
            self.assertTrue(any("client_id" in error for error in errors))
            self.assertTrue(any("GUID" in error or "mapping" in error for error in errors))


class ConfigurationTests(unittest.TestCase):
    def test_existing_service_overrides_are_preserved_without_prompts(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "validation.local.json"
            original = {**CONFIG, "operations_metadata_api": ORIGIN, "operations_workload_host": HOST,
                        "data_agent_metadata_api": ORIGIN, "data_agent_workload_host": HOST}
            path.write_text(json.dumps(original))
            ask = Mock(side_effect=answers)
            self.assertEqual(configure(path, {"operations.lakehouse", "data-agent.lakehouse"}, input_fn=ask), 0)
            self.assertEqual(json.loads(path.read_text()), original)
            self.assertFalse(any("OA /" in call.args[0] or "ML /" in call.args[0] for call in ask.call_args_list))

    def test_operations_wizard_never_prompts_separate_service_routes(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "validation.local.json"
            path.write_text(json.dumps(CONFIG))
            ask = Mock(side_effect=answers)
            self.assertEqual(configure(path, {"operations.lakehouse", "operations.runtime"}, input_fn=ask), 0)
            actual = json.loads(path.read_text())
            self.assertNotIn("operations_metadata_api", actual)
            self.assertNotIn("operations_workload_host", actual)
            self.assertEqual(actual["ux_metadata_api"], ORIGIN)
            self.assertFalse(any("ML /" in call.args[0] or "OA /" in call.args[0] for call in ask.call_args_list))
            self.assertFalse(any("draft" in call.args[0].lower() for call in ask.call_args_list))
            self.assertNotIn("allow_create", actual)

    def test_operations_runtime_only_does_not_prompt_oa_route(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "validation.local.json"
            path.write_text(json.dumps(CONFIG))
            ask = Mock(side_effect=answers)
            self.assertEqual(configure(path, {"operations.runtime"}, input_fn=ask), 0)
            self.assertFalse(any("OA /" in call.args[0] for call in ask.call_args_list))
            self.assertNotIn("operations_metadata_api", json.loads(path.read_text()))

    def test_configure_preserves_settings_and_backups_without_creation_authorization(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "validation.local.json"
            original = {**CONFIG, "timeout": 300, "scenario_timeout": 600,
                        "data_agent_ids": {"data-agent.lakehouse": AGENT}, "allow_create": True}
            path.write_text(json.dumps(original), encoding="utf-8")
            before = path.read_bytes()
            self.assertEqual(configure(path, {"data-agent.lakehouse"}, input_fn=answers), 0)
            actual = json.loads(path.read_text())
            self.assertNotIn("data_agent_metadata_api", actual)
            self.assertNotIn("data_agent_workload_host", actual)
            self.assertEqual(actual["data_agent_ids"], original["data_agent_ids"])
            self.assertEqual(actual["timeout"], 300)
            self.assertNotIn("allow_create", actual)
            self.assertEqual(next(Path(temporary).glob("*.bak")).read_bytes(), before)

    def test_cancel_invalid_route_and_eof_never_change_config(self):
        for answer in (lambda _: "", lambda q: "https://evil.example" if q.startswith("Workspace metadata") else "",
                       Mock(side_effect=EOFError)):
            with self.subTest(answer=answer), tempfile.TemporaryDirectory() as temporary:
                path = Path(temporary) / "validation.local.json"
                path.write_text(json.dumps(CONFIG))
                before = path.read_bytes()
                with self.assertRaises((ValueError, EOFError)):
                    configure(path, {"ontology.definition"}, input_fn=answer)
                self.assertEqual(path.read_bytes(), before)
                self.assertEqual(list(Path(temporary).glob("*.bak")), [])

    def test_incomplete_override_can_be_saved_but_not_reported_ready(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "validation.local.json"
            path.write_text(json.dumps({**CONFIG, "data_agent_metadata_api": ORIGIN}))
            self.assertEqual(configure(path, {"data-agent.lakehouse"},
                                       input_fn=lambda q: "SAVE" if q.startswith("Type SAVE") else ""), 1)
            self.assertNotIn("data_agent_workload_host", json.loads(path.read_text()))

    def test_concurrent_file_change_not_overwritten(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "validation.local.json"
            path.write_text(json.dumps(CONFIG))

            def edit_during_prompt(question):
                if question.startswith("Type SAVE"):
                    path.write_text('{"concurrent": true}')
                    return "SAVE"
                return ""

            with self.assertRaisesRegex(ValueError, "changed during setup"):
                configure(path, {"ontology.definition"}, input_fn=edit_during_prompt)
            self.assertEqual(json.loads(path.read_text()), {"concurrent": True})

    def test_import_only_explicit_target_do_settings_not_tokens_or_service_guesses(self):
        with tempfile.TemporaryDirectory() as temporary:
            manifest = Path(temporary) / "run.manifest.json"
            manifest.write_text(json.dumps({
                "environment": "Daily", "authoringMode": "hybrid", "status": "failed",
                "tenantId": TENANT, "targetWorkspaceId": WORKSPACE,
                "items": {"Ontology": {"id": ONTOLOGY}}, "targetNetwork": "wspl",
                "uxMetadataApi": ORIGIN, "uxExpectedWorkloadHost": HOST,
                "uxTokenVersion": "v2", "authentication": "cli", "Token": "never-copy",
            }))
            result = {}
            import_sample_settings(result, manifest)
            self.assertEqual(result["ux_metadata_api"], ORIGIN)
            self.assertEqual(result["ontology_id"], ONTOLOGY)
            self.assertNotIn("Token", result)
            self.assertNotIn("data_agent_metadata_api", result)
            self.assertNotIn("operations_metadata_api", result)
            self.assertNotIn("operations_workload_host", result)
            with self.assertRaisesRegex(ValueError, "conflicts"):
                import_sample_settings({"workspace_id": AGENT}, manifest)

    def test_new_config_from_manifest_and_main_configure_never_authenticates(self):
        with tempfile.TemporaryDirectory() as temporary, \
                patch("azure.identity.AzureCliCredential") as auth, \
                patch("builtins.input", side_effect=answers):
            root = Path(temporary)
            manifest = root / "run.manifest.json"
            manifest.write_text(json.dumps({
                "environment": "Daily", "authoringMode": "hybrid", "tenantId": TENANT,
                "targetWorkspaceId": WORKSPACE, "items": {"Ontology": {"id": ONTOLOGY}},
                "targetNetwork": "wspl", "uxMetadataApi": ORIGIN, "uxExpectedWorkloadHost": HOST,
            }))
            path = root / "validation.local.json"
            self.assertEqual(main(["--configure", "--config", str(path), "--sample-manifest",
                                   str(manifest), "--agents", "data-agent"]), 0)
            auth.assert_not_called()
            self.assertEqual(json.loads(path.read_text())["workspace_id"], WORKSPACE)


class ReuseTests(unittest.TestCase):
    def test_import_only_selected_ids_without_credentials_or_creation(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "results.json"
            path.write_text(json.dumps({
                "config": {**CONFIG, "allow_create": True, "Token": "never-copy"},
                "resources": {"data_agents": {"data-agent.lakehouse": AGENT, "data-agent.kql": "ignored"},
                              "operations": ["never-copy"]},
            }))
            config = {**CONFIG, "data_agent_ids": {"data-agent.sql": ONTOLOGY,
                                                 "data-agent.lakehouse": TENANT}}
            reuse_data_agents(config, path, {"data-agent.lakehouse"})
            self.assertEqual(config["data_agent_ids"],
                             {"data-agent.sql": ONTOLOGY, "data-agent.lakehouse": AGENT})
            self.assertNotIn("Token", config)
            self.assertNotIn("allow_create", config)
            self.assertNotIn("operations", config)

    def test_reject_mismatched_target_missing_metadata_and_bad_drafts_without_mutation(self):
        cases = [
            {"config": {**CONFIG, key: AGENT},
             "resources": {"data_agents": {"data-agent.lakehouse": AGENT}}}
            for key in ("tenant_id", "workspace_id", "ontology_id")
        ] + [
            {"data_agents": {"data-agent.lakehouse": AGENT}},
            {"config": CONFIG, "resources": {}},
            {"config": CONFIG, "resources": {"data_agents": {"data-agent.kql": AGENT}}},
            {"config": CONFIG, "resources": {"data_agents": {"data-agent.lakehouse": "invalid"}}},
            [],
        ]
        for saved in cases:
            with self.subTest(saved=saved), tempfile.TemporaryDirectory() as temporary:
                path = Path(temporary) / "results.json"
                path.write_text(json.dumps(saved))
                config = dict(CONFIG)
                with self.assertRaises(ValueError):
                    reuse_data_agents(config, path, {"data-agent.lakehouse"})
                self.assertEqual(config, CONFIG)

    def test_reuse_rejects_creation_configuration_and_listing(self):
        for mode in ("--allow-create", "--configure", "--list"):
            with self.subTest(mode=mode), self.assertRaises(SystemExit) as caught:
                main(["--reuse-results", "unused.json", mode])
            self.assertEqual(caught.exception.code, 2)


class RunnerPreflightTests(unittest.TestCase):
    def run_main(self, root, extra, overrides=None):
        config = root / "validation.local.json"
        config.write_text(json.dumps({**CONFIG, **(overrides or {})}))
        return main(["--config", str(config), "--output", str(root / "out"), *extra])

    def test_all_blocked_skips_auth_and_emits_report(self):
        with tempfile.TemporaryDirectory() as temporary, \
                patch("azure.identity.AzureCliCredential") as auth:
            root = Path(temporary)
            self.assertEqual(self.run_main(root, ["--agents", "data-agent", "--allow-create"],
                                           {"data_agent_metadata_api": ORIGIN}), 0)
            auth.assert_not_called()
            report = json.loads((root / "out" / "results.json").read_text())
            selected = [r for r in report["results"] if r["selected"]]
            self.assertEqual(len(selected), 10)
            self.assertTrue(all(r["status"] == "BLOCKED" for r in selected))
            self.assertIn("Configuration preflight", (root / "out" / "report.md").read_text())
            self.assertEqual(len(list((root / "out").glob("*.result.json"))), 10)

    def test_operations_blocks_authoring_but_runtime_is_manual_without_auth(self):
        with tempfile.TemporaryDirectory() as temporary, \
                patch("azure.identity.AzureCliCredential") as auth, \
                patch("validate_sample.importlib.import_module") as importer:
            root = Path(temporary)
            self.assertEqual(self.run_main(root, ["--agents", "operations"]), 0)
            auth.assert_not_called()
            importer.assert_not_called()
            report = json.loads((root / "out" / "results.json").read_text())
            selected = [r for r in report["results"] if r["selected"]]
            self.assertEqual(len(selected), 11)
            self.assertEqual(sum(r["status"] == "BLOCKED" for r in selected), 10)
            runtime = next(r for r in selected if r["scenario"] == "operations.runtime")
            self.assertEqual(runtime["status"], "SKIP")
            self.assertIn("This runtime entry performs no calls", runtime["summary"])
            self.assertNotIn("No creation", runtime["summary"])
            self.assertEqual(len(report["results"]), 43)

    def test_operations_runtime_only_skips_auth_even_without_browser_client(self):
        with tempfile.TemporaryDirectory() as temporary, \
                patch("azure.identity.AzureCliCredential") as cli, \
                patch("sample_auth.open_credential") as browser:
            root = Path(temporary)
            config = root / "validation.local.json"
            config.write_text(json.dumps({**CONFIG, "auth": "browser", "ux_token_version": "v1",
                                          "scenario_timeout": 240}))
            self.assertEqual(main(["--config", str(config), "--output", str(root / "out"),
                                   "--scenarios", "operations.runtime"]), 0)
            cli.assert_not_called()
            browser.assert_not_called()
            report = json.loads((root / "out" / "results.json").read_text())
            self.assertEqual(report["preflight"], {})
            self.assertEqual([r["status"] for r in report["results"] if r["selected"]], ["SKIP"])

    def test_operations_allow_create_does_not_persist_from_json(self):
        with tempfile.TemporaryDirectory() as temporary, patch("azure.identity.AzureCliCredential") as auth:
            root = Path(temporary)
            config = root / "validation.local.json"
            config.write_text(json.dumps({**CONFIG, "operations_metadata_api": ORIGIN,
                                          "operations_workload_host": HOST, "allow_create": True}))
            self.assertEqual(main(["--config", str(config), "--output", str(root / "out"),
                                   "--scenarios", "operations.lakehouse"]), 0)
            auth.assert_not_called()
            report = json.loads((root / "out" / "results.json").read_text())
            self.assertIn("AllowCreate", report["preflight"]["operations.lakehouse"][0])

    def test_authorized_operations_dispatches_ten_authoring_cases_not_runtime(self):
        from validate_sample import SOURCE_CASES

        calls = {f"operations.{case}": Mock(return_value={"status": "PASS", "summary": "preview only"})
                 for case in SOURCE_CASES}
        adapter = Mock(SCENARIOS=calls)
        with tempfile.TemporaryDirectory() as temporary, \
                patch("azure.identity.AzureCliCredential"), \
                patch("validate_sample.ValidationContext") as ctx, \
                patch("validate_sample.importlib.import_module", return_value=adapter) as importer:
            ctx.return_value.state, ctx.return_value.requests = {}, []
            root = Path(temporary)
            config = root / "validation.local.json"
            config.write_text(json.dumps(CONFIG))
            self.assertEqual(main(["--config", str(config), "--output", str(root / "out"),
                                   "--agents", "operations", "--allow-create"]), 0)
            self.assertTrue(ctx.call_args.args[0]["allow_create"])
            self.assertEqual(importer.call_count, 10)
            for call in calls.values():
                call.assert_called_once_with(ctx.return_value)
            report = json.loads((root / "out" / "results.json").read_text())
            self.assertEqual(report["preflight"], {})
            selected = [r for r in report["results"] if r["selected"]]
            self.assertEqual(sum(r["status"] == "PASS" for r in selected), 10)
            runtime = next(r for r in selected if r["scenario"] == "operations.runtime")
            self.assertEqual(runtime["status"], "SKIP")
            self.assertIn("Separate authoring entries may create inactive artifacts", runtime["summary"])

    def test_plan_accepts_shared_workspace_route_without_live_calls(self):
        with tempfile.TemporaryDirectory() as temporary, \
                patch("azure.identity.AzureCliCredential") as auth:
            root = Path(temporary)
            self.assertEqual(self.run_main(root, ["--agents", "ontology", "data-agent",
                                                  "--plan", "--allow-create"]), 0)
            auth.assert_not_called()
            report = json.loads((root / "out" / "results.json").read_text())
            statuses = {r["scenario"]: r["status"] for r in report["results"]}
            self.assertEqual(statuses["ontology.definition"], "SKIP")
            self.assertEqual(statuses["data-agent.lakehouse"], "SKIP")
            self.assertEqual(report["preflight"], {})

    def test_mixed_live_selection_executes_only_ready_scenarios(self):
        ready = Mock(return_value={"status": "PASS", "summary": "definition read"})
        blocked = Mock()
        with tempfile.TemporaryDirectory() as temporary, \
                patch("validate_sample.catalog", return_value={
                    "data-agent.lakehouse": blocked, "ontology.definition": ready}), \
                patch("azure.identity.AzureCliCredential"), \
                patch("validate_sample.ValidationContext") as ctx:
            ctx.return_value.state, ctx.return_value.requests = {}, []
            root = Path(temporary)
            self.assertEqual(self.run_main(root, ["--agents", "ontology", "data-agent",
                                                  "--allow-create", "--strict"],
                                           {"data_agent_metadata_api": ORIGIN}), 1)
            ready.assert_called_once()
            blocked.assert_not_called()


@unittest.skipUnless(shutil.which("powershell"), "Windows PowerShell is unavailable")
class LauncherTests(unittest.TestCase):
    def test_powershell_operations_configure_and_plan_preserve_authorization_boundary(self):
        launcher = Path(__file__).with_name("Start-Validation.ps1")
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            config = root / "validation.local.json"
            config.write_text(json.dumps(CONFIG))
            command = [shutil.which("powershell"), "-NoProfile", "-ExecutionPolicy", "Bypass",
                       "-File", str(launcher), "-Config", str(config), "-Agents", "operations",
                       "-PythonExecutable", sys.executable]
            result = subprocess.run(command + ["-Configure"],
                                    input="\n" * 8 + "SAVE\n",
                                    text=True, capture_output=True, timeout=60, cwd=root)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn("OA / Operations Agent", result.stdout)
            self.assertNotIn("operations_workload_host", json.loads(config.read_text()))
            before = config.read_bytes()
            for allowed in (False, True):
                output = root / str(allowed)
                result = subprocess.run(command + ["-PlanOnly", "-OutputDirectory", str(output)]
                                        + (["-AllowCreate"] if allowed else []),
                                        text=True, capture_output=True, timeout=60, cwd=root)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
                report = json.loads((output / "results.json").read_text())
                self.assertEqual(report["config"]["allow_create"], allowed)
                selected = [r for r in report["results"] if r["selected"]]
                self.assertEqual(len(selected), 11)
                self.assertEqual(sum(r["status"] == "BLOCKED" for r in selected), 0 if allowed else 10)
                self.assertEqual(next(r["status"] for r in selected if r["scenario"] == "operations.runtime"), "SKIP")
                self.assertEqual(report["resources"], {})
            self.assertEqual(config.read_bytes(), before)

    def test_powershell_reuse_plan_preserves_config_and_blocks_missing_drafts(self):
        launcher = Path(__file__).with_name("Start-Validation.ps1")
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            config = root / "validation.local.json"
            config.write_text(json.dumps({**CONFIG, "data_agent_metadata_api": ORIGIN,
                                          "data_agent_workload_host": HOST}))
            before = config.read_bytes()
            previous = root / "previous.json"
            previous.write_text(json.dumps({
                "config": CONFIG, "resources": {"data_agents": {"data-agent.lakehouse": AGENT}},
            }))
            output = root / "plan"
            result = subprocess.run([
                shutil.which("powershell"), "-NoProfile", "-ExecutionPolicy", "Bypass",
                "-File", str(launcher), "-Config", str(config), "-Agents", "data-agent",
                "-ReuseResults", str(previous), "-PlanOnly", "-OutputDirectory", str(output),
                "-PythonExecutable", sys.executable,
            ], text=True, capture_output=True, timeout=60, cwd=root)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertEqual(config.read_bytes(), before)
            report = json.loads((output / "results.json").read_text())
            self.assertFalse(report["config"]["allow_create"])
            self.assertEqual(report["config"]["data_agent_ids"], {"data-agent.lakehouse": AGENT})
            self.assertNotIn("data-agent.lakehouse", report["preflight"])
            self.assertEqual(len(report["preflight"]), 9)

    def test_powershell_configure_then_plan_uses_no_live_calls(self):
        launcher = Path(__file__).with_name("Start-Validation.ps1")
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            path = root / "validation.local.json"
            path.write_text(json.dumps(CONFIG))
            command = [shutil.which("powershell"), "-NoProfile", "-ExecutionPolicy", "Bypass",
                       "-File", str(launcher), "-Config", str(path),
                       "-Agents", "data-agent", "-PythonExecutable", sys.executable]
            result = subprocess.run(command + ["-Configure"],
                                    input="\n" * 8 + "SAVE\n",
                                    text=True, capture_output=True, timeout=60, cwd=root)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn("No tests ran", result.stdout)
            self.assertNotIn("data_agent_workload_host", json.loads(path.read_text()))
            output = root / "plan"
            result = subprocess.run(command + ["-PlanOnly", "-AllowCreate", "-OutputDirectory", str(output)],
                                    text=True, capture_output=True, timeout=60, cwd=root)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            report = json.loads((output / "results.json").read_text())
            self.assertEqual(report["preflight"], {})
            selected = [r for r in report["results"] if r["selected"]]
            self.assertEqual(len(selected), 10)
            self.assertTrue(all(r["status"] == "SKIP" for r in selected))
            self.assertEqual(report["resources"], {})


if __name__ == "__main__":
    unittest.main()
