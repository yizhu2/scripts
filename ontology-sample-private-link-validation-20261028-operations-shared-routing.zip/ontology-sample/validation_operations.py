"""Operations runtime is explicitly untested; no ALM substitute or activation."""

"""Inactive Operations playbook previews, not monitoring or notification tests."""

import re
import time
from contextlib import closing, contextmanager
from decimal import Decimal, InvalidOperation
from functools import partial
from types import SimpleNamespace
from uuid import UUID, uuid4

from create_sample import Api, PBI_SCOPE
from ux_authoring import workload_host, workspace_routing
from validation_common import HttpFailure, InvalidResponse, ScenarioBlocked, sanitize, utc_now
from validation_queries import GROUPS
from validation_setup import MANUAL_SCENARIOS


API_VERSION = {"api-version": "2025-05-01"}
SCOPE = ("Inactive preview authoring and static playbook checks only; the runner does not separately "
         "execute generated queries or test monitoring, rule firing, notifications or external actions.")


def operations_routing(config):
    if config.get("ux_token_version", "v2") != "v2":
        raise ScenarioBlocked("Operations Agent requires OA MWC v2; no v1 fallback")
    try:
        return workspace_routing(config, "operations")
    except ValueError as error:
        raise ScenarioBlocked(f"Operations workspace routing: {error}") from error


@contextmanager
def operations_context(ctx, agent_id, capacity_id):
    origin, expected_host = operations_routing(ctx.config)
    workspace = str(UUID(ctx.config["workspace_id"]))
    agent_id, capacity_id = str(UUID(agent_id)), str(UUID(capacity_id))
    with closing(Api(origin, PBI_SCOPE, ctx.credential, ctx.timeout,
                     sensitive_response=True)) as metadata:
        result = ctx.request(metadata, "POST", origin + "/metadata/v201606/generatemwctokenv2", {
            "workspaceObjectId": workspace, "workloadType": "OA",
            "artifacts": [{"artifactType": "OperationalAgents", "artifactObjectId": agent_id}],
        })
    if not isinstance(result, dict):
        raise InvalidResponse("OA MWC response must be an object")
    host = workload_host(result.get("TargetUriHost"))
    if expected_host and host != expected_host:
        raise ScenarioBlocked("OA routing host mismatch; no workload call or public fallback attempted")
    if result.get("CapacityObjectId") and str(UUID(result["CapacityObjectId"])) != capacity_id:
        raise ScenarioBlocked("OA MWC capacity mismatch; no workload call attempted")
    token = result.get("Token")
    if not isinstance(token, str) or not token:
        raise InvalidResponse("OA MWC response omitted its workload token")
    credential = SimpleNamespace(get_token=lambda *_args, **_kwargs: SimpleNamespace(token=token))
    base = f"https://{host}/webapi/capacities/{capacity_id}/workloads/OA/OAgentsService/automatic"
    with closing(Api(base, PBI_SCOPE, credential, ctx.timeout, auth_scheme="MwcToken")) as api:
        yield api


def preview_configuration(config, case, ontology_name):
    dimensions, readings = GROUPS[case]
    return {
        "goals": "Draft one historical sample temperature rule. Do not start the agent.",
        "instructions": (
            f"Use only {readings}_Readings, {dimensions}_Assets and {dimensions}_Plants "
            f"from the supplied ontology. Create exactly one rule for {readings}_Readings "
            "whose numeric TemperatureC is strictly above 32.5 degrees Celsius. "
            "Keep the rule property named TemperatureC and its condition Is Above 32.5. "
            "Return TemperatureC, ReadingId, AssetId and PlantId, joining each reading's AssetId to the "
            f"AssetId in {dimensions}_Assets and that asset's PlantId to {dimensions}_Plants.PlantId. "
            "Use historical fixture data without a relative-time or now() filter. "
            "Include the backing ontology query and the rule condition in the playbook. "
            "Do not replace an unavailable source group with another group. "
            "Generate a preview only: no activation, schedule, notification recipient, "
            "message destination, external action or source/ontology mutation."
        ),
        "dataSources": {"businessOntology": {
            "id": config["ontology_id"], "type": "Ontology",
            "displayName": ontology_name, "workspaceId": config["workspace_id"],
            # The shared native DTO requires this Eventhouse field even for Ontology.
            "connection": {"tableName": ""},
        }},
        "actions": {},
    }


def assess_playbook(value, case):
    """Check service-rendered rule structure, never count prose as source/query proof."""
    if (not isinstance(value, dict) or not isinstance(value.get("ontology"), str)
            or not isinstance(value.get("rules"), str)):
        raise InvalidResponse("Preview must contain ontology and rules Markdown strings")
    dimensions, readings = GROUPS[case]
    expected = {f"{dimensions}_Assets", f"{dimensions}_Plants", f"{readings}_Readings"}
    rules = value["rules"]
    details = re.findall(r"<details>\s*(.*?)\s*</details>", rules, re.S | re.I)
    check = {
        "scope": "Static service-rendered playbook contract; not query execution or data correctness",
        "expectedEntities": sorted(expected), "queryExecuted": False,
        "ruleCount": len(details), "status": "UNVERIFIED",
    }
    if not details:
        check["reason"] = "No inspectable rule/query/condition structure; prose alone is insufficient"
        return check
    if len(details) != 1:
        check.update(status="FAIL", reason="Expected exactly one rule")
        return check
    queries = re.findall(r"^\s*```(gql|kql|kqldataquery)\s*\n(.*?)^\s*```\s*$",
                         details[0], re.S | re.M | re.I)
    conditions = re.findall(
        r"^\s*\|\s*([^|\r\n]+)\s*\|\s*([^|\r\n]+)\s*\|\s*([^|\r\n]+)\s*\|\s*$",
        details[0], re.M)
    conditions = [tuple(part.strip() for part in row) for row in conditions
                  if row[0].strip().lower() != "property"
                  and not all(re.fullmatch(r"[-: ]+", part) for part in row)]
    check["conditions"] = conditions
    if len(queries) != 1 or len(conditions) != 1:
        check["reason"] = "Expected one inspectable native query and one condition row"
        return check
    prop, condition, threshold = conditions[0]
    try:
        threshold_matches = Decimal(threshold) == Decimal("32.5")
    except InvalidOperation:
        threshold_matches = False
    if prop != "TemperatureC" or condition != "Is Above" or not threshold_matches:
        check.update(status="FAIL", reason="Generated condition differs from TemperatureC Is Above 32.5")
        return check
    language, query = queries[0][0].lower(), queries[0][1].strip()
    check.update(queryLanguage=language, query=query)
    if language != "gql":
        check["reason"] = ("Native KQL query and threshold are inspectable, but physical-source-to-ontology "
                           "binding and requested dimension joins need review; not a source-validation pass")
        return check
    # Strings/comments cannot establish entity selection. This is intentionally a bounded
    # shape check, not a GQL parser or authorization to execute model-produced code.
    code = re.sub(r"'(?:''|\\.|[^'\\])*'|\"(?:\"\"|\\.|[^\"\\])*\"|//[^\n]*|/\*.*?\*/",
                  " ", query, flags=re.S)
    labels = set(re.findall(
        r"\(\s*(?:[A-Za-z_]\w*\s*)?(?::|\bIS\b)\s*`?([A-Za-z_]\w*)`?(?=\s*[{)])",
        code, re.I))
    check["queryEntityLabels"] = sorted(labels)
    if labels != expected:
        check.update(status="FAIL" if labels - expected else "UNVERIFIED",
                     reason="Query entity labels do not establish exactly the requested source groups")
        return check
    identifiers = set(re.findall(r"\b[A-Za-z_]\w*\b", code))
    required = {"TemperatureC", "ReadingId", "AssetId", "PlantId"}
    forbidden = {"INSERT", "DELETE", "UPDATE", "CREATE", "DROP", "SET", "CALL", "MERGE", "LOAD"}
    if {word.upper() for word in identifiers} & forbidden:
        check.update(status="FAIL", reason="Query contains unsupported mutation/procedure keywords")
    elif not required <= identifiers or not re.search(r"\bRETURN\b", code, re.I):
        check["reason"] = "Required reading/dimension properties or RETURN are not inspectable"
    elif re.search(r"\b(?:now|current_timestamp|datetime)\s*\(", code, re.I):
        check["reason"] = "Time expressions require manual review against the historical fixture"
    elif not value["ontology"].strip():
        check["reason"] = "Generated ontology concepts are empty"
    else:
        check.update(status="PASS", reason="One source-specific rule, query shape and threshold inspected")
    return check


def read_state(ctx, api, path, evidence, phase):
    try:
        value = ctx.request(api, "GET", path + "/settings", params=API_VERSION)
        state = value.get("agentState") if isinstance(value, dict) else None
        evidence.setdefault("stateChecks", []).append({"phase": phase, "utc": utc_now(), "agentState": state})
        if state not in ("Inactive", "Unconfigured"):
            raise InvalidResponse(f"Agent state is {state!r}, not Inactive/Unconfigured; no activation was requested")
        return state
    except Exception:
        ctx.state["operations_safety_stop"] = (
            f"Inactive state could not be verified for {evidence['agentId']} ({phase}); "
            "inspect this retained agent before another Operations run.")
        raise


def generate_preview(ctx, api, path, case, evidence):
    read_state(ctx, api, path, evidence, "before")
    evidence["phase"] = "generation"
    primary_error = None
    safety_error = None
    result = None
    scenario_deadline = ctx.deadline
    try:
        configuration = preview_configuration(ctx.config, case, evidence["ontologyDisplayName"])
        ctx.save_evidence("operations-preview-request", configuration)
        evidence["generationPostAttempted"] = True
        ctx.save_evidence("operations-progress", evidence)
        started = time.monotonic()
        deadline = started + ctx.config.get("operations_generation_timeout", 900)
        ctx.deadline = min(scenario_deadline, deadline) if scenario_deadline is not None else deadline
        response = ctx.request(api, "POST", path + "/behaviorModel", configuration, params=API_VERSION)
        if not isinstance(response, dict):
            raise InvalidResponse("Playbook generation response must be an object containing id")
        try:
            playbook = str(UUID(response.get("id", "")))
        except (ValueError, TypeError, AttributeError) as error:
            raise InvalidResponse("Playbook generation response omitted a valid id; POST will not be replayed") from error
        evidence["playbookId"] = playbook
        ctx.state.setdefault("operations_playbooks", {})[ctx.scenario] = playbook
        ctx.save_evidence("operations-progress", evidence)
        model_path = path + "/behaviorModel/" + playbook
        while time.monotonic() < deadline:
            current = ctx.request(api, "GET", model_path + "/status", params=API_VERSION)
            state = current.get("state") if isinstance(current, dict) else None
            evidence["generationStatus"] = current
            evidence["generationSeconds"] = round(time.monotonic() - started, 3)
            ctx.save_evidence("operations-progress", evidence)
            if state == "Failed":
                result = {"status": "FAIL", "summary": "Native playbook generation failed; inspect service error"}
                break
            if state == "Completed":
                if current.get("error"):
                    raise InvalidResponse("Completed generation also returned an error; inspect status evidence")
                value = ctx.request(api, "GET", model_path, params=API_VERSION)
                ctx.save_evidence("operations-playbook", value)
                check = assess_playbook(value, case)
                evidence["playbookCheck"] = check
                result = {
                    "status": "PARTIAL" if check["status"] == "UNVERIFIED" else check["status"],
                    "summary": f"Preview generation completed; static playbook check {check['status']}. "
                               "No monitoring or generated-query execution.",
                }
                break
            if state != "InProgress":
                raise InvalidResponse(f"Unknown playbook generation state: {state!r}")
            time.sleep(min(ctx.config.get("poll_seconds", 5), max(0, deadline - time.monotonic())))
        else:
            raise TimeoutError("Playbook generation budget exhausted; retained agent/model, no POST replay")
    except Exception as error:
        primary_error = error
        evidence["generationError"] = {"type": type(error).__name__, "message": sanitize(str(error))}
    finally:
        ctx.deadline = scenario_deadline
        try:
            read_state(ctx, api, path, evidence, "after")
            evidence["inactiveVerified"] = True
        except Exception as error:
            safety_error = error
            evidence["inactiveVerified"] = False
            evidence["safetyError"] = {"type": type(error).__name__, "message": sanitize(str(error))}
        ctx.save_evidence("operations-progress", evidence)
    if primary_error is not None:
        raise primary_error
    if safety_error is not None:
        raise safety_error
    return result


def authoring(ctx, case):
    evidence = {
        "scope": SCOPE, "runtimeValidated": False, "queryExecuted": False,
        "activatedByRunner": False, "actionsInvokedByRunner": False,
        "notificationsSentByRunner": False, "inactiveVerified": False, "phase": "setup",
    }
    try:
        if ctx.state.get("operations_safety_stop"):
            raise ScenarioBlocked(ctx.state["operations_safety_stop"])
        operations_routing(ctx.config)
        if not ctx.config.get("allow_create"):
            raise ScenarioBlocked("Fresh Operations previews require explicit --allow-create; no existing agents are reused")
        workspace = str(UUID(ctx.config["workspace_id"]))
        metadata = ctx.request(ctx.fabric, "GET", f"{ctx.fabric.base}/workspaces/{workspace}")
        capacity = str(UUID(metadata["capacityId"]))
        ontology = ctx.request(ctx.fabric, "GET",
                               f"{ctx.fabric.base}/workspaces/{workspace}/items/{ctx.config['ontology_id']}")
        if (not isinstance(ontology, dict) or ontology.get("id") != ctx.config["ontology_id"]
                or ontology.get("type") != "Ontology" or not isinstance(ontology.get("displayName"), str)
                or not ontology["displayName"].strip()):
            raise InvalidResponse("Ontology item metadata did not contain the expected identity/type/displayName")
        evidence["ontologyDisplayName"] = ontology["displayName"]
        name = f"OntologySample-Operations-{case}-{uuid4().hex[:12]}"
        evidence["createdDisplayName"] = name
        ctx.state.setdefault("operations_creation_attempts", {})[ctx.scenario] = name
        ctx.save_evidence("operations-resource", evidence)
        item = ctx.mutate(ctx.fabric, f"{ctx.fabric.base}/workspaces/{workspace}/operationsAgents",
                          {"displayName": name, "description": "Inactive sample playbook preview; do not activate."})
        agent = str(UUID(item["id"]))
        evidence.update(agentId=agent, created=True)
        ctx.state.setdefault("operations_agents", {})[ctx.scenario] = agent
        ctx.save_evidence("operations-resource", evidence)
        with operations_context(ctx, agent, capacity) as api:
            path = f"{api.base}/v1/workspaces/{workspace}/operationalagents/{agent}/configuration"
            result = generate_preview(ctx, api, path, case, evidence)
        return {**result, "evidence": evidence}
    except Exception as error:
        evidence["error"] = {"type": type(error).__name__, "message": sanitize(str(error))}
        ctx.save_evidence("operations-progress", evidence)
        status = "ERROR"
        if isinstance(error, TimeoutError):
            status = "TIMEOUT"
        elif isinstance(error, ScenarioBlocked) or (
                isinstance(error, HttpFailure) and evidence["phase"] == "setup"):
            status = "BLOCKED"
        elif isinstance(error, HttpFailure):
            status = "FAIL"
        return {"status": status, "summary": f"Operations {evidence['phase']}: {sanitize(str(error))}",
                "evidence": evidence}


def runtime_not_automated(ctx):
    return {"status": "SKIP", "summary": MANUAL_SCENARIOS["operations.runtime"],
            "evidence": {"runtimeValidated": False, "activated": False}}


SCENARIOS = {f"operations.{case}": partial(authoring, case=case) for case in GROUPS}
SCENARIOS["operations.runtime"] = runtime_not_automated
