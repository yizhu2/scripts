import base64
import hashlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch
from zipfile import ZipFile

import requests
import sdk_bootstrap as sdk

BLOB = "https://test.vsblob.vsassets.io/blob?sig=do-not-log"
BASE = "https://pkgs.dev.azure.com/powerbi/test/flat2/"


def package(files=None):
    stream = io.BytesIO()
    with ZipFile(stream, "w") as archive:
        for name in (files if files is not None else [
            sdk.PREFIX + "Microsoft.AnalysisServices.Core.dll",
            sdk.PREFIX + "Microsoft.AnalysisServices.Tabular.dll",
            sdk.PREFIX + "Microsoft.AnalysisServices.Tabular.Json.dll",
            sdk.PREFIX + "fr/messages.resources.dll",
            "lib/net472/unused.dll",
        ]):
            archive.writestr(name, b"test assembly")
    return stream.getvalue()


def checksum(data):
    return base64.b64encode(hashlib.sha512(data).digest()).decode("ascii")


def response(status=200, data=b"", headers=None):
    result = MagicMock()
    result.__enter__.return_value = result
    result.status_code = status
    result.headers = headers or {}
    result.iter_content.return_value = [data]
    return result


class SdkBootstrapTests(unittest.TestCase):
    def test_download_pins_package_and_never_forwards_token_to_blob(self):
        data = package()
        credential = MagicMock()
        credential.get_token.return_value.token = "test-token"
        with tempfile.TemporaryDirectory() as temporary, patch.object(sdk, "SHA512", checksum(data)), \
                patch("sdk_bootstrap.requests.Session") as session_type:
            session = session_type.return_value.__enter__.return_value
            session.get.side_effect = [
                response(data=json.dumps({"resources": [
                    {"@type": "PackageBaseAddress/3.0.0", "@id": BASE}
                ]}).encode()),
                response(303, headers={"Location": BLOB}),
                response(data=data),
            ]
            root = Path(temporary)
            directory = sdk.install_sdk(credential, root)
            self.assertEqual(directory, root / sdk.VERSION / "lib" / "net8.0")
            self.assertTrue((directory / "Microsoft.AnalysisServices.Tabular.Json.dll").is_file())
            self.assertTrue((directory / "fr" / "messages.resources.dll").is_file())
            self.assertFalse((root / sdk.VERSION / "lib" / "net472").exists())
            credential.get_token.assert_called_once_with(sdk.ADO_SCOPE)
            calls = session.get.call_args_list
            self.assertEqual(calls[0].kwargs["headers"], {"Authorization": "Bearer test-token"})
            self.assertEqual(calls[1].kwargs["headers"], {"Authorization": "Bearer test-token"})
            self.assertEqual(calls[2].kwargs["headers"], {})
            self.assertIn(sdk.VERSION, calls[1].args[0])
            receipt = (root / sdk.VERSION / "receipt.json").read_text()
            self.assertNotIn("test-token", receipt)
            self.assertNotIn("do-not-log", receipt)
            credential.get_token.reset_mock()
            session.get.reset_mock()
            self.assertEqual(sdk.install_sdk(credential, root), directory)
            credential.get_token.assert_not_called()
            session.get.assert_not_called()

    def test_denied_feed_has_actionable_error_without_server_body(self):
        session = MagicMock()
        session.get.return_value = response(403, b"secret response")
        with self.assertRaisesRegex(PermissionError, "Reader access"):
            sdk.fetch(session, sdk.FEED, "token", 1024)

    def test_network_exception_does_not_expose_signed_url(self):
        session = MagicMock()
        session.get.side_effect = requests.ConnectionError(BLOB)
        with self.assertRaises(RuntimeError) as raised:
            sdk.fetch(session, BLOB, "token", 1024, allow_blob=True)
        self.assertNotIn("sig=", str(raised.exception))
        self.assertNotIn("do-not-log", str(raised.exception))
        self.assertIn("ConnectionError", str(raised.exception))

    def test_rejects_untrusted_urls_before_request(self):
        session = MagicMock()
        for url in ("http://pkgs.dev.azure.com/powerbi/a", "https://evil.test/file",
                    "https://pkgs.dev.azure.com/other-org/file", "https://user@pkgs.dev.azure.com/powerbi/a",
                    "https://pkgs.dev.azure.com:444/powerbi/a", "https://test.vsblob.vsassets.io.evil.test/file"):
            with self.subTest(url=url), self.assertRaises(ValueError):
                sdk.fetch(session, url, "token", 1024, allow_blob=True)
        session.get.assert_not_called()

    def test_rejects_blob_redirect_for_feed_index(self):
        session = MagicMock()
        session.get.return_value = response(303, headers={"Location": BLOB})
        with self.assertRaises(ValueError):
            sdk.fetch(session, sdk.FEED, "token", 1024)
        self.assertEqual(session.get.call_count, 1)

    def test_bounds_redirects_and_download_size(self):
        session = MagicMock()
        session.get.return_value = response(303, headers={"Location": sdk.FEED})
        with self.assertRaisesRegex(RuntimeError, "Too many"):
            sdk.fetch(session, sdk.FEED, "token", 1024)
        self.assertEqual(session.get.call_count, 5)
        session.get.return_value = response(data=b"too much")
        with self.assertRaisesRegex(ValueError, "size limit"):
            sdk.fetch(session, sdk.FEED, "token", 2)

    def test_checksum_failure_does_not_extract(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with self.assertRaisesRegex(ValueError, "checksum"):
                sdk.extract_package(package(), root)
            self.assertEqual(list(root.iterdir()), [])

    def test_invalid_archive_path_and_missing_assemblies(self):
        for files in ([sdk.PREFIX + "../escape.dll"], [sdk.PREFIX + "C:escape.dll"],
                      [sdk.PREFIX + "bad\\file.dll"], [sdk.PREFIX + "only.dll"]):
            data = package(files)
            with self.subTest(files=files), tempfile.TemporaryDirectory() as temporary, \
                    patch.object(sdk, "SHA512", checksum(data)):
                with self.assertRaises(ValueError):
                    sdk.extract_package(data, Path(temporary))

    def test_rejects_duplicate_paths_and_extracted_size(self):
        data = package([sdk.PREFIX + "file.dll", sdk.PREFIX + "FILE.dll"])
        with tempfile.TemporaryDirectory() as temporary, patch.object(sdk, "SHA512", checksum(data)):
            with self.assertRaisesRegex(ValueError, "duplicate"):
                sdk.extract_package(data, Path(temporary))
        data = package()
        with tempfile.TemporaryDirectory() as temporary, patch.object(sdk, "SHA512", checksum(data)), \
                patch.object(sdk, "MAX_EXTRACTED", 1):
            with self.assertRaisesRegex(ValueError, "size limit"):
                sdk.extract_package(data, Path(temporary))

    def test_tampered_cache_stops_without_network_or_replacement(self):
        data = package()
        with tempfile.TemporaryDirectory() as temporary, patch.object(sdk, "SHA512", checksum(data)), \
                patch("sdk_bootstrap.requests.Session") as network:
            root = Path(temporary)
            destination = root / sdk.VERSION
            destination.mkdir()
            sdk.extract_package(data, destination)
            (destination / "lib" / "net8.0" / "Microsoft.AnalysisServices.Core.dll").write_bytes(b"changed")
            credential = MagicMock()
            with self.assertRaisesRegex(RuntimeError, "incomplete or damaged"):
                sdk.install_sdk(credential, root)
            credential.get_token.assert_not_called()
            network.assert_not_called()

    def test_bad_checksum_does_not_publish_partial_cache(self):
        session = MagicMock()
        session.get.side_effect = [
            response(data=json.dumps({"resources": [{"@type": "PackageBaseAddress/3.0.0", "@id": BASE}]}).encode()),
            response(data=b"bad package"),
        ]
        with tempfile.TemporaryDirectory() as temporary, patch("sdk_bootstrap.requests.Session") as factory:
            factory.return_value.__enter__.return_value = session
            with self.assertRaisesRegex(ValueError, "checksum"):
                sdk.install_sdk(MagicMock(), Path(temporary))
            self.assertEqual(list(Path(temporary).iterdir()), [])


if __name__ == "__main__":
    unittest.main()
