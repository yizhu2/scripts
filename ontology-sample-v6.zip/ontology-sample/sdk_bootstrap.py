"""Install the pinned Ontology SDK from its authenticated internal NuGet feed."""

import base64
import hashlib
import io
import json
import logging
import stat
from pathlib import Path, PurePosixPath
from tempfile import TemporaryDirectory
from urllib.parse import urljoin, urlsplit
from zipfile import ZipFile

import requests

LOG = logging.getLogger("ontology-sample")
PACKAGE = "microsoft.bi.analysisservices.objectmodels.public.retail.amd64"
VERSION = "170.95.29-ontology"
FEED = "https://pkgs.dev.azure.com/powerbi/MWC/_packaging/workload-digitaloperations-Consumption/nuget/v3/index.json"
ADO_SCOPE = "499b84ac-1321-427f-aa17-267ca6975798/.default"
SHA512 = "iGBVoVVrFHa87xTpXKxYGUEO7df2ys+bJ9GJkPusWoTOtfAI42MRgypCaYGw95YGfBp7qeivYR/KArj/w3k5DA=="
PREFIX = "lib/net8.0/"
REQUIRED = {"Microsoft.AnalysisServices.Core.dll", "Microsoft.AnalysisServices.Tabular.dll"}
MAX_DOWNLOAD = 64 * 1024 * 1024
MAX_EXTRACTED = 128 * 1024 * 1024


def feed_url(url):
    parsed = urlsplit(url)
    return parsed.hostname == "pkgs.dev.azure.com" and parsed.path.startswith("/powerbi/")


def check_url(url, allow_blob=False):
    parsed = urlsplit(url)
    blob = bool(parsed.hostname and parsed.hostname.endswith(".vsblob.vsassets.io"))
    if (parsed.scheme != "https" or parsed.port not in (None, 443) or parsed.username or parsed.password
            or parsed.fragment or not (feed_url(url) or (allow_blob and blob))):
        raise ValueError("SDK feed returned an untrusted download location")


def fetch(session, url, token, limit, allow_blob=False):
    try:
        for _ in range(5):
            check_url(url, allow_blob)
            headers = {"Authorization": f"Bearer {token}"} if feed_url(url) else {}
            with session.get(url, headers=headers, timeout=(30, 120), stream=True, allow_redirects=False) as response:
                if response.status_code in (301, 302, 303, 307, 308):
                    location = response.headers.get("Location")
                    if not location:
                        raise RuntimeError("SDK download redirect contained no location")
                    url = urljoin(url, location)
                    continue
                if response.status_code in (401, 403):
                    raise PermissionError(
                        "SDK download denied (HTTP 401/403). The signed-in account needs Reader access to the "
                        "Power BI workload-digitaloperations-Consumption feed; an approved browser client also "
                        "needs Azure DevOps delegated permission/consent. No Fabric resources were created."
                    )
                if response.status_code != 200:
                    raise RuntimeError(f"SDK download failed with HTTP {response.status_code}; no resources were created")
                data = bytearray()
                for chunk in response.iter_content(chunk_size=1024 * 1024):
                    if len(data) + len(chunk) > limit:
                        raise ValueError("SDK download exceeded its size limit")
                    data.extend(chunk)
                return bytes(data)
    except requests.RequestException as error:
        # Request exceptions can contain signed blob URLs. Report only the exception type.
        raise RuntimeError(f"SDK download network failure ({type(error).__name__}); check feed connectivity") from None
    raise RuntimeError("Too many SDK download redirects")


def relative_file(name):
    path = PurePosixPath(name)
    if (not name.startswith(PREFIX) or path.is_absolute() or ".." in path.parts or "\\" in name
            or ":" in name or path.as_posix() != name):
        raise ValueError("Invalid SDK archive or cache file path")
    return path


def validate_cache(destination):
    try:
        receipt = json.loads((destination / "receipt.json").read_text(encoding="utf-8"))
        if receipt["package"] != PACKAGE or receipt["version"] != VERSION or receipt["sha512"] != SHA512:
            raise ValueError("SDK cache receipt does not match the pinned package")
        hashes = receipt["files"]
        if not isinstance(hashes, dict) or not {PREFIX + name for name in REQUIRED}.issubset(hashes):
            raise ValueError("SDK cache is missing required assemblies")
        for name, digest in hashes.items():
            path = destination.joinpath(*relative_file(name).parts)
            if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
                raise ValueError("SDK cache file integrity check failed")
    except (OSError, ValueError, KeyError, TypeError) as error:
        raise RuntimeError(
            f"SDK cache at {destination} is incomplete or damaged. Remove that specific cache directory "
            "before retrying, or provide -SdkDirectory. No resources were created."
        ) from error
    return destination / "lib" / "net8.0"


def extract_package(data, destination):
    if base64.b64encode(hashlib.sha512(data).digest()).decode("ascii") != SHA512:
        raise ValueError("SDK package checksum does not match the tested version; refusing to load its assemblies")
    hashes = {}
    seen = set()
    size = 0
    with ZipFile(io.BytesIO(data)) as archive:
        for member in archive.infolist():
            if not member.filename.startswith(PREFIX) or member.is_dir():
                continue
            path = relative_file(member.filename)
            if stat.S_ISLNK(member.external_attr >> 16) or member.filename.casefold() in seen:
                raise ValueError("SDK archive contains a symlink or duplicate path")
            seen.add(member.filename.casefold())
            size += member.file_size
            if size > MAX_EXTRACTED:
                raise ValueError("Extracted SDK exceeded its size limit")
            contents = archive.read(member)
            target = destination.joinpath(*path.parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as stream:
                stream.write(contents)
            hashes[member.filename] = hashlib.sha256(contents).hexdigest()
    if not {PREFIX + name for name in REQUIRED}.issubset(hashes):
        raise ValueError("Downloaded SDK package is missing required net8.0 assemblies")
    (destination / "receipt.json").write_text(json.dumps({
        "package": PACKAGE, "version": VERSION, "sha512": SHA512, "files": hashes,
    }, indent=2), encoding="utf-8")


def install_sdk(credential, cache_root=None):
    cache_root = cache_root or Path(__file__).resolve().parent / ".sdk"
    destination = cache_root / VERSION
    if destination.exists():
        return validate_cache(destination)
    LOG.info("Downloading the tested Ontology SDK %s from the internal Power BI package feed", VERSION)
    token = credential.get_token(ADO_SCOPE).token
    with requests.Session() as session:
        index = json.loads(fetch(session, FEED, token, 1024 * 1024))
        resources = [entry["@id"] for entry in index["resources"]
                     if entry.get("@type", "").startswith("PackageBaseAddress/")]
        if len(resources) != 1:
            raise ValueError("SDK feed must advertise exactly one NuGet package base address")
        check_url(resources[0])
        package_url = resources[0].rstrip("/") + f"/{PACKAGE}/{VERSION}/{PACKAGE}.{VERSION}.nupkg"
        data = fetch(session, package_url, token, MAX_DOWNLOAD, allow_blob=True)
    cache_root.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix="sdk-download-", dir=cache_root) as temporary:
        staged = Path(temporary) / VERSION
        staged.mkdir()
        extract_package(data, staged)
        try:
            staged.rename(destination)
        except FileExistsError:
            return validate_cache(destination)
    sdk = validate_cache(destination)
    LOG.info("SDK checksum verified and cached at %s", sdk)
    return sdk
