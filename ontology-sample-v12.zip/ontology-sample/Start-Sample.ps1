#Requires -Version 5.1
[CmdletBinding()]
param(
    [string]$TenantId,
    [string]$CapacityId,
    [string]$WorkspaceId,
    [string]$PythonExecutable,
    [ValidateSet('auto', 'cli', 'browser')][string]$Auth = 'auto',
    [string]$ClientId,
    [string]$SourceWorkspaceName,
    [string]$OntologyName,
    [string]$SourcesManifest,
    [string]$OntologyId,
    [string]$RunDirectory,
    [ValidateRange(30, 86400)][int]$TimeoutSeconds = 1800,
    [ValidateRange(0, 86400)][int]$SettleSeconds = 120,
    [ValidateRange(30, 3600)][int]$KqlRequestTimeoutSeconds = 300,
    [switch]$VerifyOnly,
    [switch]$PlanOnly
)

$ErrorActionPreference = 'Stop'
$python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $python)) {
    if ($PythonExecutable) {
        $launcher = Get-Command $PythonExecutable -ErrorAction Stop
        $pythonArgs = @()
    }
    else {
        $launcher = Get-Command py -ErrorAction SilentlyContinue
        $pythonArgs = @('-3')
        if (-not $launcher) {
            $launcher = Get-Command python -ErrorAction SilentlyContinue
            $pythonArgs = @()
        }
    }
    if (-not $launcher) { throw 'Install Python 3.10 or newer, then run this launcher again.' }
    & $launcher.Source @pythonArgs -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)'
    if ($LASTEXITCODE -ne 0) { throw 'A working Python 3.10+ is required. Use -PythonExecutable if it is not on PATH.' }
    & $launcher.Source @pythonArgs -m venv (Join-Path $PSScriptRoot '.venv')
    if ($LASTEXITCODE -ne 0) { throw 'Python virtual environment creation failed. Install a working Python 3.10+.' }
}

$requirements = Join-Path $PSScriptRoot 'requirements.txt'
$stamp = Join-Path $PSScriptRoot '.venv\ontology-sample.requirements.sha256'
$hash = & $python -c 'import hashlib, pathlib, sys; print(hashlib.sha256(pathlib.Path(sys.argv[1]).read_bytes()).hexdigest())' $requirements
if ($LASTEXITCODE -ne 0) { throw 'Could not read the package requirements.' }
& $python -c 'import azure.identity, azure.storage.filedatalake, pyarrow.parquet, pyodbc, requests, tzdata'
$missingDependencies = $LASTEXITCODE -ne 0
$changedRequirements = -not (Test-Path -LiteralPath $stamp)
if (-not $changedRequirements) { $changedRequirements = (Get-Content -LiteralPath $stamp -Raw).Trim() -ne $hash }
if ($missingDependencies -or $changedRequirements) {
    Write-Host 'Installing the package requirements into the local .venv...'
    & $python -m pip install -r $requirements
    if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Check the pip error and your approved package feed.' }
    Set-Content -LiteralPath $stamp -Value $hash -Encoding ASCII
}

if (-not $TenantId) { $TenantId = Read-Host 'Tenant ID' }
if (-not $CapacityId) { $CapacityId = Read-Host 'Capacity ID for the NEW source workspace' }
if (-not $WorkspaceId) { $WorkspaceId = Read-Host 'Existing target workspace ID where the ontology should be created' }
foreach ($id in @($TenantId, $CapacityId, $WorkspaceId)) {
    $parsed = [guid]::Empty
    if (-not [guid]::TryParse($id, [ref]$parsed)) { throw "Invalid GUID: $id" }
}

$arguments = @(
    (Join-Path $PSScriptRoot 'run_sample.py'),
    '--tenant-id', $TenantId, '--capacity-id', $CapacityId, '--workspace-id', $WorkspaceId,
    '--auth', $Auth, '--timeout', "$TimeoutSeconds",
    '--settle-seconds', "$SettleSeconds", '--kql-request-timeout', "$KqlRequestTimeoutSeconds"
)
foreach ($pair in @(
    @('--client-id', $ClientId),
    @('--source-workspace-name', $SourceWorkspaceName), @('--ontology-name', $OntologyName),
    @('--sources-manifest', $SourcesManifest), @('--ontology-id', $OntologyId),
    @('--run-directory', $RunDirectory)
)) {
    if ($pair[1]) { $arguments += $pair }
}
if ($VerifyOnly) { $arguments += '--verify-only' }
if (-not $PlanOnly) {
    if (-not $VerifyOnly) {
        Write-Host "Normal Daily: create a NEW ontology in target workspace $WorkspaceId."
        if ($SourcesManifest) { Write-Host 'Reusing the supplied successfully verified source manifest.' }
        else { Write-Host 'Creating a separate source workspace with all seven source types.' }
        Write-Host 'This consumes capacity. Existing target items are not overwritten or deleted.'
        if ((Read-Host 'Type CREATE to proceed') -cne 'CREATE') { throw 'Cancelled; no Fabric resources created.' }
    }
    $arguments += '--execute'
}
& $python @arguments
if ($LASTEXITCODE -ne 0) {
    throw 'Sample workflow failed. Read the original Python exception above and the run manifests before retrying; resources were not deleted.'
}
