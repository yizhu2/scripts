"""Create a Gen2 ontology using the UX's native semantic-model import path in normal Daily."""

import argparse
import base64
import json
import logging
import re
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
from tempfile import TemporaryDirectory
from urllib.parse import quote
from uuid import UUID

from create_ontology import validate_inventory
from create_sample import Api, Manifest, PBI_SCOPE, m_literal, sample_tables, wait_for
from replace_ontology import unpack_tmdl
from run_sample import workspace_items
from sample_auth import open_credential

LOG = logging.getLogger("ontology-sample")


def native_create_request(state, name):
    return {
        "artifactType": "Ontology", "displayName": name,
        "description": "Created from the sample semantic model using native Gen2 import.",
        "payloadContentType": "InlineJson",
        "workloadPayload": json.dumps({
            "semanticModelImportConfiguration": {
                "workspaceId": state["workspaceId"], "itemId": state["items"]["SemanticModel"]["id"],
            },
            "featureLevel": 2,
        }),
    }


def wait_for_native_import(pbi, workspace_id, item_id, name, manifest, timeout):
    path = f"{pbi.base}/metadata/artifacts/{item_id}"
    manifest.data["nativePollUrl"] = path
    manifest.save()

    def check():
        item = pbi.json("GET", path)
        manifest.data["nativeArtifact"] = item
        manifest.save()
        if (item.get("objectId", "").lower() != item_id.lower()
                or item.get("folderObjectId", "").lower() != workspace_id.lower()
                or item.get("artifactType") != "Ontology" or item.get("displayName") != name):
            raise ValueError("Native artifact identity does not match the requested ontology")
        properties = item.get("extendedProperties") or {}
        status = item.get("provisionState")
        import_status = properties.get("SemanticModelImportStatus")
        LOG.info("Native ontology state: %s; semantic model import: %s", status, import_status)
        if status == "Failed" or import_status == "Failed":
            raise RuntimeError(f"Native semantic model import failed; inspect nativeArtifact in {manifest.path}")
        if status not in ("InProgress", "Active"):
            raise RuntimeError(f"Unexpected native artifact state: {status!r}")
        if status == "InProgress":
            return None
        if properties.get("FeatureLevel") not in (2, "2") or import_status != "Completed":
            raise RuntimeError("Active artifact did not confirm completed Gen2 native semantic model import")
        manifest.data["verified"]["nativeImport"] = {
            "provisionState": "Active", "featureLevel": 2, "semanticModelImportStatus": "Completed",
        }
        manifest.save()
        return item

    return wait_for(check, timeout, f"native semantic model import for {item_id}")


def create_native_ontology(pbi, workspace_id, state, name, manifest):
    path = f"{pbi.base}/metadata/workspaces/{workspace_id}/artifacts"
    body = native_create_request(state, name)
    manifest.data["nativeCreateRequest"] = {"url": path, "body": body}
    manifest.step("Requesting native Gen2 semantic model import through the UX artifact creation API")
    # A native 202 contains artifact metadata, not a public API Location-based operation.
    response = pbi.request("POST", path, body)
    manifest.data["nativeCreateResponse"] = response.json()
    manifest.data["nativeCreateHttpStatus"] = response.status_code
    manifest.data["nativeCreateRequestId"] = response.headers.get("RequestId")
    manifest.save()
    item_id = str(UUID(manifest.data["nativeCreateResponse"]["objectId"]))
    item = {"id": item_id, "type": "Ontology", "displayName": name, "workspaceId": workspace_id}
    manifest.data["items"]["Ontology"] = item
    manifest.data["createAccepted"] = True
    manifest.save()
    return item


def source_model(export):
    parts = [part for part in export["definition"]["parts"] if part["path"] == "model.bim"]
    if len(parts) != 1 or parts[0]["payloadType"] != "InlineBase64":
        raise ValueError("The semantic model must return exactly one inline model.bim in TMSL format")
    return json.loads(base64.b64decode(parts[0]["payload"], validate=True))["model"]


def verify_source_schema(export):
    source = source_model(export)
    tables = source["tables"]
    indexed = {table["name"]: table for table in tables}
    samples = sample_tables()
    if len(indexed) != len(tables) or set(indexed) != {table.name for table in samples}:
        raise ValueError("This companion supports exactly the shipped Plants/Assets/Readings sample, not arbitrary models")
    types = {"string": "string", "datetime": "dateTime", "double": "double"}
    for sample in samples:
        table = indexed[sample.name]
        columns = table["columns"]
        found = {column["name"]: column["dataType"] for column in columns}
        if (len(found) != len(columns) or found != {name: types[kind] for name, kind in sample.columns}
                or table.get("isHidden") or table.get("measures") or table.get("hierarchies")
                or any(column.get("isHidden") or column.get("type", "data") != "data" for column in columns)):
            raise ValueError(f"Unsupported or changed sample schema for {sample.name}")
    relationships = source.get("relationships", [])
    found = {(r["fromTable"], r["fromColumn"], r["toTable"], r["toColumn"]) for r in relationships}
    expected = {("Assets", "PlantId", "Plants", "PlantId"), ("Readings", "AssetId", "Assets", "AssetId")}
    if (len(relationships) != 2 or found != expected or any(
        r.get("fromCardinality", "many") != "many" or r.get("toCardinality", "one") != "one"
        or r.get("crossFilteringBehavior", "oneDirection") != "oneDirection"
        or r.get("isActive", True) is not True for r in relationships
    )):
        raise ValueError("Semantic model relationships do not match the verified sample")
    return {"tables": 3, "relationships": 2, "measures": 0}


def verify_native_definition(exported, source_export, state):
    """Check the native sample's exported bindings, not deserialize arbitrary TMDL or author a definition."""
    source = source_model(source_export)
    with TemporaryDirectory(prefix="native-import-readback-") as temporary:
        folder = Path(temporary)
        unpack_tmdl(exported["definition"], folder)
        files = {file.relative_to(folder).as_posix(): file.read_text(encoding="utf-8-sig").splitlines()
                 for file in folder.rglob("*.tmdl")}
    expected_files = {"database.tmdl", "model.tmdl", "expressions.tmdl", "relationships.tmdl",
                      "namespaces/default.tmdl", *(f"tables/{table['name']}.tmdl" for table in source["tables"])}
    if set(files) != expected_files or "\tcompatibilityLevel: 1000000" not in files["database.tmdl"]:
        raise ValueError("Unexpected native sample definition files or compatibility level")

    def blocks(lines, depth, kind):
        prefix = "\t" * depth
        result = {}
        for index, line in enumerate(lines):
            if not line.startswith(prefix + kind + " "):
                continue
            name = line[len(prefix + kind + " "):]
            if name in result:
                raise ValueError(f"Duplicate native {kind}: {name}")
            end = index + 1
            while end < len(lines) and (not lines[end].strip() or lines[end].startswith(prefix + "\t")):
                end += 1
            result[name] = lines[index + 1:end]
        return result

    def scalar(lines, depth, name, default=None):
        prefix = "\t" * depth + name + ": "
        found = [line[len(prefix):] for line in lines if line.startswith(prefix)]
        if len(found) > 1:
            raise ValueError(f"Duplicate native property: {name}")
        return found[0] if found else default

    model_refs = [line for line in files["model.tmdl"] if line.startswith("ref table ")]
    if sorted(model_refs) != sorted("ref table " + table["name"] for table in source["tables"]):
        raise ValueError("Native model table references differ from the source sample")
    expression_name = f"DirectQuery to AS - {state['workspaceId']}/{state['items']['SemanticModel']['id']}"
    expression_ref = "'" + expression_name + "'"
    for table in source["tables"]:
        name = table["name"]
        lines = files[f"tables/{name}.tmdl"]
        if [line for line in lines if line and not line.startswith("\t")] != [f"table {name}"]:
            raise ValueError(f"Unexpected native table declaration: {name}")
        columns = blocks(lines, 1, "column")
        expected_columns = {column["name"]: column["dataType"] for column in table["columns"]}
        if set(columns) != set(expected_columns):
            raise ValueError(f"Native columns differ from source: {name}")
        for column, datatype in expected_columns.items():
            if (scalar(columns[column], 2, "dataType") != datatype
                    or scalar(columns[column], 2, "sourceColumn") != column):
                raise ValueError(f"Native column binding differs from source: {name}.{column}")
        partitions = blocks(lines, 1, "partition")
        if set(partitions) != {f"{name}-partition = entity"}:
            raise ValueError(f"Native DirectQuery partition missing: {name}")
        partition = next(iter(partitions.values()))
        if (scalar(partition, 2, "mode") != "directQuery" or partition.count("\t\tsource") != 1
                or scalar(partition, 3, "entityName") != name
                or scalar(partition, 3, "expressionSource") != expression_ref):
            raise ValueError(f"Native source binding differs from expected: {name}")
        annotations = {}
        for line in partition:
            if line.startswith("\t\tannotation "):
                key, separator, value = line[len("\t\tannotation "):].partition(" = ")
                if not separator or key in annotations:
                    raise ValueError(f"Invalid or duplicate native source annotation: {name}")
                annotations[key] = value
        expected_identity = {
            "ONT_WorkspaceId": state["workspaceId"], "ONT_ItemId": state["items"]["SemanticModel"]["id"],
            "ONT_ItemKind": "Dataset", "ONT_ItemName": state["items"]["SemanticModel"]["displayName"],
            "ONT_WorkspaceName": state["workspaceName"],
        }
        if any(annotations.get(key) != value for key, value in expected_identity.items()):
            raise ValueError(f"Native source identity differs from expected: {name}")
    expressions = files["expressions.tmdl"]
    if [line for line in expressions if line and not line.startswith("\t")] != [f"expression {expression_ref} ="]:
        raise ValueError("Native shared expression identity differs from source")
    actual_m = "".join(line.strip() for line in expressions if line.startswith("\t\t"))
    # Public ALM export replaces the workspace display name; partition annotations pin the real source IDs.
    expected_m = set()
    for workspace in (quote(state["workspaceName"], safe=""), "WORKSPACE_NAME_PLACEHOLDER"):
        endpoint = "powerbi://dailyapi.powerbi.com/v1.0/myorg/" + workspace
        expected_m.add(
            f"letSource = AnalysisServices.Database({m_literal(endpoint)}, "
            f"{m_literal(state['items']['SemanticModel']['displayName'])}),"
            'Cubes = Table.Combine(Source[Data]),Cube = Cubes{[Id="Model", Kind="Cube"]}[Data]inCube')
    if actual_m not in expected_m:
        raise ValueError("Native DirectQuery expression does not match the expected semantic model")
    relationships = blocks(files["relationships.tmdl"], 0, "relationship")
    if set(relationships) != {relationship["name"] for relationship in source["relationships"]}:
        raise ValueError("Native relationship names differ from source")
    for relationship in source["relationships"]:
        lines = relationships[relationship["name"]]
        if (scalar(lines, 1, "fromColumn") != f"{relationship['fromTable']}.{relationship['fromColumn']}"
                or scalar(lines, 1, "toColumn") != f"{relationship['toTable']}.{relationship['toColumn']}"
                or scalar(lines, 1, "fromCardinality", "many") != "many"
                or scalar(lines, 1, "toCardinality", "one") != "one"
                or scalar(lines, 1, "crossFilteringBehavior", "oneDirection") != "oneDirection"
                or scalar(lines, 1, "isActive", "true") != "true"):
            raise ValueError(f"Native relationship differs from source: {relationship['name']}")
    return {"boundTables": len(source["tables"]), "relationships": len(relationships), "explicitEntities": 0,
            "sourceIdentityAnnotationsVerified": True}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sources-manifest", type=Path, required=True)
    parser.add_argument("--workspace-id", type=UUID, help="Destination workspace; defaults to source workspace")
    parser.add_argument("--name", default="Ontology_NativeSemanticImport_" + datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S"))
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--auth", choices=("auto", "cli", "browser"), default="auto")
    parser.add_argument("--client-id", type=UUID)
    parser.add_argument("--ontology-id", type=UUID, help="Only with --verify-only; never overwrite an existing item")
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--timeout", type=int, default=1800)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args(argv)
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,88}", args.name) or args.timeout < 30:
        parser.error("Name must start with a letter, use only letters/digits/underscores, be under 90 characters; timeout >=30")
    if args.verify_only != bool(args.ontology_id):
        parser.error("--ontology-id and --verify-only must be supplied together")
    state = json.loads(args.sources_manifest.read_text(encoding="utf-8-sig"))
    validate_inventory(state)
    if state["endpoints"]["fabric"].rstrip("/") != "https://dailyapi.fabric.microsoft.com/v1":
        parser.error("This companion targets normal Daily only")
    target_id = str(args.workspace_id or state["workspaceId"])
    plan = {
        "tenantId": state["tenantId"], "sourceWorkspaceId": state["workspaceId"], "workspaceId": target_id,
        "endpoints": state["endpoints"],
        "semanticModelId": state["items"]["SemanticModel"]["id"], "targetWorkspaceId": target_id,
        "ontologyName": args.name, "sourceManifest": str(args.sources_manifest.resolve()),
        "creationMethod": "Native Gen2 semantic model import through the UX artifact creation API",
        "nativeImportPromoteValidated": False, "expected": {"boundTables": 3, "relationships": 2},
        "nativeCreateRequest": {"url": f"{state['endpoints']['powerbi']}/metadata/workspaces/{target_id}/artifacts",
                                "body": native_create_request(state, args.name)},
        "operation": "verify-only" if args.verify_only else "create",
    }
    if not args.execute:
        print(json.dumps(plan, indent=2))
        return
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logging.getLogger("azure").setLevel(logging.WARNING)
    manifest = Manifest(args.manifest, plan)
    try:
        with open_credential(state["tenantId"], mode=args.auth,
                             client_id=str(args.client_id) if args.client_id else None) as credential, \
                closing(Api(state["endpoints"]["fabric"], PBI_SCOPE, credential, args.timeout, manifest.operation)) as api, \
                closing(Api(state["endpoints"]["powerbi"], PBI_SCOPE, credential, args.timeout)) as pbi:
            source = f"{api.base}/workspaces/{state['workspaceId']}"
            target = f"{api.base}/workspaces/{target_id}"
            manifest.step("Validating source and destination workspaces")
            workspace = api.json("GET", source)
            if (workspace["displayName"] != state["workspaceName"]
                    or workspace.get("capacityId", "").lower() != state["capacityId"].lower()):
                raise ValueError("Source workspace identity changed")
            if not api.json("GET", target).get("capacityId"):
                raise ValueError("Destination workspace must have a Fabric capacity")
            source_item = api.json("GET", source + "/semanticModels/" + plan["semanticModelId"])
            if source_item["displayName"] != state["items"]["SemanticModel"]["displayName"]:
                raise ValueError("Source semantic model was renamed")
            if args.verify_only:
                item = api.json("GET", f"{target}/items/{args.ontology_id}")
                if item.get("type") != "Ontology" or item.get("displayName") != args.name:
                    raise ValueError("Verification target must match the exact ontology name")
            elif any(item["displayName"].casefold() == args.name.casefold() for item in workspace_items(api, target)):
                raise ValueError("An item with this name already exists; refusing to create a duplicate")
            manifest.step("Reading and checking the actual semantic model schema")
            exported = api.mutate(source + "/semanticModels/" + plan["semanticModelId"] + "/getDefinition",
                                  params={"format": "TMSL"})
            manifest.data["sourcePublicDefinition"] = exported
            manifest.save()
            manifest.data["verified"]["sourceSchema"] = verify_source_schema(exported)
            if not args.verify_only:
                item = create_native_ontology(pbi, target_id, state, args.name, manifest)
            manifest.data["items"]["Ontology"] = item
            manifest.step("Waiting for native import and artifact provisioning to complete")
            wait_for_native_import(pbi, target_id, item["id"], args.name, manifest, args.timeout)
            if not args.verify_only:
                manifest.data["writeCompleted"] = True
            manifest.step("Reading the native-generated definition without authoring or replacing it")
            stored = api.mutate(target + "/ontologies/" + item["id"] + "/getDefinition")
            manifest.data["storedPublicDefinition"] = stored
            manifest.save()
            manifest.data["verified"]["publicDefinition"] = verify_native_definition(stored, exported, state)
            manifest.data["nativeImportPromoteValidated"] = True
            manifest.data["queryValidation"] = "Not performed; native import and definition validation only"
            manifest.data["status"] = "succeeded"
            manifest.step("Native Gen2 semantic model import and source bindings verified; data queries not tested")
    except (Exception, KeyboardInterrupt) as error:
        manifest.data.update(status="failed", error=str(error))
        manifest.save()
        LOG.exception("Stopped; inspect %s before retrying. No items were deleted or overwritten.", args.manifest)
        raise


if __name__ == "__main__":
    main()
