import base64
import copy
import io
import json
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import MagicMock, patch

import create_semantic_ontology as companion
from create_ontology import build_definition
from create_sample import sample_tables, semantic_definition
from test_create_ontology import GUID, inventory

NEW_ID = "22222222-2222-4222-8222-222222222222"


def exported(model=None):
    if model is None:
        return {"definition": semantic_definition(sample_tables())}
    return {"definition": {"parts": [{
        "path": "model.bim", "payloadType": "InlineBase64",
        "payload": base64.b64encode(json.dumps({"model": model}).encode()).decode(),
    }]}}


def native_export(state):
    model = companion.source_model(exported())
    reference = f"'DirectQuery to AS - {state['workspaceId']}/{state['items']['SemanticModel']['id']}'"
    files = {
        "database.tmdl": "database\n\tcompatibilityLevel: 1000000\n",
        "model.tmdl": "model Model\n" + "\n".join("ref table " + t["name"] for t in model["tables"]) + "\nref namespace default\n",
        "namespaces/default.tmdl": "namespace default\n\tlineageTag: default\n",
        "expressions.tmdl": (
            f"expression {reference} =\n\t\tlet\n"
            '\t\t    Source = AnalysisServices.Database("powerbi://dailyapi.powerbi.com/v1.0/myorg/'
            f'WORKSPACE_NAME_PLACEHOLDER", "{state["items"]["SemanticModel"]["displayName"]}"),\n'
            '\t\t    Cubes = Table.Combine(Source[Data]),\n'
            '\t\t    Cube = Cubes{[Id="Model", Kind="Cube"]}[Data]\n\t\tin\n\t\t    Cube\n'
            f"\tlineageTag: {GUID}\n"
        ),
        "relationships.tmdl": "\n".join(
            f"relationship {r['name']}\n\tfromColumn: {r['fromTable']}.{r['fromColumn']}\n"
            f"\ttoColumn: {r['toTable']}.{r['toColumn']}\n" for r in model["relationships"]),
    }
    for table in model["tables"]:
        name = table["name"]
        files[f"tables/{name}.tmdl"] = (
            f"table {name}\n\tlineageTag: {GUID}\n"
            + "\n".join(f"\tcolumn {c['name']}\n\t\tdataType: {c['dataType']}\n\t\tlineageTag: {GUID}\n"
                        f"\t\tsourceColumn: {c['name']}\n" for c in table["columns"])
            + f"\tpartition {name}-partition = entity\n\t\tmode: directQuery\n\t\tsource\n"
            f"\t\t\tentityName: {name}\n\t\t\texpressionSource: {reference}\n"
            f"\t\tannotation ONT_WorkspaceId = {state['workspaceId']}\n"
            f"\t\tannotation ONT_ItemId = {state['items']['SemanticModel']['id']}\n"
            "\t\tannotation ONT_ItemKind = Dataset\n"
            f"\t\tannotation ONT_ItemName = {state['items']['SemanticModel']['displayName']}\n"
            f"\t\tannotation ONT_WorkspaceName = {state['workspaceName']}\n"
            "\t\tannotation ONT_PinnedAtUtc = 2026-10-23T03:40:35+00:00\n"
        )
    return {"definition": {"parts": [
        {"path": path, "payloadType": "InlineBase64", "payload": base64.b64encode(text.encode()).decode()}
        for path, text in files.items()
    ]}}


class SemanticOntologyTests(unittest.TestCase):
    def test_native_request_matches_gen2_ux_payload_not_an_authored_definition(self):
        body = companion.native_create_request(inventory(), "Native")
        self.assertEqual(body["artifactType"], "Ontology")
        self.assertEqual(body["payloadContentType"], "InlineJson")
        self.assertEqual(json.loads(body["workloadPayload"]), {
            "semanticModelImportConfiguration": {"workspaceId": GUID, "itemId": GUID}, "featureLevel": 2,
        })
        self.assertNotIn("definition", body)
        self.assertNotIn("creationPayload", body)

    def test_native_202_persists_item_id_without_public_lro_polling(self):
        with tempfile.TemporaryDirectory() as temporary:
            manifest = companion.Manifest(Path(temporary) / "native.json", {})
            pbi = MagicMock()
            pbi.base = "https://wabi-daily-us-east2-redirect.analysis.windows.net"
            response = pbi.request.return_value
            response.status_code = 202
            response.headers = {"RequestId": GUID}
            response.json.return_value = {"objectId": NEW_ID, "provisionState": "InProgress"}
            item = companion.create_native_ontology(pbi, NEW_ID, inventory(), "Native", manifest)
            self.assertEqual(item["id"], NEW_ID)
            self.assertEqual(manifest.data["items"]["Ontology"], item)
            self.assertTrue(manifest.data["createAccepted"])
            self.assertEqual(pbi.request.call_args.args[1], pbi.base + "/metadata/workspaces/" + NEW_ID + "/artifacts")
            payload = json.loads(pbi.request.call_args.args[2]["workloadPayload"])
            self.assertEqual(payload["semanticModelImportConfiguration"]["workspaceId"], GUID)
            pbi.mutate.assert_not_called()
            pbi.json.assert_not_called()

    @patch("create_sample.time.sleep")
    def test_native_poll_requires_active_completed_gen2(self, sleep):
        with tempfile.TemporaryDirectory() as temporary:
            manifest = companion.Manifest(Path(temporary) / "native.json", {})
            pbi = MagicMock()
            pbi.base = "https://wabi-daily-us-east2-redirect.analysis.windows.net"
            active = {"objectId": NEW_ID, "folderObjectId": GUID, "artifactType": "Ontology",
                      "displayName": "Native", "provisionState": "Active",
                      "extendedProperties": {"FeatureLevel": 2, "SemanticModelImportStatus": "Completed"}}
            pending = {**active, "provisionState": "InProgress",
                       "extendedProperties": {"FeatureLevel": 2, "SemanticModelImportStatus": "InProgress"}}
            import_completed = {**pending, "extendedProperties": active["extendedProperties"]}
            pbi.json.side_effect = [pending, import_completed, active]
            self.assertEqual(companion.wait_for_native_import(pbi, GUID, NEW_ID, "Native", manifest, 30), active)
            self.assertEqual(sleep.call_count, 2)
            self.assertEqual(pbi.json.call_count, 3)
            self.assertEqual(manifest.data["verified"]["nativeImport"]["semanticModelImportStatus"], "Completed")
            pbi.request.assert_not_called()
            pbi.mutate.assert_not_called()

    def test_native_poll_rejects_manual_definitions_failures_and_wrong_identities(self):
        for change in ("missing-import", "wrong-generation", "failed", "workspace"):
            with self.subTest(change=change), tempfile.TemporaryDirectory() as temporary:
                manifest = companion.Manifest(Path(temporary) / "native.json", {})
                item = {"objectId": NEW_ID, "folderObjectId": GUID, "artifactType": "Ontology",
                        "displayName": "Native", "provisionState": "Active",
                        "extendedProperties": {"FeatureLevel": 2, "SemanticModelImportStatus": "Completed"}}
                if change == "missing-import":
                    item["extendedProperties"]["SemanticModelImportStatus"] = "None"
                elif change == "wrong-generation":
                    item["extendedProperties"]["FeatureLevel"] = 1
                elif change == "failed":
                    item["provisionState"] = "Failed"
                else:
                    item["folderObjectId"] = NEW_ID
                pbi = MagicMock()
                pbi.base = "https://wabi-daily-us-east2-redirect.analysis.windows.net"
                pbi.json.return_value = item
                with self.assertRaises((RuntimeError, ValueError)):
                    companion.wait_for_native_import(pbi, GUID, NEW_ID, "Native", manifest, 30)
                self.assertNotIn("nativeImport", manifest.data["verified"])
                self.assertEqual(manifest.data["nativeArtifact"], item)

    def test_actual_sample_schema(self):
        self.assertEqual(companion.verify_source_schema(exported()), {"tables": 3, "relationships": 2, "measures": 0})

    def test_changed_or_unsupported_schema_is_rejected(self):
        definition = semantic_definition(sample_tables())
        part = next(p for p in definition["parts"] if p["path"] == "model.bim")
        source = json.loads(base64.b64decode(part["payload"]))["model"]
        for change in ("type", "column", "duplicate", "table", "measure", "hidden", "inactive", "relationship"):
            with self.subTest(change=change):
                model = copy.deepcopy(source)
                table = model["tables"][0]
                if change == "type":
                    table["columns"][0]["dataType"] = "int64"
                elif change == "column":
                    table["columns"].pop()
                elif change == "duplicate":
                    table["columns"].append(table["columns"][0])
                elif change == "table":
                    model["tables"].pop()
                elif change == "measure":
                    table["measures"] = [{"name": "Extra", "expression": "1"}]
                elif change == "hidden":
                    table["isHidden"] = True
                elif change == "inactive":
                    model["relationships"][0]["isActive"] = False
                else:
                    model["relationships"][0]["toColumn"] = "Name"
                with self.assertRaises(ValueError):
                    companion.verify_source_schema(exported(model))

    def test_group_selection_rejects_invalid_values(self):
        for groups in ((), ("SemanticModel", "SemanticModel"), ("Unknown",)):
            with self.assertRaises(ValueError):
                build_definition(inventory(), {"SemanticModel": {}}, "powerbi://dailyapi.powerbi.com", groups=groups)

    def test_native_readback_checks_columns_partition_provenance_and_relationships(self):
        result = companion.verify_native_definition(native_export(inventory()), exported(), inventory())
        self.assertEqual(result, {"boundTables": 3, "relationships": 2, "explicitEntities": 0,
                                  "sourceIdentityAnnotationsVerified": True})
        mutations = (
            ("tables/Plants.tmdl", "dataType: string", "dataType: double"),
            ("tables/Plants.tmdl", "sourceColumn: PlantId", "sourceColumn: City"),
            ("tables/Plants.tmdl", "mode: directQuery", "mode: import"),
            ("tables/Plants.tmdl", "entityName: Plants", "entityName: Other"),
            ("tables/Plants.tmdl", "ONT_ItemId = " + GUID, "ONT_ItemId = " + NEW_ID),
            ("tables/Plants.tmdl", "ONT_WorkspaceId = " + GUID, "ONT_WorkspaceId = " + NEW_ID),
            ("expressions.tmdl", "WORKSPACE_NAME_PLACEHOLDER", "WrongWorkspace"),
            ("expressions.tmdl", '"SemanticModel"', '"WrongModel"'),
            ("relationships.tmdl", "toColumn: Plants.PlantId", "toColumn: Plants.Name"),
            ("model.tmdl", "ref table Plants", "ref table Wrong"),
        )
        for path, old, new in mutations:
            with self.subTest(path=path, old=old):
                response = native_export(inventory())
                part = next(part for part in response["definition"]["parts"] if part["path"] == path)
                text = base64.b64decode(part["payload"]).decode()
                self.assertIn(old, text)
                part["payload"] = base64.b64encode(text.replace(old, new).encode()).decode()
                with self.assertRaises(ValueError):
                    companion.verify_native_definition(response, exported(), inventory())

    def test_native_readback_rejects_missing_tables_and_unsafe_parts(self):
        response = native_export(inventory())
        response["definition"]["parts"].pop()
        with self.assertRaises(ValueError):
            companion.verify_native_definition(response, exported(), inventory())
        response = native_export(inventory())
        response["definition"]["parts"][0]["path"] = "../database.tmdl"
        with self.assertRaises(ValueError):
            companion.verify_native_definition(response, exported(), inventory())

    @patch("create_sample.time.sleep")
    def test_native_pending_timeout_keeps_poll_evidence_without_claiming_success(self, sleep):
        with tempfile.TemporaryDirectory() as temporary:
            manifest = companion.Manifest(Path(temporary) / "native.json", {})
            pbi = MagicMock()
            pbi.base = "https://wabi-daily-us-east2-redirect.analysis.windows.net"
            pbi.json.return_value = {
                "objectId": NEW_ID, "folderObjectId": GUID, "artifactType": "Ontology",
                "displayName": "Native", "provisionState": "InProgress",
                "extendedProperties": {"FeatureLevel": 2, "SemanticModelImportStatus": "Completed"},
            }
            with patch("create_sample.time.monotonic", side_effect=[0, 31]), self.assertRaises(TimeoutError):
                companion.wait_for_native_import(pbi, GUID, NEW_ID, "Native", manifest, 30)
            self.assertNotIn("nativeImport", manifest.data["verified"])
            self.assertEqual(manifest.data["nativeArtifact"]["provisionState"], "InProgress")
            self.assertTrue(manifest.data["nativePollUrl"].endswith(NEW_ID))

    def run_flow(self, folder, extra=(), collision=False, fail_create=False, native_status="Active"):
        state = inventory()
        source = folder / "source.json"
        source.write_text(json.dumps(state), encoding="utf-8")
        result = folder / "result.json"
        definition = native_export(state)
        api = MagicMock()
        api.base = state["endpoints"]["fabric"]

        def get(method, path, **kwargs):
            self.assertEqual(method, "GET")
            if path.endswith("/items"):
                return {"value": [{"displayName": "Second"}] if collision else []}
            if "/semanticModels/" in path:
                return state["items"]["SemanticModel"]
            if "/items/" in path:
                return {"id": NEW_ID, "displayName": "Second", "type": "Ontology"}
            return {"displayName": state["workspaceName"], "capacityId": GUID}

        def mutate(path, body=None, **kwargs):
            if "/semanticModels/" in path:
                self.assertEqual(kwargs, {"params": {"format": "TMSL"}})
                return exported()
            self.assertTrue(path.endswith(NEW_ID + "/getDefinition"))
            return definition

        api.json.side_effect = get
        api.mutate.side_effect = mutate
        pbi = MagicMock()
        pbi.base = state["endpoints"]["powerbi"]
        pbi.json.return_value = {"objectId": NEW_ID, "folderObjectId": GUID, "artifactType": "Ontology",
                                "displayName": "Second", "provisionState": native_status,
                                "extendedProperties": {"FeatureLevel": 2, "SemanticModelImportStatus": "Completed"}}
        pbi.request.return_value.status_code = 202
        pbi.request.return_value.headers = {"RequestId": GUID}
        pbi.request.return_value.json.return_value = {"objectId": NEW_ID, "provisionState": "InProgress"}
        if fail_create:
            pbi.request.side_effect = TimeoutError("Ambiguous create")
        with patch.object(companion, "Api", side_effect=[api, pbi]), \
                patch("create_ontology.build_definition", side_effect=AssertionError("No client-generated definition")), \
                patch("sample_tmdl.serialize", side_effect=AssertionError("No client-side TMDL authoring")), \
                patch.object(companion, "open_credential") as authentication, redirect_stdout(io.StringIO()):
            companion.main(["--sources-manifest", str(source), "--manifest", str(result), "--name", "Second", *extra])
        if "--execute" in extra:
            self.assertTrue(all(call.args[0].endswith("/getDefinition") for call in api.mutate.call_args_list))
            pbi.mutate.assert_not_called()
            if "--verify-only" in extra:
                pbi.request.assert_not_called()
            else:
                pbi.request.assert_called_once_with(
                    "POST", pbi.base + "/metadata/workspaces/" + GUID + "/artifacts",
                    companion.native_create_request(state, "Second"))
        return api, authentication, result

    def test_offline_preview_does_not_authenticate_or_create_manifest(self):
        with tempfile.TemporaryDirectory() as temporary:
            api, auth, result = self.run_flow(Path(temporary))
            auth.assert_not_called()
            api.mutate.assert_not_called()
            self.assertFalse(result.exists())

    def test_create_and_readback_verify_native_completion_and_three_bindings(self):
        with tempfile.TemporaryDirectory() as temporary:
            api, _, result = self.run_flow(Path(temporary), ["--execute"])
            state = json.loads(result.read_text())
            self.assertEqual(state["status"], "succeeded")
            self.assertTrue(state["nativeImportPromoteValidated"])
            self.assertTrue(state["writeCompleted"])
            self.assertEqual(state["verified"]["publicDefinition"],
                             {"boundTables": 3, "relationships": 2, "explicitEntities": 0,
                              "sourceIdentityAnnotationsVerified": True})
            self.assertEqual(state["verified"]["nativeImport"]["semanticModelImportStatus"], "Completed")
            self.assertNotIn("authoredDefinition", state)

    def test_verify_only_has_no_create(self):
        with tempfile.TemporaryDirectory() as temporary:
            api, _, result = self.run_flow(Path(temporary), ["--execute", "--verify-only", "--ontology-id", NEW_ID])
            self.assertNotIn("writeCompleted", json.loads(result.read_text()))
            self.assertTrue(all(call.args[0].endswith("/getDefinition") for call in api.mutate.call_args_list))

    def test_collision_and_ambiguous_creation_leave_failed_manifests(self):
        for failure in ("collision", "ambiguous"):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as temporary:
                folder = Path(temporary)
                with self.assertRaises((ValueError, TimeoutError)):
                    self.run_flow(folder, ["--execute"], collision=failure == "collision",
                                  fail_create=failure == "ambiguous")
                state = json.loads((folder / "result.json").read_text())
                self.assertEqual(state["status"], "failed")
                self.assertNotIn("writeCompleted", state)

    def test_invalid_source_stops_before_native_creation(self):
        with tempfile.TemporaryDirectory() as temporary, \
                patch.object(companion, "verify_source_schema", side_effect=ValueError("Changed source")), \
                patch.object(companion, "create_native_ontology") as create:
            with self.assertRaisesRegex(ValueError, "Changed source"):
                self.run_flow(Path(temporary), ["--execute"])
            create.assert_not_called()
            state = json.loads((Path(temporary) / "result.json").read_text())
            self.assertEqual(state["status"], "failed")
            self.assertFalse(state["nativeImportPromoteValidated"])

    def test_native_failure_preserves_created_id_without_definition_write_or_success(self):
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaisesRegex(RuntimeError, "Native semantic model import failed"):
                self.run_flow(Path(temporary), ["--execute"], native_status="Failed")
            state = json.loads((Path(temporary) / "result.json").read_text())
            self.assertEqual(state["items"]["Ontology"]["id"], NEW_ID)
            self.assertTrue(state["createAccepted"])
            self.assertEqual(state["status"], "failed")
            self.assertFalse(state["nativeImportPromoteValidated"])
            self.assertNotIn("writeCompleted", state)
            self.assertNotIn("storedPublicDefinition", state)


if __name__ == "__main__":
    unittest.main()
