"""Read-only validation configuration discovery for same-workspace Daily WSPL or tenant PL.

Protocol references (extension-ontology, commit 3c3fb3f49a8752c18060b5cf44a582ff05aa98bc):
  test/artifacts/provisioners/metadataApi.mts: GET /metadata/artifacts/{objectId},
      extendedProperties.ChildItems is a JSON string.
  src/tmsl/data/repositories/childEventhouseQueryRepository.ts: CascadeDelete (1)
      dependentArtifactObjectId is the execution database, NOT ontology_kustodb.
  src/tmsl/data/repositories/eventHouseRepository.ts: QueryServiceUri, with the
      workloadPayload.content.queryUri representation as an alternative.
  src/data/repositories/artifactRepository.ts: CascadeDelete wire bit is 1.
  test/artifacts/provisioners/metadataApi.vitest.ts: raw metadata also represents
      that enum as the exact string "CascadeDelete".

Only GET metadata and MWC v2 token acquisition are performed. No SQL/ODBC/TDS
connection, SQL token, source data query, child provisioning, refresh, ontology
edit or agent creation is performed during configuration construction.
Missing settings can be entered in the VM without editing JSON. Operator-observed
child associations are recorded separately from independently verified metadata;
preview.execution.provenance names the asserted execution role, not verification.
"""

import argparse
import copy
import json
import os
import re
import sys
from contextlib import ExitStack, closing, contextmanager
from pathlib import Path
from uuid import UUID, uuid4

from create_ontology import MwcCredential, validate_inventory
from create_sample import PBI_SCOPE, sample_tables
from source_selection import normalize_source_types
from target_routing import TargetApi, target_fabric_api, validate_same_workspace_manifest
from validation_preview import SQL_SUFFIXES, _host, _text, cluster_origin

FRONTEND_COMMIT = "3c3fb3f49a8752c18060b5cf44a582ff05aa98bc"
SOURCE_TYPES = ("Eventhouse", "KQLDatabase", "Lakehouse")
POSITIVE_SCENARIOS = (
    "ontology.definition",
    *(f"{family}.{case}" for family in ("ontology", "mcp", "data-agent", "operations", "preview")
      for case in ("lakehouse", "kql")),
    "generation.lifecycle", "generation.kql",
    *(f"p0.{mode}.{case}" for mode in ("access-baseline", "topology", "resolution")
      for case in ("lakehouse", "kql")),
)


class DiscoveryError(RuntimeError):
    """A bounded diagnostic containing no server bodies or authentication details."""


def require(condition, message):
    if not condition:
        raise DiscoveryError(message)


def guid(value):
    try:
        result = UUID(str(value))
        require(bool(result.int), "An identifier is empty; discovery stopped.")
        return str(result)
    except (ValueError, TypeError, AttributeError):
        raise DiscoveryError("Expected a nonempty GUID in the selected manifests or metadata.") from None


def object_value(value):
    require(isinstance(value, dict), "Expected an object in the selected manifest or metadata.")
    return value


def read_manifest(path):
    try:
        require(path.stat().st_size <= 16 * 1024 * 1024, "Selected manifest exceeds 16 MiB.")
        return object_value(json.loads(path.read_text(encoding="utf-8-sig")))
    except (OSError, ValueError):
        raise DiscoveryError("Cannot read the selected manifest as JSON; no other run was selected.") from None


def expected_host(workspace):
    workspace = UUID(workspace).hex
    return f"{workspace}.z{workspace[:2]}.daily-c.fabric.microsoft.com"


def check_host(host, workspace):
    require(isinstance(host, str) and host.lower() == expected_host(workspace),
            "MWC TargetUriHost is not the selected workspace's Daily private workload host; "
            "no workload request or public fallback was made.")


def metadata_origin(value, route, workspace, network="wspl"):
    from ux_authoring import DAILY_METADATA_API, trusted_origin

    origin = trusted_origin(value)
    if network == "wspl":
        require(origin in (route.removesuffix("/v1"), "https://" + expected_host(workspace)),
                "Observed UX metadata origin must be private and specific to the selected workspace; "
                "global or other-workspace origins are outside this bounded discovery workflow.")
    else:
        require(network == "tenantpl", "Only wspl and tenantpl private networks are supported.")
        require(origin != DAILY_METADATA_API and
                origin.endswith((".analysis.windows.net", ".pbidedicated.windows.net")),
                "Tenant PL requires an explicit observed analysis/pbidedicated UX origin, not public Daily "
                "defaults or a workspace-private endpoint. No route is inferred.")
        # Tenant-addressed origins carry a verifiable tenant ID. Regional UX hosts do
        # not, so they must be explicitly observed and remain pinned to the MWC reply.
        if re.fullmatch(r"https://[0-9a-f]{32}-api\.analysis\.windows\.net", origin):
            require(origin == route.removesuffix("/v1"), "Observed UX origin addresses another tenant.")
    return origin


def configured_host(value, config):
    from ux_authoring import workload_host

    host = workload_host(value)
    if config["target_network"] == "wspl":
        check_host(host, config["workspace_id"])
    else:
        route = target_fabric_api(config["target_network"], config["workspace_id"], config["tenant_id"])
        metadata_origin("https://" + host, route, config["workspace_id"], config["target_network"])
    return host


def validate_mwc_host(value, config):
    require(configured_host(value, config) == config["ux_workload_host"],
            "MWC TargetUriHost differs from the explicitly recorded/entered expected hostname; "
            "no workload request or alternate route was attempted.")


class MissingFields:
    def __init__(self, non_interactive=False, input_fn=None):
        self.non_interactive = non_interactive
        self.input_fn = input_fn or input
        self.configured = []

    def ask(self, field, description, validator):
        require(not self.non_interactive,
                f"Missing {field}; rerun interactively in the VM to enter the observed value. "
                "No authentication fallback or resource creation is performed.")
        try:
            value = self.input_fn(f"{description} ({field}): ").strip()
        except (EOFError, KeyboardInterrupt):
            raise DiscoveryError(f"Input cancelled or unavailable for {field}; no config was written.") from None
        require(bool(value), f"Missing {field}; an explicit observed value is required.")
        result = validator(value)
        self.configured.append(field)
        return result


def initial_missing(config):
    missing = [field for field in ("auth", "ux_metadata_api", "ux_workload_host") if not config.get(field)]
    if config.get("auth") == "browser" and not config.get("client_id"):
        missing.append("client_id")
    return missing


def complete_initial(config, route, prompts):
    missing = initial_missing(config)
    require(not (prompts.non_interactive and missing),
            "Missing settings: " + ", ".join(missing) + ". Rerun interactively in the VM; no request was made.")
    if not config.get("auth"):
        def mode(value):
            require(value in ("cli", "browser"), "Authentication must be cli or browser; auto fallback is disabled.")
            return value
        config["auth"] = prompts.ask("auth", "Choose existing CLI identity or approved browser client: cli/browser", mode)
    if config["auth"] == "browser" and not config.get("client_id"):
        config["client_id"] = prompts.ask("client_id", "Organization-approved browser application GUID", guid)
    if not config.get("ux_metadata_api"):
        config["ux_metadata_api"] = prompts.ask(
            "ux_metadata_api", "Observed working UX metadata HTTPS origin (no path, never a token)",
            lambda value: metadata_origin(value, route, config["workspace_id"], config["target_network"]))
    if not config.get("ux_workload_host"):
        def host(value):
            return configured_host(value, config)
        config["ux_workload_host"] = prompts.ask(
            "ux_workload_host", "Observed working MWC TargetUriHost (hostname only, never its token)", host)


def check_authored_sources(run, sources, workspace):
    model = object_value(object_value(run.get("authoredDefinition")).get("model"))
    tables = model.get("tables")
    require(isinstance(tables, list), "Selected run has no authored source tables.")
    expected = {f"{group}_{table.name}": kind
                for kind, group in (("Lakehouse", "Lakehouse"), ("KQLDatabase", "EventhouseKQL"))
                for table in sample_tables()}
    require(len(tables) == len(expected) and
            {object_value(table).get("name") for table in tables} == set(expected),
            "Only the six individual Lakehouse/Eventhouse sample tables are supported.")
    for table in tables:
        kind = expected[table["name"]]
        partitions = table.get("partitions")
        require(isinstance(partitions, list) and len(partitions) == 1,
                "Each authored sample table must have exactly one source partition.")
        annotations = object_value(partitions[0]).get("annotations")
        require(isinstance(annotations, list), "Authored partition source identities are missing.")
        values = {}
        for entry in annotations:
            entry = object_value(entry)
            name = entry.get("name")
            require(isinstance(name, str) and name not in values, "Invalid or duplicate authored annotations.")
            values[name] = entry.get("value")
        require(guid(values.get("ONT_WorkspaceId")) == workspace and
                guid(values.get("ONT_ItemId")) == guid(sources["items"][kind]["id"]) and
                values.get("ONT_ItemKind") == kind,
                "Authored source identity differs from the selected source inventory.")


def load_inputs(run_path, sources_path, auth=None, client_id=None, timeout=240):
    run, sources = read_manifest(run_path), read_manifest(sources_path)
    require(run.get("environment") == "Daily" and run.get("status") == "succeeded" and
            run.get("authoringMode") in ("public", "ux", "hybrid"),
            "Select a successful Daily run.manifest.json.")
    network = run.get("targetNetwork")
    require(network in ("wspl", "tenantpl") and run.get("sameWorkspace") is True,
            "Discovery supports only explicitly same-workspace Daily WSPL/tenantpl Lakehouse/Eventhouse runs.")
    tenant, workspace = guid(run.get("tenantId")), guid(run.get("targetWorkspaceId"))
    capacity = guid(run.get("capacityId"))
    ontology = guid(object_value(object_value(run.get("items")).get("Ontology")).get("id"))
    route = target_fabric_api(network, workspace, tenant)
    require(run.get("targetFabricApi") == route and run.get("sourceFabricApi") == route,
            "Selected run routing does not match its exact selected private-network Fabric endpoint.")
    require(guid(run.get("sourceWorkspaceId")) == workspace, "Cross-workspace sources are unsupported.")
    require(normalize_source_types(run.get("sourceTypes")) == SOURCE_TYPES and
            normalize_source_types(sources.get("sourceTypes")) == SOURCE_TYPES,
            "Select only Lakehouse and Eventhouse/KQLDatabase sources; mixed or other sources are unsupported.")
    try:
        validate_same_workspace_manifest(sources, workspace, tenant, network)
        validate_inventory(sources)
    except (ValueError, KeyError, TypeError, AttributeError):
        raise DiscoveryError("Source manifest lacks matching successful same-workspace private-network provenance.") from None
    require(guid(sources.get("capacityId")) == capacity, "Manifest capacities disagree.")
    source_items = object_value(run.get("sourceItems"))
    require(set(source_items) == set(SOURCE_TYPES), "Run sourceItems does not match the selected source types.")
    ids = {ontology}
    for kind in SOURCE_TYPES:
        item = object_value(sources["items"][kind])
        selected = object_value(source_items[kind])
        identity = guid(item.get("id"))
        require(identity not in ids, "Ontology and source item identities must be distinct.")
        ids.add(identity)
        require(guid(selected.get("id")) == identity and selected.get("displayName") == item["displayName"],
                "Run sourceItems disagrees with sources.manifest.json; no alternate run was searched.")
        _text(item["displayName"])
    check_authored_sources(run, sources, workspace)
    mode = auth if auth is not None else run.get("authentication")
    if mode not in ("cli", "browser"):
        mode = None
    require(client_id is None or mode == "browser", "--client-id is only valid with browser authentication.")
    if client_id is not None:
        client_id = guid(client_id)
    require(type(timeout) is int and 30 <= timeout <= 1800, "--timeout must be from 30 to 1800 seconds.")
    origin = route.removesuffix("/v1")
    if run.get("uxMetadataApi"):
        origin = metadata_origin(run["uxMetadataApi"], route, workspace, network)
    config = {"tenant_id": tenant, "workspace_id": workspace, "ontology_id": ontology,
              "target_network": network, "authoring_mode": "ux", "auth": mode,
              "ux_token_version": "v2", "timeout": timeout, "conversation_timeout": 900,
              "scenario_timeout": max(1800, timeout),
              "operations_generation_timeout": 900, "poll_seconds": 5, "data_agent_mode": "shared",
              "source_types": list(SOURCE_TYPES), "p0_access": {"context": "authorized"},
              "generation_source_workspace_id": workspace,
              "generation_lakehouse_id": guid(source_items["Lakehouse"]["id"]),
              "generation_kql_database_id": guid(source_items["KQLDatabase"]["id"])}
    if client_id:
        config["client_id"] = client_id
    if run.get("uxMetadataApi"):
        config["ux_metadata_api"] = origin
    if run.get("uxExpectedWorkloadHost"):
        config["ux_workload_host"] = configured_host(run["uxExpectedWorkloadHost"], config)
    return run, sources, config, route, origin


@contextmanager
def open_identity(config):
    # Unlike sample_auth's initial-login helper, this CLI path never opens a browser.
    from azure.identity import AzureCliCredential, InteractiveBrowserCredential

    with ExitStack() as stack:
        if config["auth"] == "cli":
            credential = AzureCliCredential(tenant_id=config["tenant_id"], process_timeout=config["timeout"])
        else:
            credential = InteractiveBrowserCredential(
                tenant_id=config["tenant_id"], client_id=config["client_id"],
                redirect_uri="http://localhost:8400", disable_automatic_authentication=True)
        stack.callback(credential.close)
        try:
            if config["auth"] == "browser":
                credential.authenticate(scopes=[PBI_SCOPE])
            credential.get_token(PBI_SCOPE)
        except Exception:
            raise DiscoveryError("Selected authentication failed. CLI mode requires an existing tenant login; "
                                 "no other credential or browser fallback was attempted.") from None
        yield credential


class DiscoveryApi(TargetApi):
    def request(self, method, path, body=None, **kwargs):
        token_path = self.base + "/metadata/v201606/generatemwctokenv2"
        require(method == "GET" or (method == "POST" and path == token_path),
                "Discovery permits only metadata GETs and MWC v2 token acquisition.")
        try:
            return super().request(method, path, body, **kwargs)
        except Exception as error:
            # Api's own HTTP error prefix is generated locally. Never print the exception,
            # response body, redirect Location, token, or SDK error text.
            match = re.match(re.escape(f"{method} {path}: HTTP ") + r"([1-5][0-9]{2}):", str(error))
            status = f" HTTP {match[1]}." if match else ""
            operation = ("MWC v2 bootstrap" if method == "POST" else
                         "artifact metadata GET" if "/metadata/artifacts/" in path else
                         "workload definition GET" if "/workloads/" in path else "workspace-scoped metadata GET")
            raise DiscoveryError(
                f"Read-only {operation} failed.{status} "
                "Check VM private DNS/network, selected CLI tenant and item permissions. "
                "A 403 alone does not distinguish policy, routing or application permission; "
                "no alternate origin or authentication was attempted."
            ) from None


def request_object(api, path, body=None):
    try:
        return object_value(api.json("GET" if body is None else "POST", api.base + path, body))
    except DiscoveryError:
        raise
    except Exception:
        raise DiscoveryError("Metadata response was not a supported JSON object; response omitted.") from None


def checked_item(api, workspace, item_id, kind, collection="items", display_name=None):
    item = request_object(api, f"/workspaces/{workspace}/{collection}/{item_id}")
    require(guid(item.get("id")) == item_id and item.get("type") == kind,
            "Workspace-scoped item metadata returned a different identity or type.")
    if "workspaceId" in item:
        require(guid(item["workspaceId"]) == workspace, "Live item workspace does not match the selected workspace.")
    _text(item.get("displayName"))
    if display_name is not None:
        require(item["displayName"] == display_name, "A selected source was renamed; manifest no longer matches.")
    return item


def metadata_item(api, item_id, kind, workspace):
    item = request_object(api, "/metadata/artifacts/" + item_id)
    require(guid(item.get("objectId")) == item_id and item.get("artifactType") == kind,
            "Artifact metadata returned a different identity or artifact type.")
    if "workspaceObjectId" in item:
        require(guid(item["workspaceObjectId"]) == workspace,
                "Artifact metadata belongs to another workspace.")
    return item


def child_coordinates(fabric, metadata, config, source_ids, prompts):
    workspace, ontology = config["workspace_id"], config["ontology_id"]
    item = metadata_item(metadata, ontology, "Ontology", workspace)
    extended = object_value(item.get("extendedProperties") or {})
    child_items = extended.get("ChildItems")
    try:
        # This is the wire JSON string, not the SDK's already-flattened properties.
        children = object_value(json.loads(child_items)) if child_items is not None else {}
    except (ValueError, TypeError):
        raise DiscoveryError("Ontology ChildItems metadata is malformed; child provisioning is not performed.") from None
    child = children.get("OntologyEventhouse")
    ontology_relation_verified = bool(child)
    if child:
        child = guid(child)
    else:
        print("Ontology child association is unavailable in metadata. Enter only an operator-observed "
              "ONTOLOGY child, never the source Eventhouse. Its ontology association will be marked configured, "
              "not independently verified; no child will be created.")
        child = prompts.ask("preview.execution.eventhouse_id", "Observed ONTOLOGY child Eventhouse GUID", guid)
    require(child not in source_ids | {ontology}, "Ontology child Eventhouse cannot be a source item.")
    checked_item(fabric, workspace, child, "Eventhouse")
    eventhouse = metadata_item(metadata, child, "KustoEventHouse", workspace)
    if eventhouse.get("parentArtifactObjectId") is not None:
        require(guid(eventhouse["parentArtifactObjectId"]) == ontology, "Child Eventhouse has another parent.")
    relations = eventhouse.get("artifactRelations")
    require(relations is None or isinstance(relations, list), "Child Eventhouse relations metadata is malformed.")
    children = []
    for relation in relations or []:
        settings = object_value(relation).get("settings")
        if (type(settings) is int and settings == 1) or settings == "CascadeDelete":
            children.append(relation.get("dependentArtifactObjectId"))
    require(len(children) <= 1, "Multiple CascadeDelete child databases are ambiguous; nothing was created.")
    database_relation_verified = bool(children)
    if children:
        database = guid(children[0])
    else:
        print("Child KQL relation is unavailable. An operator-observed child database can be configured; "
              "this is not independently verified by the missing relation.")
        database = prompts.ask("preview.execution.database_id", "Observed ONTOLOGY child KQL database GUID", guid)
    require(database not in source_ids | {ontology, child}, "Child KQL database cannot be a source or parent item.")
    checked_item(fabric, workspace, database, "KQLDatabase")
    details = checked_item(fabric, workspace, database, "KQLDatabase", "kqlDatabases")
    properties = object_value(details.get("properties"))
    if properties.get("parentEventhouseItemId") is not None:
        require(guid(properties["parentEventhouseItemId"]) == child,
                "Child KQL database does not belong to the ontology child Eventhouse.")
        database_relation_verified = True
    extended = object_value(eventhouse.get("extendedProperties") or {})
    uri = extended.get("QueryServiceUri")
    if not uri and eventhouse.get("workloadPayload"):
        try:
            payload = object_value(json.loads(eventhouse["workloadPayload"]))
            uri = object_value(json.loads(payload["content"])).get("queryUri")
        except (ValueError, KeyError, TypeError):
            raise DiscoveryError("Child Eventhouse workloadPayload is malformed; no endpoint was inferred.") from None
    database_uri = properties.get("queryServiceUri")
    if uri and database_uri:
        require(cluster_origin(database_uri) == cluster_origin(uri),
                "Child Eventhouse and its KQL database advertise different query endpoints.")
    endpoint_verified = bool(uri or database_uri)
    origin = cluster_origin(uri or database_uri) if endpoint_verified else prompts.ask(
        "preview.execution.cluster_uri", "Observed ONTOLOGY child Kusto HTTPS origin", cluster_origin)
    config.setdefault("discovery", {}).update({
        "execution_provenance": ("metadata-verified" if ontology_relation_verified and
                                 database_relation_verified and endpoint_verified
                                 else "operator-configured-not-independently-verified"),
        "ontology_child_relation_verified": ontology_relation_verified,
        "eventhouse_database_relation_verified": database_relation_verified,
        "child_cluster_verified": endpoint_verified,
        "child_workspace_verified": True,
    })
    return {"workspace_id": workspace, "ontology_id": ontology, "eventhouse_id": child,
            "database_id": database, "cluster_uri": origin, "provenance": "ontology-child-eventhouse"}


def saved_lakehouse_schema(run, sources, workspace):
    """Use only explicit, agreeing schemas on every identity-checked source partition."""
    check_authored_sources(run, sources, workspace)
    schemas = set()
    for table in run["authoredDefinition"]["model"]["tables"]:
        if not table["name"].startswith("Lakehouse_"):
            continue
        source = table["partitions"][0].get("source")
        if (not isinstance(source, dict) or source.get("type") != "entity"
                or source.get("entityName") != table["name"].removeprefix("Lakehouse_")):
            return None
        schema = source.get("schemaName")
        try:
            _text(schema)
        except ValueError:
            return None
        schemas.add(schema)
    return next(iter(schemas)) if len(schemas) == 1 else None


def lakehouse_schema(run, sources, workspace, prompts):
    schema = saved_lakehouse_schema(run, sources, workspace)
    if schema is not None:
        require(schema == "dbo", "The bounded generation adapter requires dbo; saved source schemas are unsupported.")
        return schema, "selected-run-authored-definition-not-live-verified"

    def supported(value):
        require(value == "dbo", "The bounded generation adapter requires an explicitly observed dbo schema.")
        return value

    print("Selected authored source partitions do not provide one unambiguous schema. "
          "Enter the observed Lakehouse SQL schema; no SQL connection or verification will be performed.")
    schema = prompts.ask("preview.sources.lakehouse.schema", "Observed SOURCE Lakehouse SQL schema", supported)
    return schema, "operator-configured-not-independently-verified"


def discover(config, run, sources, route, origin, credential, prompts=None):
    config = copy.deepcopy(config)
    prompts = prompts or MissingFields(non_interactive=True)
    require(not initial_missing(config), "Complete observed UX routing and authentication before any request.")
    origin = config["ux_metadata_api"]
    workspace, ontology = config["workspace_id"], config["ontology_id"]
    schema, schema_provenance = lakehouse_schema(run, sources, workspace, prompts)
    with ExitStack() as stack:
        fabric = stack.enter_context(closing(DiscoveryApi(
            route, PBI_SCOPE, credential, config["timeout"], sensitive_response=True)))
        metadata = stack.enter_context(closing(DiscoveryApi(
            origin, PBI_SCOPE, credential, config["timeout"], sensitive_response=True)))
        workspace_item = request_object(fabric, "/workspaces/" + workspace)
        require(guid(workspace_item.get("id")) == workspace and
                guid(workspace_item.get("capacityId")) == guid(run["capacityId"]),
                "Live target workspace or capacity differs from the selected manifests.")
        checked_item(fabric, workspace, ontology, "Ontology")
        try:
            mwc = MwcCredential(metadata, {"workspaceId": workspace, "capacityId": guid(run["capacityId"])},
                                ontology, token_version="v2",
                                validate_host=lambda host: validate_mwc_host(host, config))
        except DiscoveryError:
            raise
        except Exception:
            raise DiscoveryError("Selected private-network MWC v2 bootstrap returned an unsupported token/routing response; "
                                 "no public fallback was attempted.") from None
        config.update(ux_metadata_api=origin, ux_workload_host=mwc.host.lower())
        workload_base = (f"https://{mwc.host}/webapi/capacities/{guid(run['capacityId'])}"
                         "/workloads/DO/DigitalOperationsService/direct")
        workload = stack.enter_context(closing(DiscoveryApi(
            workload_base, "", mwc, config["timeout"], auth_scheme="MwcToken", sensitive_response=True)))
        definition = request_object(workload, f"/v4/workspaces/{workspace}/ontologies/{ontology}/definition")
        check_authored_sources({"authoredDefinition": definition}, sources, workspace)
        properties = {}
        for kind, collection in (("Eventhouse", "items"), ("Lakehouse", "lakehouses"),
                                 ("KQLDatabase", "kqlDatabases")):
            selected = sources["items"][kind]
            identity = guid(selected["id"])
            details = checked_item(fabric, workspace, identity, kind, display_name=selected["displayName"])
            if collection != "items":
                details = checked_item(fabric, workspace, identity, kind, collection, selected["displayName"])
            properties[kind] = object_value(details.get("properties", {}))
        require(guid(properties["KQLDatabase"].get("parentEventhouseItemId")) ==
                guid(sources["items"]["Eventhouse"]["id"]), "Source KQL database belongs to another Eventhouse.")
        uri = properties["KQLDatabase"].get("queryServiceUri")
        source_cluster = cluster_origin(uri) if uri else prompts.ask(
            "preview.sources.kql.cluster_uri", "Observed SOURCE KQL query HTTPS origin", cluster_origin)
        endpoint = object_value(properties["Lakehouse"].get("sqlEndpointProperties") or {})
        require(endpoint.get("provisioningStatus") in (None, "Success"), "Lakehouse SQL endpoint is not provisioned.")
        if endpoint.get("id") is not None:
            guid(endpoint["id"])
        server = (_host(endpoint["connectionString"], SQL_SUFFIXES) if endpoint.get("connectionString")
                  else prompts.ask("preview.sources.lakehouse.sql_endpoint",
                                   "Observed SOURCE Lakehouse SQL hostname (no connection string)",
                                   lambda value: _host(value, SQL_SUFFIXES)))
        source_ids = {guid(sources["items"][kind]["id"]) for kind in SOURCE_TYPES}
        execution = child_coordinates(fabric, metadata, config, source_ids, prompts)
        catalog = sources["items"]["Lakehouse"]["displayName"]
        config["preview"] = {"execution": execution, "sources": {
            "lakehouse": {"workspace_id": workspace, "item_id": config["generation_lakehouse_id"],
                          "sql_endpoint": server, "sql_database": catalog, "schema": schema},
            "kql": {"workspace_id": workspace, "item_id": config["generation_kql_database_id"],
                    "cluster_uri": source_cluster,
                    "database": config["generation_kql_database_id"]},
        }}
        config.setdefault("discovery", {}).update({
            "configured_fields": list(prompts.configured),
            "ux_route_verification": "mwc-v2-host-and-workload-definition",
            "source_sql_catalog_provenance": "live-fabric-item-metadata",
            "source_sql_schema_provenance": schema_provenance,
            "source_sql_schema_live_verified": False,
        })
    from validate_sample import validate_config
    from validation_setup import prerequisites, unselected_source_reason

    checked = validate_config(copy.deepcopy(config))
    require(not any(unselected_source_reason(checked, name) for name in POSITIVE_SCENARIOS),
            "A positive individual scenario was excluded by source selection.")
    require(not prerequisites(checked, POSITIVE_SCENARIOS, check_creation=False),
            "Discovered settings did not satisfy all 19 positive individual scenario prerequisites.")
    # Creation authorization is deliberately NOT persisted or implied by discovery.
    return config


def check_output(path):
    require(not os.path.lexists(path), "Output config already exists; choose a new path (nothing was overwritten).")
    require(path.parent.is_dir(), "Output config parent directory must already exist.")


def write_exclusive(path, config):
    check_output(path)
    staged = path.with_name("." + path.name + "." + uuid4().hex + ".staging")
    created = False
    try:
        with staged.open("x", encoding="utf-8", newline="\n") as stream:
            created = True
            json.dump(config, stream, indent=2, allow_nan=False)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        # Publishing a hard link is atomic and fails if another process won the name.
        # Unlike replace()/POSIX rename(), this can never overwrite an existing config.
        os.link(staged, path)
    except FileExistsError:
        raise DiscoveryError("Output config collision; the existing file was not overwritten.") from None
    except OSError:
        raise DiscoveryError("Cannot atomically publish config on this filesystem; no replacement was attempted.") from None
    finally:
        if created:
            staged.unlink(missing_ok=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-manifest", type=Path, required=True)
    parser.add_argument("--sources-manifest", type=Path)
    parser.add_argument("--output-config", type=Path, required=True)
    parser.add_argument("--auth", choices=("cli", "browser"))
    parser.add_argument("--client-id")
    parser.add_argument("--timeout", type=int, default=240)
    parser.add_argument("--execute", action="store_true", help="Perform live read-only discovery in the intended VM")
    parser.add_argument("--non-interactive", action="store_true", help="Block on missing settings instead of prompting")
    args = parser.parse_args(argv)
    stage = "manifest/output validation"
    try:
        check_output(args.output_config)
        inputs = load_inputs(args.run_manifest, args.sources_manifest or args.run_manifest.with_name("sources.manifest.json"),
                             args.auth, args.client_id, args.timeout)
        run, sources, config, route, origin = inputs
        if not args.execute:
            print("PLAN ONLY: no authentication, network calls or config write.")
            print(f"Same-workspace {config['target_network']} target: {config['workspace_id']}; "
                  f"ontology: {config['ontology_id']}")
            print("Missing initial settings: " + (", ".join(initial_missing(config)) or "none"))
            if config.get("ux_metadata_api"):
                print("Saved observed metadata origin: " + config["ux_metadata_api"])
            print("Observed UX routing is required before requests; absent child IDs/cluster may be requested later. "
                  "No inferred UX bootstrap is attempted.")
            print(f"Authentication: {config['auth']}; 19 positive individual LH/EH scenarios. "
                  "Read-only metadata and MWC v2 only; no SQL connection, provisioning or fallback. "
                  "Schema uses explicit saved source partitions or a later prompt, never a guess.")
            return 0
        prompts = MissingFields(args.non_interactive)
        stage = "missing-setting prompts"
        complete_initial(config, route, prompts)
        stage = "selected authentication"
        with open_identity(config) as credential:
            stage = "selected private-network metadata and source discovery"
            config = discover(config, run, sources, route, origin, credential, prompts)
        stage = "exclusive config publication"
        write_exclusive(args.output_config, config)
        print("Created complete validation configuration for 19 positive individual LH/EH scenarios. "
              f"Child provenance: {config['discovery']['execution_provenance']}. "
              f"SQL schema provenance: {config['discovery']['source_sql_schema_provenance']} (not live verified). "
              "Discovery made no resource changes. Agent/generation validation still requires explicit "
              "-AllowCreate; runtime, negative-network and browser checks are not certified.")
        return 0
    except DiscoveryError as error:
        print(f"Discovery stopped during {stage}: {error}", file=sys.stderr)
    except Exception:
        print(f"Discovery stopped during {stage}: unsupported input/metadata or local dependency failure; "
              "details omitted to protect credentials. No fallback or resource creation was attempted.", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
