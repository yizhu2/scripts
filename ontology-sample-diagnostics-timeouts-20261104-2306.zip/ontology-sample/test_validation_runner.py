import json
import io
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from validation_common import OperationFailed, ScenarioBlocked, ValidationContext, console, sanitize
from validation_queries import EXPECTED, answer_check, context, definition, mcp, ontology
from validate_sample import SOURCE_CASES, catalog, execute_scenarios, load_config, main, persist, select_scenarios, validate_config


CONFIG = {"tenant_id": "11111111-1111-1111-1111-111111111111",
          "workspace_id": "22222222-2222-2222-2222-222222222222",
          "ontology_id": "33333333-3333-3333-3333-333333333333", "target_network": "public"}


class RunnerTests(unittest.TestCase):
    def test_conversation_timeout_default_bounds_and_legacy_config(self):
        self.assertEqual(validate_config({**CONFIG, "timeout": 120})["conversation_timeout"], 900)
        for value in (30, 7200):
            self.assertEqual(validate_config({**CONFIG, "conversation_timeout": value})["conversation_timeout"], value)
        for value in (29, 7201, True, False, None, "900", 900.0):
            with self.subTest(value=value), self.assertRaisesRegex(ValueError, "conversation_timeout"):
                validate_config({**CONFIG, "conversation_timeout": value})

    def test_timeout_overrides_are_validated_before_auth_and_do_not_rewrite_config(self):
        with tempfile.TemporaryDirectory() as temporary, patch("validate_sample.ValidationContext") as context_class:
            root = Path(temporary)
            config = root / "config.json"
            config.write_text(json.dumps({**CONFIG, "timeout": 120, "conversation_timeout": 10,
                                          "scenario_timeout": 60}))
            before = config.read_bytes()
            args = ["--config", str(config), "--plan", "--conversation-timeout", "900",
                    "--scenario-timeout", "3600", "--output", str(root / "plan")]
            self.assertEqual(main(args), 0)
            saved = json.loads((root / "plan" / "results.json").read_text())
            self.assertEqual(saved["config"]["timeout"], 120)
            self.assertEqual(saved["config"]["conversation_timeout"], 900)
            self.assertEqual(saved["config"]["scenario_timeout"], 3600)
            self.assertFalse(saved["config"]["_explicit_ux_routing"])
            self.assertEqual(config.read_bytes(), before)
            self.assertIn("conversation_timeout=900", (root / "plan" / "report.md").read_text())
            context_class.assert_not_called()
            for key, value in (("conversation_timeout", 29), ("scenario_timeout", 7201)):
                with self.subTest(key=key), self.assertRaisesRegex(ValueError, key):
                    load_config(config, **{"conversation_timeout": 900, "scenario_timeout": 3600, key: value})

    def test_omitted_overrides_preserve_configured_conversation_budget(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "config.json"
            path.write_text(json.dumps({**CONFIG, "conversation_timeout": 1200, "scenario_timeout": 3600}))
            actual = load_config(path)
            self.assertEqual(actual["conversation_timeout"], 1200)
            self.assertEqual(actual["scenario_timeout"], 3600)

    def test_timeout_overrides_reject_setup_only_modes(self):
        for args in (["--list", "--conversation-timeout", "900"],
                     ["--configure", "--scenario-timeout", "3600"]):
            with self.subTest(args=args), patch("sys.stderr", new=io.StringIO()), self.assertRaises(SystemExit) as error:
                main(args)
            self.assertEqual(error.exception.code, 2)

    def test_data_agent_mode_defaults_to_shared_and_requires_explicit_isolation(self):
        self.assertEqual(validate_config(dict(CONFIG))["data_agent_mode"], "shared")
        self.assertEqual(validate_config({**CONFIG, "data_agent_mode": "isolated"})["data_agent_mode"], "isolated")
        for mode in ("per-source", "", None, True, 1):
            with self.subTest(mode=mode), self.assertRaisesRegex(ValueError, "data_agent_mode"):
                validate_config({**CONFIG, "data_agent_mode": mode})

    def test_console_output_cannot_abort_on_windows_encoding(self):
        output = io.BytesIO()
        stream = io.TextIOWrapper(output, encoding="cp1252")
        console("Unexpected server text \u2705 | Bearer opaque-secret", file=stream)
        stream.flush()
        self.assertIn(b"\\u2705", output.getvalue())
        self.assertNotIn(b"opaque-secret", output.getvalue())

    def test_listing_does_not_import_optional_adapters(self):
        with patch("validate_sample.importlib.import_module", side_effect=ImportError("optional adapter")) as importer:
            scenarios = catalog()
            self.assertIn("generation.lifecycle", scenarios)
            importer.assert_not_called()
            with self.assertRaises(ImportError):
                scenarios["generation.lifecycle"](Mock())

    def test_select_names_groups_and_unknown(self):
        names = {"ontology.definition": None, "ontology.lakehouse": None, "mcp.lakehouse": None}
        self.assertEqual(select_scenarios(names), {"ontology.definition"})
        self.assertEqual(select_scenarios(names, agents=["mcp"]), {"mcp.lakehouse"})
        self.assertEqual(select_scenarios(names, scenarios=["*.lakehouse"]),
                         {"ontology.lakehouse", "mcp.lakehouse"})
        with self.assertRaises(ValueError):
            select_scenarios(names, scenarios=["typo"])

    def test_operations_catalog_and_lazy_dispatch(self):
        names = catalog()
        expected = {f"operations.{case}" for case in SOURCE_CASES} | {"operations.runtime"}
        self.assertEqual(select_scenarios(names, agents=["operations"]), expected)
        self.assertEqual(select_scenarios(names, scenarios=["operations.*"]), expected)
        adapter = Mock()
        adapter.SCENARIOS = {name: Mock(return_value={"status": "PASS", "summary": "preview only"})
                             for name in expected}
        ctx = Mock()
        with patch("validate_sample.importlib.import_module", return_value=adapter) as importer:
            for name in sorted(expected - {"operations.runtime"}):
                self.assertEqual(names[name](ctx)["status"], "PASS")
                adapter.SCENARIOS[name].assert_called_once_with(ctx)
            self.assertTrue(all(call.args == ("validation_operations",) for call in importer.call_args_list))

    def test_operations_timeout_validation_is_independent_of_selection(self):
        self.assertEqual(validate_config(dict(CONFIG))["operations_generation_timeout"], 900)
        for timeout in (30, 3600):
            self.assertEqual(validate_config({**CONFIG, "operations_generation_timeout": timeout})[
                "operations_generation_timeout"], timeout)
        for timeout in (True, False, 29, 3601, 900.0, "900", None):
            with self.subTest(timeout=timeout), self.assertRaisesRegex(ValueError, "operations_generation_timeout"):
                validate_config({**CONFIG, "operations_generation_timeout": timeout})
        # A small budget remains valid for unrelated checks; Ops preflight enforces its own budget.
        self.assertEqual(validate_config({**CONFIG, "scenario_timeout": 240})["scenario_timeout"], 240)

    def test_report_distinguishes_operations_authoring_from_runtime(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary)
            persist(path, {"startedUtc": "test", "state": "completed", "results": []})
            text = (path / "report.md").read_text()
            self.assertIn("Operations authoring: one fresh inactive artifact per run", text)
            self.assertIn("Operations runtime remains SKIP", text)
            self.assertIn("no independent query execution", text)
            self.assertIn("Operations authoring PASS requires native Completed", text)
            self.assertIn("TemperatureC or TemperatureCelsius Is Above 32.5", text)
            self.assertIn("reported Inactive/Unconfigured before and after", text)
            self.assertIn("not data-correctness or trigger validation", text)
            self.assertIn("operations_agents/operations_playbooks", text)
            self.assertIn("no automatic deletion or cross-run reuse", text)
            self.assertIn("blocks later Operations previews", text)
            self.assertIn("Not a Private Link certification", text)
            self.assertIn("source/lineage proof is informational", text)
            stored = json.loads((path / "results.json").read_text())
            self.assertFalse(stored["assessmentPolicy"]["sourceEvidenceRequired"])

    def test_failure_isolation_and_incremental_report(self):
        def fail(_):
            raise ValueError("unexpected test error | does not stop following checks")

        def blocked(_):
            raise ScenarioBlocked("Missing optional service route")

        def timeout(_):
            raise TimeoutError("Finite budget")

        scenarios = {"a": fail, "b": blocked, "c": timeout,
                     "d": lambda _: {"status": "PASS", "summary": "Last scenario executed"}}
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary)
            report = {"startedUtc": "test", "state": "running", "results": [
                {"scenario": name, "selected": True, "status": "PENDING", "summary": ""}
                for name in scenarios]}
            ctx = Mock(state={"retained": "item"})
            execute_scenarios(scenarios, set(scenarios), ctx, report, path)
            self.assertEqual([row["status"] for row in report["results"]],
                             ["ERROR", "BLOCKED", "TIMEOUT", "PASS"])
            self.assertIn("Last scenario executed", (path / "report.md").read_text())
            self.assertEqual(len(list(path.glob("*.result.json"))), 4)
            self.assertIn("retained", (path / "results.json").read_text())

    def test_interrupt_persists_current_result(self):
        def interrupt(_):
            raise KeyboardInterrupt()
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary)
            report = {"startedUtc": "test", "state": "running", "results": [
                {"scenario": "a", "selected": True, "status": "PENDING", "summary": ""}]}
            with self.assertRaises(KeyboardInterrupt):
                execute_scenarios({"a": interrupt}, {"a"}, Mock(state={}), report, path)
            self.assertEqual(json.loads((path / "a.result.json").read_text())["status"], "ERROR")

    def test_config_error_still_writes_report(self):
        with tempfile.TemporaryDirectory() as temporary, patch("validate_sample.catalog", return_value={"a": None}):
            path = Path(temporary)
            config = path / "bad.json"
            config.write_text("{}")
            output = path / "output"
            self.assertEqual(main(["--config", str(config), "--output", str(output), "--scenarios", "a"]), 2)
            self.assertTrue((output / "report.md").is_file())
            self.assertEqual(json.loads((output / "results.json").read_text())["results"][0]["status"], "BLOCKED")

    def test_plan_never_authenticates(self):
        with tempfile.TemporaryDirectory() as temporary, patch("validate_sample.catalog", return_value={"a": Mock()}) as cat:
            path = Path(temporary)
            config = path / "config.json"
            config.write_text(json.dumps(CONFIG))
            self.assertEqual(main(["--config", str(config), "--output", str(path / "out"),
                                   "--scenarios", "a", "--plan"]), 0)
            cat.return_value["a"].assert_not_called()

    def test_strict_changes_only_exit_code_not_failure_isolation(self):
        scenarios = {"a": lambda _: {"status": "FAIL", "summary": "Service failed"},
                     "b": lambda _: {"status": "PASS", "summary": "Still ran"}}
        for strict in (False, True):
            with self.subTest(strict=strict), tempfile.TemporaryDirectory() as temporary, \
                    patch("validate_sample.catalog", return_value=scenarios), \
                    patch("azure.identity.AzureCliCredential"), \
                    patch("validate_sample.ValidationContext") as context_type:
                context_type.return_value.state = {}
                context_type.return_value.requests = []
                path = Path(temporary)
                config = path / "config.json"
                config.write_text(json.dumps(CONFIG))
                argv = ["--config", str(config), "--output", str(path / "out"), "--scenarios", "a", "b"]
                result = main(argv + (["--strict"] if strict else []))
                self.assertEqual(result, int(strict))
                results = json.loads((path / "out" / "results.json").read_text())["results"]
                self.assertEqual([row["status"] for row in results], ["FAIL", "PASS"])

    def test_private_mode_requires_pinned_hosts_and_never_uses_public_default(self):
        with tempfile.TemporaryDirectory() as temporary:
            config = Path(temporary) / "config.json"
            for value in ({**CONFIG, "target_network": "wspl"},
                          {**CONFIG, "target_network": "tenantpl", "ux_metadata_api":
                           "https://wabi-daily-us-east2-redirect.analysis.windows.net",
                           "ux_workload_host": "test.pbidedicated.windows.net"}):
                config.write_text(json.dumps(value))
                with self.assertRaises(ValueError):
                    load_config(config)
            config.write_text(json.dumps({**CONFIG, "allow_create": True}))
            self.assertFalse(load_config(config)["allow_create"])

    def test_retry_selection_includes_partial_and_unfinished(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "results.json"
            path.write_text(json.dumps({"results": [
                {"scenario": name, "status": status, "selected": True}
                for name, status in (("a", "PARTIAL"), ("b", "PASS"), ("c", "RUNNING"))]}))
            self.assertEqual(select_scenarios({"a": None, "b": None, "c": None}, previous=path), {"a", "c"})

    def test_report_and_json_redact_tokens_and_escape_table_cells(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary)
            report = {"startedUtc": "test", "state": "completed", "resources": {"accessToken": "opaque-secret"},
                      "results": [{"scenario": "a", "selected": True, "status": "ERROR",
                                   "summary": "Bearer opaque-secret | another\nline"}]}
            persist(path, report)
            for name in ("report.md", "results.json"):
                self.assertNotIn("opaque-secret", (path / name).read_text())
            self.assertIn("\\|", (path / "report.md").read_text())
        self.assertNotIn("abc", sanitize("https://x/?sig=abc"))


class QueryTests(unittest.TestCase):
    def test_fixture_answer_requires_all_fields(self):
        self.assertEqual(answer_check(json.dumps(EXPECTED))["status"], "PASS")
        self.assertEqual(answer_check(json.dumps({**EXPECTED, "TemperatureC": 99}))["status"], "FAIL")
        self.assertEqual(answer_check("A012 32.9 East Plant")["status"], "UNVERIFIED")
        self.assertEqual(answer_check(json.dumps({**EXPECTED, "ObservedAt": "2026-01-01T00:45:00+00:00"}))["status"], "PASS")

    def test_plan_context_is_json_string(self):
        actual = json.loads(context(CONFIG)["fabricOntology.context"])
        self.assertEqual(actual["MutationMode"], 0)
        self.assertTrue(actual["MutationModeExplicit"])
        self.assertEqual(actual["OntologyId"], CONFIG["ontology_id"])

    def test_known_utc_fixture_accepts_timezone_less_timestamp_spellings(self):
        for timestamp in ("2026-01-01T00:45:00", "2026-01-01 00:45:00", "2026-01-01T00:45:00.000000"):
            with self.subTest(timestamp=timestamp):
                result = answer_check(json.dumps({**EXPECTED, "ObservedAt": timestamp}))
                self.assertEqual(result["status"], "PASS")
                self.assertEqual(result["actual"]["ObservedAt"], EXPECTED["ObservedAt"])
                self.assertEqual(result["timestampNormalization"]["input"], timestamp)
                self.assertEqual(result["timestampNormalization"]["assumedTimeZone"], "UTC")

    def test_timestamp_normalization_preserves_instant_and_rejects_bad_answers(self):
        equivalent = answer_check(json.dumps({**EXPECTED, "ObservedAt": "2025-12-31T19:45:00-05:00"}))
        self.assertEqual(equivalent["status"], "PASS")
        self.assertNotIn("timestampNormalization", equivalent)
        for timestamp in (None, "", "invalid", "2026-01-01", "2026-01-01T00:46:00",
                          "2026-01-01T00:45:00+05:00", "2026-01-01T00:45:00.001", False, 0):
            with self.subTest(timestamp=timestamp):
                result = answer_check(json.dumps({**EXPECTED, "ObservedAt": timestamp}))
                self.assertEqual(result["status"], "FAIL")
                self.assertIn("ObservedAt", result["mismatches"])

    def test_resolver_failure_is_an_observation_not_an_exception(self):
        ctx = Mock(config=CONFIG)
        ctx.workload.return_value.__enter__ = Mock(return_value=Mock(base="https://test.pbidedicated.windows.net"))
        ctx.workload.return_value.__exit__ = Mock(return_value=False)
        ctx.request.return_value = {"model": {"tables": [{"name": "Lakehouse_Plants", "partitions": [
            {"name": "Plants", "annotations": [{"name": "ONT_RESOLVED_State", "value": "Failed"},
                                              {"name": "ONT_RESOLVED_Error", "value": "ResolutionUnavailable"}]}]}]}}
        result = definition(ctx)
        self.assertEqual(result["status"], "PARTIAL")
        self.assertEqual(result["evidence"]["resolverIssues"][0]["errors"], ["ResolutionUnavailable"])

    def test_correct_prose_does_not_claim_source_execution(self):
        api = Mock(base="https://test.pbidedicated.windows.net")
        ctx = Mock(config=CONFIG, state={})
        ctx.workload.return_value.__enter__ = Mock(return_value=api)
        ctx.workload.return_value.__exit__ = Mock(return_value=False)
        ctx.request.side_effect = [{"id": "test"}, [
            {"role": "assistant", "contents": [{"$type": "text", "text": json.dumps(EXPECTED)}]}]]
        ctx.poll_conversation.return_value = {"status": "completed"}
        result = ontology(ctx, "lakehouse")
        body = ctx.request.call_args_list[0].args[3]
        self.assertIn("additionalContext", body)
        self.assertNotIn("additionalContext", body["initialMessage"])
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["evidence"]["answerCheck"]["status"], "PASS")
        self.assertFalse(result["evidence"]["executionVerified"])
        self.assertFalse(result["evidence"]["sourceEvidenceRequired"])

    def test_ontology_failed_or_incomplete_answers_are_not_upgraded(self):
        for state, text, expected in (("failed", json.dumps(EXPECTED), "FAIL"),
                                      ("completed", "Only A012 was returned", "PARTIAL"),
                                      ("completed", json.dumps({**EXPECTED, "TemperatureC": 99}), "FAIL")):
            ctx = Mock(config=CONFIG, state={})
            ctx.workload.return_value.__enter__ = Mock(return_value=Mock(base="https://test"))
            ctx.workload.return_value.__exit__ = Mock(return_value=False)
            ctx.request.side_effect = [{"id": "test"}, [
                {"role": "assistant", "contents": [{"$type": "text", "text": text}]}]]
            ctx.poll_conversation.return_value = {"status": state}
            self.assertEqual(ontology(ctx, "lakehouse")["status"], expected)

    def test_mcp_fixture_correct_answers_pass_without_lineage(self):
        for text, expected in ((json.dumps(EXPECTED), "PASS"),
                               (json.dumps({**EXPECTED, "AssetId": "A011"}), "FAIL"),
                               ("Only A012 was returned", "PARTIAL")):
            ctx = Mock(config=CONFIG)
            ctx.fabric.base = "https://test"
            ctx.request.side_effect = [{"id": 1, "result": {}}, {"id": 2, "result": {}},
                                       {"id": 3, "result": {"content": [{"type": "text", "text": text}]}}]
            result = mcp(ctx, "lakehouse")
            self.assertEqual(result["status"], expected)
            self.assertFalse(result["evidence"]["executionVerified"])

    def test_mcp_error_empty_and_wrong_rpc_id_fail(self):
        for reply in ({"jsonrpc": "2.0", "id": 9, "result": {}},
                      {"jsonrpc": "2.0", "id": 1, "error": {"code": 500}}):
            ctx = Mock(config=CONFIG)
            ctx.fabric.base = "https://dailyapi.fabric.microsoft.com/v1"
            ctx.request.return_value = reply
            with self.assertRaises(RuntimeError):
                mcp(ctx, "lakehouse")


class TransportTests(unittest.TestCase):
    def test_completed_response_after_conversation_deadline_is_not_accepted(self):
        clock = [0.0]
        with tempfile.TemporaryDirectory() as temporary, \
                patch("validation_common.time.monotonic", side_effect=lambda: clock[0]):
            ctx = ValidationContext({**CONFIG, "conversation_timeout": 30}, Mock(), temporary)
            def request(*args):
                clock[0] = 31
                return {"status": "completed"}
            ctx.request = Mock(side_effect=request)
            try:
                ctx.begin("test")
                with self.assertRaisesRegex(TimeoutError, "Conversation did not finish in 30s"):
                    ctx.poll_conversation(ctx.fabric, "/conversation")
                ctx.request.assert_called_once()
                self.assertIsNone(ctx._conversation_deadline)
            finally:
                ctx.close()

    def test_conversation_can_outlast_http_timeout_without_increasing_request_budget(self):
        clock = [0.0]
        def sleep(seconds):
            clock[0] += seconds
        with tempfile.TemporaryDirectory() as temporary, \
                patch("validation_common.time.monotonic", side_effect=lambda: clock[0]), \
                patch("validation_common.time.sleep", side_effect=sleep):
            ctx = ValidationContext({**CONFIG, "timeout": 120, "poll_seconds": 60}, Mock(), temporary)
            budgets = []
            def request(*args):
                budgets.append(ctx.remaining())
                return {"status": "completed" if clock[0] >= 180 else "inProgress"}
            ctx.request = Mock(side_effect=request)
            try:
                ctx.begin("test")
                self.assertEqual(ctx.poll_conversation(ctx.fabric, "/conversation"), {"status": "completed"})
                self.assertEqual(clock[0], 180)
                self.assertEqual(budgets, [120] * 4)
                self.assertEqual(ctx.conversation_timeout, 900)
                self.assertIsNone(ctx._conversation_deadline)
            finally:
                ctx.close()

    def test_conversation_and_scenario_deadlines_are_independent_and_exact(self):
        for conversation, scenario, expected_time, message in (
                (180, 900, 180, "Conversation did not finish in 180s"),
                (900, 150, 150, "Scenario time budget exhausted")):
            clock = [0.0]
            def sleep(seconds):
                clock[0] += seconds
            with self.subTest(conversation=conversation), tempfile.TemporaryDirectory() as temporary, \
                    patch("validation_common.time.monotonic", side_effect=lambda: clock[0]), \
                    patch("validation_common.time.sleep", side_effect=sleep):
                ctx = ValidationContext({**CONFIG, "timeout": 120, "conversation_timeout": conversation,
                                         "scenario_timeout": scenario, "poll_seconds": 60}, Mock(), temporary)
                ctx.request = Mock(return_value={"status": "inProgress"})
                try:
                    ctx.begin("test")
                    with self.assertRaisesRegex(TimeoutError, message):
                        ctx.poll_conversation(ctx.fabric, "/conversation")
                    self.assertEqual(clock[0], expected_time)
                    self.assertEqual(ctx.request.call_count, 3)
                    self.assertIsNone(ctx._conversation_deadline)
                    self.assertEqual(ctx.timeout, 120)
                finally:
                    ctx.close()

    def test_poll_http_timeout_is_capped_and_deadline_is_restored_on_errors(self):
        from requests import Response
        with tempfile.TemporaryDirectory() as temporary, patch("validation_common.time.monotonic", return_value=100):
            ctx = ValidationContext({**CONFIG, "timeout": 240, "conversation_timeout": 30}, Mock(), temporary)
            response = Response()
            response.status_code = 200
            response._content = b'{"status":"completed"}'
            response._content_consumed = True
            ctx.fabric.session = Mock()
            ctx.fabric.session.request.return_value.__enter__ = Mock(return_value=response)
            ctx.fabric.session.request.return_value.__exit__ = Mock(return_value=False)
            try:
                ctx.begin("test")
                self.assertEqual(ctx.poll_conversation(ctx.fabric, ctx.fabric.base + "/conversation")["status"], "completed")
                self.assertEqual(ctx.fabric.session.request.call_args.kwargs["timeout"], (30, 30))
                self.assertEqual(ctx.remaining(), 240)
                ctx.request = Mock(side_effect=ValueError("invalid response"))
                with self.assertRaisesRegex(ValueError, "invalid response"):
                    ctx.poll_conversation(ctx.fabric, ctx.fabric.base + "/conversation")
                self.assertIsNone(ctx._conversation_deadline)
                self.assertEqual(ctx.remaining(), 240)
            finally:
                ctx.close()

    def test_failed_operation_preserves_sanitized_error_without_retry(self):
        with tempfile.TemporaryDirectory() as temporary, patch("validation_common.time.sleep"):
            ctx = ValidationContext(CONFIG, Mock(), temporary)
            operation = ctx.fabric.base + "/operations/test"
            accepted = Mock(status_code=202, headers={"Location": operation})
            failed = Mock()
            failed.json.return_value = {"status": "Failed", "error": {
                "errorCode": "Unknown", "message": "unknown error; Bearer private-token",
                "isRetriable": False, "accessToken": "never-copy",
            }}
            ctx.exchange = Mock(side_effect=[accepted, failed])
            try:
                with self.assertRaises(OperationFailed) as caught:
                    ctx.mutate(ctx.fabric, ctx.fabric.base + "/items/test/getDefinition", None)
                error = caught.exception
                self.assertEqual(error.operation, operation)
                self.assertEqual(error.operation_error["errorCode"], "Unknown")
                self.assertFalse(error.operation_error["isRetriable"])
                self.assertNotIn("private-token", str(error))
                self.assertNotIn("never-copy", str(error))
                self.assertIn("unknown error", str(error))
                self.assertEqual([call.args[1] for call in ctx.exchange.call_args_list], ["POST", "GET"])
                self.assertEqual(ctx.state["operations"], [operation])
            finally:
                ctx.close()

    def test_missing_operation_error_and_sensitive_url_are_safe(self):
        error = OperationFailed("https://test/operations/id?sig=private-signature", "Failed", None)
        self.assertEqual(error.operation_error, {})
        self.assertNotIn("private-signature", str(error))
        self.assertNotIn("private-signature", error.operation)

    def test_sensitive_response_never_written_to_disk(self):
        from requests import Response
        with tempfile.TemporaryDirectory() as temporary:
            response = Response()
            response.status_code = 200
            response._content = b'{"Token":"opaque-topsecret"}'
            response._content_consumed = True
            ctx = ValidationContext(CONFIG, Mock(), temporary)
            ctx.fabric.sensitive_response = True
            ctx.fabric.session = Mock()
            ctx.fabric.session.request.return_value.__enter__ = Mock(return_value=response)
            ctx.fabric.session.request.return_value.__exit__ = Mock(return_value=False)
            try:
                ctx.begin("test")
                result = ctx.request(ctx.fabric, "POST", ctx.fabric.base + "/generatemwctokenv2", {})
                self.assertEqual(result["Token"], "opaque-topsecret")
                self.assertNotIn("opaque-topsecret", (Path(temporary) / "test.http.json").read_text())
            finally:
                ctx.close()

    def test_socket_timeout_is_bounded_and_recorded(self):
        import requests
        with tempfile.TemporaryDirectory() as temporary:
            ctx = ValidationContext(CONFIG, Mock(), temporary)
            ctx.fabric.session = Mock()
            ctx.fabric.session.request.side_effect = requests.exceptions.ReadTimeout("socket expired")
            try:
                ctx.begin("test")
                with self.assertRaises(TimeoutError):
                    ctx.exchange(ctx.fabric, "POST", ctx.fabric.base + "/query", {})
                self.assertEqual(ctx.fabric.session.request.call_count, 1)
                ledger = json.loads((Path(temporary) / "test.http.json").read_text())
                self.assertEqual(ledger[0]["error"]["type"], "ReadTimeout")
            finally:
                ctx.close()

    def test_cross_origin_prevented_before_token_or_http(self):
        with tempfile.TemporaryDirectory() as temporary:
            credential = Mock()
            ctx = ValidationContext(CONFIG, credential, temporary)
            try:
                ctx.begin("test")
                with self.assertRaises(RuntimeError):
                    ctx.exchange(ctx.fabric, "GET", "https://unrelated.example/v1")
                credential.get_token.assert_not_called()
            finally:
                ctx.close()

    def test_empty_http_success_not_json_success_and_no_write_retry(self):
        from requests import Response
        for status in (200, 403, 503):
            with self.subTest(status=status), tempfile.TemporaryDirectory() as temporary:
                response = Response()
                response.status_code = status
                response._content = b""
                response._content_consumed = True
                ctx = ValidationContext(CONFIG, Mock(), temporary)
                ctx.fabric.session = Mock()
                ctx.fabric.session.request.return_value.__enter__ = Mock(return_value=response)
                ctx.fabric.session.request.return_value.__exit__ = Mock(return_value=False)
                try:
                    ctx.begin("test")
                    with self.assertRaises(RuntimeError):
                        ctx.request(ctx.fabric, "POST", ctx.fabric.base + "/test", {})
                    self.assertEqual(ctx.fabric.session.request.call_count, 1)
                    kwargs = ctx.fabric.session.request.call_args.kwargs
                    self.assertFalse(kwargs["allow_redirects"])
                    self.assertTrue((Path(temporary) / "test.http.json").exists())
                finally:
                    ctx.close()


if __name__ == "__main__":
    unittest.main()
