"""Bounded HTTP evidence and shared context for standalone scenario validation."""

import json
import re
import sys
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4

import requests

from create_sample import PBI_SCOPE, same_origin_url
from target_routing import TargetApi, target_fabric_api
from ux_authoring import open_workload


class ScenarioBlocked(RuntimeError):
    """A scenario lacks a required, explicitly configured prerequisite."""


class InvalidResponse(RuntimeError):
    """The service responded, but did not return the required response contract."""


class HttpFailure(RuntimeError):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


class OperationFailed(RuntimeError):
    def __init__(self, operation, status, error):
        self.operation = sanitize(operation)
        self.operation_error = sanitize({
            key: error[key] for key in ("errorCode", "message", "isRetriable")
            if isinstance(error, dict) and key in error
        })
        super().__init__(f"Operation did not succeed: {sanitize(status)!r}; "
                         f"service error: {json.dumps(self.operation_error)}; "
                         f"operation: {self.operation}; inspect HTTP evidence")


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def console(message, file=None):
    stream = file or sys.stdout
    text = str(sanitize(message))
    encoding = getattr(stream, "encoding", None) or "utf-8"
    print(text.encode(encoding, errors="backslashreplace").decode(encoding), file=stream, flush=True)


def sanitize(value, secrets=()):
    if isinstance(value, dict):
        return {
            sanitize(str(key), secrets): "[REDACTED]" if any(part in re.sub(r"[^a-z]", "", str(key).lower())
                                       for part in ("token", "authorization", "password", "secret", "cookie"))
            else sanitize(item, secrets)
            for key, item in value.items()
        }
    if isinstance(value, (tuple, list)):
        return [sanitize(item, secrets) for item in value]
    if isinstance(value, str):
        for secret in secrets:
            if secret:
                value = value.replace(secret, "[REDACTED]")
        value = re.sub(r"eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+", "[REDACTED JWT]", value)
        value = re.sub(r"(?i)\b(Bearer|MwcToken)\s+\S+", r"\1 [REDACTED]", value)
        value = re.sub(r"(?i)([?&](?:sig|token|access_token|code)=)[^&\s\"']+", r"\1[REDACTED]", value)
        value = re.sub(r"(?i)(;\s*Token\s*=)[^;\s\"'\\)]+", r"\1[REDACTED]", value)
        value = re.sub(r'(?i)("?(?:token|access_token|refresh_token|password|client_secret|authorization)"?\s*[:=]\s*)("[^"]*"|[^\s,;]+)',
                       r'\1"[REDACTED]"', value)
        return value
    return value


def write_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(sanitize(value), indent=2, ensure_ascii=True), encoding="utf-8")
    temporary.replace(path)


class ValidationContext:
    def __init__(self, config, credential, directory):
        self.config = config
        self.credential = credential
        self.directory = Path(directory)
        self.timeout = config.get("timeout", 240)
        self.conversation_timeout = config.get("conversation_timeout", 900)
        self._conversation_deadline = None
        self.fabric = TargetApi(target_fabric_api(config["target_network"], config["workspace_id"],
                                                 config["tenant_id"]), PBI_SCOPE, credential, self.timeout)
        self.state = {}
        self.scenario = "setup"
        self.requests = []
        self.deadline = None
        self.progress_at = 0
        self._secrets = set()

    def close(self):
        self.fabric.close()
        self._secrets.clear()

    def redact(self, value):
        return sanitize(value, self._secrets)

    def begin(self, name):
        self.scenario = name
        self.requests = []
        self.deadline = time.monotonic() + self.config.get("scenario_timeout", 1800)

    def remaining(self):
        budget = self.timeout
        if self.deadline is not None:
            remaining = self.deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError("Scenario time budget exhausted; no write replay was attempted")
            budget = min(budget, remaining)
        if self._conversation_deadline is not None:
            remaining = self._conversation_deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError(f"Conversation did not finish in {self.conversation_timeout}s; "
                                   "inspect retained conversation")
            budget = min(budget, remaining)
        return budget

    def save_evidence(self, label, data):
        if not re.fullmatch(r"[A-Za-z0-9_.-]+", label):
            raise ValueError("Evidence labels must be simple file names")
        path = self.directory / f"{self.scenario}.{label}.json"
        write_json(path, self.redact(data))
        write_json(self.directory / "resources.json", self.state)
        return str(path)

    def exchange(self, api, method, url, body=None, params=None):
        """One bounded request; no redirects, retries, or ambiguous write replays."""
        url = same_origin_url(api.base, url)
        entry = {"utc": utc_now(), "method": method, "url": url, "params": params,
                 "clientRequestId": str(uuid4())}
        preview_request = self.scenario.startswith("preview.") or (
            self.scenario.startswith("p0.") and url.endswith("/v2/rest/query"))
        if preview_request:
            entry.update(clientRequestId="Ontology;" + entry["clientRequestId"], request=self.redact(body))
        self.requests.append(entry)
        self.save_evidence("http", self.requests)
        started = time.monotonic()
        if method != "GET" or started - self.progress_at >= 30:
            console(f"[{self.scenario}] {method} {url}")
            self.progress_at = started
        response = None
        try:
            token = api.credential.get_token(api.scope).token
            if isinstance(token, str):
                self._secrets.add(token)
            budget = self.remaining()
            with api.session.request(
                method, url, json=body, params=params,
                headers={"Authorization": f"{api.auth_scheme} {token}",
                         "x-ms-client-request-id": entry["clientRequestId"],
                         **({"x-ms-app": "Ontology", "Accept": "application/json"}
                            if preview_request else {})},
                allow_redirects=False, timeout=(min(30, budget), budget), stream=True,
            ) as response:
                # Bound SSE/streaming responses by total elapsed time, not only socket inactivity.
                content = bytearray()
                # Check every byte: a trickling SSE response must not keep a large buffered read alive indefinitely.
                for chunk in response.iter_content(chunk_size=1):
                    if time.monotonic() - started > budget:
                        raise TimeoutError("HTTP total time budget exceeded")
                    self.remaining()
                    content.extend(chunk)
                    if len(content) > 16 * 1024 * 1024:
                        raise RuntimeError("Response exceeded the 16 MiB evidence limit")
                response._content = bytes(content)
                response._content_consumed = True
            entry.update(
                httpStatus=response.status_code, responseByteLength=len(response.content),
                headers=self.redact({key: value for key, value in response.headers.items()
                         if key.lower() in ("requestid", "activityid", "x-ms-request-id",
                                            "x-ms-correlation-request-id", "x-ms-root-activity-id",
                                            "x-ms-activity-id", "x-ms-client-request-id",
                                            "content-type", "content-length", "location", "retry-after")}),
            )
            # Token exchange bodies never enter reports or the evidence bundle.
            if api.sensitive_response or "generatemwctoken" in url.lower():
                entry["response"] = "[sensitive response omitted]"
            else:
                try:
                    entry["response"] = self.redact(response.json())
                except ValueError:
                    entry["response"] = self.redact(response.text)
            if not 200 <= response.status_code < 300:
                raise HttpFailure(response.status_code, f"{method} {url}: HTTP {response.status_code}; "
                                  "see sanitized HTTP evidence. No redirect or fallback attempted.")
            return response
        except requests.exceptions.Timeout as error:
            entry["error"] = {"type": type(error).__name__, "message": self.redact(str(error))}
            raise TimeoutError("HTTP request timed out; see HTTP evidence; no write replay attempted") from error
        except Exception as error:
            entry["error"] = {"type": type(error).__name__, "message": self.redact(str(error))}
            if response is not None:
                entry["httpStatus"] = response.status_code
            raise
        finally:
            entry["durationSeconds"] = round(time.monotonic() - started, 3)
            self.save_evidence("http", self.requests)

    def request(self, api, method, url, body=None, params=None):
        response = self.exchange(api, method, url, body, params)
        if not response.content.strip():
            raise InvalidResponse(f"HTTP {response.status_code} had an empty response, not a result")
        try:
            return response.json()
        except ValueError as error:
            raise InvalidResponse("Response was not valid JSON; inspect HTTP evidence") from error

    def mutate(self, api, path, body):
        response = self.exchange(api, "POST", path, body)
        if response.status_code != 202:
            return response.json()
        location = response.headers.get("Location")
        if not location:
            raise RuntimeError("Accepted operation has no Location; inspect resources before retrying")
        operation = api.operation_url(location)
        self.state.setdefault("operations", []).append(operation)
        self.save_evidence("operations", self.state["operations"])
        deadline = time.monotonic() + self.timeout
        while time.monotonic() < deadline:
            time.sleep(min(self.config.get("poll_seconds", 5), max(0, deadline - time.monotonic())))
            response = self.exchange(api, "GET", operation)
            current = response.json()
            status = current.get("status")
            if status == "Succeeded":
                result = response.headers.get("Location") or operation.rstrip("/") + "/result"
                return self.request(api, "GET", api.operation_url(result))
            if status not in ("NotStarted", "Running"):
                raise OperationFailed(operation, status, current.get("error"))
        raise TimeoutError(f"Operation still pending: {operation}; retained, not replayed")

    @contextmanager
    def workload(self, ontology_id=None):
        metadata = self.request(self.fabric, "GET",
                                f"{self.fabric.base}/workspaces/{self.config['workspace_id']}")
        args = SimpleNamespace(
            target_network=self.config["target_network"], workspace_id=self.config["workspace_id"],
            ux_metadata_api=self.config.get("ux_metadata_api"),
            ux_workload_host=self.config.get("ux_workload_host"),
            ux_token_version=self.config.get("ux_token_version", "v2"), timeout=self.timeout)
        with open_workload(args, self.credential, metadata, ontology_id or self.config["ontology_id"]) as api:
            # open_workload validates the service-returned host before using its in-memory MWC token.
            yield api

    def poll_conversation(self, api, path):
        previous = self._conversation_deadline
        self._conversation_deadline = time.monotonic() + self.conversation_timeout
        try:
            while True:
                self.remaining()
                current = self.request(api, "GET", path)
                self.remaining()
                status = str(current.get("status", "")).lower()
                if status in ("completed", "failed", "cancelled", "canceled", "idle", "requiresaction"):
                    return current
                time.sleep(min(self.config.get("poll_seconds", 5), self.remaining()))
        finally:
            self._conversation_deadline = previous
