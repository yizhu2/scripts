"""Daily Fabric public-API routing for the target ontology workspace."""

import re
from urllib.parse import urlsplit
from uuid import UUID

from create_sample import Api, https_url

DAILY_FABRIC_API = "https://dailyapi.fabric.microsoft.com/v1"


def target_fabric_api(network, workspace_id, tenant_id):
    workspace = UUID(workspace_id).hex
    tenant = str(UUID(tenant_id))
    if network == "public":
        return DAILY_FABRIC_API
    if network == "wspl":
        return f"https://{workspace}.z{workspace[:2]}.w.dailyapi.fabric.microsoft.com/v1"
    if network == "tenantpl":
        return f"https://{tenant}-api.analysis.windows.net/v1"
    raise ValueError("Target network must be public, wspl, or tenantpl")


class TargetApi(Api):
    def operation_url(self, location):
        # Fabric may advertise canonical LRO links. Keep their operation path on the selected route.
        parsed = urlsplit(https_url(location)) if location.startswith("https://") else None
        if (parsed and self.base != DAILY_FABRIC_API
                and parsed.netloc.lower() == "dailyapi.fabric.microsoft.com"
                and re.fullmatch(r"/v1/operations/[0-9a-fA-F-]{36}(?:/result)?", parsed.path)):
            UUID(parsed.path.split("/")[3])
            return self.base + parsed.path[len("/v1"):]
        return super().operation_url(location)
