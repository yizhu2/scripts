import base64
import copy
import json
import time
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

import create_ontology as ontology
import create_sample as sample


GUID = "11111111-1111-1111-1111-111111111111"


def inventory():
    return {
        "status": "succeeded", "tenantId": GUID, "capacityId": GUID, "workspaceId": GUID,
        "workspaceName": 'Workspace # "sample"',
        "endpoints": {"fabric": "https://dailyapi.fabric.microsoft.com/v1",
                      "powerbi": "https://wabi-daily-us-east2-redirect.analysis.windows.net",
                      "onelake": "https://daily-onelake.dfs.fabric.microsoft.com"},
        "items": {kind: {"id": GUID, "displayName": kind} for kind in (*ontology.GROUPS, "Eventhouse")},
        "verified": {kind: {"Plants": 3, "Assets": 12, "Readings": 120} for kind in ontology.GROUPS},
    }


def metadata():
    return {
        "Lakehouse": {"oneLakeTablesPath": f"https://daily-onelake.dfs.fabric.microsoft.com/{GUID}/{GUID}/Tables"},
        "MirroredDatabase": {"oneLakeTablesPath": f"https://daily-onelake.dfs.fabric.microsoft.com/{GUID}/{GUID}/Tables"},
        "SQLDatabase": {"serverFqdn": "test.daily-database.fabric.microsoft.com,1433", "databaseName": 'DB "quoted"'},
        "Warehouse": {"connectionString": "test.daily-datawarehouse.fabric.microsoft.com"},
        "SemanticModel": {},
        "KQLDatabase": {"queryServiceUri": "https://test.kusto.fabric.microsoft.com", "parentEventhouseItemId": GUID},
    }


class OntologyTests(unittest.TestCase):
    def definition(self):
        return ontology.build_definition(inventory(), metadata(), "powerbi://dailyapi.powerbi.com")

    def test_requires_all_seven_verified_source_types(self):
        ontology.validate_inventory(inventory())
        for change in ("status", "counts", "item"):
            state = inventory()
            if change == "status":
                state["status"] = "failed"
            elif change == "counts":
                state["verified"]["KQLDatabase"]["Readings"] = 119
            else:
                del state["items"]["Eventhouse"]
            with self.assertRaises((ValueError, KeyError)):
                ontology.validate_inventory(state)

    def test_separate_groups_keys_and_relationships(self):
        model = self.definition()["model"]
        self.assertEqual(len(model["tables"]), 18)
        self.assertEqual(len(model["entities"]), 18)
        self.assertEqual(len(model["relationships"]), 12)
        self.assertEqual(len(model["entityRelationships"]), 12)
        tables = {t["name"]: t for t in model["tables"]}
        self.assertEqual(len(tables), 18)
        for entity in model["entities"]:
            table = tables[entity["backingTable"]]
            self.assertEqual(entity["keyProperties"], [table["columns"][0]["name"]])
            for prop in entity["properties"]:
                self.assertEqual(prop["backingConfiguration"]["valueColumn"],
                                 {"table": table["name"], "column": prop["name"]})
        for rel in model["relationships"]:
            self.assertEqual(rel["fromTable"].split("_")[0], rel["toTable"].split("_")[0])
            self.assertEqual((rel["fromCardinality"], rel["toCardinality"]), ("many", "one"))

    def test_deferred_semantic_data_requires_explicit_caller_support_and_manifest_marker(self):
        state = inventory()
        del state["verified"]["SemanticModel"]
        with self.assertRaisesRegex(ValueError, "SemanticModel"):
            ontology.validate_inventory(state, allow_deferred_semantic=True)
        state["deferredValidation"] = {"SemanticModel": ["refresh", "sampleRows"]}
        with self.assertRaisesRegex(ValueError, "SemanticModel"):
            ontology.validate_inventory(state)
        ontology.validate_inventory(state, allow_deferred_semantic=True)
        for change in ("failed", "missing_source", "other_unverified", "wrong_semantic_counts"):
            invalid = copy.deepcopy(state)
            if change == "failed":
                invalid["status"] = "failed"
            elif change == "missing_source":
                del invalid["items"]["SemanticModel"]
            elif change == "other_unverified":
                del invalid["verified"]["KQLDatabase"]
            else:
                invalid["verified"]["SemanticModel"] = {"Plants": 0}
            with self.subTest(change=change), self.assertRaises((ValueError, KeyError)):
                ontology.validate_inventory(invalid, allow_deferred_semantic=True)

    def test_binding_shapes_and_endpoint_names(self):
        model = self.definition()["model"]
        expressions = {e["name"]: e["expression"] for e in model["expressions"]}
        self.assertIn("Workspace%20%23%20%22sample%22", expressions["SemanticModel_Source"])
        self.assertIn(f'"{GUID}"', expressions["SemanticModel_Source"])
        self.assertIn('DB ""quoted""', expressions["SQLDatabase_Source"])
        self.assertEqual(len(expressions), 5)
        for table in model["tables"]:
            group = table["name"].split("_")[0]
            partition = table["partitions"][0]
            if group in ("Lakehouse", "MirroredDatabase"):
                self.assertEqual(partition["mode"], "directLake")
                self.assertIn("AzureStorage.DataLake", expressions[f"{group}_Source"])
            else:
                self.assertEqual(partition["mode"], "directQuery")
            if group == "EventhouseKQL":
                self.assertIn("AzureDataExplorer.Contents", partition["source"]["expression"])
                self.assertIn(GUID, partition["source"]["expression"])
            else:
                self.assertEqual(partition["source"]["type"], "entity")
        self.assertFalse(any(t["name"].startswith("Eventhouse_") for t in model["tables"]))

    def test_readback_verifies_bindings_not_only_counts(self):
        expected = self.definition()
        actual = copy.deepcopy(expected)
        actual["model"]["tables"].reverse()
        actual["model"]["tables"][0]["lineageTag"] = GUID
        ontology.verify_definition(expected, actual)
        actual["model"]["tables"][0]["partitions"][0]["source"]["expression"] = "wrong source"
        with self.assertRaises(ValueError):
            ontology.verify_definition(expected, actual)

    def test_every_partition_pins_ux_source_identity_not_destination_identity(self):
        state = inventory()
        for index, kind in enumerate(ontology.GROUPS, start=1):
            state["items"][kind]["id"] = f"22222222-2222-4222-8222-{index:012d}"
        definition = ontology.build_definition(state, metadata(), "powerbi://dailyapi.powerbi.com")
        for table in definition["model"]["tables"]:
            group = table["name"].split("_")[0]
            kind = "KQLDatabase" if group == "EventhouseKQL" else group
            partition = table["partitions"][0]
            annotations = {entry["name"]: entry["value"] for entry in partition["annotations"]}
            with self.subTest(table=table["name"]):
                self.assertEqual(annotations["ONT_WorkspaceId"], state["workspaceId"])
                self.assertEqual(annotations["ONT_ItemId"], state["items"][kind]["id"])
                self.assertEqual(annotations["ONT_ItemKind"], "Dataset" if kind == "SemanticModel" else kind)
                self.assertEqual(annotations["ONT_ItemName"], state["items"][kind]["displayName"])
                self.assertEqual(annotations["ONT_WorkspaceName"], state["workspaceName"])
                self.assertFalse(any(name.startswith("ONT_RESOLVED_") for name in annotations))
                if kind == "SQLDatabase":
                    self.assertEqual(annotations["ONT_SqlEndpoint"], metadata()[kind]["serverFqdn"])
                    self.assertEqual(annotations["ONT_SqlDatabase"], metadata()[kind]["databaseName"])
                elif kind == "Warehouse":
                    self.assertEqual(annotations["ONT_SqlEndpoint"], metadata()[kind]["connectionString"])
                    self.assertEqual(annotations["ONT_SqlDatabase"], state["items"][kind]["displayName"])

    def test_readback_requires_pinned_identity_but_allows_response_only_annotations(self):
        expected = self.definition()
        for table_index, table in enumerate(expected["model"]["tables"]):
            for index, annotation in enumerate(table["partitions"][0]["annotations"]):
                for corrupt in ("missing", "wrong", "duplicate"):
                    actual = copy.deepcopy(expected)
                    found = actual["model"]["tables"][table_index]["partitions"][0]["annotations"]
                    if corrupt == "missing":
                        found.pop(index)
                    elif corrupt == "wrong":
                        found[index]["value"] = "incorrect"
                    else:
                        found.append(copy.deepcopy(annotation))
                    with self.subTest(table=table["name"], annotation=annotation["name"], corrupt=corrupt):
                        with self.assertRaises(ValueError):
                            ontology.verify_definition(expected, actual)
        actual = copy.deepcopy(expected)
        for table in actual["model"]["tables"]:
            table["partitions"][0]["annotations"].append({"name": "ONT_RESOLVED_State", "value": "Resolved"})
        ontology.verify_definition(expected, actual)

    def test_missing_relationship_or_wrong_key_fails_readback(self):
        for collection in ("relationships", "entities", "expressions"):
            expected = self.definition()
            actual = copy.deepcopy(expected)
            actual["model"][collection].pop()
            with self.assertRaises(ValueError):
                ontology.verify_definition(expected, actual)

    def test_extension_is_create_only_and_does_not_reauthor_existing_objects(self):
        existing = {"model": {"tables": [{"name": "test"}], "namespaces": [{"name": "default"}]}}
        before = copy.deepcopy(existing)
        script = ontology.build_extension_script(self.definition(), existing)
        self.assertEqual(existing, before)
        operations = script["sequence"]["operations"]
        self.assertEqual(len(operations), 35)
        self.assertTrue(all(set(operation) == {"create"} for operation in operations))
        self.assertTrue(all(next(iter(operation["create"].values()))["name"] != "test" for operation in operations))
        self.assertEqual(set(operations[0]["create"]), {"expression"})
        self.assertEqual(set(operations[5]["create"]), {"table"})
        self.assertEqual(set(operations[-1]["create"]), {"relationship"})

    def test_extension_refuses_authored_or_projected_name_collisions(self):
        for collection in ("tables", "expressions", "relationships", "entities", "entityRelationships"):
            existing = {"model": {"namespaces": [{"name": "default"}],
                                  collection: [self.definition()["model"][collection][0]]}}
            with self.assertRaisesRegex(ValueError, "Refusing to replace"):
                ontology.build_extension_script(self.definition(), existing)

    def test_extension_verification_allows_new_root_objects_but_preserves_nested_content(self):
        expected = self.definition()
        actual = copy.deepcopy(expected)
        actual["model"]["tables"].append({"name": "test"})
        ontology.verify_definition(expected, actual, allow_extra_named=True)
        actual["model"]["tables"][0]["columns"][0]["sourceColumn"] = "Changed"
        with self.assertRaises(ValueError):
            ontology.verify_definition(expected, actual, allow_extra_named=True)

    def test_atomic_script_result_checks_operation_targets(self):
        script = ontology.build_extension_script(self.definition(), {"model": {"namespaces": [{"name": "default"}]}})
        result = {"results": [
            {"opIndex": i, "verb": "create", "target": {kind: entry["name"]}}
            for i, operation in enumerate(script["sequence"]["operations"])
            for kind, entry in operation["create"].items()
        ]}
        ontology.verify_script_result(script, result)
        result["results"][-1]["target"] = {"table": "test"}
        with self.assertRaises(ValueError):
            ontology.verify_script_result(script, result)

    def test_preservation_ignores_only_the_server_resolution_timestamp(self):
        before = self.definition()
        before["model"]["tables"][0]["partitions"][0]["annotations"] = [
            {"name": "ONT_RESOLVED_At", "value": "earlier"}, {"name": "UserNote", "value": "preserve"}
        ]
        after = copy.deepcopy(before)
        after["model"]["tables"][0]["partitions"][0]["annotations"][0]["value"] = "later"
        ontology.verify_existing_content(before, after)
        self.assertEqual(before["model"]["tables"][0]["partitions"][0]["annotations"][0]["value"], "earlier")
        after["model"]["tables"][0]["partitions"][0]["annotations"][1]["value"] = "changed"
        with self.assertRaises(ValueError):
            ontology.verify_existing_content(before, after)

    def test_mwc_token_is_cached_and_host_change_is_rejected(self):
        pbi = Mock(base="https://ssp.example")
        pbi.json.return_value = {"token": "test-token", "TargetUriHost": "target.example"}
        credential = ontology.MwcCredential(pbi, inventory(), GUID)
        self.assertEqual(credential.get_token("").token, "test-token")
        self.assertEqual(pbi.json.call_count, 1)
        credential.expires = 0
        pbi.json.return_value = {"token": "second-token", "TargetUriHost": "other.example"}
        with self.assertRaisesRegex(RuntimeError, "routing host changed"):
            credential.get_token("")

    def test_daily_pascal_case_token_response(self):
        pbi = Mock(base="https://ssp.example")
        pbi.json.return_value = {"Token": "test-token", "TargetUriHost": "target.example", "Expiration": None}
        self.assertEqual(ontology.MwcCredential(pbi, inventory(), GUID).get_token("").token, "test-token")

    def test_v1_uses_artifact_ids_and_the_same_contract_on_refresh(self):
        pbi = Mock(base="https://ssp.example")
        pbi.json.return_value = {"Token": "test-token", "TargetUriHost": "target.example"}
        credential = ontology.MwcCredential(pbi, inventory(), GUID, token_version="v1")
        expected = ("POST", "https://ssp.example/metadata/v201606/generatemwctoken", {
            "capacityObjectId": GUID, "workspaceObjectId": GUID,
            "workloadType": "DO", "artifactObjectIds": [GUID],
        })
        self.assertEqual(pbi.json.call_args.args, expected)
        credential.expires = 0
        credential.get_token("")
        self.assertEqual(pbi.json.call_args.args, expected)
        self.assertEqual(pbi.json.call_count, 2)

    def test_token_version_validation_and_denial_never_try_another_version(self):
        pbi = Mock(base="https://ssp.example")
        with self.assertRaises(ValueError):
            ontology.MwcCredential(pbi, inventory(), GUID, token_version="v3")
        pbi.json.assert_not_called()
        pbi.json.side_effect = RuntimeError("HTTP 403")
        with self.assertRaisesRegex(RuntimeError, "403"):
            ontology.MwcCredential(pbi, inventory(), GUID, token_version="v1")
        pbi.json.assert_called_once()
        self.assertTrue(pbi.json.call_args.args[1].endswith("/generatemwctoken"))

    def test_reuse_refuses_all_authored_definition_content(self):
        ontology.require_empty_definition({"model": {"namespaces": [{"name": "default"}], "tables": []}})
        for key in ("tables", "entities", "relationships", "expressions", "rules", "metrics", "annotations"):
            with self.assertRaises(ValueError):
                ontology.require_empty_definition({"model": {key: [{"name": "Existing"}]}})
        with self.assertRaises(ValueError):
            ontology.require_empty_definition({"model": {"namespaces": [{"name": "Custom"}]}})

    def test_api_authorization_scheme_does_not_change_existing_default(self):
        for scheme in ("Bearer", "MwcToken"):
            with patch("requests.Session") as session:
                session.return_value.request.return_value = SimpleNamespace(status_code=200)
                credential = Mock()
                credential.get_token.return_value = SimpleNamespace(token="test-token")
                api = sample.Api("https://test.example", "", credential, 60, auth_scheme=scheme)
                api.request("GET", "https://test.example/item")
                kwargs = session.return_value.request.call_args.kwargs
                self.assertEqual(kwargs["headers"]["Authorization"], f"{scheme} test-token")
                self.assertFalse(kwargs["allow_redirects"])
                api.request("GET", "https://test.example/item", params={"expand": "true"}, request_timeout=120)
                self.assertEqual(session.return_value.request.call_args.kwargs["params"], {"expand": "true"})
                self.assertEqual(session.return_value.request.call_args.kwargs["timeout"], 120)
                api.close()

    def token_header(self, **overrides):
        claims = {"tid": GUID, "oid": GUID, "aud": ontology.PBI_SCOPE.removesuffix("/.default"),
                  "scp": "Dataset.Read.All", "exp": int(time.time()) + 3600}
        claims.update(overrides)
        payload = base64.urlsafe_b64encode(json.dumps(claims).encode()).decode().rstrip("=")
        return f"Bearer header.{payload}.signature"

    def test_powerbi_powershell_credential_checks_scope_and_lifetime(self):
        credential = ontology.PowerBIPowerShellCredential(self.token_header(), GUID)
        self.assertTrue(credential.get_token(sample.PBI_SCOPE).token.startswith("header."))
        with self.assertRaisesRegex(ValueError, "another resource"):
            credential.get_token(sample.STORAGE_SCOPE)
        with patch("create_ontology.time.time", return_value=credential.access_token.expires_on - 30):
            with self.assertRaisesRegex(RuntimeError, "expire"):
                credential.get_token(sample.PBI_SCOPE)

    def test_powerbi_powershell_credential_rejects_wrong_claims(self):
        for override in (
            {"tid": "other"}, {"aud": "other"}, {"scp": "user_impersonation"},
            {"exp": "tomorrow"}, {"exp": True}, {"exp": 0}, {"oid": None},
        ):
            with self.subTest(override=override):
                with self.assertRaises((ValueError, RuntimeError)):
                    ontology.PowerBIPowerShellCredential(self.token_header(**override), GUID)

    def test_powerbi_powershell_credential_rejects_malformed_tokens_without_echoing_them(self):
        for header in ("sensitive-token", "Bearer secret", "Bearer a.%%%%.s", "Bearer a.W10.s"):
            with self.subTest(header=header):
                with self.assertRaises(ValueError) as error:
                    ontology.PowerBIPowerShellCredential(header, GUID)
                self.assertNotIn(header, str(error.exception))

    def test_fabric_and_powerbi_clients_must_use_the_same_identity(self):
        token = self.token_header().removeprefix("Bearer ")
        ontology.require_same_user(token, GUID, GUID)
        for overrides in ({"tid": "other"}, {"oid": "other"}, {"oid": None}):
            with self.subTest(overrides=overrides):
                with self.assertRaisesRegex(ValueError, "same tenant and user"):
                    ontology.require_same_user(self.token_header(**overrides).removeprefix("Bearer "), GUID, GUID)

    def test_build_probe_verifies_arrow_result_not_just_http_success(self):
        import pyarrow as pa

        for result, column in ((1, "[Result]"), (2, "[Result]"), (1, "WrongColumn")):
            table = pa.table({column: [result]})
            stream = pa.BufferOutputStream()
            with pa.ipc.new_stream(stream, table.schema) as writer:
                writer.write_table(table)
            response = SimpleNamespace(content=stream.getvalue().to_pybytes())
            if (result, column) == (1, "[Result]"):
                self.assertEqual(ontology.verify_build_probe(response), {"result": 1})
            else:
                with self.assertRaises(ValueError):
                    ontology.verify_build_probe(response)


if __name__ == "__main__":
    unittest.main()
